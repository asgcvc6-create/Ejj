//! A program's preprocessed GLSL (any version from 110 to 460, compatibility or core) turned
//! into the Vulkan-flavoured GLSL 450 naga reads, then into validated naga modules (spec 1.6,
//! 2.2). The rewrite works on preprocessing tokens and never adds or removes a line of the pack's
//! code, so naga's line numbers map back through the preprocessor to the pack's files.
//!
//! What it does:
//! - Loose uniforms go into one uniform block shared by both stages (`bool` stored as `int`).
//! - Each sampler is split into a texture and a sampler object, combined again where it is used
//!   (`sampler2D(t, s)`), or passed as two arguments to the pack's own functions.
//! - The compatibility built-ins (`gl_Vertex`, `gl_MultiTexCoordN`, `gl_*Matrix`, `ftransform()`,
//!   `gl_FragData`, `gl_FragColor`, `gl_TexCoord`, `texture2D`...) become declarations of ours,
//!   named with the reserved prefix `hz_`; varyings get locations by name across the stages.
//! - The pack's `main` becomes `hz_main`, called by a `main` of ours that sets the inputs and
//!   adapts GL's conventions (spec 5.5): clip y is negated for every target but the window, so
//!   memory rows are GL's rows and `gl_FragCoord` needs no change, and clip z goes from GL's
//!   [-w, w] to [0, w], so stored depth is GL's window depth.
//!
//! Composite-style programs draw one quad from (0,0) to (1,1) with an identity model-view and an
//! orthographic projection onto it, the texture coordinate equal to the position (OQ-6).

use std::collections::BTreeMap;
use std::fmt::Write;

use naga::ShaderStage;
use naga::front::glsl::{Frontend, Options};
use naga::valid::{Capabilities, ValidationFlags, Validator};

use crate::Preprocessed;

mod anonymous_structs;
mod array_constructors;
mod atomic_vectors;
mod buffer_bools;
mod defaults;
mod geometry;
mod image_parameters;
mod integer_bounds;
mod interface_blocks;
mod ordering;
mod rewrite;
mod scan;

pub use geometry::{GeometryInputs, translate_geometry};

use scan::Stage;

/// What a program's stages need from the game.
#[derive(Debug, Default, PartialEq)]
pub struct Interface {
    /// The uniform block at binding 0: its size and each value's name, GLSL type and offset.
    /// Ours come first: `hz_target` (the target's width, height, 1/width, 1/height), and the
    /// fixed-function fog the compatibility `gl_Fog` reads (OQ-28): `hz_fog_color` (vanilla's fog
    /// colour) and `hz_fog` (density, start, end, 1 / (end - start)), then `hz_depth_linear`:
    /// 1 where `shadowtex0`, `shadowtex1`, `shadow` and `watershadow` (x to w) read through a
    /// plain sampler filter linearly, 0 where they take the nearest texel.
    pub uniform_size: u32,
    pub uniforms: Vec<Uniform>,
    /// std140 initial contents; runtime values overwrite their members each frame.
    pub initial_values: Vec<u8>,
    /// Each sampler: texture at `binding`, sampler object at `binding + 1`.
    pub samplers: Vec<Sampler>,
    /// The fragment stage's output locations.
    pub outputs: Vec<u32>,
    /// A gbuffers program reads `DRAW_UNIFORMS`: the block at set 2, binding 0, set per draw.
    pub draw: bool,
    /// Storage images (`colorimg4`...), after the samplers.
    pub images: Vec<Image>,
    /// The SSBOs' bindings in set 4 (`bufferObject.<n>`).
    pub buffers: Vec<u32>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Image {
    pub name: String,
    /// `image2D`, `uimage3D`...
    pub ty: String,
    /// The format qualifier (`rgba16f`).
    pub format: String,
    /// `readonly`, `writeonly`, empty for both, or `atomic` for an image an atomic function
    /// uses.
    pub access: String,
    pub binding: u32,
    /// A compute program's copy of image `before` as it was before the dispatch, which its
    /// loads read (see `ordering`).
    pub before: Option<String>,
}

/// A compute program (`deferred4_a.csh`): its module, what it reads and writes, and how many
/// work groups it runs: `workGroups`, or `workGroupsRender` times the target's size over the
/// local size (1, 1 when neither is set).
pub struct ComputeProgram {
    pub module: naga::Module,
    pub interface: Interface,
    /// Non-fatal translation diagnostics, located in the authored source.
    pub notes: Vec<Error>,
    pub work_groups: Option<[u32; 3]>,
    pub work_groups_render: [f32; 2],
}

/// The uniforms a gbuffers program reads per draw (5.3's "D"), in a block of their own
/// (`HzDraw`, std140: four ints, a vec4; 32 bytes) the game sets for each draw.
pub const DRAW_UNIFORMS: [(&str, &str); 5] = [
    ("renderStage", "int"),
    ("entityId", "int"),
    ("blockEntityId", "int"),
    ("currentRenderedItemId", "int"),
    ("entityColor", "vec4"),
];

#[derive(Clone, Debug, PartialEq)]
pub struct Uniform {
    pub name: String,
    /// The type the pack declared (`float`, `ivec2`, `mat4`; `bool` is stored as an `int`).
    pub ty: String,
    pub offset: u32,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Sampler {
    pub name: String,
    /// The type the pack declared: `sampler2D`, `sampler2DShadow`, `usampler2D`, `sampler3D`...
    pub ty: String,
    pub binding: u32,
}

/// A translation diagnostic at a pack file and line.
#[derive(Clone, Debug, PartialEq)]
pub struct Error {
    pub file: String,
    pub line: u32,
    pub message: String,
}

pub struct Program {
    pub vertex: naga::Module,
    pub fragment: naga::Module,
    pub interface: Interface,
    /// Non-fatal translation diagnostics, located in the authored source.
    pub notes: Vec<Error>,
}

/// Where the program draws, which decides the conventions of 5.5.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Target {
    /// Pack buffers: rows stored as GL stores them.
    Buffers,
    /// The window (`final`).
    Window,
}

/// What a gbuffers-style program's vertex stage reads. The game writes it: it knows its vertex
/// formats, the translator only places it.
#[derive(Clone, Debug, Default)]
pub struct GbuffersInputs {
    /// GLSL declarations: the vertex inputs and any bindings of set 1.
    pub declarations: String,
    /// GLSL statements that set `hz_Vertex`, `hz_Color`, `hz_MultiTexCoord0`,
    /// `hz_MultiTexCoord1` and `hz_Normal` (the compatibility inputs), run first in `main`.
    pub body: String,
    /// The value of each attribute a pack may declare (`mc_Entity`, `vaPosition`...), as a GLSL
    /// expression of the declared type's size; an attribute not listed reads zero. Terrain
    /// also supplies `mc_chunkFade`, an implicit float input rather than a declared attribute.
    pub attributes: Vec<(String, String)>,
    /// GLSL statements run last in `main`, with `gl_Position` in wgpu's clip space.
    pub after: String,
    /// The alpha test applied to output 0 (`gl_FragData[0]`, `gl_FragColor`), the loader's
    /// (3.2 `alphaTest.<program>`): `None` keeps every fragment.
    pub alpha_test: Option<AlphaTest>,
    /// The program may read `currentRenderedItemId` without declaring it, as Iris 1.11.7
    /// lets the hand's (observed with probe packs; terrain's may not).
    pub item_id_declared: bool,
    /// The depth test sees the far plane (window depth 1) unless the program writes
    /// `gl_FragDepth`, while `gl_FragCoord.z` stays the geometry's own: the sky shows only where
    /// nothing else drew, and reads its own depth as in Iris 1.11.7.
    pub far_depth: bool,
}

/// A fragment stays when its output 0's alpha compares to `reference` as `op` says (a GLSL
/// comparison operator, `true` for GL's `ALWAYS`, `false` for `NEVER`).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AlphaTest {
    pub op: &'static str,
    pub reference: f32,
}

impl AlphaTest {
    /// `alphaTest.<program>`'s value: `off`, or a GL comparison and a reference.
    pub fn parse(value: &str) -> Option<Option<Self>> {
        let mut words = value.split_whitespace();
        let func = words.next()?;
        if func == "off" {
            return Some(None);
        }
        let op = match func.trim_start_matches("GL_") {
            "NEVER" => "false",
            "LESS" => "<",
            "EQUAL" => "==",
            "LEQUAL" => "<=",
            "GREATER" => ">",
            "NOTEQUAL" => "!=",
            "GEQUAL" => ">=",
            "ALWAYS" => return Some(None),
            _ => return None,
        };
        let reference = words.next()?.parse().ok()?;
        Some(Some(Self { op, reference }))
    }
}

/// Translates a composite-style program (`composite`, `deferred`, `final`...).
pub fn translate_composite(
    vertex: &Preprocessed,
    fragment: &Preprocessed,
    target: Target,
) -> Result<Program, Vec<Error>> {
    translate(vertex, fragment, target, None, false)
}

/// Translates a gbuffers-style program (`gbuffers_terrain`...) drawing the game's geometry
/// described by `inputs`, into `target` (the pack's buffers).
pub fn translate_gbuffers(
    vertex: &Preprocessed,
    fragment: &Preprocessed,
    target: Target,
    inputs: &GbuffersInputs,
) -> Result<Program, Vec<Error>> {
    translate(vertex, fragment, target, Some(inputs), false)
}

/// Translates a shadow program (`shadow`, `shadow_water`...) drawing the game's geometry
/// described by `inputs` from the shadow light: its model-view and projection matrices are the
/// shadow camera's (5.2).
pub fn translate_shadow(
    vertex: &Preprocessed,
    fragment: &Preprocessed,
    inputs: &GbuffersInputs,
) -> Result<Program, Vec<Error>> {
    translate(vertex, fragment, Target::Buffers, Some(inputs), true)
}

/// The matrices of the compatibility profile in a gbuffers-style program, from the frame's.
const GBUFFERS_MATRICES: &str = "    hz_ModelViewMatrix = gbufferModelView;\n    \
     hz_ProjectionMatrix = gbufferProjection;\n    \
     hz_ModelViewProjectionMatrix = gbufferProjection * gbufferModelView;\n    \
     hz_ModelViewMatrixInverse = gbufferModelViewInverse;\n    \
     hz_ProjectionMatrixInverse = gbufferProjectionInverse;\n    \
     hz_NormalMatrix = mat3(gbufferModelView);\n    \
     mat4 hz_light = mat4(vec4(1.0 / 256.0, 0.0, 0.0, 0.0), vec4(0.0, 1.0 / 256.0, 0.0, 0.0), vec4(0.0, 0.0, 1.0, 0.0), vec4(1.0 / 32.0, 1.0 / 32.0, 0.0, 1.0));\n    \
     hz_TextureMatrix = mat4[8](mat4(1.0), hz_light, hz_light, mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0));\n";

/// Whether `code` names `name` (a whole identifier).
fn uses_name(code: &str, name: &str) -> bool {
    let ident = |c: char| c.is_ascii_alphanumeric() || c == '_';
    code.match_indices(name)
        .any(|(at, _)| !code[..at].ends_with(ident) && !code[at + name.len()..].starts_with(ident))
}

fn translate(
    vertex: &Preprocessed,
    fragment: &Preprocessed,
    target: Target,
    gbuffers: Option<&GbuffersInputs>,
    shadow: bool,
) -> Result<Program, Vec<Error>> {
    let matrices = if shadow {
        GBUFFERS_MATRICES.replace("gbuffer", "shadow")
    } else {
        GBUFFERS_MATRICES.to_owned()
    };
    // Struct types without a name get one (`anonymous_structs`), interface blocks travel
    // as plain varyings (`interface_blocks`), and buffer vectors that atomic functions use by
    // component become arrays (`atomic_vectors`).
    let flat = |pp: &Preprocessed| {
        let named = anonymous_structs::name(&pp.code);
        let code = named.as_deref().unwrap_or(&pp.code);
        let flat = interface_blocks::flatten(code)
            .or(named)
            .map(|code| Preprocessed { code, ..pp.clone() });
        let split = atomic_vectors::rewrite(flat.as_ref().unwrap_or(pp));
        split.or(flat)
    };
    let (vertex_flat, fragment_flat) = (flat(vertex), flat(fragment));
    let vertex = vertex_flat.as_ref().unwrap_or(vertex);
    let fragment = fragment_flat.as_ref().unwrap_or(fragment);
    // A `bool` member of a storage buffer travels as a `uint` (`buffer_bools`).
    let ((vertex_bools, vertex_bool_errors), (fragment_bools, fragment_bool_errors)) = (
        buffer_bools::rewrite(vertex),
        buffer_bools::rewrite(fragment),
    );
    let vertex = vertex_bools.as_ref().unwrap_or(vertex);
    let fragment = fragment_bools.as_ref().unwrap_or(fragment);
    let mut v = Stage::scan(vertex, ShaderStage::Vertex);
    let mut f = Stage::scan(fragment, ShaderStage::Fragment);
    v.gbuffers = gbuffers.is_some();
    f.gbuffers = gbuffers.is_some();
    let mut errors: Vec<Error> = v
        .errors
        .drain(..)
        .chain(f.errors.drain(..))
        .chain(vertex_bool_errors)
        .chain(fragment_bool_errors)
        .collect();

    // One uniform block and one set of samplers for both stages.
    let mut uniforms: BTreeMap<String, String> = BTreeMap::new();
    if gbuffers.is_some() {
        for name in [
            "gbufferModelView",
            "gbufferModelViewInverse",
            "gbufferProjection",
            "gbufferProjectionInverse",
        ] {
            uniforms.insert(name.to_owned(), "mat4".to_owned());
            if shadow {
                uniforms.insert(name.replace("gbuffer", "shadow"), "mat4".to_owned());
            }
        }
    }
    let mut samplers: BTreeMap<String, String> = BTreeMap::new();
    for stage in [&v, &f] {
        for (name, ty, at) in &stage.uniforms {
            if let Some(old) = uniforms.insert(name.clone(), ty.clone())
                && &old != ty
            {
                errors.push(stage.error(
                    *at,
                    &format!("`{name}` is `{old}` in one stage and `{ty}` in the other"),
                ));
            }
        }
        for (name, ty) in &stage.samplers {
            samplers.insert(name.clone(), ty.clone());
        }
    }
    if gbuffers.is_some() {
        // The references use the geometry transform state instead of a second frame slot.
        for name in ["projectionMatrix", "modelViewMatrix"] {
            if uniforms.get(name).is_some_and(|ty| ty == "mat4") {
                uniforms.remove(name);
            }
        }
        // A compatibility-profile stage keeps reading the frame's `normalMatrix`.
        let normal = "normalMatrix";
        if uniforms.get(normal).is_some_and(|ty| ty == "mat3")
            && [&v, &f].into_iter().all(|stage| {
                stage.core_matrix(normal).is_some()
                    || !stage.uniforms.iter().any(|(name, ..)| name == normal)
            })
        {
            uniforms.remove(normal);
        }
        // The fragment stage's own `textureMatrix` keeps its frame slot (it reads zero).
        if !f.uniforms.iter().any(|(n, _, _)| n == "textureMatrix")
            && uniforms.get("textureMatrix").is_some_and(|ty| ty == "mat4")
        {
            uniforms.remove("textureMatrix");
        }
    }
    // `alphaTestRef` is the program's alpha test reference: a constant of the program.
    let alpha_test_ref = gbuffers
        .filter(|_| uniforms.get("alphaTestRef").is_some_and(|t| t == "float"))
        .map(|g| g.alpha_test.map_or(0.0, |t| t.reference));
    if alpha_test_ref.is_some() {
        uniforms.remove("alphaTestRef");
    }
    // Per-draw values move to their own block; another type than the documented one keeps
    // the frame's block (and reads zero).
    let mut draw = false;
    if gbuffers.is_some() {
        for (name, ty) in DRAW_UNIFORMS {
            if uniforms.get(name).is_some_and(|t| t == ty) {
                uniforms.remove(name);
                draw = true;
            }
        }
        // Where Iris declares `currentRenderedItemId` itself, a program may read it undeclared;
        // `HzDraw` declares it.
        let item = "currentRenderedItemId";
        draw |= gbuffers.is_some_and(|g| g.item_id_declared)
            && !uniforms.contains_key(item)
            && [vertex, fragment]
                .iter()
                .any(|pp| uses_name(&pp.code, item));
    }
    let samplers: Vec<Sampler> = samplers
        .into_iter()
        .enumerate()
        .map(|(i, (name, ty))| Sampler {
            name,
            ty,
            binding: 1 + 2 * i as u32,
        })
        .collect();
    let images = bind_images([&v, &f], samplers.len());

    // Varyings by name: the vertex outputs, then fragment inputs the vertex stage lacks. A
    // matrix or array travels as one varying per column or element (`varying_parts`), a
    // struct as its members packed into vectors (`struct_parts`).
    let mut locations: BTreeMap<String, (u32, String)> = BTreeMap::new();
    let mut split: BTreeMap<String, (String, Vec<(String, String)>)> = BTreeMap::new();
    let vars = v.outs.iter().map(|o| (&v, o));
    for (stage, var) in vars.chain(f.ins.iter().map(|i| (&f, i))) {
        if locations.contains_key(&var.name) || split.contains_key(&var.name) {
            continue;
        }
        if var.structure {
            match struct_parts(&var.decl, &stage.structs) {
                Some(parts) => {
                    let mut copies = Vec::new();
                    for (k, (decl, members)) in parts.into_iter().enumerate() {
                        let part = format!("hz_v_{}_{k}", var.name);
                        let next = locations.len() as u32;
                        locations.insert(part.clone(), (next, decl));
                        for (swizzle, access) in members {
                            copies.push((format!("{part}{swizzle}"), access));
                        }
                    }
                    split.insert(var.name.clone(), (String::new(), copies));
                }
                None => errors.push(Error {
                    file: stage.pp.files.first().cloned().unwrap_or_default(),
                    line: 0,
                    message: format!("`{}`: this struct can't be a varying", var.name),
                }),
            }
            continue;
        }
        match varying_parts(&var.decl) {
            Some((global, parts)) => {
                let mut copies = Vec::new();
                for (k, (decl, access)) in parts.into_iter().enumerate() {
                    let part = format!("hz_v_{}_{k}", var.name);
                    let next = locations.len() as u32;
                    locations.insert(part.clone(), (next, decl));
                    copies.push((part, access));
                }
                split.insert(var.name.clone(), (global, copies));
            }
            None => {
                let next = locations.len() as u32;
                locations.insert(var.name.clone(), (next, var.decl.clone()));
            }
        }
    }

    // Terrain's fade input is supplied without a pack declaration. Inject it only when
    // the renderer provides the actual value; other geometry and authored globals keep
    // their existing behavior.
    let chunk_fade = gbuffers
        .and_then(|g| g.attributes.iter().find(|(n, _)| n == "mc_chunkFade"))
        .filter(|_| uses_name(&vertex.code, "mc_chunkFade") && !v.globals.contains("mc_chunkFade"));
    let header = |stage: &Stage| {
        let mut h = resources(&uniforms, &samplers, &images);
        if let Some(reference) = alpha_test_ref {
            writeln!(h, "const float alphaTestRef = {reference:?};").unwrap();
        }
        if draw {
            h.push_str(
                "layout(set = 2, binding = 0) uniform HzDraw { int renderStage; int entityId; \
                 int blockEntityId; int currentRenderedItemId; vec4 entityColor; };\n",
            );
        }
        let direction = if stage.kind == ShaderStage::Vertex {
            "out"
        } else {
            "in"
        };
        for (name, (location, decl)) in &locations {
            writeln!(
                h,
                "layout(location = {location}) {direction} {}",
                decl.replace("@", name)
            )
            .unwrap();
        }
        for (name, (global, _)) in split.iter().filter(|(_, (g, _))| !g.is_empty()) {
            writeln!(h, "{}", global.replace("@", name)).unwrap();
        }
        if let (Some(inputs), ShaderStage::Vertex) = (gbuffers, stage.kind) {
            h.push_str(&inputs.declarations);
            h.push('\n');
            if chunk_fade.is_some() {
                h.push_str("float mc_chunkFade;\n");
            }
        }
        h.push_str(&stage.prelude());
        h
    };
    let flip = if target == Target::Buffers { "-" } else { "" };
    let fog =
        "    hz_Fog = hz_FogParameters(hz_fog_color, hz_fog.x, hz_fog.y, hz_fog.z, hz_fog.w);\n";
    let mut vertex_main = String::from("\nvoid main() {\n");
    match gbuffers {
        None => vertex_main.push_str(
            "    vec2 hz_p = hz_quad[gl_VertexIndex];\n    hz_Vertex = vec4(hz_p, 0.0, 1.0);\n    \
             hz_MultiTexCoord0 = hz_Vertex;\n    hz_Color = vec4(1.0);\n    hz_Normal = vec3(0.0, 0.0, 1.0);\n",
        ),
        Some(inputs) => {
            vertex_main.push_str(&matrices);
            vertex_main.push_str(&inputs.body);
        }
    }
    if let Some((_, value)) = chunk_fade {
        writeln!(vertex_main, "    mc_chunkFade = {value};").unwrap();
    }
    for (name, value, ty) in &v.attributes {
        let value = match gbuffers {
            // Our quad's values for a composite.
            None => value.clone(),
            // The game's, or zero for anything it doesn't provide.
            Some(inputs) => match inputs.attributes.iter().find(|a| &a.0 == name) {
                Some((_, given)) => format!("{ty}({given})"),
                None => format!("{ty}(0)"),
            },
        };
        writeln!(vertex_main, "    {name} = {value};").unwrap();
    }
    vertex_main.push_str(fog);
    for name in &v.inits {
        writeln!(vertex_main, "    {name} = hz_init_{name}();").unwrap();
    }
    vertex_main.push_str("    hz_main();\n");
    // A struct's own declaration is the pack's: only a stage that declares it copies it.
    let declared = |list: &[scan::Var], name: &str, global: &str| {
        !global.is_empty() || list.iter().any(|var| var.name == name)
    };
    for (name, (global, copies)) in &split {
        if !declared(&v.outs, name, global) {
            continue;
        }
        for (part, access) in copies {
            writeln!(vertex_main, "    {part} = {name}{access};").unwrap();
        }
    }
    write!(
        vertex_main,
        "    gl_Position = vec4(gl_Position.x, {flip}gl_Position.y, (gl_Position.z + gl_Position.w) * 0.5, gl_Position.w);\n{}}}\n",
        gbuffers.map_or("", |g| &g.after)
    )
    .unwrap();
    let mut fragment_main = String::from("\nvoid main() {\n");
    if gbuffers.is_some() {
        fragment_main.push_str(&matrices);
    }
    fragment_main.push_str(fog);
    if f.frag_coord {
        fragment_main.push_str(match target {
            Target::Window => "    hz_FragCoord = vec4(gl_FragCoord.x, hz_target.y - gl_FragCoord.y, gl_FragCoord.zw);\n",
            Target::Buffers => "    hz_FragCoord = gl_FragCoord;\n",
        });
    }
    for (name, (global, copies)) in &split {
        if !declared(&f.ins, name, global) {
            continue;
        }
        for (part, access) in copies {
            writeln!(fragment_main, "    {name}{access} = {part};").unwrap();
        }
    }
    for name in &f.inits {
        writeln!(fragment_main, "    {name} = hz_init_{name}();").unwrap();
    }
    if gbuffers.is_some_and(|g| g.far_depth) {
        fragment_main.push_str("    gl_FragDepth = 1.0;\n");
    }
    fragment_main.push_str("    hz_main();\n");
    for copy in &f.out_copies {
        writeln!(fragment_main, "    {copy}").unwrap();
    }
    // With `out` variables the pack tests alpha itself.
    if let Some(t) = gbuffers.and_then(|g| g.alpha_test)
        && f.outputs.contains(&0)
        && !f.frag_outs.iter().any(|(n, _)| *n == 0)
    {
        match t.op {
            "false" => fragment_main.push_str("    discard;\n"),
            op => writeln!(
                fragment_main,
                "    if (!(hz_out0.a {op} {:?})) {{ discard; }}",
                t.reference
            )
            .unwrap(),
        }
    }
    fragment_main.push_str("}\n");

    let v_text = format!(
        "{}{}{vertex_main}",
        header(&v),
        v.rewrite(&samplers, &uniforms)
    );
    let f_text = format!(
        "{}{}{fragment_main}",
        header(&f),
        f.rewrite(&samplers, &uniforms)
    );
    if !errors.is_empty() {
        return Err(errors);
    }
    let vertex_module = compile(&v, &v_text, header(&v).lines().count());
    let fragment_module = compile(&f, &f_text, header(&f).lines().count());
    let (vertex, fragment) = match (vertex_module, fragment_module) {
        (Ok(v), Ok(f)) => (v, f),
        (a, b) => return Err(a.err().into_iter().chain(b.err()).flatten().collect()),
    };
    let (initial_values, notes) = defaults::merge([(&v, &vertex), (&f, &fragment)])?;
    let (uniform_size, offsets) = block_layout(&fragment);
    let uniforms = offsets
        .into_iter()
        .filter_map(|(member, offset)| {
            let name = member
                .strip_prefix("hz_bool_")
                .unwrap_or(&member)
                .to_owned();
            let ty = if name.starts_with("hz_") {
                "vec4".to_owned()
            } else {
                uniforms.get(&name)?.clone()
            };
            Some(Uniform { name, ty, offset })
        })
        .collect();
    let outputs = f.outputs.iter().copied().collect();
    let mut images = images;
    mark_atomic(&vertex, &mut images);
    mark_atomic(&fragment, &mut images);
    Ok(Program {
        notes,
        interface: Interface {
            uniform_size,
            initial_values,
            uniforms,
            samplers,
            outputs,
            draw,
            images,
            buffers: v.buffers.union(&f.buffers).copied().collect(),
        },
        vertex,
        fragment,
    })
}

/// Images an atomic function uses (naga gave them atomic access) are bound for atomics.
fn mark_atomic(module: &naga::Module, images: &mut [Image]) {
    for (_, g) in module.global_variables.iter() {
        let naga::TypeInner::Image {
            class: naga::ImageClass::Storage { access, .. },
            ..
        } = module.types[g.ty].inner
        else {
            continue;
        };
        if let Some(b) = &g.binding
            && access.contains(naga::StorageAccess::ATOMIC)
            && let Some(i) = images.iter_mut().find(|i| i.binding == b.binding)
        {
            i.access = "atomic".into();
        }
    }
}

/// The images of `stages`, by name, bound after `samplers` samplers.
fn bind_images(stages: [&Stage; 2], samplers: usize) -> Vec<Image> {
    let mut images: BTreeMap<String, scan::ImageDecl> = BTreeMap::new();
    for stage in stages {
        for i in &stage.images {
            images.entry(i.name.clone()).or_insert_with(|| i.clone());
        }
    }
    images
        .into_values()
        .enumerate()
        .map(|(k, i)| Image {
            name: i.name,
            ty: i.ty,
            format: i.format,
            access: i.access,
            binding: 1 + 2 * samplers as u32 + k as u32,
            before: None,
        })
        .collect()
}

/// `#version 450`, the uniform block at binding 0, each sampler as a texture and a sampler
/// object, and the images.
fn resources(
    uniforms: &BTreeMap<String, String>,
    samplers: &[Sampler],
    images: &[Image],
) -> String {
    let mut h = String::from("#version 450\n");
    h.push_str("layout(set = 0, binding = 0) uniform HzUniforms { vec4 hz_target; vec4 hz_fog_color; vec4 hz_fog; vec4 hz_depth_linear;");
    for (name, ty) in uniforms {
        match ty.as_str() {
            "bool" => write!(h, " int hz_bool_{name};"),
            _ => match ty.split_once('[') {
                Some((base, size)) => write!(h, " {base} {name}[{size};"),
                None => write!(h, " {ty} {name};"),
            },
        }
        .unwrap();
    }
    h.push_str(" };\n");
    for s in samplers {
        let (texture, sampler) = split_sampler(&s.ty);
        writeln!(
            h,
            "layout(set = 0, binding = {}) uniform {texture} {}; layout(set = 0, binding = {}) uniform {sampler} hz_s_{};",
            s.binding, s.name, s.binding + 1, s.name
        )
        .unwrap();
    }
    for i in images {
        writeln!(
            h,
            "layout(set = 0, binding = {}, {}) uniform {} {} {};",
            i.binding, i.format, i.access, i.ty, i.name
        )
        .unwrap();
    }
    h
}

/// Translates a compute program (`.csh`).
pub fn translate_compute(compute: &Preprocessed) -> Result<ComputeProgram, Vec<Error>> {
    let named = anonymous_structs::name(&compute.code).map(|code| Preprocessed {
        code,
        ..compute.clone()
    });
    let compute = named.as_ref().unwrap_or(compute);
    let split = atomic_vectors::rewrite(compute);
    let compute = split.as_ref().unwrap_or(compute);
    let (bools, bool_errors) = buffer_bools::rewrite(compute);
    let compute = bools.as_ref().unwrap_or(compute);
    let mut c = Stage::scan(compute, ShaderStage::Compute);
    let mut errors = std::mem::take(&mut c.errors);
    errors.extend(bool_errors);
    let mut uniforms: BTreeMap<String, String> = BTreeMap::new();
    for (name, ty, _) in &c.uniforms {
        uniforms.insert(name.clone(), ty.clone());
    }
    let samplers: Vec<Sampler> = c
        .samplers
        .iter()
        .map(|(name, ty)| (name, ty))
        .collect::<BTreeMap<_, _>>()
        .into_iter()
        .enumerate()
        .map(|(i, (name, ty))| Sampler {
            name: name.clone(),
            ty: ty.clone(),
            binding: 1 + 2 * i as u32,
        })
        .collect();
    let mut images = bind_images([&c, &c], samplers.len());
    let code = c.rewrite(&samplers, &uniforms);
    let code = work_group_size(&code).unwrap_or_else(|message| {
        errors.push(Error {
            file: compute.files.first().cloned().unwrap_or_default(),
            line: 0,
            message,
        });
        code
    });
    let code = ordering::barriers_after_atomics(&code).unwrap_or(code);
    let declared: Vec<(String, bool)> = c
        .images
        .iter()
        .map(|i| (i.name.clone(), i.coherent))
        .collect();
    let before = ordering::snapshots(&code, &declared);
    let code = ordering::read_before(&code, &before);
    for name in before {
        let image = images.iter().find(|i| i.name == name).expect("declared");
        let copy = Image {
            name: ordering::before_name(&name),
            ty: image.ty.clone(),
            format: image.format.clone(),
            access: String::new(),
            binding: 1 + 2 * samplers.len() as u32 + images.len() as u32,
            before: Some(name),
        };
        images.push(copy);
    }
    let mut main = String::from("\nvoid main() {\n");
    main.push_str(
        "    hz_Fog = hz_FogParameters(hz_fog_color, hz_fog.x, hz_fog.y, hz_fog.z, hz_fog.w);\n",
    );
    for name in &c.inits {
        writeln!(main, "    {name} = hz_init_{name}();").unwrap();
    }
    main.push_str("    hz_main();\n}\n");
    let header = resources(&uniforms, &samplers, &images) + &c.prelude();
    let text = format!("{header}{code}{main}");
    // `workGroups` is an ivec3, `workGroupsRender` a vec2 (a third number, the depth of a 2D
    // render, is taken as 1); anything else is not understood rather than guessed.
    let mut sizes = |name: &str, counts: &[usize]| {
        let v = constant(&c, name)?;
        if !counts.contains(&v.len()) {
            errors.push(Error {
                file: compute.files.first().cloned().unwrap_or_default(),
                line: 0,
                message: format!("`{name}` must have {counts:?} numbers, not {}", v.len()),
            });
            return None;
        }
        Some(v)
    };
    let work_groups = sizes("workGroups", &[3]).map(|v| [v[0] as u32, v[1] as u32, v[2] as u32]);
    let work_groups_render =
        sizes("workGroupsRender", &[2, 3]).map_or([1.0, 1.0], |v| [v[0] as f32, v[1] as f32]);
    if !errors.is_empty() {
        return Err(errors);
    }
    let module = compile(&c, &text, header.lines().count()).map_err(|e| {
        errors.extend(e);
        std::mem::take(&mut errors)
    })?;
    let (uniform_size, offsets) = block_layout(&module);
    let (initial_values, notes) = defaults::merge([(&c, &module)])?;
    let mut interface = Interface {
        uniform_size,
        initial_values,
        uniforms: offsets
            .into_iter()
            .filter_map(|(member, offset)| {
                let name = member
                    .strip_prefix("hz_bool_")
                    .unwrap_or(&member)
                    .to_owned();
                let ty = if name.starts_with("hz_") {
                    "vec4".to_owned()
                } else {
                    uniforms.get(&name)?.clone()
                };
                Some(Uniform { name, ty, offset })
            })
            .collect(),
        samplers,
        outputs: Vec::new(),
        draw: false,
        images,
        buffers: c.buffers.iter().copied().collect(),
    };
    mark_atomic(&module, &mut interface.images);
    Ok(ComputeProgram {
        notes,
        module,
        interface,
        work_groups,
        work_groups_render,
    })
}

/// `code` with `gl_WorkGroupSize` written as the constant its `layout(local_size_*)` declares:
/// GLSL defines it so, and naga's HLSL writer has no such built-in.
fn work_group_size(code: &str) -> Result<String, String> {
    let mut tokens: Vec<String> = crate::macros::lex(code)
        .into_iter()
        .map(str::to_owned)
        .collect();
    let mut sizes = [1u32; 3];
    let axes = ["local_size_x", "local_size_y", "local_size_z"];
    let sig: Vec<usize> = (0..tokens.len())
        .filter(|&i| scan::significant(&tokens[i]))
        .collect();
    for (k, &at) in sig.iter().enumerate() {
        let Some(axis) = axes.iter().position(|a| tokens[at] == *a) else {
            continue;
        };
        if sig.get(k + 1).is_none_or(|&e| tokens[e] != "=") {
            continue;
        }
        // The size's expression runs to the `,` or `)` that ends the qualifier.
        let mut depth = 0usize;
        let expr: Vec<usize> = sig[k + 2..]
            .iter()
            .copied()
            .take_while(|&i| match tokens[i].as_str() {
                "(" => {
                    depth += 1;
                    true
                }
                ")" if depth > 0 => {
                    depth -= 1;
                    true
                }
                "," | ")" if depth == 0 => false,
                _ => true,
            })
            .collect();
        let words: Vec<&str> = expr.iter().map(|&i| tokens[i].as_str()).collect();
        let size = ConstantSize::eval(&words)
            .ok_or_else(|| format!("`{}` is not a size Horizon can work out", axes[axis]))?;
        sizes[axis] = size;
        // naga takes a number there: the expression becomes its value.
        if let (Some(&first), Some(&last)) = (expr.first(), expr.last()) {
            tokens[first] = size.to_string();
            for t in &mut tokens[first + 1..=last] {
                t.retain(|c| c == '\n');
            }
        }
    }
    let value = format!("uvec3({}u, {}u, {}u)", sizes[0], sizes[1], sizes[2]);
    for t in &mut tokens {
        if t == "gl_WorkGroupSize" {
            *t = value.clone();
        }
    }
    Ok(tokens.concat())
}

/// A work group size given as an integer constant expression (GLSL 4.60, 4.4 and 4.4.1):
/// numbers, `+ - * / %`, brackets, `min`, `max` and `gl_MaxComputeWorkGroupSize`, the minimum
/// GLSL requires (`ivec3(1024, 1024, 64)`, 7.3); the translation knows no device.
struct ConstantSize<'w> {
    words: &'w [&'w str],
    at: usize,
}

impl<'w> ConstantSize<'w> {
    fn eval(words: &'w [&'w str]) -> Option<u32> {
        let mut p = Self { words, at: 0 };
        let v = p.sum()?;
        (p.at == words.len())
            .then_some(v)
            .and_then(|v| u32::try_from(v).ok())
    }

    fn peek(&self) -> Option<&'w str> {
        self.words.get(self.at).copied()
    }

    fn eat(&mut self, word: &str) -> bool {
        let found = self.peek() == Some(word);
        self.at += usize::from(found);
        found
    }

    fn sum(&mut self) -> Option<i64> {
        let mut v = self.product()?;
        loop {
            if self.eat("+") {
                v = v.checked_add(self.product()?)?;
            } else if self.eat("-") {
                v = v.checked_sub(self.product()?)?;
            } else {
                return Some(v);
            }
        }
    }

    fn product(&mut self) -> Option<i64> {
        let mut v = self.unary()?;
        loop {
            if self.eat("*") {
                v = v.checked_mul(self.unary()?)?;
            } else if self.eat("/") {
                v = v.checked_div(self.unary()?)?;
            } else if self.eat("%") {
                v = v.checked_rem(self.unary()?)?;
            } else {
                return Some(v);
            }
        }
    }

    fn unary(&mut self) -> Option<i64> {
        if self.eat("-") {
            return self.unary()?.checked_neg();
        }
        if self.eat("+") {
            return self.unary();
        }
        if self.eat("(") {
            let v = self.sum()?;
            return self.eat(")").then_some(v);
        }
        let word = self.peek()?;
        self.at += 1;
        match word {
            "min" | "max" => {
                if !self.eat("(") {
                    return None;
                }
                let a = self.sum()?;
                if !self.eat(",") {
                    return None;
                }
                let b = self.sum()?;
                if !self.eat(")") {
                    return None;
                }
                Some(if word == "min" { a.min(b) } else { a.max(b) })
            }
            "gl_MaxComputeWorkGroupSize" => {
                if !self.eat(".") {
                    return None;
                }
                let axis = self.peek()?;
                self.at += 1;
                match axis {
                    "x" => Some(1024),
                    "y" => Some(1024),
                    "z" => Some(64),
                    _ => None,
                }
            }
            number => number.trim_end_matches(['u', 'U']).parse().ok(),
        }
    }
}

/// The numbers of a constant's constructor, `const ivec3 name = ivec3(1, 2, 3);` → 1, 2, 3.
fn constant(stage: &Stage, name: &str) -> Option<Vec<f64>> {
    let at = stage.tokens.iter().position(|&t| t == name)?;
    let rest = &stage.tokens[at + 1..];
    if rest.iter().find(|t| scan::significant(t)) != Some(&"=") {
        return None;
    }
    let end = rest.iter().position(|&t| t == ";")?;
    let mut values: Vec<f64> = rest[..end]
        .iter()
        .filter_map(|t| t.trim_end_matches(['u', 'U', 'f', 'F']).parse().ok())
        .collect();
    if values.len() == 1 && values[0] >= 0.0 {
        // A vector constructor with one scalar fills every component (GLSL 5.4.2).
        // Only splat a literal; collecting a number out of an expression loses its operators.
        let words: Vec<_> = rest[..end]
            .iter()
            .copied()
            .filter(|t| scan::significant(t))
            .collect();
        let count = match words.as_slice() {
            ["=", "ivec2" | "uvec2" | "vec2", "(", _, ")"] => 2,
            ["=", "ivec3" | "uvec3" | "vec3", "(", _, ")"] => 3,
            _ => 1,
        };
        values.resize(count, values[0]);
    }
    Some(values)
}

/// A matrix or array varying (`flat mat3 @[2];`): wgpu's stage interfaces take only scalars
/// and vectors (WGSL), so it becomes a private global (`mat3 @[2];`) and one varying per
/// column or element, each with the qualifiers and how to reach it (`[1][2]`). `None` for
/// scalars and vectors, and for sizes that are not plain numbers.
fn varying_parts(decl: &str) -> Option<(String, Vec<(String, String)>)> {
    let (before, after) = decl.split_once('@')?;
    let mut words: Vec<&str> = before.split_whitespace().collect();
    let ty = words.pop()?;
    let qualifiers: String = words.iter().map(|w| format!("{w} ")).collect();
    let array = after.trim().trim_end_matches(';').trim();
    let mut sizes = Vec::new();
    let mut rest = array;
    while let Some(r) = rest.strip_prefix('[') {
        let (n, r) = r.split_once(']')?;
        sizes.push(n.trim().parse::<usize>().ok()?);
        rest = r.trim_start();
    }
    if !rest.is_empty() {
        return None;
    }
    // matC or matCxR: C columns of R rows.
    let column = ty.strip_prefix("mat").and_then(|d| {
        let (c, r) = d.split_once('x').unwrap_or((d, d));
        Some((c.parse::<usize>().ok()?, r.parse::<usize>().ok()?))
    });
    if sizes.is_empty() && column.is_none() {
        return None;
    }
    let part_ty = column.map_or(ty.to_owned(), |(_, r)| format!("vec{r}"));
    if let Some((c, _)) = column {
        sizes.push(c);
    }
    let count: usize = sizes.iter().product();
    let parts = (0..count)
        .map(|mut k| {
            let mut access = String::new();
            for &size in sizes.iter().rev() {
                access.insert_str(0, &format!("[{}]", k % size));
                k /= size;
            }
            (format!("{qualifiers}{part_ty} @;"), access)
        })
        .collect();
    Some((format!("{ty} @{array};"), parts))
}

/// A struct varying (`flat Params @;`) as vectors: its scalar, vector and matrix members, through
/// nested structs and arrays, packed four components at a time by base type. Each part: its
/// declaration and, per member, the swizzle of the part and how to reach the member (`.a[1].b`).
/// `None` for a member that can't travel (`bool`, an unknown type, a size that is not a number).
#[allow(clippy::type_complexity)]
fn struct_parts(
    decl: &str,
    structs: &std::collections::HashMap<String, Vec<(String, String)>>,
) -> Option<Vec<(String, Vec<(String, String)>)>> {
    let (before, after) = decl.split_once('@')?;
    let mut words: Vec<&str> = before.split_whitespace().collect();
    let ty = words.pop()?;
    let qualifiers: String = words.iter().map(|w| format!("{w} ")).collect();
    let mut leaves = Vec::new();
    leaves_of(
        ty,
        after.trim().trim_end_matches(';'),
        String::new(),
        structs,
        &mut leaves,
    )?;
    // Slots of one base type and up to four components: (base, used, members (from, size, access)).
    let mut slots: Vec<(&str, usize, Vec<(usize, usize, String)>)> = Vec::new();
    for (base, size, access) in leaves {
        match slots
            .iter_mut()
            .find(|(b, used, _)| *b == base && used + size <= 4)
        {
            Some(slot) => {
                slot.2.push((slot.1, size, access));
                slot.1 += size;
            }
            None => slots.push((base, size, vec![(0, size, access)])),
        }
    }
    Some(
        slots
            .into_iter()
            .map(|(base, used, members)| {
                let ty = match (base, used) {
                    (b, 1) => b.to_owned(),
                    ("float", n) => format!("vec{n}"),
                    ("int", n) => format!("ivec{n}"),
                    (_, n) => format!("uvec{n}"),
                };
                // Integers only travel flat.
                let flat = if base != "float" && !qualifiers.contains("flat") {
                    "flat "
                } else {
                    ""
                };
                let members = members
                    .into_iter()
                    .map(|(from, size, access)| {
                        let swizzle = if used == 1 {
                            String::new()
                        } else {
                            format!(".{}", &"xyzw"[from..from + size])
                        };
                        (swizzle, access)
                    })
                    .collect();
                (format!("{flat}{qualifiers}{ty} @;"), members)
            })
            .collect(),
    )
}

/// The scalars and vectors inside a value of type `ty` with array suffix `array`, reached by
/// `access`: (base type, components, access).
fn leaves_of(
    ty: &str,
    array: &str,
    access: String,
    structs: &std::collections::HashMap<String, Vec<(String, String)>>,
    out: &mut Vec<(&'static str, usize, String)>,
) -> Option<()> {
    if let Some(rest) = array.trim().strip_prefix('[') {
        let (n, rest) = rest.split_once(']')?;
        for k in 0..n.trim().parse::<usize>().ok()? {
            leaves_of(ty, rest, format!("{access}[{k}]"), structs, out)?;
        }
        return Some(());
    }
    if let Some(members) = structs.get(ty) {
        for (member_ty, member) in members {
            let (name, array) = member
                .split_once('[')
                .map_or((member.as_str(), ""), |(n, _)| (n, &member[n.len()..]));
            leaves_of(member_ty, array, format!("{access}.{name}"), structs, out)?;
        }
        return Some(());
    }
    if let Some(dims) = ty.strip_prefix("mat") {
        let (c, r) = dims.split_once('x').unwrap_or((dims, dims));
        let (c, r) = (c.parse::<usize>().ok()?, r.parse::<usize>().ok()?);
        for k in 0..c {
            out.push(("float", r, format!("{access}[{k}]")));
        }
        return Some(());
    }
    let (base, size) = match ty {
        "float" => ("float", 1),
        "int" => ("int", 1),
        "uint" => ("uint", 1),
        _ => {
            let (base, n) = if let Some(n) = ty.strip_prefix("vec") {
                ("float", n)
            } else if let Some(n) = ty.strip_prefix("ivec") {
                ("int", n)
            } else {
                ("uint", ty.strip_prefix("uvec")?)
            };
            (base, n.parse().ok()?)
        }
    };
    out.push((base, size, access));
    Some(())
}

/// `sampler2DShadow` → (`texture2D`, `samplerShadow`); `isampler3D` → (`itexture3D`, `sampler`).
pub(super) fn split_sampler(ty: &str) -> (String, &'static str) {
    let shadow = ty.ends_with("Shadow");
    let base = ty
        .trim_end_matches("Shadow")
        .replacen("sampler", "texture", 1);
    (base, if shadow { "samplerShadow" } else { "sampler" })
}

/// Parses and validates one stage; errors at the pack's files and lines.
fn compile(stage: &Stage, text: &str, header_lines: usize) -> Result<naga::Module, Vec<Error>> {
    let specialized = image_parameters::rewrite(text).map_err(|message| {
        vec![Error {
            file: stage.pp.files.first().cloned().unwrap_or_default(),
            line: 1,
            message,
        }]
    })?;
    let bounded = integer_bounds::rewrite(&array_constructors::rewrite(&specialized));
    let text = bounded.as_str();
    let at = |text: &str, span: naga::Span, message: String| {
        let start = span.to_range().map_or(0, |r| r.start);
        let line = text[..start.min(text.len())].matches('\n').count();
        match line
            .checked_sub(header_lines)
            .and_then(|l| stage.pp.lines.get(l))
        {
            Some(o) => Error {
                file: stage
                    .pp
                    .files
                    .get(o.file as usize)
                    .cloned()
                    .unwrap_or_default(),
                line: o.line,
                message,
            },
            None => Error {
                file: "<horizon>".into(),
                line: line as u32 + 1,
                message,
            },
        }
    };
    let parse = |text: &str| {
        Frontend::default()
            .parse(&Options::from(stage.kind), text)
            .map_err(|e| {
                e.errors
                    .into_iter()
                    .map(|e| at(text, e.meta, e.kind.to_string()))
                    .collect::<Vec<_>>()
            })
    };
    // naga's frontend refuses a few things GL takes: a scalar's swizzle (`f.x`, GLSL 4.20), a
    // matrix column's component written to (`m[1].y =`) and `min`/`max`/`clamp` of a `uint` and
    // integer literals, and a function prototype declared again. Each refusal is rewritten where
    // naga points, and the source parsed again.
    let mut text = std::borrow::Cow::Borrowed(text);
    let mut tries = 0;
    let mut module = loop {
        tries += 1;
        match Frontend::default().parse(&Options::from(stage.kind), &text) {
            Ok(m) => break m,
            Err(e) => match e.errors.iter().find_map(|e| {
                scalar_swizzle(&text, e)
                    .or_else(|| unsigned_literals(&text, e))
                    .or_else(|| repeated_prototype(&text, e))
            }) {
                Some(fixed) if tries < 256 => text = fixed.into(),
                _ => return parse(&text),
            },
        }
    };
    end_returns_give_zero(&mut module);
    Validator::new(ValidationFlags::all(), Capabilities::all())
        .subgroup_operations(naga::valid::SubgroupOperationSet::all())
        .subgroup_stages(naga::valid::ShaderStages::all())
        .validate(&module)
        .map_err(|e| {
            let span = e.spans().next().map_or(naga::Span::default(), |(s, _)| *s);
            // The validator nests its reasons: say them all.
            let inner = e.into_inner();
            let mut message = inner.to_string();
            let mut source = std::error::Error::source(&inner);
            while let Some(s) = source {
                write!(message, ": {s}").unwrap();
                source = s.source();
            }
            vec![at(&text, span, message)]
        })?;
    Ok(module)
}

/// GLSL lets a function that returns a value reach its end without a `return`: what it returns
/// then is undefined (GLSL 4.60, 6.1). naga's frontend ends every body that can reach its end
/// with a `return` of no value, which its validator refuses in such a function; those returns
/// give the result type's zero instead.
fn end_returns_give_zero(module: &mut naga::Module) {
    fn fill(block: &mut naga::Block, zero: &mut dyn FnMut() -> naga::Handle<naga::Expression>) {
        // The ends naga's frontend gives a `return` to (`naga::proc::ensure_block_returns`).
        match block.last_mut() {
            Some(naga::Statement::Block(b)) => fill(b, zero),
            Some(naga::Statement::If { accept, reject, .. }) => {
                fill(accept, zero);
                fill(reject, zero);
            }
            Some(naga::Statement::Switch { cases, .. }) => {
                for case in cases.iter_mut().filter(|c| !c.fall_through) {
                    fill(&mut case.body, zero);
                }
            }
            Some(naga::Statement::Return { value }) if value.is_none() => *value = Some(zero()),
            _ => {}
        }
    }
    for (_, f) in module.functions.iter_mut() {
        let Some(ty) = f.result.as_ref().map(|r| r.ty) else {
            continue;
        };
        let (body, expressions) = (&mut f.body, &mut f.expressions);
        let mut made = None;
        fill(body, &mut || {
            *made.get_or_insert_with(|| {
                expressions.append(naga::Expression::ZeroValue(ty), naga::Span::default())
            })
        });
    }
}

/// `text` without the scalar swizzle naga's frontend refused (`e`, GLSL 4.20's `f.x`, `f.xx`): one
/// component dropped, more a vector constructor of the scalar.
fn scalar_swizzle(text: &str, e: &naga::front::glsl::Error) -> Option<String> {
    if !e
        .kind
        .to_string()
        .starts_with("Can't lookup field on this type")
    {
        return None;
    }
    let r = e.meta.to_range()?;
    let field = text.get(r.clone())?.strip_prefix('.')?;
    let one = |c: char| field.chars().all(|f| f == c);
    let indexed = text[..r.start].trim_end().ends_with(']');
    let component = field.len() == 1 && "xyzwrgbastpq".contains(field);
    if field.is_empty()
        || field.len() > 4
        || !(one('x') || one('r') || one('s') || indexed && component)
    {
        return None;
    }
    let mut out = text.to_owned();
    if field.len() == 1 && indexed {
        // A matrix column's component, written to: `m[1].y` as `m[1][1]`.
        let k = "xyzwrgbastpq".find(field).map(|k| k % 4)?;
        out.replace_range(r, &format!("[{k}]"));
    } else if field.len() == 1 {
        out.replace_range(r, "");
    } else {
        let start = expression_start(text, r.start)?;
        out.replace_range(r, ")");
        out.insert_str(start, &format!("vec{}(", field.len()));
    }
    Some(out)
}

/// `text` with the integer literals of the `min`/`max`/`clamp` call naga found ambiguous (`e`)
/// made unsigned: with a `uint` beside them GL takes the `uint` overload.
fn unsigned_literals(text: &str, e: &naga::front::glsl::Error) -> Option<String> {
    let kind = e.kind.to_string();
    let f = kind
        .strip_prefix("Ambiguous best function for '")?
        .trim_end_matches('\'');
    if !matches!(f, "min" | "max" | "clamp") {
        return None;
    }
    let r = e.meta.to_range()?;
    let call = text.get(r.clone())?;
    let b = call.as_bytes();
    let word = |c: u8| c.is_ascii_alphanumeric() || c == b'_' || c == b'.';
    let mut out = String::with_capacity(call.len() + 8);
    let mut i = 0;
    let mut changed = false;
    while i < b.len() {
        if b[i].is_ascii_digit() && (i == 0 || !word(b[i - 1])) {
            let start = i;
            while i < b.len() && b[i].is_ascii_digit() {
                i += 1;
            }
            out.push_str(&call[start..i]);
            if i == b.len() || !(word(b[i])) {
                out.push('u');
                changed = true;
            }
            continue;
        }
        out.push(b[i] as char);
        i += 1;
    }
    changed.then(|| format!("{}{out}{}", &text[..r.start], &text[r.end..]))
}

/// `text` without the function prototype naga's frontend refused as declared before (`e`): GLSL
/// lets a function be declared again (packs include the same helper's prototype from two
/// files). The prototype and its `;` turn to spaces, keeping lines where they are; one with
/// qualifiers before its type (naga's span starts at the type) is left alone.
fn repeated_prototype(text: &str, e: &naga::front::glsl::Error) -> Option<String> {
    if e.kind.to_string() != "Prototype already defined" {
        return None;
    }
    let r = e.meta.to_range()?;
    let end = r.end + text.get(r.end..)?.find(';')? + 1;
    if !text.get(r.end..end - 1)?.trim().is_empty() {
        return None;
    }
    let before = text.get(..r.start)?.trim_end();
    let line = &before[before.rfind('\n').map_or(0, |n| n + 1)..];
    let boundary =
        before.is_empty() || before.ends_with([';', '}']) || line.trim_start().starts_with('#');
    if !boundary {
        return None;
    }
    let blank: String = text[r.start..end]
        .chars()
        .map(|c| if c == '\n' { '\n' } else { ' ' })
        .collect();
    Some(format!("{}{blank}{}", &text[..r.start], &text[end..]))
}

/// Where the operand that ends right before byte `end` begins: a name, a call or an index (with
/// what it is of), or a bracketed expression.
fn expression_start(text: &str, end: usize) -> Option<usize> {
    let b = text.as_bytes();
    let mut i = end;
    while i > 0 && b[i - 1].is_ascii_whitespace() {
        i -= 1;
    }
    loop {
        match b.get(i.checked_sub(1)?) {
            Some(b')') | Some(b']') => {
                let mut level = 0i32;
                loop {
                    i = i.checked_sub(1)?;
                    match b[i] {
                        b')' | b']' => level += 1,
                        b'(' | b'[' => {
                            level -= 1;
                            if level == 0 {
                                break;
                            }
                        }
                        _ => {}
                    }
                }
            }
            Some(c) if c.is_ascii_alphanumeric() || *c == b'_' || *c == b'.' => i -= 1,
            _ => return Some(i),
        }
        if i == 0 {
            return Some(0);
        }
    }
}

/// The uniform block's size and member offsets, from naga's layout.
fn block_layout(module: &naga::Module) -> (u32, Vec<(String, u32)>) {
    for (_, var) in module.global_variables.iter() {
        let frame = var
            .binding
            .as_ref()
            .is_some_and(|b| b.group == 0 && b.binding == 0);
        if var.space != naga::AddressSpace::Uniform || !frame {
            continue;
        }
        if let naga::TypeInner::Struct { members, span } = &module.types[var.ty].inner {
            let offsets = members
                .iter()
                .filter_map(|m| Some((m.name.clone()?, m.offset)))
                .collect();
            return (*span, offsets);
        }
    }
    (16, vec![("hz_target".into(), 0)])
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A gbuffers program whose fragment stage writes `float(<name>)` after `decl`.
    fn item_program(
        program: &str,
        decl: &str,
        name: &str,
        game: &GbuffersInputs,
    ) -> Result<Program, Vec<Error>> {
        let vsh = "#version 330 compatibility\nvoid main() { gl_Position = ftransform(); }\n";
        let fsh = format!(
            "#version 330 compatibility\n{decl}\nlayout(location = 0) out vec4 c;\n\
             void main() {{ c = vec4(float({name})); }}\n"
        );
        let (v, f) = (format!("{program}.vsh"), format!("{program}.fsh"));
        let files = [
            (format!("shaders/{v}"), vsh.to_owned()),
            (format!("shaders/{f}"), fsh),
        ];
        let files: Vec<(&str, &str)> = files
            .iter()
            .map(|(a, b)| (a.as_str(), b.as_str()))
            .collect();
        let pack = Pack::from_zip_bytes("P.zip", zip(&files)).unwrap();
        let m = Macros::standard();
        translate_gbuffers(
            &preprocess(&pack, &v, &m),
            &preprocess(&pack, &f, &m),
            Target::Buffers,
            game,
        )
    }

    fn item_game() -> GbuffersInputs {
        GbuffersInputs {
            declarations: "layout(location = 0) in vec3 game_pos;".into(),
            body: "    hz_Vertex = vec4(game_pos, 1.0);\n".into(),
            ..Default::default()
        }
    }

    /// `currentRenderedItemId` is set per draw, in `HzDraw`, as `entityId` is.
    #[test]
    fn the_rendered_item_id_is_a_per_draw_value() {
        let decl = "uniform int currentRenderedItemId;";
        let p = item_program("gbuffers_hand", decl, "currentRenderedItemId", &item_game())
            .unwrap_or_else(|e| panic!("{e:?}"));
        let names: Vec<&str> = p
            .interface
            .uniforms
            .iter()
            .map(|u| u.name.as_str())
            .collect();
        assert!(
            p.interface.draw && !names.contains(&"currentRenderedItemId"),
            "{names:?}"
        );
    }

    /// The hand's programs may read `currentRenderedItemId` without declaring it, as Iris lets
    /// them; terrain's may not, nor a longer name that begins with it.
    #[test]
    fn the_hand_may_read_the_rendered_item_id_undeclared() {
        let hand = GbuffersInputs {
            item_id_declared: true,
            ..item_game()
        };
        let p = item_program("gbuffers_hand", "", "currentRenderedItemId", &hand)
            .unwrap_or_else(|e| panic!("{e:?}"));
        assert!(p.interface.draw);
        assert!(
            item_program(
                "gbuffers_terrain",
                "",
                "currentRenderedItemId",
                &item_game()
            )
            .is_err()
        );
        let longer = "uniform int currentRenderedItemId2;";
        let p = item_program("gbuffers_hand", longer, "currentRenderedItemId2", &hand)
            .unwrap_or_else(|e| panic!("{e:?}"));
        assert!(!p.interface.draw);
    }

    #[test]
    fn compute_dispatch_splats_absolute_vector_constants() {
        for (declaration, expected) in [
            ("const ivec3 workGroups = ivec3(1);", [1, 1, 1]),
            ("const ivec3 workGroups = ivec3(2);", [2, 2, 2]),
            ("const ivec3 workGroups = ivec3(2, 3, 4);", [2, 3, 4]),
        ] {
            let source = format!(
                "#version 430\nlayout(local_size_x=1) in;\n{declaration}\nvoid main(){{}}\n"
            );
            let pack =
                Pack::from_zip_bytes("dispatch.zip", zip(&[("shaders/composite.csh", &source)]))
                    .unwrap();
            let program =
                translate_compute(&preprocess(&pack, "composite.csh", &Macros::standard()))
                    .unwrap_or_else(|errors| panic!("{declaration}: {errors:?}"));
            assert_eq!(program.work_groups, Some(expected), "{declaration}");
            assert_eq!(program.work_groups_render, [1.0, 1.0]);
        }
    }

    #[test]
    fn compute_dispatch_splats_relative_vector_constants() {
        for (declaration, expected) in [
            ("const vec2 workGroupsRender = vec2(0.5);", [0.5, 0.5]),
            ("const vec3 workGroupsRender = vec3(0.25);", [0.25, 0.25]),
            (
                "const vec2 workGroupsRender = vec2(0.25, 0.75);",
                [0.25, 0.75],
            ),
            ("", [1.0, 1.0]),
        ] {
            let source = format!(
                "#version 430\nlayout(local_size_x=1) in;\n{declaration}\nvoid main(){{}}\n"
            );
            let pack =
                Pack::from_zip_bytes("dispatch.zip", zip(&[("shaders/composite.csh", &source)]))
                    .unwrap();
            let program =
                translate_compute(&preprocess(&pack, "composite.csh", &Macros::standard()))
                    .unwrap_or_else(|errors| panic!("{declaration}: {errors:?}"));
            assert_eq!(program.work_groups_render, expected, "{declaration}");
            assert_eq!(program.work_groups, None);
        }
    }

    /// Core matrix state and compatibility matrix state describe the same geometry transform.
    #[test]
    fn gbuffers_core_matrices_use_frame_state() {
        for declaration in ["", "uniform mat4 projectionMatrix, modelViewMatrix;"] {
            for profile in ["330 compatibility", "330 core"] {
                let source = format!(
                    "#version {profile}\n{declaration}\nin vec3 vaPosition;\nvoid main() {{ gl_Position = projectionMatrix * modelViewMatrix * vec4(vaPosition, 1.0); }}\n"
                );
                let p = core_matrix_program(&source, false).unwrap();
                for name in ["projectionMatrix", "modelViewMatrix"] {
                    assert!(!p.interface.uniforms.iter().any(|u| u.name == name));
                }
                for name in ["gbufferProjection", "gbufferModelView"] {
                    assert!(p.interface.uniforms.iter().any(|u| u.name == name));
                }
            }
        }
    }

    /// `normalMatrix` follows the geometry's transform in a core-profile gbuffers stage and stays
    /// a uniform of the frame (zero) in a compatibility-profile one, as our #9136 probe's Iris
    /// 1.11.7 pictures show at these four `#version` lines.
    #[test]
    fn core_normal_matrix_uses_frame_state_in_the_core_profile_only() {
        for (profile, core) in [
            ("330 core", true),
            ("330", true),
            ("150", true),
            ("330 compatibility", false),
        ] {
            let source = format!(
                "#version {profile}\nuniform mat3 normalMatrix;\nin vec3 vaNormal;\nout vec3 n;\n\
                 void main() {{ n = normalMatrix * vaNormal; gl_Position = vec4(n, 1.0); }}\n"
            );
            let p = core_matrix_program(&source, false).unwrap();
            let uniform = p
                .interface
                .uniforms
                .iter()
                .any(|u| u.name == "normalMatrix");
            assert_eq!(uniform, !core, "{profile}");
        }
    }

    /// `textureMatrix` in the vertex stage is the texture matrix state, not a frame uniform the
    /// game has no value for; the fragment stage's own one keeps its slot (Iris 1.11.7 reads
    /// zero there in our probe, #9080).
    #[test]
    fn vertex_texture_matrix_is_not_a_frame_uniform() {
        let vertex = "#version 460 core\nuniform mat4 textureMatrix;\nin vec2 vaUV0;\nout vec2 uv;\n\
                      void main() { uv = mat2(textureMatrix) * vaUV0 + textureMatrix[3].xy; gl_Position = vec4(1.0); }";
        let p = core_matrix_program(vertex, false).unwrap();
        assert!(
            !p.interface
                .uniforms
                .iter()
                .any(|u| u.name == "textureMatrix")
        );
        let fragment = "#version 460 core\nuniform mat4 textureMatrix;\nout vec4 color;\n\
                        void main() { color = textureMatrix[0]; }";
        let files = [
            ("shaders/gbuffers_terrain.vsh", vertex),
            ("shaders/gbuffers_terrain.fsh", fragment),
        ];
        let pack = Pack::from_zip_bytes("texture-matrix.zip", zip(&files)).unwrap();
        let macros = Macros::standard();
        let p = translate_gbuffers(
            &preprocess(&pack, "gbuffers_terrain.vsh", &macros),
            &preprocess(&pack, "gbuffers_terrain.fsh", &macros),
            Target::Buffers,
            &GbuffersInputs::default(),
        )
        .unwrap();
        assert!(
            p.interface
                .uniforms
                .iter()
                .any(|u| u.name == "textureMatrix" && u.ty == "mat4")
        );
    }

    #[test]
    fn core_matrix_aliases_preserve_authored_names_and_errors() {
        for declarations in [
            "mat4 projectionMatrix = mat4(2.0), modelViewMatrix = mat4(3.0);",
            "mat4 projectionMatrix; mat4 modelViewMatrix;",
            "const mat4 projectionMatrix = mat4(2.0), modelViewMatrix = mat4(3.0);",
            "uniform mat4 projectionMatrix, modelViewMatrix;",
        ] {
            let source = format!(
                "#version 330\n{declarations}\n\
                 struct S {{ mat4 projectionMatrix; mat4 modelViewMatrix; }};\n\
                 vec4 local(mat4 projectionMatrix, mat4 modelViewMatrix) {{\n\
                 return projectionMatrix * modelViewMatrix * vec4(1.0); }}\n\
                 void main() {{\n\
                 S s; s.projectionMatrix = mat4(1.0); s.modelViewMatrix = mat4(1.0);\n\
                 vec4 p = projectionMatrix * modelViewMatrix * vec4(1.0);\n\
                 {{ mat4 projectionMatrix = modelViewMatrix; p += projectionMatrix * vec4(1.0); }}\n\
                 for (int modelViewMatrix = 0; modelViewMatrix < 2; modelViewMatrix++) p.x += float(modelViewMatrix);\n\
                 gl_Position = p + local(s.projectionMatrix, s.modelViewMatrix); }}"
            );
            core_matrix_program(&source, false).unwrap_or_else(|e| panic!("{declarations}: {e:?}"));
        }
        core_matrix_program(
            "#version 330\nmat4 projectionMatrix() { return mat4(2.0); }\nvoid main() { gl_Position = projectionMatrix() * modelViewMatrix * vec4(1.0); }", false,
        ).unwrap();
        let unknown = core_matrix_program(
            "#version 330\nvoid main() { gl_Position = unknownMatrix * vec4(1.0); }",
            false,
        )
        .err()
        .unwrap();
        assert!(unknown.iter().any(|e| e.message.contains("unknownMatrix")));
        let shadow = core_matrix_program(
            "#version 330\nvoid main() { gl_Position = projectionMatrix * modelViewMatrix * vec4(1.0); }", true,
        ).unwrap();
        for name in ["shadowProjection", "shadowModelView"] {
            assert!(shadow.interface.uniforms.iter().any(|u| u.name == name));
        }
        // Composite shaders have their own transform; undeclared core names stay errors.
        let composite = program(
            &[
                (
                    "composite.vsh",
                    "#version 330\nvoid main() { gl_Position = projectionMatrix * vec4(1.0); }",
                ),
                (
                    "composite.fsh",
                    "#version 330\nout vec4 c; void main() { c = vec4(1.0); }",
                ),
            ],
            Target::Buffers,
        )
        .err()
        .unwrap();
        assert!(
            composite
                .iter()
                .any(|e| e.message.contains("projectionMatrix"))
        );
    }

    fn core_matrix_program(source: &str, shadow: bool) -> Result<Program, Vec<Error>> {
        let files = [
            ("shaders/gbuffers_line.vsh", source),
            (
                "shaders/gbuffers_line.fsh",
                "#version 330\nout vec4 color; void main() { color = vec4(1.0); }",
            ),
        ];
        let pack = Pack::from_zip_bytes("core-matrices.zip", zip(&files)).unwrap();
        let macros = Macros::standard();
        let vertex = preprocess(&pack, "gbuffers_line.vsh", &macros);
        let fragment = preprocess(&pack, "gbuffers_line.fsh", &macros);
        let inputs = GbuffersInputs {
            body: "hz_Vertex = vec4(0.25, 0.5, -2.0, 1.0);".into(),
            attributes: vec![("vaPosition".into(), "hz_Vertex.xyz".into())],
            ..Default::default()
        };
        if shadow {
            translate_shadow(&vertex, &fragment, &inputs)
        } else {
            translate_gbuffers(&vertex, &fragment, Target::Buffers, &inputs)
        }
    }

    #[test]
    fn compute_dispatch_does_not_guess_unsupported_scalar_expressions() {
        for declaration in [
            "const ivec3 workGroups = ivec3(-1);",
            "const vec2 workGroupsRender = vec2(-0.5);",
            "const ivec3 workGroups = ivec3(int(1.0));",
        ] {
            let source = format!(
                "#version 430\nlayout(local_size_x=1) in;\n{declaration}\nvoid main(){{}}\n"
            );
            let pack =
                Pack::from_zip_bytes("dispatch.zip", zip(&[("shaders/composite.csh", &source)]))
                    .unwrap();
            assert!(
                translate_compute(&preprocess(&pack, "composite.csh", &Macros::standard()))
                    .is_err(),
                "{declaration}"
            );
        }
    }
    use crate::pack::tests::zip;
    use crate::{Macros, Pack, preprocess};

    fn program(files: &[(&str, &str)], target: Target) -> Result<Program, Vec<Error>> {
        let files: Vec<(String, &str)> = files
            .iter()
            .map(|(p, t)| (format!("shaders/{p}"), *t))
            .collect();
        let files: Vec<(&str, &str)> = files.iter().map(|(p, t)| (p.as_str(), *t)).collect();
        let pack = Pack::from_zip_bytes("P.zip", zip(&files)).unwrap();
        let m = Macros::standard();
        translate_composite(
            &preprocess(&pack, "composite.vsh", &m),
            &preprocess(&pack, "composite.fsh", &m),
            target,
        )
    }

    const VSH_120: &str = "#version 120\nvarying vec2 texcoord;\nvoid main() {\n    gl_Position = ftransform();\n    \
                           texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;\n}\n";

    #[test]
    fn mixed_type_array_constructor_arguments_validate() {
        // Drivers take these; naga composed them unconverted ("Composing 0's component type").
        for body in [
            "int k[2] = int[2](1u, 2); return float(k[1]);",
            "float k[] = float[](1u, 2); return k[1];",
            "uint k[2] = uint[2](1.0, 2); return float(k[1]);",
            "vec2 k[2] = vec2[](ivec2(1), texcoord); return k[1].x;",
        ] {
            let fsh = format!(
                "#version 120\nvarying vec2 texcoord;\nfloat n2d() {{ {body} }}\nvoid main() {{ gl_FragColor = vec4(n2d()); }}\n"
            );
            let p = program(
                &[("composite.vsh", VSH_120), ("composite.fsh", &fsh)],
                Target::Window,
            );
            assert!(p.is_ok(), "{body}: {:?}", p.err());
        }
    }

    #[test]
    fn mixed_type_constructor_arguments_validate() {
        // Each kind of constructor and call, with arguments drivers convert (spec 5.4).
        let cases = [
            ("", "vec3 k = vec3(1u, 2, texcoord.x); return k.x;"),
            ("", "ivec2 k = ivec2(1u, 2.0); return float(k.x);"),
            ("", "mat2 m = mat2(1u, 2, texcoord.x, 4.0); return m[0].x;"),
            (
                "struct S { int a; float b; vec2 c; };\n",
                "S s = S(1u, 2, ivec2(3)); return s.b;",
            ),
            (
                "struct S { uint a; float b; };\n",
                "S s = S(1.0, 2); return s.b;",
            ),
            (
                "float h(float x, int y) { return x + float(y); }\n",
                "return h(1, 2);",
            ),
        ];
        let mut bad = Vec::new();
        for (decl, body) in cases {
            let fsh = format!(
                "#version 120\nvarying vec2 texcoord;\n{decl}float n2d() {{ {body} }}\nvoid main() {{ gl_FragColor = vec4(n2d()); }}\n"
            );
            let p = program(
                &[("composite.vsh", VSH_120), ("composite.fsh", &fsh)],
                Target::Window,
            );
            if let Err(e) = p {
                bad.push(format!("{body}: {:?}", e.first().map(|e| &e.message)));
            }
        }
        assert!(bad.is_empty(), "{}", bad.join("\n"));
    }

    #[test]
    fn compatibility_programs_translate() {
        let fsh = "#version 120\nuniform sampler2D colortex0;\nuniform sampler2D depthtex0;\nuniform float viewWidth;\n\
                   uniform bool hideGUI;\nuniform int frameCounter;\nvarying vec2 texcoord;\n\
                   vec3 tint(sampler2D s, vec2 c) { return texture2D(s, c).rgb; }\nvoid main() {\n    \
                   vec3 c = tint(colortex0, texcoord) * texture2D(depthtex0, texcoord).r;\n    if (hideGUI) c *= 0.5;\n    \
                   /* DRAWBUFFERS:04 */\n    gl_FragData[0] = vec4(c, 1.0);\n    gl_FragData[1] = vec4(frameCounter / viewWidth);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap();
        let i = &p.interface;
        let samplers: Vec<(&str, u32)> = i
            .samplers
            .iter()
            .map(|s| (s.name.as_str(), s.binding))
            .collect();
        assert_eq!(samplers, [("colortex0", 1), ("depthtex0", 3)]);
        let uniforms: Vec<(&str, &str)> = i
            .uniforms
            .iter()
            .map(|u| (u.name.as_str(), u.ty.as_str()))
            .collect();
        assert_eq!(
            uniforms,
            [
                ("hz_target", "vec4"),
                ("hz_fog_color", "vec4"),
                ("hz_fog", "vec4"),
                ("hz_depth_linear", "vec4"),
                ("frameCounter", "int"),
                ("hideGUI", "bool"),
                ("viewWidth", "float")
            ]
        );
        assert_eq!(i.uniforms[0].offset, 0);
        assert!(i.uniform_size >= 28);
        assert_eq!(i.outputs, [0, 1]);
    }

    /// naga drops non-constant global initializers: they run in our `main`, one per declarator,
    /// converting as GLSL's initialization does.
    #[test]
    fn global_initializers_read_uniforms() {
        let fsh = "#version 120\nuniform float rainStrength;\nuniform ivec2 atlasSize;\n\
                   vec2 size = atlasSize;\nvec3 a = vec3(rainStrength), b = a * 2.0, c;\n\
                   const float k = rainStrength > 0.5 ? 1.0 : 0.0;\nfloat w[] = float[](rainStrength, 1.0);\n\
                   void main() { c = b; gl_FragColor = vec4(a + c, size.x * k + w[0]); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Window,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// `sqrt` of a negative is undefined in GLSL: in functions it reads zero, as packs written
    /// against GL drivers expect at `sqrt(1.0 - y * y)` with y rounding just above 1. A global
    /// constant keeps the built-in, so it stays a constant (an array's size here).
    #[test]
    fn sqrt_in_functions_never_takes_a_negative() {
        let fsh = "#version 120\nconst int n = int(sqrt(16.0));\nfloat w[n];\n\
                   vec2 f(vec2 v) { float y = v.x; return vec2(sqrt(1.0 - y * y), sqrt(v).y); }\n\
                   void main() { w[3] = 1.0; gl_FragColor = vec4(f(vec2(1.0)), w[3], 1.0); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Window,
        )
        .unwrap();
        let clamped = p.fragment.functions.iter().any(|(_, f)| {
            f.expressions.iter().any(|(_, e)| {
                matches!(e, naga::Expression::Math { fun: naga::MathFunction::Sqrt, arg, .. }
                    if matches!(f.expressions[*arg], naga::Expression::Math { fun: naga::MathFunction::Max, .. }))
            })
        });
        assert!(clamped, "sqrt's argument is clamped at zero");
    }

    /// #8175: a `bool` member of a `layout(std430)` buffer (GLSL: size and alignment 4) is
    /// "not host-shareable" to naga. The shapes packs write: read in a condition, in an
    /// expression, written from a comparison, an array of them, beside other members.
    #[test]
    fn bool_members_of_std430_buffers_translate() {
        let mut failures = Vec::new();
        for (block, body) in [
            (
                "layout(std430, binding = 4) buffer State { mat4 matrix; bool flag; };",
                "if (flag) { gl_FragColor = vec4(1.0); } else { gl_FragColor = vec4(0.0); }",
            ),
            (
                "layout(std430, binding = 4) buffer State { bool flag; };",
                "gl_FragColor = vec4(float(flag), 0.0, 0.0, 1.0);",
            ),
            (
                "layout(std430, binding = 4) buffer State { int count; bool flag; } state;",
                "gl_FragColor = vec4(state.flag ? 1.0 : 0.0, float(state.count), 0.0, 1.0);",
            ),
            (
                "layout(std430, binding = 4) buffer State { bool flags[4]; };",
                "gl_FragColor = vec4(flags[2] && !flags[1] ? 1.0 : 0.0, 0.0, 0.0, 1.0);",
            ),
            (
                "layout(std430, binding = 4) buffer State { vec2 size; bool flag; };",
                "flag = size.x > 1.0;
    gl_FragColor = vec4(size, flag ? 1.0 : 0.0, 1.0);",
            ),
        ] {
            let fsh = format!(
                "#version 430 compatibility
{block}
void main() {{
    {body}
}}
"
            );
            if let Err(e) = program(
                &[("composite.vsh", VSH_120), ("composite.fsh", &fsh)],
                Target::Buffers,
            ) {
                failures.push(format!("`{block}` / `{body}`: {e:?}"));
            }
        }
        assert!(
            failures.is_empty(),
            "{}",
            failures.join(
                "
"
            )
        );
    }

    /// #8175: what the rewrite cannot make sure of is refused with the member's name and its
    /// line, not left to naga's "Global variable [6] '' is invalid".
    #[test]
    fn bool_buffer_members_that_cannot_be_rewritten_are_named() {
        for (block, body, wanted) in [
            (
                "layout(std430, binding = 4) buffer State { bool flag; };",
                "flag |= true;",
                "`flag`: `|=`",
            ),
            (
                "layout(std430, binding = 4) buffer State { bool flag; };",
                "bool other = (flag = true);",
                "`flag` is assigned inside an expression",
            ),
            (
                "layout(std430, binding = 4) buffer State { bool flag; };",
                "bool flag = false;",
                "`flag` is also declared as a local or parameter",
            ),
            (
                "layout(std430, binding = 4) buffer State { bvec2 pair; };",
                "",
                "`pair`: a `bvec2` is not supported",
            ),
            (
                "layout(std430, binding = 4) buffer State { bool flag; } states[2];",
                "",
                "an instance array",
            ),
        ] {
            let fsh = format!(
                "#version 430 compatibility
{block}
void main() {{
    {body}
    gl_FragColor = vec4(1.0);
}}
"
            );
            let errors = program(
                &[("composite.vsh", VSH_120), ("composite.fsh", &fsh)],
                Target::Buffers,
            )
            .err()
            .unwrap_or_else(|| panic!("`{body}` translated"));
            let error = errors
                .iter()
                .find(|e| e.message.contains(wanted))
                .unwrap_or_else(|| panic!("`{wanted}` in {errors:?}"));
            assert_eq!(error.file, "composite.fsh");
            assert!(error.line >= 2, "{error:?}");
            assert!(!error.message.contains("host-shareable"), "{error:?}");
        }
    }

    /// #8175: a compute program reads and writes a `bool` of its buffer too.
    #[test]
    fn bool_members_of_std430_buffers_translate_in_compute_programs() {
        let source = "#version 430
layout(local_size_x = 1) in;
                      layout(std430, binding = 3) buffer State { int count; bool flag; };
                      void main() {
    flag = count > 2;
    if (flag) { count = 0; }
}
";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/setup.csh", source)])).unwrap();
        let stage = crate::preprocess(&pack, "setup.csh", &crate::Macros::standard());
        let result = crate::translate_compute(&stage);
        assert!(result.is_ok(), "{:?}", result.err());
    }

    #[test]
    fn core_programs_translate() {
        let vsh = "#version 330 core\nin vec3 vaPosition;\nin vec2 vaUV0;\nuniform mat4 modelViewMatrix, projectionMatrix;\n\
                   out vec2 uv;\nflat out int flatId;\nvoid main() {\n    \
                   gl_Position = projectionMatrix * modelViewMatrix * vec4(vaPosition, 1.0);\n    uv = vaUV0;\n    flatId = 1;\n}\n";
        let fsh = "#version 330 core\nin vec2 uv;\nuniform sampler2D colortex0;\nuniform usampler2D colortex5;\n\
                   layout(location = 2) out vec4 color;\nvoid main() {\n    \
                   if (texture(colortex0, uv).a < 0.1) discard;\n    color = texture(colortex0, uv) + float(texelFetch(colortex5, ivec2(gl_FragCoord.xy), 0).r);\n}\n";
        let p = program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Window,
        )
        .unwrap();
        assert_eq!(p.interface.outputs, [2]);
        assert!(
            p.interface
                .uniforms
                .iter()
                .any(|u| u.name == "projectionMatrix" && u.ty == "mat4")
        );
    }

    /// `gl_FogFragCoord` travels from the vertex stage to the fragment stage as a float (MakeUp,
    /// E-LITE, VanillAA).
    #[test]
    fn fog_frag_coord_is_a_varying() {
        let vsh = "#version 120\nvarying vec2 texcoord;\nvoid main() {\n    gl_Position = ftransform();\n    \
                   texcoord = gl_MultiTexCoord0.xy;\n    gl_FogFragCoord = length((gl_ModelViewMatrix * gl_Vertex).xyz);\n}\n";
        let fsh = "#version 120\nvarying vec2 texcoord;\n\
                   void main() { gl_FragColor = vec4(vec3(texcoord, gl_FogFragCoord * 0.01), 1.0); }\n";
        let p = program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
        // Read by the fragment stage without the vertex stage writing it: still declared.
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// #8174: the interpolation qualifiers on a varying, in the order and the profile packs write
    /// them. The reporter's own two-line pair first; each variant alone, so one failing shows.
    #[test]
    fn interpolation_qualifiers_translate_on_varyings() {
        let vsh = |version: &str, decl: &str| {
            format!(
                "#version {version}
{decl}
void main() {{
    texcoord = gl_MultiTexCoord0.xy;
                     gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}}
"
            )
        };
        let fsh = |version: &str, decl: &str| {
            format!(
                "#version {version}
{decl}
void main() {{ gl_FragColor = vec4(texcoord, 0.0, 1.0); }}
"
            )
        };
        let mut failures = Vec::new();
        for version in ["430 compatibility", "330 compatibility", "430"] {
            for qualifier in [
                "flat",
                "smooth",
                "centroid",
                "noperspective",
                "centroid smooth",
                "flat centroid",
                "centroid flat",
            ] {
                for order in [0, 1] {
                    let (out, input) = if order == 0 {
                        (
                            format!("{qualifier} out vec2 texcoord;"),
                            format!("{qualifier} in vec2 texcoord;"),
                        )
                    } else {
                        (
                            format!("out {qualifier} vec2 texcoord;"),
                            format!("in {qualifier} vec2 texcoord;"),
                        )
                    };
                    let p = program(
                        &[
                            ("composite.vsh", &vsh(version, &out)),
                            ("composite.fsh", &fsh(version, &input)),
                        ],
                        Target::Buffers,
                    );
                    if let Err(e) = p {
                        failures.push(format!("{version}: `{out}` / `{input}`: {e:?}"));
                    }
                }
            }
        }
        assert!(
            failures.is_empty(),
            "{}",
            failures.join(
                "
"
            )
        );
    }

    /// #8174: the same qualifiers on the members of an interface block, which is how packs with
    /// a `dimensions/` folder pass their varyings. Before #6875 the members' `flat` reached naga
    /// as "Expected Void, Struct or a type, found Interpolation(Flat)".
    #[test]
    fn interpolation_qualifiers_translate_on_interface_block_members() {
        let mut failures = Vec::new();
        for member in [
            "flat vec2 texcoord;",
            "flat int id; vec2 texcoord;",
            "smooth vec2 texcoord;",
            "centroid vec2 texcoord;",
            "noperspective vec2 texcoord;",
            "flat centroid vec2 texcoord;",
            "centroid flat vec2 texcoord;",
            "flat sample vec2 texcoord;",
            "sample flat vec2 texcoord;",
            "layout(location = 1) flat vec2 texcoord;",
        ] {
            let id_out = if member.contains("int id") {
                "    vOut.id = 1;
"
            } else {
                ""
            };
            let vsh = format!(
                "#version 430 compatibility
out VertexData {{ {member} }} vOut;
void main() {{
{id_out}                     vOut.texcoord = gl_MultiTexCoord0.xy;
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}}
"
            );
            let fsh = format!(
                "#version 430 compatibility
in VertexData {{ {member} }} vIn;
                 void main() {{ gl_FragColor = vec4(vIn.texcoord, 0.0, 1.0); }}
"
            );
            if let Err(e) = program(
                &[("composite.vsh", &vsh), ("composite.fsh", &fsh)],
                Target::Buffers,
            ) {
                failures.push(format!("`{member}`: {e:?}"));
            }
        }
        assert!(
            failures.is_empty(),
            "{}",
            failures.join(
                "
"
            )
        );
    }

    #[test]
    fn frag_coord_is_set_for_every_target() {
        let fsh = "#version 120\nvoid main() { gl_FragColor = vec4(gl_FragCoord.x); }\n";
        for target in [Target::Buffers, Target::Window] {
            let p = program(
                &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
                target,
            )
            .unwrap();
            let m = &p.fragment;
            let (handle, _) = m
                .global_variables
                .iter()
                .find(|(_, g)| g.name.as_deref() == Some("hz_FragCoord"))
                .unwrap();
            // naga calls our `main` from its entry point: look in every function.
            let functions = m.functions.iter().map(|(_, f)| f);
            let stores = functions.chain([&m.entry_points[0].function]).any(|f| {
                f.body.iter().any(|s| match s {
                    naga::Statement::Store { pointer, .. } => {
                        matches!(f.expressions[*pointer], naga::Expression::GlobalVariable(h) if h == handle)
                    }
                    _ => false,
                })
            });
            assert!(stores, "{target:?}: main does not set hz_FragCoord");
        }
    }

    /// Code after an unconditional `discard` (BSL's `gbuffers_clouds` with its own clouds on)
    /// or `return;` still makes a valid module.
    #[test]
    fn code_after_discard_or_return_translates() {
        let vsh = "#version 120\nvoid main() { gl_Position = ftransform(); }\n";
        for fsh in [
            "#version 120\nuniform sampler2D texture;\nvoid main() {\n    discard;\n    vec4 c = texture2D(texture, vec2(0.5));\n    gl_FragData[0] = c;\n}\n",
            "#version 120\nvoid main() {\n    gl_FragData[0] = vec4(1.0);\n    return;\n    gl_FragData[0] = vec4(0.5);\n}\n",
        ] {
            let files = [
                ("shaders/gbuffers_clouds.vsh", vsh),
                ("shaders/gbuffers_clouds.fsh", fsh),
            ];
            let pack = Pack::from_zip_bytes("P.zip", zip(&files)).unwrap();
            let m = Macros::standard();
            let inputs = GbuffersInputs {
                body: "    hz_Vertex = vec4(0.0, 0.0, 0.0, 1.0);\n".into(),
                ..Default::default()
            };
            translate_gbuffers(
                &preprocess(&pack, "gbuffers_clouds.vsh", &m),
                &preprocess(&pack, "gbuffers_clouds.fsh", &m),
                Target::Buffers,
                &inputs,
            )
            .unwrap_or_else(|e| panic!("{fsh}: {e:?}"));
        }
    }

    #[test]
    fn the_alpha_test_discards_below_its_reference() {
        assert_eq!(
            AlphaTest::parse("GREATER 0.1"),
            Some(Some(AlphaTest {
                op: ">",
                reference: 0.1
            }))
        );
        assert_eq!(AlphaTest::parse("off"), Some(None));
        assert_eq!(AlphaTest::parse("GL_ALWAYS 0"), Some(None));
        assert_eq!(AlphaTest::parse("SOMETIMES 0.5"), None);
        let vsh = "#version 120\nvoid main() { gl_Position = ftransform(); }\n";
        let legacy = "#version 120\nvoid main() { gl_FragData[0] = vec4(0.5); }\n";
        let outs =
            "#version 330\nlayout(location = 0) out vec4 c;\nvoid main() { c = vec4(0.5); }\n";
        for (fsh, kills) in [(legacy, true), (outs, false)] {
            let files = [
                ("shaders/gbuffers_entities.vsh", vsh),
                ("shaders/gbuffers_entities.fsh", fsh),
            ];
            let pack = Pack::from_zip_bytes("P.zip", zip(&files)).unwrap();
            let m = Macros::standard();
            let inputs = GbuffersInputs {
                body: "    hz_Vertex = vec4(0.0, 0.0, 0.0, 1.0);\n".into(),
                alpha_test: AlphaTest::parse("GREATER 0.1").unwrap(),
                ..Default::default()
            };
            let p = translate_gbuffers(
                &preprocess(&pack, "gbuffers_entities.vsh", &m),
                &preprocess(&pack, "gbuffers_entities.fsh", &m),
                Target::Buffers,
                &inputs,
            )
            .unwrap_or_else(|e| panic!("{e:?}"));
            let functions = p.fragment.functions.iter().map(|(_, f)| f);
            let kill = functions
                .chain([&p.fragment.entry_points[0].function])
                .any(|f| format!("{:?}", f.body).contains("Kill"));
            // With `out` variables the pack tests alpha itself.
            assert_eq!(kill, kills, "{fsh}");
        }
    }

    #[test]
    fn gbuffers_programs_read_the_games_vertices() {
        let vsh = "#version 120\nattribute vec4 mc_Entity;\nattribute vec2 mc_midTexCoord;\nvarying vec2 uv;\nvarying vec2 light;\n\
                   varying vec4 color;\nvarying vec3 normal;\nvarying float id;\nvoid main() {\n    \
                   gl_Position = ftransform();\n    uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;\n    \
                   light = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;\n    color = gl_Color;\n    \
                   normal = normalize(gl_NormalMatrix * gl_Normal);\n    id = mc_Entity.x + mc_midTexCoord.x;\n}\n";
        let fsh = "#version 120\nuniform sampler2D texture;\nuniform sampler2D lightmap;\nuniform mat4 gbufferModelView;\n\
                   uniform int renderStage;\nvarying vec2 uv;\nvarying vec2 light;\nvarying vec4 color;\nvarying vec3 normal;\nvarying float id;\n\
                   void main() {\n    vec4 c = texture2D(texture, uv) * texture2D(lightmap, light) * color;\n    \
                   /* DRAWBUFFERS:02 */\n    gl_FragData[0] = c * gl_FragCoord.z * float(renderStage);\n    \
                   gl_FragData[1] = vec4(normal * 0.5 + 0.5, id);\n}\n";
        let files: Vec<(String, &str)> =
            [("gbuffers_terrain.vsh", vsh), ("gbuffers_terrain.fsh", fsh)]
                .iter()
                .map(|(p, t)| (format!("shaders/{p}"), *t))
                .collect();
        let files: Vec<(&str, &str)> = files.iter().map(|(p, t)| (p.as_str(), *t)).collect();
        let pack = Pack::from_zip_bytes("P.zip", zip(&files)).unwrap();
        let m = Macros::standard();
        let game = GbuffersInputs {
            declarations: "layout(location = 0) in vec3 game_pos;\nlayout(location = 1) in uvec2 game_uv;".into(),
            body: "    hz_Vertex = vec4(game_pos, 1.0);\n    hz_MultiTexCoord0 = vec4(vec2(game_uv) / 32768.0, 0.0, 1.0);\n    \
                   hz_MultiTexCoord1 = vec4(240.0, 240.0, 0.0, 1.0);\n    hz_Color = vec4(1.0);\n    hz_Normal = vec3(0.0, 1.0, 0.0);\n"
                .into(),
            attributes: vec![("mc_midTexCoord".into(), "vec2(game_uv) / 32768.0".into())],
            ..Default::default()
        };
        let p = translate_gbuffers(
            &preprocess(&pack, "gbuffers_terrain.vsh", &m),
            &preprocess(&pack, "gbuffers_terrain.fsh", &m),
            Target::Buffers,
            &game,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let names: Vec<&str> = p
            .interface
            .uniforms
            .iter()
            .map(|u| u.name.as_str())
            .collect();
        for name in [
            "gbufferModelView",
            "gbufferProjection",
            "gbufferModelViewInverse",
        ] {
            assert!(names.contains(&name), "{name} missing from {names:?}");
        }
        assert_eq!(p.interface.outputs, vec![0, 1]);
        // renderStage is set per draw, in its own block.
        assert!(p.interface.draw && !names.contains(&"renderStage"));
        let per_draw = p.fragment.global_variables.iter().any(|(_, v)| {
            v.binding
                .as_ref()
                .is_some_and(|b| b.group == 2 && b.binding == 0)
        });
        assert!(per_draw);
        let inputs: Vec<&str> = p.vertex.entry_points[0]
            .function
            .arguments
            .iter()
            .filter_map(|a| a.name.as_deref())
            .collect();
        assert!(
            inputs.contains(&"game_pos") && inputs.contains(&"game_uv"),
            "{inputs:?}"
        );
        // From the light, the compatibility matrices are the shadow camera's.
        let shadow = translate_shadow(
            &preprocess(&pack, "gbuffers_terrain.vsh", &m),
            &preprocess(&pack, "gbuffers_terrain.fsh", &m),
            &game,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let names: Vec<&str> = (shadow.interface.uniforms.iter())
            .map(|u| u.name.as_str())
            .collect();
        for name in ["shadowModelView", "shadowProjection", "gbufferModelView"] {
            assert!(names.contains(&name), "{name} missing from {names:?}");
        }
    }

    #[test]
    fn matrix_and_array_varyings_travel_in_parts() {
        let vsh = "#version 120\nvarying mat3 tbn;\nflat varying ivec2 ids[2];\nvarying mat2x3 m[2];\n\
                   void main() {\n    gl_Position = ftransform();\n    tbn = mat3(2.0);\n    \
                   ids[1] = ivec2(3);\n    m[1][0] = vec3(4.0);\n}\n";
        let fsh = "#version 120\nvarying mat3 tbn;\nflat varying ivec2 ids[2];\nvarying mat2x3 m[2];\n\
                   void main() { gl_FragColor = vec4(tbn[2] + m[1][0], float(ids[1].x)); }\n";
        let p = program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let inputs = p.fragment.entry_points[0].function.arguments.len();
        // 3 columns + 2 elements + 2 x 2 columns, and the fragment position.
        assert!(inputs >= 9, "{inputs} inputs");
        assert_eq!(
            varying_parts("flat ivec2 @[2];").unwrap().1,
            [
                ("flat ivec2 @;".to_owned(), "[0]".to_owned()),
                ("flat ivec2 @;".to_owned(), "[1]".to_owned())
            ]
        );
        assert_eq!(varying_parts("mat2x3 @[2];").unwrap().1[3].1, "[1][1]");
        assert!(varying_parts("vec4 @;").is_none());
        assert!(varying_parts("vec4 @[N];").is_none());
    }

    #[test]
    fn sized_array_types_initialize_globals() {
        let fsh = "#version 400\nuniform float k;\nivec3[2] offsets = ivec3[](ivec3(1, 0, 0), ivec3(0, int(k), 0));\n\
                   out vec4 c;\nvoid main() { c = vec4(offsets[1], 1.0); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    #[test]
    fn struct_varyings_travel_packed() {
        let lib = "struct Light { vec3 color; float power; int id; mat2 m; float k[2]; };\n";
        let vsh = "#version 400\n#include \"/lib.glsl\"\nflat out Light light;\nvoid main() {\n    \
                   gl_Position = ftransform();\n    light.color = vec3(1.0);\n    light.id = 2;\n}\n";
        let fsh = "#version 400\n#include \"/lib.glsl\"\nflat in Light light;\nout vec4 c;\n\
                   void main() { c = vec4(light.color * light.power * light.m[1].x * light.k[1], float(light.id)); }\n";
        let p = program(
            &[
                ("lib.glsl", lib),
                ("composite.vsh", vsh),
                ("composite.fsh", fsh),
            ],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        // color and power, the matrix's columns, the array, and the int: four slots.
        let inputs = p.fragment.entry_points[0].function.arguments.len();
        assert_eq!(inputs, 4, "{inputs} inputs");
        let structs = std::collections::HashMap::from([(
            "S".to_owned(),
            vec![
                ("vec3".to_owned(), "a".to_owned()),
                ("int".to_owned(), "i".to_owned()),
                ("float".to_owned(), "b[2]".to_owned()),
            ],
        )]);
        assert_eq!(
            struct_parts("S @;", &structs).unwrap(),
            [
                (
                    "vec4 @;".to_owned(),
                    vec![
                        (".xyz".to_owned(), ".a".to_owned()),
                        (".w".to_owned(), ".b[0]".to_owned())
                    ]
                ),
                (
                    "flat int @;".to_owned(),
                    vec![(String::new(), ".i".to_owned())]
                ),
                (
                    "float @;".to_owned(),
                    vec![(String::new(), ".b[1]".to_owned())]
                ),
            ]
        );
        let bools = std::collections::HashMap::from([(
            "B".to_owned(),
            vec![("bool".to_owned(), "b".to_owned())],
        )]);
        assert!(struct_parts("B @;", &bools).is_none());
    }

    #[test]
    fn vulkan_type_names_are_free_names() {
        let fsh = "#version 400\nuniform sampler2D colortex0;\nout vec4 c;\n\
                   vec4 fetch(sampler2D sampler, vec2 p) { return texture(sampler, p); }\n\
                   void main() { float texture2D = 1.0; c = fetch(colortex0, vec2(0.5)) * texture2D; }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    #[test]
    fn gathers_and_vertex_texture_reads_translate() {
        let vsh = "#version 400\nuniform sampler2D colortex1;\nout vec3 tint;\nvoid main() {\n    \
                   gl_Position = ftransform();\n    tint = texture(colortex1, vec2(0.5)).rgb;\n}\n";
        let fsh = "#version 400\nuniform sampler2D colortex1;\nuniform sampler2D depthtex0;\nin vec3 tint;\nout vec4 c;\n\
                   struct S { float k[2]; };\n\
                   void main() {\n    const S s = S(float[2](1.0, 2.0));\n    \
                   vec4 d = textureGather(depthtex0, vec2(0.5)) + textureGather(colortex1, vec2(0.5), 3);\n    \
                   c = vec4(tint * vec3(d.x > 0.5) * s.k[1], float(ivec2(d.xy) % 2));\n}\n";
        program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    #[test]
    fn fields_and_elements_as_out_arguments_write_spirv() {
        let fsh = "#version 330\nstruct S { float a; vec2 b; };\nvoid f(out float x) { x = 0.5; }\n\
                   void main() { S s; float arr[2]; f(s.a); f(arr[1]); f(s.b.y);\n\
                   gl_FragData[0] = vec4(s.a, arr[1], s.b.y, 1.0); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        for module in [&p.vertex, &p.fragment] {
            let info = Validator::new(ValidationFlags::all(), Capabilities::all())
                .validate(module)
                .unwrap();
            let entry = &module.entry_points[0];
            let pipeline = naga::back::spv::PipelineOptions {
                shader_stage: entry.stage,
                entry_point: entry.name.clone(),
            };
            naga::back::spv::write_vec(module, &info, &Default::default(), Some(&pipeline))
                .unwrap();
        }
    }

    /// `textureGatherOffsets` (GLSL 4.60, 8.9.4), which naga lacks: offsets from a `const`
    /// array or a constructor, a component, an unsigned texture and the depth compare form, in a
    /// pack function that takes the sampler too; every form must reach SPIR-V.
    #[test]
    fn shadow_depth_reads_through_a_plain_sampler_translate() {
        // One function given a colour buffer and a shadow depth, direct reads with a level, a
        // texel offset and a projection, and a local named like a depth sampler elsewhere.
        let fsh = "#version 330 compatibility\nuniform sampler2D colortex0;\n\
                   uniform sampler2D shadowtex1;\nuniform sampler2D shadow;\n\
                   vec4 tap(sampler2D s, vec2 p) {\n    \
                   return texture2D(s, p) + texture2DLod(s, p, 0.0) + texture2DProj(s, vec3(p, 1.0));\n}\n\
                   float lit(vec2 p) { float shadow = texture2D(shadowtex1, p).r; return shadow * 0.5; }\n\
                   void main() {\n    vec2 uv = gl_FragCoord.xy / 64.0;\n    \
                   gl_FragData[0] = tap(colortex0, uv) + tap(shadowtex1, uv) + texture(shadow, uv)\n        \
                   + textureOffset(shadow, uv, ivec2(1, 0)) + textureProj(shadow, vec4(uv, 0.0, 1.0))\n        \
                   + vec4(lit(uv));\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let info = Validator::new(ValidationFlags::all(), Capabilities::all())
            .validate(&p.fragment)
            .unwrap();
        let entry = &p.fragment.entry_points[0];
        let pipeline = naga::back::spv::PipelineOptions {
            shader_stage: entry.stage,
            entry_point: entry.name.clone(),
        };
        naga::back::spv::write_vec(&p.fragment, &info, &Default::default(), Some(&pipeline))
            .unwrap();
    }

    #[test]
    fn texture_gather_offsets_translate() {
        let fsh = "#version 430\nuniform sampler2D colortex0;\nuniform usampler2D colortex5;\n\
                   uniform sampler2DShadow shadowtex0;\nout vec4 c;\n\
                   const ivec2 ring[4] = ivec2[4](ivec2(-1, 0), ivec2(1, 0), ivec2(0, -1), ivec2(0, 1));\n\
                   float edge(sampler2D s, vec2 uv) { return textureGatherOffsets(s, uv, ring, 3).x; }\n\
                   void main() {\n    vec2 uv = gl_FragCoord.xy / 64.0;\n    \
                   vec4 a = textureGatherOffsets(colortex0, uv, ring);\n    \
                   uvec4 b = textureGatherOffsets(colortex5, uv,\n        \
                   ivec2[4](ivec2(0), ivec2(2, 0), ivec2(0, 2), ivec2(2)), 1);\n    \
                   vec4 d = textureGatherOffsets(shadowtex0, uv, 0.5, ring);\n    \
                   c = a + vec4(b) + d + edge(colortex0, uv);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let info = Validator::new(ValidationFlags::all(), Capabilities::all())
            .validate(&p.fragment)
            .unwrap();
        let entry = &p.fragment.entry_points[0];
        let pipeline = naga::back::spv::PipelineOptions {
            shader_stage: entry.stage,
            entry_point: entry.name.clone(),
        };
        naga::back::spv::write_vec(&p.fragment, &info, &Default::default(), Some(&pipeline))
            .unwrap();
        // A program that doesn't call it gets none of it.
        let plain = program(
            &[
                ("composite.vsh", VSH_120),
                (
                    "composite.fsh",
                    "#version 120\nvoid main() { gl_FragColor = vec4(1.0); }\n",
                ),
            ],
            Target::Buffers,
        )
        .unwrap();
        assert!(
            !plain
                .fragment
                .functions
                .iter()
                .any(|(_, f)| f.name.as_deref() == Some("hz_textureGatherOffsets"))
        );
    }

    /// `textureQueryLod` (GLSL 4.60, 8.9.1), which naga lacks, on 2D, 3D and integer samplers
    /// and through a pack function that takes the sampler: every form reaches SPIR-V, and a
    /// program that doesn't call it gets none of it.
    #[test]
    fn texture_query_lod_translates() {
        let fsh = "#version 430\nuniform sampler2D colortex0;\nuniform sampler3D lut;\n\
                   uniform usampler2D colortex5;\nout vec4 c;\n\
                   float level(sampler2D s, vec2 uv) { return textureQueryLod(s, uv).x; }\n\
                   void main() {\n    vec2 uv = gl_FragCoord.xy / 64.0;\n    \
                   vec2 a = textureQueryLod(colortex0, uv);\n    \
                   vec2 b = textureQueryLod(lut, vec3(uv, 0.5));\n    \
                   vec2 d = textureQueryLod(colortex5, uv);\n    \
                   c = vec4(a + b + d, level(colortex0, uv), 1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let info = Validator::new(ValidationFlags::all(), Capabilities::all())
            .validate(&p.fragment)
            .unwrap();
        let entry = &p.fragment.entry_points[0];
        let pipeline = naga::back::spv::PipelineOptions {
            shader_stage: entry.stage,
            entry_point: entry.name.clone(),
        };
        naga::back::spv::write_vec(&p.fragment, &info, &Default::default(), Some(&pipeline))
            .unwrap();
        let plain = program(
            &[
                ("composite.vsh", VSH_120),
                (
                    "composite.fsh",
                    "#version 120\nvoid main() { gl_FragColor = vec4(1.0); }\n",
                ),
            ],
            Target::Buffers,
        )
        .unwrap();
        assert!(
            !plain
                .fragment
                .functions
                .iter()
                .any(|(_, f)| f.name.as_deref() == Some("hz_textureQueryLod"))
        );
    }

    /// A `return` with code after it in its block (Miniature's hand: `#ifdef GBUFFERS_HAND
    /// return 0.5 * diffuse; #endif` and the rest of the function), which naga's frontend
    /// leaves half-built.
    #[test]
    fn early_returns_with_values_translate() {
        let fsh = "#version 120\nuniform sampler2D shadowtex1;\nuniform mat4 shadowModelView;\n\
                   float len2(vec3 v) { return dot(v, v); }\n\
                   float f(float d, vec3 p) {\n    d *= 2.0;\n    return 0.5 * d;\n    \
                   vec3 q = p * len2(p);\n    vec4 v = shadowModelView * vec4(q, 1.0);\n    \
                   if (dot(q, q) < 4.0 && d > 0.0 && v.z < 1.0) {\n        \
                   float s = texture2D(shadowtex1, v.st).x;\n        return d * s / shadowModelView[2].z;\n    }\n    \
                   return d;\n}\nvoid main() { gl_FragColor = vec4(f(0.5, vec3(1.0))); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// A non-void function whose only `return` has unreachable code after it and no trailing
    /// return at the end of the block (which naga would otherwise end with `return;` without a value).
    #[test]
    fn early_return_without_trailing_return_translates() {
        let fsh = "#version 120\n\
                   vec3 exposure(vec3 color) {\n    return color * 3.5;\n    int x = 1;\n}\n\
                   void main() { gl_FragColor = vec4(exposure(vec3(1.0)), 1.0); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// GLSL's `dot` and `normalize` take a `float` too (genType); naga's take vectors only. A
    /// pack's own `dot` is kept.
    #[test]
    fn scalar_dot_and_normalize_translate() {
        let fsh = "#version 330\nuniform float k;\nout vec4 c;\n\
                   void main() { c = vec4(dot(k, 2.0), normalize(k - 0.5), dot(vec2(k), vec2(1.0)), 1.0); }\n";
        let own = "#version 330\nuniform float k;\nout vec4 c;\nfloat dot(float a, float b) { return a + b; }\n\
                   void main() { c = vec4(dot(k, 2.0)); }\n";
        for fsh in [fsh, own] {
            program(
                &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
                Target::Buffers,
            )
            .unwrap_or_else(|e| panic!("{fsh}: {e:?}"));
        }
    }

    /// GL_AMD_shader_trinary_minmax adds `min3`, `max3` and `mid3` for genType, genIType and
    /// genUType; naga has none of them. A pack's own `max3` is kept, with or without the
    /// extension (glslangValidator takes both).
    #[test]
    fn trinary_min_max_translate() {
        let ext = "#extension GL_AMD_shader_trinary_minmax : require\n";
        let calls = "uniform float k;\nuniform int i;\nuniform uint u;\nout vec4 c;\n\
                     void main() {\n    vec3 v = vec3(k, 0.5, 0.25);\n    \
                     float f = min3(k, 0.5, 0.25) + max3(v.xy, v.yz, v.zx).y + mid3(v, v.yzx, v.zxy).z\n        \
                     + mid3(vec4(k), vec4(0.5), vec4(1.0)).w;\n    \
                     ivec2 n = max3(ivec2(i), ivec2(2), ivec2(-1)) + ivec2(mid3(i, 3, 7), min3(ivec4(i), ivec4(1), ivec4(2)).x);\n    \
                     uvec3 m = min3(uvec3(u), uvec3(2u), uvec3(9u)) + mid3(u, 4u, 8u) + max3(uvec4(u), uvec4(1u), uvec4(5u)).xyz;\n    \
                     c = vec4(f, float(n.x + n.y), float(m.x), mid3(1.0, 2.0, 3.0));\n}\n";
        let own = "uniform float k;\nout vec4 c;\n\
                   float max3(float a, float b, float c) { return max(a, max(b, c)); }\n\
                   void main() { c = vec4(max3(k, 0.5, 0.25)); }\n";
        for fsh in [
            format!("#version 330\n{ext}{calls}"),
            format!("#version 330\n{ext}{own}"),
            format!("#version 330\n{own}"),
        ] {
            program(
                &[("composite.vsh", VSH_120), ("composite.fsh", &fsh)],
                Target::Buffers,
            )
            .unwrap_or_else(|e| panic!("{fsh}: {e:?}"));
        }
        let csh = format!(
            "#version 430\n{ext}layout(local_size_x = 1) in;\n\
             layout(std430, binding = 0) buffer B {{ uvec2 data; }} b;\n\
             void main() {{ b.data = uvec2(max3(b.data.x, 2u, 3u), min3(b.data, uvec2(1u), uvec2(4u)).y); }}\n"
        );
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/composite.csh", &csh)])).unwrap();
        translate_compute(&preprocess(&pack, "composite.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// GLSL converts a returned value to the function's type (Kappa's `GetEmissionScale`):
    /// `return 1;` in a `float` function, an `int` or `ivec2` returned as `float` or `vec2`.
    #[test]
    fn returns_convert_to_the_function_type() {
        let fsh = "#version 330\nuniform int k;\nout vec4 c;\n\
                   float one() { return 1; }\nfloat twice(int a) { return a * 2 + 1; }\n\
                   vec2 cell() { ivec2 p = ivec2(k, 3); return p; }\n\
                   float unsigned_value() { uint u = 3u; return u; }\n\
                   float early(float x) {\n    if (x > 0.5) return 2;\n    return x;\n}\n\
                   void main() { c = vec4(one() + twice(k), cell(), unsigned_value() + early(0.7)); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// Returns that are an `if`'s branches, last in a function that returns a value (TAA's
    /// `ClipAABB` in BSL, Complementary and Solas): naga ends such tail blocks with a `return`
    /// of its own, which must not land in a guard of ours.
    #[test]
    fn returns_as_branches_stay_plain() {
        let fsh = "#version 120\nuniform float k;\n\
                   vec3 clip(vec3 a, vec3 b) {\n    vec3 d = b - a;\n    \
                   if (k > 1.0) return a + d / k;\n    else return b;\n}\n\
                   float pick(float x) {\n    if (x > 0.5) { return 1.0; }\n    return x;\n}\n\
                   void main() { gl_FragColor = vec4(clip(vec3(0.0), vec3(1.0)), pick(k)); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// A vertex stage that redeclares `gl_PerVertex` and whose block instance shares its name
    /// with a function's parameter: it still writes the position, and the
    /// block still reaches the fragment stage.
    #[test]
    fn a_per_vertex_redeclaration_and_a_parameter_named_like_the_instance() {
        let vsh = "#version 460\nout gl_PerVertex { vec4 gl_Position; };\n\
                   float luma(vec3 v) { return dot(v, vec3(0.3, 0.6, 0.1)); }\n\
                   out VertexData {\n    layout(location = 1, component = 0) vec2 coord;\n} v;\n\
                   void main() { v.coord = vec2(luma(vec3(1.0))); gl_Position = vec4(0.0, 0.0, 0.5, 1.0); }\n";
        let fsh = "#version 460\nin VertexData {\n    layout(location = 1, component = 0) vec2 coord;\n} v;\n\
                   /* RENDERTARGETS: 0 */\nlayout(location = 0) out vec4 c;\n\
                   void main() { c = vec4(v.coord, 0.0, 1.0); }\n";
        program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// Interface blocks between the stages may give members their own interpolation (GLSL 4.60,
    /// 4.3.9; Shrimple's gbuffers programs): a `flat` member arrives flat.
    #[test]
    fn interface_block_members_keep_their_qualifiers() {
        let vsh = "#version 330 compatibility\nout VertexData {\n    flat int id;\n    vec2 uv;\n} vOut;\n\
                   void main() { gl_Position = ftransform(); vOut.id = 3; vOut.uv = vec2(0.5); }\n";
        let fsh = "#version 330 compatibility\nin VertexData {\n    flat int id;\n    vec2 uv;\n} vIn;\n\
                   void main() { gl_FragData[0] = vec4(float(vIn.id), vIn.uv, 1.0); }\n";
        let p = program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let entry = &p.fragment.entry_points[0].function;
        let mut flats = 0;
        for arg in &entry.arguments {
            let bindings: Vec<&naga::Binding> = match &p.fragment.types[arg.ty].inner {
                naga::TypeInner::Struct { members, .. } => {
                    members.iter().filter_map(|m| m.binding.as_ref()).collect()
                }
                _ => arg.binding.iter().collect(),
            };
            for b in bindings {
                if let naga::Binding::Location {
                    interpolation: Some(naga::Interpolation::Flat),
                    ..
                } = b
                {
                    flats += 1;
                }
            }
        }
        assert_eq!(flats, 1, "one flat input, `id`");
    }

    /// A function that returns a value may reach its end without a `return` (GLSL 4.60, 6.1:
    /// the value is undefined): after a loop (Lux's `MaxIdx`), an `if` without `else`, a
    /// `switch` without `default`; it returns zero there. A function ending in its own
    /// `return` keeps it.
    #[test]
    fn functions_reaching_their_end_return_zero() {
        let fsh = "#version 330\nuniform int k;\nout vec4 c;\n\
                   struct S { float a; ivec2 b; };\n\
                   float after_loop(float x) {\n    for (int i = 0; i < 4; i++) {\n        \
                   if (x > float(i)) return float(i);\n    }\n}\n\
                   vec3 after_if(float x) { if (x > 0.5) return vec3(x); }\n\
                   int after_switch() { switch (k) { case 0: return 1; case 1: return 2; } }\n\
                   S after_struct(float x) { if (x > 0.5) { return S(x, ivec2(k)); } }\n\
                   float own(float x) { return x * 2.0; }\n\
                   void main() {\n    float x = float(k) * 0.25;\n    \
                   c = vec4(after_loop(x) + after_if(x).x, float(after_switch()), \
                   after_struct(x).a, own(x));\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let zero_returns = |name: &str| {
            let (_, f) = (p.fragment.functions.iter())
                .find(|(_, f)| f.name.as_deref() == Some(name))
                .unwrap_or_else(|| panic!("{name} missing"));
            fn count(f: &naga::Function, b: &naga::Block) -> usize {
                b.iter()
                    .map(|s| match s {
                        naga::Statement::Return { value: Some(v) } => matches!(
                            f.expressions[*v],
                            naga::Expression::ZeroValue(t) if Some(t) == f.result.as_ref().map(|r| r.ty)
                        )
                        .into(),
                        naga::Statement::Block(b) => count(f, b),
                        naga::Statement::If { accept, reject, .. } => {
                            count(f, accept) + count(f, reject)
                        }
                        naga::Statement::Switch { cases, .. } => {
                            cases.iter().map(|c| count(f, &c.body)).sum()
                        }
                        naga::Statement::Loop { body, continuing, .. } => {
                            count(f, body) + count(f, continuing)
                        }
                        _ => 0,
                    })
                    .sum()
            }
            count(f, &f.body)
        };
        for name in ["after_loop", "after_if", "after_switch", "after_struct"] {
            assert!(zero_returns(name) > 0, "{name}: its end returns no zero");
        }
        assert_eq!(zero_returns("own"), 0, "own: its own return was replaced");
    }

    /// A function may be declared again (GLSL 4.60, 6.1), before or after its definition: Bloop
    /// includes the same helper's prototype from two files.
    #[test]
    fn functions_declared_again_translate() {
        let fsh = "#version 330\nuniform float k;\nout vec4 c;\n\
                   float f(float x);\nfloat f(float x);\nvec2 g(vec2 v, float s);\n\
                   float f(float x) { return x * 2.0; }\nfloat f(float x);\n\
                   vec2 g(vec2 v, float s) { return v * s; }\nvec2 g(vec2 v,\n       float s);\n\
                   void main() { c = vec4(f(k), g(vec2(k), 3.0), 1.0); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        for name in ["f", "g"] {
            assert!(
                (p.fragment.functions.iter()).any(|(_, f)| f.name.as_deref() == Some(name)),
                "{name} missing"
            );
        }
    }

    /// A prototype declared again leaves the lines after it where they were: an error below it
    /// still names its own line.
    #[test]
    fn errors_after_a_prototype_declared_again_keep_their_line() {
        let fsh = "#version 330\nout vec4 c;\nfloat f(float x);\nfloat f(float x\n);\n\
                   float f(float x) { return x; }\nvoid main() { c = vec4(f(nowhere)); }\n";
        let errors = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .err()
        .expect("`nowhere` is not declared");
        assert!(
            errors
                .iter()
                .all(|e| e.line == 7 && e.message.contains("nowhere")),
            "{errors:?}"
        );
    }

    /// `if (c) return; else ...` keeps its `else`: the statements the translation guards with
    /// `if (true)` must not take an `else` that belongs to the pack's `if`.
    #[test]
    fn else_stays_with_its_if() {
        let fsh = "#version 120\nuniform float k;\n\
                   void g(inout float x) { if (k > 0.5) return; else x = 3.0; }\n\
                   float h(float x) { if (k > 0.5) return 1.0; else x = 2.0; return x; }\n\
                   void main() {\n    float x = 0.0;\n    g(x);\n    \
                   if (k > 0.9) discard; else x += h(x);\n    gl_FragColor = vec4(x);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        // Our guards are `if (true)`: one with an `else` took the pack's.
        fn guard_with_else(f: &naga::Function, body: &naga::Block) -> bool {
            body.iter().any(|s| match s {
                naga::Statement::If {
                    condition,
                    accept,
                    reject,
                } => {
                    let ours = matches!(
                        f.expressions[*condition],
                        naga::Expression::Literal(naga::Literal::Bool(true))
                    );
                    // naga ends a void function's tail blocks with a `return` of its own.
                    let pack_code = reject.iter().any(|s| {
                        !matches!(s, naga::Statement::Return { .. } | naga::Statement::Emit(_))
                    });
                    (ours && pack_code) || guard_with_else(f, accept) || guard_with_else(f, reject)
                }
                naga::Statement::Block(b) => guard_with_else(f, b),
                _ => false,
            })
        }
        for name in ["g", "h", "hz_main"] {
            let f = p
                .fragment
                .functions
                .iter()
                .find(|(_, f)| f.name.as_deref() == Some(name))
                .map(|(_, f)| f)
                .unwrap_or_else(|| panic!("{name} missing"));
            assert!(
                !guard_with_else(f, &f.body),
                "{name}: the pack's else moved into our if (true)"
            );
        }
    }

    #[test]
    fn a_pack_keeps_its_own_inverse() {
        let fsh = "#version 120\nuniform mat4 gbufferProjection;\n\
                   mat4 inverse(mat4 m) { return m; }\n\
                   void main() { gl_FragData[0] = inverse(gbufferProjection) * vec4(1.0); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// Outputs with `component` qualifiers share one location (GLSL 4.60, 4.4.2): one target
    /// at that location. The shapes glslangValidator rejects stay errors.
    #[test]
    fn outputs_sharing_a_location_by_component_are_one_target() {
        let fsh = "#version 440\nlayout(location = 0, component = 0) out float r;\n\
                   layout(location = 0, component = 1) out vec3 gba;\n\
                   layout(location = 1, component = 1) out uvec3 words;\n\
                   void main() { r = 0.0; gba = vec3(1.0, 0.0, 1.0); words = uvec3(1u); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        assert_eq!(p.interface.outputs, [0, 1]);
        let result = p.fragment.entry_points[0].function.result.as_ref().unwrap();
        let naga::TypeInner::Struct { members, .. } = &p.fragment.types[result.ty].inner else {
            panic!("two outputs are a struct");
        };
        let targets: Vec<_> = members
            .iter()
            .map(|m| (m.binding.clone(), p.fragment.types[m.ty].inner.clone()))
            .collect();
        assert_eq!(targets.len(), 2, "{targets:?}");
        for (location, scalar) in [(0, naga::Scalar::F32), (1, naga::Scalar::U32)] {
            assert!(
                targets.iter().any(|(binding, ty)| matches!(
                    binding,
                    Some(naga::Binding::Location { location: l, .. }) if *l == location
                ) && *ty
                    == naga::TypeInner::Vector {
                        size: naga::VectorSize::Quad,
                        scalar
                    }),
                "{targets:?}"
            );
        }
        for (outputs, name) in [
            (
                "layout(location = 0) out vec2 a; layout(location = 0, component = 1) out float b;",
                "b",
            ),
            (
                "layout(location = 0) out uint a; layout(location = 0, component = 1) out vec3 b;",
                "b",
            ),
            ("layout(location = 0, component = 2) out vec3 a;", "a"),
        ] {
            let fsh = format!("#version 440\n{outputs}\nvoid main() {{}}\n");
            let errors = program(
                &[("composite.vsh", VSH_120), ("composite.fsh", &fsh)],
                Target::Buffers,
            )
            .err()
            .unwrap_or_else(|| panic!("{outputs} translated"));
            assert!(
                errors
                    .iter()
                    .any(|e| e.message.contains(&format!("`{name}`"))),
                "{outputs}: {errors:?}"
            );
        }
    }

    #[test]
    fn narrow_outputs_widen_and_inverse_is_ours() {
        let fsh = "#version 400\nlayout(location = 0) out vec3 color;\nlayout(location = 1) out float depth;\n\
                   uniform mat4 gbufferProjection;\nuniform mat3 m3;\n\
                   void main() { color = (inverse(gbufferProjection) * vec4(1.0)).xyz * inverse(m3)[0]; depth = 0.5; }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let outputs: Vec<_> = p.fragment.entry_points[0]
            .function
            .result
            .iter()
            .flat_map(|r| match &p.fragment.types[r.ty].inner {
                naga::TypeInner::Struct { members, .. } => {
                    members.iter().map(|m| m.ty).collect::<Vec<_>>()
                }
                _ => vec![r.ty],
            })
            .map(|ty| p.fragment.types[ty].inner.clone())
            .collect();
        assert!(
            outputs.iter().all(|t| matches!(
                t,
                naga::TypeInner::Vector {
                    size: naga::VectorSize::Quad,
                    ..
                }
            )),
            "{outputs:?}"
        );
        assert!(p.fragment.functions.iter().all(|(_, f)| {
            f.expressions.iter().all(|(_, e)| {
                !matches!(
                    e,
                    naga::Expression::Math {
                        fun: naga::MathFunction::Inverse,
                        ..
                    }
                )
            })
        }));
    }

    /// A `shared` variable whose struct type has no name (GLSL 4.60, 4.1.8), as compute
    /// programs keep their work group's tiles.
    #[test]
    fn a_shared_struct_without_a_type_name_compiles() {
        let csh = "#version 460\nlayout(local_size_x = 8, local_size_y = 8) in;\n\
                   shared struct {\n    uint sum;\n    uint tile[gl_WorkGroupSize.x][gl_WorkGroupSize.y];\n} lds;\n\
                   layout(r32ui) uniform uimage2D colorimg4;\nvoid main() {\n    \
                   lds.tile[gl_LocalInvocationID.x][gl_LocalInvocationID.y] = gl_LocalInvocationIndex;\n    \
                   barrier();\n    imageStore(colorimg4, ivec2(gl_GlobalInvocationID.xy), uvec4(lds.tile[1][1]));\n}\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
    }

    #[test]
    fn buffer_blocks_bind_at_their_binding() {
        let csh = "#version 430\nlayout(local_size_x = 1) in;\n\
                   layout(std430, binding = 2) readonly restrict buffer Lights { uint count; vec4 data[]; } lights;\n\
                   layout(std430, binding = 5) buffer Counts { uint n[]; };\n\
                   void main() { n[0] = 1u; }\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        let c = translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
        assert_eq!(c.interface.buffers, [2, 5]);
        let missing = "#version 430\nlayout(local_size_x = 1) in;\nlayout(std430) buffer B { uint n; };\nvoid main() {}\n";
        let pack =
            Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", missing)])).unwrap();
        let errors = translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .err()
            .unwrap();
        assert!(errors[0].message.contains("needs a binding"), "{errors:?}");
    }

    #[test]
    fn atomics_on_shared_vector_components_compile() {
        let csh = "#version 430\nlayout(local_size_x = 4) in;\nshared ivec4 sums;\nshared uvec2 lights[8];\n\
                   layout(r32i) uniform iimage2D colorimg5;\nvoid main() {\n    \
                   if (gl_LocalInvocationIndex == 0u) sums = ivec4(0);\n    barrier();\n    \
                   atomicAdd(sums.y, 1);\n    atomicMax(lights[gl_LocalInvocationIndex].x, 2u);\n    \
                   sums += ivec4(1);\n    lights[gl_LocalInvocationIndex] += uvec2(1u);\n    \
                   uvec2 l = lights[gl_LocalInvocationIndex];\n    barrier();\n    \
                   imageStore(colorimg5, ivec2(0), ivec4(sums.y + int(lights[1].x + l.y)));\n}\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// The std430 offsets of the members of the buffer block at `binding`, by the names the
    /// pack gave them (a split vector's `_hz` dropped, our padding left out), and its size.
    fn buffer_layout(module: &naga::Module, binding: u32) -> (Vec<(String, u32)>, u32) {
        let (_, global) = module
            .global_variables
            .iter()
            .find(|(_, g)| g.binding.as_ref().is_some_and(|b| b.binding == binding))
            .expect("the block");
        let ty = &module.types[global.ty];
        let naga::TypeInner::Struct { members, span } = &ty.inner else {
            panic!("{ty:?}");
        };
        let members = members
            .iter()
            .filter_map(|m| {
                let name = m.name.as_deref()?;
                (!name.starts_with("hz_pad_"))
                    .then(|| (name.trim_end_matches("_hz").to_owned(), m.offset))
            })
            .collect();
        (members, *span)
    }

    /// Atomic functions on a component of a buffer block's vector, which GLSL 4.60 8.11 allows
    /// (our probe pack's shape, in a composite vertex stage): the program translates, and the
    /// block keeps the std430 layout the fragment stage, which uses no atomics, gives it.
    #[test]
    fn atomics_on_buffer_vector_components_compile_and_keep_the_layout() {
        let block = "layout(std430, binding = 2) restrict buffer probeSums { uint n; uvec2 a; uvec3 c[2]; uint m; uvec2 b; } sums;\n";
        let vsh = format!(
            "#version 430 compatibility\n{block}out vec2 uv;\nvoid main() {{\n    \
             atomicAdd(sums.a.x, 1u);\n    atomicMax(sums.b.y, uint(gl_VertexID));\n    \
             atomicOr(sums.c[gl_VertexID & 1].z, 2u);\n    sums.a += uvec2(1u);\n    \
             uv = vec2(sums.a.y + sums.c[1].x, sums.c.length());\n    gl_Position = ftransform();\n}}\n"
        );
        let fsh = format!(
            "#version 430 compatibility\n{block}in vec2 uv;\nvoid main() {{\n    \
             gl_FragData[0] = vec4(vec2(sums.a), vec2(sums.b)) + uv.x + float(sums.m + sums.c[0].z);\n}}\n"
        );
        let p = program(
            &[("composite.vsh", &vsh), ("composite.fsh", &fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let expected: Vec<(String, u32)> = [("n", 0), ("a", 8), ("c", 16), ("m", 48), ("b", 56)]
            .map(|(n, o)| (n.to_owned(), o))
            .into();
        assert_eq!(buffer_layout(&p.fragment, 2), (expected.clone(), 64));
        assert_eq!(buffer_layout(&p.vertex, 2), (expected, 64));
    }

    /// A block without an instance name: its member is named alone.
    #[test]
    fn atomics_on_vector_components_of_an_unnamed_buffer_block_compile() {
        let csh = "#version 430\nlayout(local_size_x = 4) in;\n\
                   layout(std430, binding = 1) buffer Counts { ivec4 counts; };\n\
                   void main() {\n    atomicAdd(counts.w, 1);\n    ivec4 c = counts;\n    counts = c + 1;\n}\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
    }

    /// Atomic functions on a component of a shared vector, whatever its declaration: alone, in a
    /// declaration of several names, a member of a shared struct (with whole-vector stores and
    /// reads, or atomics only). The forms of #9085's probe; glslang accepts all of them.
    #[test]
    fn atomics_on_shared_vector_components_compile_in_lists_and_structs() {
        let forms = [
            (
                "shared ivec3 mn;\nshared ivec3 mx;\n",
                "atomicMin(mn.x, i);\n    atomicMax(mx.x, i);",
            ),
            (
                "shared ivec3 mn, mx;\n",
                "atomicMin(mn.x, i);\n    atomicMax(mx.x, i);",
            ),
            (
                "shared struct { ivec3 mn; uint other; } sh;\n",
                "if (i == 0) sh.mn = ivec3(1000);\n    barrier();\n    atomicMin(sh.mn.x, i);\n    \
                 barrier();\n    ivec3 r = sh.mn;\n    sh.other = uint(r.x);",
            ),
            (
                "shared struct { ivec3 mn; uint other; } sh;\n",
                "atomicMin(sh.mn.x, i);",
            ),
        ];
        for (decl, body) in forms {
            let csh = format!(
                "#version 460 core\nlayout(local_size_x = 8) in;\n{decl}void main() {{\n    \
                 int i = int(gl_LocalInvocationIndex);\n    {body}\n}}\n"
            );
            let pack =
                Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", &csh)])).unwrap();
            let p = translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
                .unwrap_or_else(|e| panic!("{csh}\n{e:?}"));
            // The struct keeps its other member; the vector's components are atomic.
            if decl.contains("struct") {
                let (_, sh) = p
                    .module
                    .global_variables
                    .iter()
                    .find(|(_, g)| g.space == naga::AddressSpace::WorkGroup)
                    .expect("the shared struct");
                let naga::TypeInner::Struct { members, .. } = &p.module.types[sh.ty].inner else {
                    panic!("{:?}", p.module.types[sh.ty]);
                };
                let inner = |m: &naga::StructMember| p.module.types[m.ty].inner.clone();
                let [mn, other] = &members[..] else {
                    panic!("{members:?}")
                };
                let naga::TypeInner::Array { base, size, .. } = inner(mn) else {
                    panic!("{mn:?}")
                };
                assert_eq!(size, naga::ArraySize::Constant(3.try_into().unwrap()));
                assert!(matches!(
                    p.module.types[base].inner,
                    naga::TypeInner::Atomic(naga::Scalar::I32)
                ));
                assert!(matches!(
                    inner(other),
                    naga::TypeInner::Scalar(naga::Scalar::U32)
                ));
            }
        }
    }

    /// A stage's `#version` may come from a header it includes: the program is that version
    /// (`shared` is a keyword in GLSL 4.30, not a name to rename).
    #[test]
    fn the_version_may_come_from_an_included_header() {
        let csh = "#include \"/prelude/core.glsl\"\nlayout(local_size_x = 4) in;\n\
                   shared uint counts[4];\nlayout(r32ui) uniform uimage2D colorimg4;\n\
                   void main() {\n    counts[gl_LocalInvocationIndex] = 1u;\n    barrier();\n    \
                   imageStore(colorimg4, ivec2(0), uvec4(counts[1]));\n}\n";
        let pack = Pack::from_zip_bytes(
            "P.zip",
            zip(&[
                ("shaders/deferred_a.csh", csh),
                ("shaders/prelude/core.glsl", "#version 460 core\n"),
            ]),
        )
        .unwrap();
        let pp = preprocess(&pack, "deferred_a.csh", &Macros::standard());
        assert_eq!(pp.version, Some((460, Some("core".into()))));
        translate_compute(&pp).unwrap_or_else(|e| panic!("{e:?}"));
    }

    #[test]
    fn work_group_size_is_its_layout() {
        let csh = "#version 430\nlayout(local_size_x = 8, local_size_y = 4) in;\n\
                   layout(r32ui) uniform uimage2D colorimg4;\nvoid main() {\n    \
                   imageStore(colorimg4, ivec2(gl_WorkGroupSize.xy), uvec4(gl_WorkGroupSize.z));\n}\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        let c = translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
        let main = &c
            .module
            .functions
            .iter()
            .find(|f| f.1.name.as_deref() == Some("hz_main"))
            .unwrap()
            .1;
        assert!(
            main.expressions
                .iter()
                .any(|(_, e)| matches!(e, naga::Expression::Literal(naga::Literal::U32(8))))
        );
        // A constant expression (GLSL 4.60, 4.4) is worked out, also where naga reads it.
        assert_eq!(
            work_group_size(
                "layout(local_size_x = min(gl_MaxComputeWorkGroupSize.x, 256 * 2), local_size_y = (3 + 1) / 2) in;\n\
                 uvec3 s = gl_WorkGroupSize;"
            )
            .as_deref(),
            Ok("layout(local_size_x = 512, local_size_y = 2) in;\nuvec3 s = uvec3(512u, 2u, 1u);")
        );
        assert_eq!(
            work_group_size("layout(local_size_x = SIZE) in;\nvoid main() {}"),
            Err("`local_size_x` is not a size Horizon can work out".into())
        );
        assert!(
            work_group_size("layout(local_size_x = 16) in;\nuvec3 s = gl_WorkGroupSize;")
                .is_ok_and(|c| c.contains("uvec3(16u, 1u, 1u)"))
        );
    }

    /// A work group size given as a constant expression (GLSL 4.60, 4.4 and 4.4.1), kept within
    /// the implementation's: the program compiles with its value.
    #[test]
    fn a_work_group_size_may_be_a_constant_expression() {
        let csh = "#version 460\nlayout(local_size_x = min(gl_MaxComputeWorkGroupSize.x, 256), \
                   local_size_y = 1, local_size_z = 1) in;\n\
                   layout(r32ui) uniform uimage2D colorimg4;\n\
                   void main() { imageStore(colorimg4, ivec2(gl_GlobalInvocationID.xy), uvec4(1u)); }\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        let c = translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
        let entry = &c.module.entry_points[0];
        assert_eq!(entry.workgroup_size, [256, 1, 1]);
    }

    #[test]
    fn compute_programs_translate() {
        let csh = "#version 430\nlayout(local_size_x = 64) in;\nconst ivec3 workGroups = ivec3(2, 1, 1);\n\
                   layout(rgba16f) writeonly uniform image2D colorimg4;\nuniform sampler2D colortex4;\n\
                   uniform float frameTimeCounter;\nshared vec3 sums[64];\nvoid main() {\n    \
                   uint i = gl_LocalInvocationID.x;\n    sums[i] = texelFetch(colortex4, ivec2(i, 0), 0).rgb * frameTimeCounter;\n    \
                   barrier();\n    if (i == 0u) imageStore(colorimg4, ivec2(0), vec4(sums[0] + subgroupAdd(sums[1]), 1.0));\n}\n";
        let pack = Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", csh)])).unwrap();
        let c = translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
            .unwrap_or_else(|e| panic!("{e:?}"));
        assert_eq!(c.work_groups, Some([2, 1, 1]));
        assert_eq!(c.work_groups_render, [1.0, 1.0]);
        let render = |decl: &str| {
            let csh =
                format!("#version 430\nlayout(local_size_x = 8) in;\n{decl}\nvoid main() {{}}\n");
            let pack =
                Pack::from_zip_bytes("P.zip", zip(&[("shaders/deferred_a.csh", &csh)])).unwrap();
            translate_compute(&preprocess(&pack, "deferred_a.csh", &Macros::standard()))
                .map(|c| c.work_groups_render)
                .map_err(|e| e[0].message.clone())
        };
        assert_eq!(
            render("const vec2 workGroupsRender = vec2(0.5, 0.25);"),
            Ok([0.5, 0.25])
        );
        assert_eq!(
            render("const vec3 workGroupsRender = vec3(0.5, 1.0, 1.0);"),
            Ok([0.5, 1.0])
        );
        assert!(render("const float workGroupsRender = 0.5;").is_err());
        assert_eq!(c.module.entry_points[0].workgroup_size, [64, 1, 1]);
        let i = &c.interface;
        assert_eq!(
            (i.samplers[0].binding, i.images[0].binding),
            (1, 3),
            "{:?}",
            i.images
        );
        assert_eq!(
            (i.images[0].format.as_str(), i.images[0].access.as_str()),
            ("rgba16f", "writeonly")
        );
    }

    #[test]
    fn locals_may_hide_a_sampler() {
        let fsh = "#version 120\nuniform sampler2D specular;\nstruct M { float specular; };\n\
                   float f(float x) { float specular = x * 2.0; return specular; }\n\
                   void main() { M m = M(0.5); gl_FragColor = texture2D(specular, vec2(0.5)) * f(m.specular); }\n";
        program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
    }

    #[test]
    fn errors_point_at_the_pack_file_and_line() {
        let fsh =
            "#version 120\n#include \"/lib/bad.glsl\"\nvoid main() { gl_FragColor = vec4(f()); }\n";
        let bad = "// fine\nfloat f() {\n    return undefinedThing;\n}\n";
        let errors = program(
            &[
                ("composite.vsh", VSH_120),
                ("composite.fsh", fsh),
                ("lib/bad.glsl", bad),
            ],
            Target::Buffers,
        )
        .err()
        .unwrap();
        assert_eq!(
            (errors[0].file.as_str(), errors[0].line),
            ("lib/bad.glsl", 3),
            "{errors:?}"
        );
    }

    /// Swizzled scalars, GLSL 4.20's (Kappa's weather map: `noise(p).x`).
    #[test]
    fn scalar_swizzles_translate() {
        let fsh = "#version 430\nout vec4 color;\nfloat noise(vec2 p) { return fract(p.x * 3.1); }\n\
                   void main() {\n    float a = noise(gl_FragCoord.xy * 0.1).x;\n    float s = a.r * 2.0;\n    \
                   vec2 w = s.xx + noise(vec2(a)).ss;\n    color = vec4(w, a, s);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// `x / 0.0` and `sqrt(-1.0)` are GL's infinity and NaN at run time; naga folds them into
    /// constants and refuses them (Mellow, Bloop). `texelFetch2D` is GL_EXT_gpu_shader4's name
    /// (Bliss).
    #[test]
    fn infinities_nans_and_old_fetches_translate() {
        let fsh = "#version 330\nuniform sampler2D noisetex;\nout vec4 color;\nvoid main() {\n    \
                   ivec2 t = ivec2(gl_FragCoord.xy);\n    \
                   color = texelFetch2D(noisetex, t, 0) + vec4(-1.0 / 0.0) + vec4(sqrt(-1.0));\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// A matrix varying's column written by component, and `uint` with integer literals in
    /// `max`, `min` and `clamp` (Kappa, Hysteria).
    #[test]
    fn matrix_columns_and_unsigned_overloads_translate() {
        let vsh = "#version 330 compatibility\nout mat2x2 uv;\nvoid main() {\n    \
                   uv = mat2x2(gl_MultiTexCoord0.xy, gl_MultiTexCoord1.xy);\n    \
                   uv[1].y = uv[1].y * 0.5;\n    gl_Position = ftransform();\n}\n";
        let fsh = "#version 330\nin mat2x2 uv;\nout vec4 color;\nvoid main() {\n    uint n = 3u;\n    \
                   uint s = max(n, 1);\n    s = min(s, 32) + uint(clamp(n, 0, 7));\n    \
                   color = vec4(uv[0], uv[1]) / float(s);\n}\n";
        let p = program(
            &[("composite.vsh", vsh), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// `const`s that call a built-in naga's constant evaluator lacks (`mix`, `smoothstep`...)
    /// are evaluated where the program runs: a global by our `main`, a local in place (Bliss).
    #[test]
    fn constants_naga_cannot_fold_are_evaluated_at_run_time() {
        let fsh = "#version 120\nvarying vec2 texcoord;\nconst vec3 tint = mix(vec3(0.2), vec3(1.0), 0.25);\n\
                   const float edge = smoothstep(0.0, 1.0, 0.5), mid = 0.5;\n\
                   float shade(float x) {\n    const float k = mix(0.5, 1.0, 0.3);\n    return x * k;\n}\n\
                   void main() { gl_FragColor = vec4(tint * shade(texcoord.x) * edge * mid, 1.0); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// `const` parameters (`const in float x`, which naga's parser refuses) translate.
    #[test]
    fn const_parameters_translate() {
        let fsh = "#version 120\nvarying vec2 texcoord;\n\
                   float lift(const in float x) { return x * 2.0; }\n\
                   vec2 both(const in vec2 a, const vec2 b, out float c) { c = a.x; return a + b; }\n\
                   float twice(const in float x);\n\
                   float twice(const in float x) { return lift(x); }\n\
                   void main() { float c; vec2 v = both(texcoord, vec2(lift(0.5)), c); \
                   gl_FragColor = vec4(v, twice(c), 1.0); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// Arrays of arrays nest as GL reads them in every spelling: naga's frontend reverses
    /// `T x[A][B]`, `T[A][B]`, struct members and parameters, so `x[2][1]` of a `float[3][2]`
    /// would index past the inner array.
    #[test]
    fn arrays_of_arrays_keep_their_order() {
        let fsh = "#version 330\nout vec4 color;\nfloat m[3][2];\nfloat[2] n[3];\n\
                   struct S { float a[4][2]; };\nfloat f(float x[3][2]) { return x[2][1]; }\n\
                   void main() {\n    float k[3][2];\n    k[2][1] = 1.0;\n    m[2][1] = f(k);\n    \
                   n[2][1] = float[3][2](float[2](1.0, 2.0), float[2](3.0, 4.0), float[2](5.0, 6.0))[2][1];\n    \
                   S s;\n    s.a[3][1] = 2.0;\n    color = vec4(m[2][1], n[2][1], s.a[3][1], 1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap();
        let outer = |name: &str| {
            let (_, g) = (p.fragment.global_variables.iter())
                .find(|(_, g)| g.name.as_deref() == Some(name))
                .unwrap();
            match p.fragment.types[g.ty].inner {
                naga::TypeInner::Array { size, .. } => size,
                ref t => panic!("{t:?}"),
            }
        };
        let size = |n: u32| naga::ArraySize::Constant(std::num::NonZeroU32::new(n).unwrap());
        assert_eq!(outer("m"), size(3));
        assert_eq!(outer("n"), size(3));
    }

    /// A local named like the sampler parameter it reads in its own initializer (Potato's
    /// depth-aware blur), and like a global sampler.
    #[test]
    fn locals_named_like_samplers_read_them_first() {
        let fsh = "#version 330\nuniform sampler2D colortex1;\nuniform sampler2D depthtex0;\n\
                   uniform sampler2D colortex2;\nin vec2 uv;\nout vec4 color;\n\
                   vec3 blur(sampler2D tex, sampler2D depth, vec2 c) {\n    vec3 s = vec3(0.0);\n    \
                   for (int i = 0; i < 2; i++) {\n        float depth = texture(depth, c).x;\n        \
                   s += texture(tex, c).rgb * depth;\n    }\n    return s;\n}\n\
                   void main() {\n    float colortex2 = texture(colortex2, uv).x;\n    \
                   color = vec4(blur(colortex1, depthtex0, uv) * colortex2, 1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// A sampler named `texture`, called with the function of the same name (Bloop).
    #[test]
    fn samplers_named_like_functions_translate() {
        let fsh = "#version 330\nuniform sampler2D texture;\nin vec2 uv;\nout vec4 color;\n\
                   void main() {\n    color = texture(texture, uv) + texture(texture, uv, -1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// Parameters and locals named like a bool uniform hide it (GLSL 4.60, 4.2): the uniform is
    /// only rewritten where it is the name in scope, and a prototype's parameter ends with it.
    #[test]
    fn parameters_and_locals_named_like_bool_uniforms_hide_them() {
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   float f(in bool hideGUI) { return hideGUI ? 1.0 : 0.0; }\n\
                   float g() { bool hideGUI = gl_FragCoord.x > 0.5; return hideGUI ? 2.0 : 0.0; }\n\
                   float h(bool hideGUI);\n\
                   void main() { c = vec4(f(true), g(), h(false), hideGUI ? 1.0 : 0.0); }\n\
                   float h(bool hideGUI) { return hideGUI ? 3.0 : 0.0; }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        let arg = |name: &str| {
            let (_, f) = (p.fragment.functions.iter())
                .find(|(_, f)| f.name.as_deref() == Some(name))
                .unwrap();
            f.arguments[0].name.clone()
        };
        assert_eq!(arg("f").as_deref(), Some("hideGUI"));
        assert_eq!(arg("h").as_deref(), Some("hideGUI"));
        assert!(p.interface.uniforms.iter().any(|u| u.name == "hideGUI"));
        // `main` reads the uniform as an int compared with zero; `f`, `g` and `h` do not.
        assert!(reads_bool_uniform(&p));
        for name in ["f", "g", "h"] {
            let (_, func) = (p.fragment.functions.iter())
                .find(|(_, f)| f.name.as_deref() == Some(name))
                .unwrap();
            let uses = func.expressions.iter().any(|(_, e)| {
                matches!(
                    e,
                    naga::Expression::Binary {
                        op: naga::BinaryOperator::NotEqual,
                        ..
                    }
                )
            });
            assert!(!uses, "{name} read the uniform instead of its own hideGUI");
        }
    }

    /// A struct member and a member access named like a bool uniform stay plain.
    #[test]
    fn members_named_like_bool_uniforms_stay_plain() {
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   struct S { bool hideGUI; float x; };\n\
                   float f(S v) { return v.hideGUI ? 1.0 : 0.0; }\n\
                   void main() { S s = S(true, 1.0); c = vec4(f(s), hideGUI ? 1.0 : 0.0, 0.0, 1.0); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        assert!(reads_bool_uniform(&p));
    }

    /// Whether `hz_main` compares an int uniform with zero (a bool uniform read).
    fn reads_bool_uniform(p: &Program) -> bool {
        let (_, main) = (p.fragment.functions.iter())
            .find(|(_, f)| f.name.as_deref() == Some("hz_main"))
            .unwrap();
        main.expressions.iter().any(|(_, e)| {
            matches!(
                e,
                naga::Expression::Binary {
                    op: naga::BinaryOperator::NotEqual,
                    ..
                }
            )
        })
    }

    /// A `for` header's variable (and a second declarator) hide the uniform to the loop's end.
    #[test]
    fn for_header_and_second_declarators_hide_bool_uniforms() {
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   void main() {\n    float t = 0.0;\n    \
                   for (bool hideGUI = false; t < 2.0; t += 1.0) { t += hideGUI ? 1.0 : 0.0; }\n    \
                   for (int i = 0, hideGUI = 3; i < 2; i++) { t += float(hideGUI); }\n    \
                   bool a = true, hideGUI = false, b = a;\n    t += hideGUI ? 1.0 : 0.0;\n    \
                   c = vec4(t, b ? 1.0 : 0.0, 0.0, 1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        assert!(!reads_bool_uniform(&p), "the local hides the uniform");
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   void main() {\n    float t = 0.0;\n    \
                   for (bool hideGUI = false; t < 2.0; t += 1.0) { t += hideGUI ? 1.0 : 0.0; }\n    \
                   for (int i = 0, k = 3; i < 2; i++) { t += float(k); }\n    \
                   c = vec4(t, hideGUI ? 1.0 : 0.0, 0.0, 1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        assert!(reads_bool_uniform(&p), "the uniform is back after the loop");
    }

    /// A `for` loop with a single-statement body: its variable hides the uniform to the `;`.
    #[test]
    fn unbraced_for_body_ends_the_hiding_at_its_statement() {
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   void main() {\n    float t = 0.0;\n    \
                   for (bool hideGUI = false; t < 2.0; t += 1.0) t += hideGUI ? 1.0 : 0.0;\n    \
                   c = vec4(t, hideGUI ? 1.0 : 0.0, 0.0, 1.0);\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        )
        .unwrap_or_else(|e| panic!("{e:?}"));
        assert!(reads_bool_uniform(&p));
        // The body is a `return`, which the translator rewrites on its own.
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   float f(float t) {\n    \
                   for (bool hideGUI = false; t < 2.0; t += 1.0) return hideGUI ? 1.0 : t;\n    \
                   return hideGUI ? 1.0 : 0.0;\n}\n\
                   void main() { c = vec4(f(0.0)); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// A sampler parameter's name reused as a local of an inner block, then read again.
    #[test]
    fn sampler_parameter_is_back_after_the_block_of_a_local() {
        let fsh = "#version 330\nuniform sampler2D colortex1;\nin vec2 uv;\nout vec4 color;\n\
                   vec4 f(sampler2D tex, vec2 c) {\n    vec4 r = vec4(0.0);\n    \
                   if (c.x > 0.5) { float tex = 2.0; r += vec4(tex); }\n    \
                   return r + texture(tex, c);\n}\n\
                   void main() { color = f(colortex1, uv); }\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        assert!(p.is_ok(), "{:?}", p.err());
    }

    /// A local in an inner block hides the uniform only to the block's end.
    #[test]
    fn bool_uniform_is_back_after_the_block_of_a_local() {
        let fsh = "#version 330\nuniform bool hideGUI;\nout vec4 c;\n\
                   void main() {\n    c = vec4(0.0);\n    \
                   if (gl_FragCoord.x > 0.5) { bool hideGUI = true; c.r = hideGUI ? 1.0 : 0.0; }\n    \
                   c.a = hideGUI ? 1.0 : 0.0;\n}\n";
        let p = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fsh)],
            Target::Buffers,
        );
        let p = p.unwrap_or_else(|e| panic!("{e:?}"));
        assert!(
            reads_bool_uniform(&p),
            "the uniform is back after the block"
        );
    }

    #[test]
    fn storage_buffer_extension_keeps_the_legacy_buffer_keyword() {
        let fragment = "#version 130\n#extension GL_ARB_shader_storage_buffer_object : enable\nlayout(std430,binding=0) readonly buffer Data{uvec4 cells[4];}data;void main(){gl_FragColor=vec4(data.cells[0]);}";
        let result = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fragment)],
            Target::Window,
        );
        assert!(result.is_ok(), "{:?}", result.err());
    }
    #[test]
    fn ordinary_legacy_buffer_identifiers_still_translate() {
        let fragment = "#version 120\nvoid main(){float buffer=0.5;gl_FragColor=vec4(buffer);}";
        let result = program(
            &[("composite.vsh", VSH_120), ("composite.fsh", fragment)],
            Target::Window,
        );
        assert!(result.is_ok(), "{:?}", result.err());
    }
}

#[cfg(test)]
mod image_parameter_tests {
    use crate::{Macros, Pack, preprocess, translate_compute};
    #[test]
    fn nested_image_helpers_specialize_multiple_storage_formats() {
        let src = "#version 430\nlayout(local_size_x=1)in;layout(rgba16f) uniform image3D imageA;layout(r32f) uniform image3D imageB;void write_value(writeonly image3D img,ivec3 p){imageStore(img,p,vec4(0.5));}\nvoid nested(image3D img,ivec3 p){write_value(img,p);}\nvoid main(){nested(imageA,ivec3(0));nested(imageB,ivec3(0));}";
        let pack = Pack::from_zip_bytes(
            "formats.zip",
            crate::pack::tests::zip(&[("shaders/setup.csh", src)]),
        )
        .unwrap();
        let result = translate_compute(&preprocess(&pack, "setup.csh", &Macros::standard()));
        assert!(result.is_ok(), "{:?}", result.err());
    }
}

#[cfg(test)]
mod mixed_integer_bounds_tests {
    #[test]
    fn compute_clamp_with_signed_index_and_unsigned_bounds_compiles() {
        let source = "#version 430\nlayout(local_size_x=1) in; layout(std430,binding=0) buffer Data{uint result;};void main(){int index=int(gl_LocalInvocationID.x);result=clamp(index,0u,47u);}";
        let pack = crate::Pack::from_zip_bytes(
            "integer-bounds.zip",
            crate::pack::tests::zip(&[("shaders/setup.csh", source)]),
        )
        .unwrap();
        let stage = crate::preprocess(&pack, "setup.csh", &crate::Macros::standard());
        let result = crate::translate_compute(&stage);
        assert!(result.is_ok(), "{:?}", result.err());
    }
}
