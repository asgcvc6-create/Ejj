//! The second pass: the stage's code written again for naga, line for line, and the
//! declarations of ours it needs.

use std::collections::{BTreeMap, HashMap};
use std::fmt::Write;

use naga::ShaderStage;

use super::scan::{
    LATER_KEYWORDS, NOT_CONSTANT, Stage, UNIFORM_STATE, VERTEX_INPUTS, is_ident, is_sampler_type,
    significant,
};
use super::{Sampler, split_sampler};

/// `inverse` for each square matrix: the adjugate over the determinant.
const INVERSE: &str = "mat2 hz_inverse(mat2 m) { return mat2(m[1][1], -m[0][1], -m[1][0], m[0][0]) / determinant(m); }\n\
    mat3 hz_inverse(mat3 m) { vec3 r0 = cross(m[1], m[2]); vec3 r1 = cross(m[2], m[0]); vec3 r2 = cross(m[0], m[1]); \
    return transpose(mat3(r0, r1, r2)) / dot(m[0], r0); }\n\
    mat4 hz_inverse(mat4 m) {\
    float a00 = m[0][0], a01 = m[0][1], a02 = m[0][2], a03 = m[0][3], a10 = m[1][0], a11 = m[1][1], a12 = m[1][2], a13 = m[1][3];\
    float a20 = m[2][0], a21 = m[2][1], a22 = m[2][2], a23 = m[2][3], a30 = m[3][0], a31 = m[3][1], a32 = m[3][2], a33 = m[3][3];\
    float b00 = a00 * a11 - a01 * a10, b01 = a00 * a12 - a02 * a10, b02 = a00 * a13 - a03 * a10, b03 = a01 * a12 - a02 * a11;\
    float b04 = a01 * a13 - a03 * a11, b05 = a02 * a13 - a03 * a12, b06 = a20 * a31 - a21 * a30, b07 = a20 * a32 - a22 * a30;\
    float b08 = a20 * a33 - a23 * a30, b09 = a21 * a32 - a22 * a31, b10 = a21 * a33 - a23 * a31, b11 = a22 * a33 - a23 * a32;\
    float det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;\
    return mat4(a11 * b11 - a12 * b10 + a13 * b09, a02 * b10 - a01 * b11 - a03 * b09, a31 * b05 - a32 * b04 + a33 * b03, a22 * b04 - a21 * b05 - a23 * b03,\
    a12 * b08 - a10 * b11 - a13 * b07, a00 * b11 - a02 * b08 + a03 * b07, a32 * b02 - a30 * b05 - a33 * b01, a20 * b05 - a22 * b02 + a23 * b01,\
    a10 * b10 - a11 * b08 + a13 * b06, a01 * b08 - a00 * b10 - a03 * b06, a30 * b04 - a31 * b02 + a33 * b00, a21 * b02 - a20 * b04 - a23 * b00,\
    a11 * b07 - a10 * b09 - a12 * b06, a00 * b09 - a01 * b07 + a02 * b06, a31 * b01 - a30 * b03 - a32 * b00, a20 * b03 - a21 * b01 + a22 * b00) / det; }\n";

impl Stage<'_> {
    /// Declarations of ours this stage uses (after the uniform block, samplers and varyings).
    pub(super) fn prelude(&self) -> String {
        let mut p = String::from(
            "float hz_modf(float x, out float i) { i = trunc(x); return x - i; }\n\
             vec2 hz_modf(vec2 x, out vec2 i) { i = trunc(x); return x - i; }\n\
             vec3 hz_modf(vec3 x, out vec3 i) { i = trunc(x); return x - i; }\n\
             vec4 hz_modf(vec4 x, out vec4 i) { i = trunc(x); return x - i; }\n\
             float hz_sqrt(float x) { return sqrt(max(x, 0.0)); }\n\
             vec2 hz_sqrt(vec2 x) { return sqrt(max(x, vec2(0.0))); }\n\
             vec3 hz_sqrt(vec3 x) { return sqrt(max(x, vec3(0.0))); }\n\
             vec4 hz_sqrt(vec4 x) { return sqrt(max(x, vec4(0.0))); }\n\
             struct hz_FogParameters { vec4 color; float density; float start; float end; float scale; };\n\
             hz_FogParameters hz_Fog;\n\
             float hz_zero = 0.0;\n",
        );
        if self.inverse {
            p.push_str(INVERSE);
        }
        if self.gather_offsets {
            p.push_str(&gather_offsets());
        }
        if self.tokens.iter().any(|t| DEPTH_NAMES.contains(t)) {
            p.push_str(DEPTH_FILTER);
        }
        // Helpers for the integer samplers declared, where a texture call could read one.
        if self.tokens.iter().any(|t| integer_call(t).is_some()) {
            let mut types: Vec<_> = self
                .tokens
                .iter()
                .filter_map(|t| integer_sampler(t))
                .collect();
            types.sort_unstable();
            types.dedup();
            p.push_str(&integer_texture(&types));
        }
        if self.query_lod {
            p.push_str(&query_lod());
        }
        // GLSL's scalar `dot` and `normalize` (genType includes `float`); naga's are vector only.
        if self.scalar_dot {
            p.push_str("float dot(float a, float b) { return a * b; }\n");
        }
        if self.scalar_normalize {
            p.push_str("float normalize(float x) { return sign(x); }\n");
        }
        for name in &self.trinary {
            p.push_str(&trinary(name));
        }
        if self.gbuffers {
            // Set by our `main` from the frame's matrices (gbuffers.rs).
            p.push_str(
                "mat4 hz_ModelViewMatrix; mat4 hz_ProjectionMatrix; mat4 hz_ModelViewProjectionMatrix;\n\
                 mat4 hz_ModelViewMatrixInverse; mat4 hz_ProjectionMatrixInverse; mat3 hz_NormalMatrix; mat4 hz_TextureMatrix[8];\n",
            );
        } else {
            p.push_str(
                "const mat4 hz_ModelViewMatrix = mat4(1.0); const mat4 hz_ProjectionMatrix = mat4(2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0, -1.0, -1.0, 0.0, 1.0);\n\
                 const mat4 hz_ModelViewProjectionMatrix = hz_ProjectionMatrix; const mat4 hz_ModelViewMatrixInverse = mat4(1.0); const mat3 hz_NormalMatrix = mat3(1.0);\n\
                 const mat4 hz_ProjectionMatrixInverse = mat4(0.5, 0.0, 0.0, 0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0, 0.5, 0.5, 0.0, 1.0);\n\
                 const mat4 hz_TextureMatrix[8] = mat4[8](mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0), mat4(1.0));\n",
            );
        }
        if self.kind == ShaderStage::Vertex {
            p.push_str(
                "const vec2 hz_quad[6] = vec2[6](vec2(0.0, 0.0), vec2(1.0, 0.0), vec2(1.0, 1.0), vec2(0.0, 0.0), vec2(1.0, 1.0), vec2(0.0, 1.0));\n\
                 vec4 hz_Vertex; vec4 hz_Color; vec4 hz_SecondaryColor; vec3 hz_Normal; float hz_FogCoord;\n\
                 vec4 hz_MultiTexCoord0; vec4 hz_MultiTexCoord1; vec4 hz_MultiTexCoord2; vec4 hz_MultiTexCoord3;\n\
                 vec4 hz_MultiTexCoord4; vec4 hz_MultiTexCoord5; vec4 hz_MultiTexCoord6; vec4 hz_MultiTexCoord7;\n",
            );
        } else if self.kind == ShaderStage::Fragment {
            for n in &self.outputs {
                if !self.frag_outs.iter().any(|(at, _)| at == n) {
                    writeln!(p, "layout(location = {n}) out vec4 hz_out{n};").unwrap();
                }
            }
            for (_, decl) in &self.frag_outs {
                writeln!(p, "{decl}").unwrap();
            }
            p.push_str("vec4 hz_FragCoord;\n");
        }
        p
    }

    /// The pack's code with the rewrites above; the same number of lines.
    pub(super) fn rewrite(
        &self,
        samplers: &[Sampler],
        uniforms: &BTreeMap<String, String>,
    ) -> String {
        let removed = |i: usize| self.removed.iter().any(|r| r.contains(&i));
        let sampler_ty: HashMap<&str, &str> = samplers
            .iter()
            .map(|s| (s.name.as_str(), s.ty.as_str()))
            .collect();
        let old = self.pp.version.as_ref().is_none_or(|(v, _)| *v < 400);
        let fragment = self.kind == ShaderStage::Fragment;
        let mut out = String::with_capacity(self.pp.code.len() + 1024);
        // Per open bracket: the function called, and the closing text to add.
        let mut calls: Vec<(&str, &str, usize)> = Vec::new();
        // Sampler parameters of the function being written: name → type.
        let mut params: HashMap<String, String> = HashMap::new();
        // Names of samplers, bool uniforms and lowered arrays a local or parameter hides.
        // Each with where its scope starts and the block depth it ends with.
        let mut hidden: Vec<(&str, usize, i32)> = Vec::new();
        // Depths of the `for` loops whose body is a single statement, ending at its `;`.
        let mut unbraced_for: Vec<i32> = Vec::new();
        let mut depth = 0;
        let mut skip_until = 0;
        // The `;` that closes a statement we rewrite, and what is written in its place.
        let mut statement_close: Option<(usize, &str)> = None;
        // The type the function being written returns, when GLSL converts to it implicitly.
        let mut returns: Option<&str> = None;
        let next = |i: usize| (i + 1..self.tokens.len()).find(|&j| significant(self.tokens[j]));
        let prev = |i: usize| (0..i).rev().find(|&j| significant(self.tokens[j]));
        let structs: Vec<&str> = (self.tokens.iter().enumerate())
            .filter(|&(_, &t)| t == "struct")
            .filter_map(|(i, _)| next(i).map(|j| self.tokens[j]))
            .collect();
        // `shadowtex0`... (`DEPTH_NAMES`) as declared, read through a plain sampler: texture
        // calls on it go to our filtering helpers, the sampler followed by its flag: its
        // `hz_depth_linear` component, or for a parameter carrying one (`depth_scope`) its own.
        let depth_flag = |j: usize,
                          params: &HashMap<String, String>,
                          hidden: &[(&str, usize, i32)],
                          scope: &[&str]|
         -> Option<String> {
            let name = self.tokens[j];
            if hidden.iter().any(|&(h, from, _)| h == name && j >= from) {
                return None;
            }
            if scope.contains(&name) {
                return Some(format!("hz_l_{name}"));
            }
            let k = DEPTH_NAMES.iter().position(|&n| n == name)?;
            (sampler_ty.get(name) == Some(&"sampler2D") && !params.contains_key(name))
                .then(|| format!("hz_depth_linear.{}", ['x', 'y', 'z', 'w'][k]))
        };
        // The pack's functions given one of them as a whole sampler argument, and where: those
        // parameters carry its `hz_depth_linear` component too (`hz_l_`, -1 for other samplers).
        let mut depth_params: Vec<(&str, usize)> = Vec::new();
        {
            let mut open: Vec<(&str, usize)> = Vec::new();
            for (j, &tok) in self.tokens.iter().enumerate() {
                match tok {
                    "(" => open.push((prev(j).map_or("", |k| self.tokens[k]), 0)),
                    ")" => {
                        open.pop();
                    }
                    "," => {
                        if let Some(c) = open.last_mut() {
                            c.1 += 1;
                        }
                    }
                    _ if DEPTH_NAMES.contains(&tok)
                        && sampler_ty.get(tok) == Some(&"sampler2D")
                        && prev(j).is_some_and(|k| matches!(self.tokens[k], "(" | ","))
                        && next(j).is_some_and(|k| matches!(self.tokens[k], "," | ")")) =>
                    {
                        if let Some(&(callee, arg)) = open.last()
                            && self
                                .sampler_functions
                                .get(callee)
                                .is_some_and(|p| p.get(arg) == Some(&true))
                            && !depth_params.contains(&(callee, arg))
                        {
                            depth_params.push((callee, arg));
                        }
                    }
                    _ => {}
                }
            }
        }
        // Sampler parameters of the function being written that carry `hz_l_`.
        let mut depth_scope: Vec<&str> = Vec::new();
        // GLSL 1.20's user functions hide all built-ins with the same name (8).
        let mut own_size = Vec::new();
        let mut declaration_depth = 0usize;
        for (i, &t) in self.tokens.iter().enumerate() {
            match t {
                "{" => declaration_depth += 1,
                "}" => declaration_depth = declaration_depth.saturating_sub(1),
                "textureSize1D" | "textureSize2D" | "textureSize3D"
                    if declaration_depth == 0
                        && next(i).is_some_and(|j| self.tokens[j] == "(")
                        && prev(i)
                            .is_some_and(|j| is_ident(self.tokens[j]) || self.tokens[j] == "]") =>
                {
                    own_size.push(t);
                }
                _ => {}
            }
        }
        for (i, &t) in self.tokens.iter().enumerate() {
            if i < skip_until {
                continue;
            }
            if let Some((end, close)) = statement_close
                && end == i
            {
                out.push_str(close);
                statement_close = None;
                // This `;` may end the single-statement body of a `for`.
                if calls.is_empty() && unbraced_for.last() == Some(&depth) {
                    while unbraced_for.last() == Some(&depth) {
                        unbraced_for.pop();
                    }
                    hidden.retain(|&(_, _, d)| d <= depth);
                }
                continue;
            }
            if let Some(text) = self.replaced.get(&i) {
                out.push_str(text);
                continue;
            }
            if removed(i) {
                out.extend(t.chars().filter(|&c| c == '\n'));
                if t.contains(' ') && !t.contains('\n') {
                    out.push(' ');
                }
                continue;
            }
            let array_length = |j| {
                self.runtime_array_length(j).filter(|_| {
                    !hidden
                        .iter()
                        .any(|&(name, from, _)| name == self.tokens[j] && j >= from)
                })
            };
            if let Some((length, close)) = array_length(i) {
                write!(out, "({length})").unwrap();
                for t in &self.tokens[i..=close] {
                    out.extend(t.chars().filter(|&c| c == '\n'));
                }
                skip_until = close + 1;
                continue;
            }
            // Dimensions naga reads in reverse (`T x[A][B]`): written reversed, read as GL does.
            if t == "["
                && let Some(groups) = self.type_dimensions(i, &structs)
            {
                for &(open, close) in groups.iter().rev() {
                    if (open + 1..close).all(|j| !significant(self.tokens[j])) {
                        // type_dimensions only accepts an unsized outer dimension with
                        // an initializer whose element count is known.
                        write!(out, "[{}]", self.array_length(close).unwrap()).unwrap();
                    } else {
                        let mut j = open;
                        while j <= close {
                            if let Some((length, end)) = array_length(j) {
                                write!(out, "({length})").unwrap();
                                for t in &self.tokens[j..=end] {
                                    out.extend(t.chars().filter(|&c| c == '\n'));
                                }
                                j = end + 1;
                            } else {
                                out.push_str(self.tokens[j]);
                                j += 1;
                            }
                        }
                    }
                }
                for pair in groups.windows(2) {
                    for &gap in &self.tokens[pair[0].1 + 1..pair[1].0] {
                        out.extend(gap.chars().filter(|&c| c == '\n'));
                    }
                }
                skip_until = groups.last().map_or(i, |g| g.1) + 1;
                continue;
            }
            // `sqrt(-1.0)`: GL's NaN at run time, which naga would fold and refuse.
            if t == "sqrt"
                && let Some(open) = next(i).filter(|&j| self.tokens[j] == "(")
                && let Some(minus) = next(open).filter(|&j| self.tokens[j] == "-")
                && let Some(n) = next(minus).filter(|&j| {
                    self.tokens[j].starts_with(|c: char| c.is_ascii_digit() || c == '.')
                })
                && let Some(close) = next(n).filter(|&j| self.tokens[j] == ")")
                && !is_zero_literal(self.tokens[n])
            {
                out.push_str("(hz_zero / hz_zero)");
                skip_until = close + 1;
                continue;
            }
            // `x / 0.0`: GL's infinity at run time, which naga would fold and refuse.
            if t == "/"
                && let Some(j) = next(i).filter(|&j| is_zero_literal(self.tokens[j]))
            {
                out.push_str("/ hz_zero");
                skip_until = j + 1;
                continue;
            }
            // naga's frontend leaves the code after an unconditional `discard` or `return`
            // unreachable but half-built (a module that fails validation): behind an `if` it
            // stays reachable as far as naga knows. The braces keep a pack's `else` with the
            // pack's `if` (`if (c) discard; else ...`). A `return` with a value is guarded only
            // as a statement of its own with code after it in its block: as an `if`'s branch
            // the code after it is reachable already, and naga would end our guard's empty
            // `else` with a `return;` of its own where the function returns a value.
            // GLSL converts a returned value to the function's type (`return 1;` in a `float`
            // function); naga does not, so the conversion is written out: `return float(1);`.
            if matches!(t, "discard" | "return")
                && let Some(end) = self.statement_end(i)
            {
                let value = t == "return" && next(i) != Some(end);
                let guard = !value
                    || (prev(i).is_none_or(|j| matches!(self.tokens[j], ";" | "{" | "}"))
                        && next(end).is_some_and(|j| self.tokens[j] != "}"));
                let wrap = returns.filter(|_| value && !self.top_level_comma(i, end));
                if guard || wrap.is_some() {
                    if guard {
                        out.push_str("{ if (true) ");
                    }
                    out.push_str(t);
                    if let Some(ty) = wrap {
                        write!(out, " {ty}(").unwrap();
                    }
                    statement_close = Some((
                        end,
                        match (wrap.is_some(), guard) {
                            (true, true) => "); }",
                            (true, false) => ");",
                            (false, _) => "; }",
                        },
                    ));
                    continue;
                }
            }
            let called = next(i).is_some_and(|j| self.tokens[j] == "(");
            match t {
                "{" => {
                    if depth == 0 {
                        returns = self.converted_return(i);
                    }
                    depth += 1;
                }
                "}" => {
                    depth -= 1;
                    hidden.retain(|&(_, _, d)| d <= depth);
                    if depth == 0 {
                        params.clear();
                        depth_scope.clear();
                        hidden.clear();
                        returns = None;
                    }
                }
                ";" if calls.is_empty() && unbraced_for.last() == Some(&depth) => {
                    while unbraced_for.last() == Some(&depth) {
                        unbraced_for.pop();
                    }
                    hidden.retain(|&(_, _, d)| d <= depth);
                }
                // A prototype (`float h(bool x);`) ends its parameters' scope.
                ";" if depth == 0 && calls.is_empty() => {
                    hidden.clear();
                    params.clear();
                    depth_scope.clear();
                }
                "(" => {
                    let callee = prev(i).map_or("", |j| self.tokens[j]);
                    let close = if matches!(callee, "shadow2D" | "shadow2DLod" | "shadow2DProj") {
                        ")"
                    } else {
                        ""
                    };
                    calls.push((callee, close, 0));
                }
                ")" => {
                    if let Some((callee, close, _)) = calls.pop() {
                        out.push_str(close);
                        if callee == "for" && next(i).is_some_and(|j| self.tokens[j] != "{") {
                            unbraced_for.push(depth);
                        }
                    }
                }
                "," => {
                    if let Some(c) = calls.last_mut() {
                        c.2 += 1;
                    }
                }
                _ => {}
            }
            // `T x[] = T[](a, b)`: naga gives unsized arrays no size, so the count is written in.
            if t == "["
                && let Some(close) = next(i).filter(|&j| self.tokens[j] == "]")
            {
                if let Some(n) = self.array_length(close) {
                    write!(out, "[{n}]").unwrap();
                    skip_until = close + 1;
                    continue;
                }
            }
            if !is_ident(t) {
                out.push_str(t);
                continue;
            }
            // A local `const` that calls a built-in naga cannot evaluate: an ordinary local.
            if t == "const" && depth > 0 && self.calls_not_constant(i) {
                continue;
            }
            // A parameter's `const` (`const in float x`, which naga's parser refuses): it only
            // promises the function does not write the parameter.
            if t == "const" && depth == 0 && !calls.is_empty() {
                continue;
            }
            // A function definition's sampler parameters: `sampler2D s` → `texture2D s, sampler hz_s_s`.
            if depth == 0 && is_sampler_type(t) && calls.len() == 1 {
                if let Some(n) = next(i).filter(|&n| is_ident(self.tokens[n])) {
                    let name = self.tokens[n];
                    let (texture, sampler) = split_sampler(t);
                    write!(out, "{texture} {name}, {sampler} hz_s_{name}").unwrap();
                    if t == "sampler2D" && depth_params.contains(&(calls[0].0, calls[0].2)) {
                        write!(out, ", float hz_l_{name}").unwrap();
                        depth_scope.push(name);
                    }
                    params.insert(name.to_owned(), t.to_owned());
                    skip_until = n + 1;
                    continue;
                }
            }
            // `float specular`: a variable of the same name as a sampler or a sampler parameter,
            // from the end of its initializer to the function's end; `.specular` a member.
            if sampler_ty.contains_key(t)
                || params.contains_key(t)
                || uniforms.get(t).is_some_and(|ty| ty == "bool")
                || self.core_matrix(t).is_some()
                || ((depth > 0 || !calls.is_empty()) && self.runtime_array_lengths.contains_key(t))
            {
                let before = prev(i).map(|j| self.tokens[j]);
                if before == Some(".") {
                    out.push_str(t);
                    continue;
                }
                let declares = before
                    .is_some_and(|b| is_ident(b) && !matches!(b, "return" | "case" | "else"))
                    || (before == Some(",")
                        && (calls.is_empty() || calls.last().is_some_and(|c| c.0 == "for"))
                        && self.is_next_declarator(i));
                if declares {
                    // A `for` header's variable ends with the loop's block.
                    let ends = if calls.last().is_some_and(|c| c.0 == "for") {
                        depth + 1
                    } else {
                        depth.max(1)
                    };
                    hidden.push((t, self.scope_start(i), ends));
                    out.push_str(t);
                    continue;
                }
            }
            if hidden.iter().any(|&(h, from, _)| h == t && i >= from) {
                out.push_str(t);
                continue;
            }
            if let Some(matrix) = self.core_matrix(t) {
                out.push_str(matrix);
                continue;
            }
            // A sampler named like a function (`texture(texture, uv)`) is the function when called.
            let sampler = params
                .get(t)
                .map(String::as_str)
                .or_else(|| sampler_ty.get(t).copied())
                .filter(|_| !called);
            if sampler.is_some()
                && calls.last().is_some_and(|&(callee, _, arg)| {
                    arg == 0 && depth_call(callee, depth_scope.contains(&t)).is_some()
                })
                && prev(i).is_some_and(|j| self.tokens[j] == "(")
                && next(i).is_some_and(|j| self.tokens[j] == ",")
                && let Some(flag) = depth_flag(i, &params, &hidden, &depth_scope)
            {
                write!(out, "{t}, hz_s_{t}, {flag}").unwrap();
                continue;
            }
            // An integer sampler sampled as a float one is (`integer_call`): our helper takes its
            // texture and sampler.
            if let Some(ty) = sampler
                && integer_sampler(ty).is_some()
                && calls
                    .last()
                    .is_some_and(|&(callee, _, arg)| arg == 0 && integer_call(callee).is_some())
                && prev(i).is_some_and(|j| self.tokens[j] == "(")
                && next(i).is_some_and(|j| self.tokens[j] == ",")
            {
                write!(out, "{t}, hz_s_{t}").unwrap();
                continue;
            }
            if let Some(ty) = sampler {
                let as_argument = calls.last().is_some_and(|(callee, _, arg)| {
                    self.sampler_functions
                        .get(*callee)
                        .is_some_and(|p| p.get(*arg) == Some(&true))
                }) && prev(i)
                    .is_some_and(|j| matches!(self.tokens[j], "(" | ","));
                if as_argument {
                    write!(out, "{t}, hz_s_{t}").unwrap();
                    if let Some(&(callee, _, arg)) = calls.last()
                        && depth_params.contains(&(callee, arg))
                    {
                        let flag = depth_flag(i, &params, &hidden, &depth_scope)
                            .unwrap_or_else(|| "-1.0".into());
                        write!(out, ", {flag}").unwrap();
                    }
                } else {
                    write!(out, "{ty}({t}, hz_s_{t})").unwrap();
                }
                continue;
            }
            if uniforms.get(t).is_some_and(|ty| ty == "bool") {
                write!(out, "(hz_bool_{t} != 0)").unwrap();
                continue;
            }
            // EXT_gpu_shader4's size names keep their dimension-specific signatures. Resolve
            // only a known sampler, leaving user functions and mismatched dimensions to naga.
            let size_sampler = match t {
                "textureSize1D" => Some("sampler1D"),
                "textureSize2D" => Some("sampler2D"),
                "textureSize3D" => Some("sampler3D"),
                _ => None,
            };
            let legacy_size_call = size_sampler.is_some_and(|expected| {
                if !called || own_size.contains(&t) {
                    return false;
                }
                let mut argument = next(i).and_then(next);
                while let Some(j) = argument.filter(|&j| self.tokens[j] == "(") {
                    argument = next(j);
                }
                let Some(argument) = argument else {
                    return false;
                };
                let name = self.tokens[argument];
                if hidden
                    .iter()
                    .any(|&(h, from, _)| h == name && argument >= from)
                {
                    return false;
                }
                params
                    .get(name)
                    .map(String::as_str)
                    .or_else(|| sampler_ty.get(name).copied())
                    .is_some_and(|ty| ty.strip_prefix(['i', 'u']).unwrap_or(ty) == expected)
            });
            if called
                && let Some(a) = next(i).and_then(next)
                && let Some(helper) = depth_call(t, depth_scope.contains(&self.tokens[a]))
                && next(a).is_some_and(|j| self.tokens[j] == ",")
                && depth_flag(a, &params, &hidden, &depth_scope).is_some()
            {
                out.push_str(helper);
                continue;
            }
            if called
                && let Some(helper) = integer_call(t)
                && let Some(a) = next(i).and_then(next)
                && next(a).is_some_and(|j| self.tokens[j] == ",")
                && !hidden
                    .iter()
                    .any(|&(h, from, _)| h == self.tokens[a] && a >= from)
                && params
                    .get(self.tokens[a])
                    .map(String::as_str)
                    .or_else(|| sampler_ty.get(self.tokens[a]).copied())
                    .and_then(integer_sampler)
                    .is_some()
            {
                out.push_str(helper);
                continue;
            }
            let replaced: Option<String> = match t {
                "main" if depth == 0 && called => Some("hz_main".into()),
                // GLSL's `modf`, which naga's frontend lacks.
                "modf" if called => Some("hz_modf".into()),
                // `sqrt` of a negative is undefined in GLSL; GL drivers' rounding keeps packs'
                // `sqrt(1.0 - y * y)` at y = 1 from going below zero, SPIR-V's fused arithmetic
                // may not, and the NaN spreads (SEUS PTGI HRR: speckled water reflections).
                // Global initializers keep theirs: they are evaluated when compiling.
                "sqrt" if called && depth > 0 => Some("hz_sqrt".into()),
                "textureGatherOffsets" if called => Some("hz_textureGatherOffsets".into()),
                "textureQueryLod" if called => Some("hz_textureQueryLod".into()),
                // Matrix inverse, which naga writes for neither Metal nor WGSL.
                "inverse" if called && self.inverse => Some("hz_inverse".into()),
                "texture2D" | "texture1D" | "texture3D" | "textureCube" if called => {
                    Some("texture".into())
                }
                "texture2DLod" | "texture3DLod" | "texture2DLodARB" | "textureCubeLod"
                    if called =>
                {
                    Some("textureLod".into())
                }
                // GL_EXT_gpu_shader4's names (Bliss).
                "texelFetch1D" | "texelFetch2D" | "texelFetch3D" if called => {
                    Some("texelFetch".into())
                }
                "textureSize1D" | "textureSize2D" | "textureSize3D" if legacy_size_call => {
                    Some("textureSize".into())
                }
                "texture2DProj" if called => Some("textureProj".into()),
                "texture2DGrad" | "texture2DGradARB" if called => Some("textureGrad".into()),
                "shadow2D" if called => Some("vec4(texture".into()),
                "shadow2DLod" if called => Some("vec4(textureLod".into()),
                "shadow2DProj" if called => Some("vec4(textureProj".into()),
                "ftransform" if called => {
                    // `ftransform()` → the transform it stands for; its `()` stays as a no-op call... so skip it.
                    // The vertex goes through the model-view matrix first, then the projection:
                    // read back with a probe pack of ours, Iris 1.11.7's `ftransform()` has the
                    // bits of `gl_ProjectionMatrix * (gl_ModelViewMatrix * gl_Vertex)` at every
                    // vertex our probes read, where the product matrix
                    // `hz_ModelViewProjectionMatrix` rounds differently in the last bits (#8464).
                    let close = next(i).and_then(next);
                    skip_until = close.map_or(i + 1, |c| c + 1);
                    Some("(hz_ProjectionMatrix * (hz_ModelViewMatrix * hz_Vertex))".into())
                }
                "gl_FragColor" => Some("hz_out0".into()),
                "gl_FragData" | "gl_TexCoord" => match self.index_after(i) {
                    Some((n, close)) => {
                        skip_until = close + 1;
                        Some(match t {
                            "gl_FragData" => format!("hz_out{n}"),
                            _ => format!("hz_TexCoord{n}"),
                        })
                    }
                    None => None,
                },
                "gl_Color" if fragment => Some("hz_FrontColor".into()),
                "gl_FragCoord" if !fragment => None,
                "gl_FragCoord" => Some("hz_FragCoord".into()),
                "gl_FrontColor" => Some("hz_FrontColor".into()),
                "gl_FogFragCoord" => Some("hz_FogFragCoord".into()),
                "gl_Fog" => Some("hz_Fog".into()),
                // Before the compatibility inputs, of which `gl_Vertex` is a prefix.
                "gl_VertexID" => Some("gl_VertexIndex".into()),
                "gl_InstanceID" => Some("gl_InstanceIndex".into()),
                "gl_VertexIndex" | "gl_InstanceIndex" => None,
                _ if UNIFORM_STATE.iter().any(|b| t.starts_with(b)) => {
                    Some(format!("hz_{}", &t[3..]))
                }
                _ if !fragment && VERTEX_INPUTS.iter().any(|b| t.starts_with(b)) => {
                    Some(format!("hz_{}", &t[3..]))
                }
                _ if old && LATER_KEYWORDS.contains(&t) => Some(format!("hz_kw_{t}")),
                _ => None,
            };
            out.push_str(replaced.as_deref().unwrap_or(t));
        }
        out
    }
}

impl Stage<'_> {
    /// The length of a lowered global array is still a constant expression. Naga attempts a
    /// runtime load before resolving `.length()`, so retain the declared size explicitly.
    fn runtime_array_length(&self, i: usize) -> Option<(&str, usize)> {
        let (length, declared) = self.runtime_array_lengths.get(self.tokens[i])?;
        if i <= *declared
            || self.tokens[..i]
                .iter()
                .rfind(|t| significant(t))
                .is_some_and(|&t| t == ".")
        {
            return None;
        }
        let mut at = i;
        for expected in [".", "length", "(", ")"] {
            at = (at + 1..self.tokens.len()).find(|&j| significant(self.tokens[j]))?;
            if self.tokens[at] != expected {
                return None;
            }
        }
        Some((length, at))
    }

    /// Whether the declaration after token `i` calls a built-in in `NOT_CONSTANT` before its `;`.
    /// The return type of the function whose body opens at token `brace`, when it is one GLSL
    /// converts returned values to (a scalar or vector of `float`, `int` or `uint`).
    pub(super) fn converted_return(&self, brace: usize) -> Option<&str> {
        let prev = |i: usize| (0..i).rev().find(|&j| significant(self.tokens[j]));
        let close = prev(brace).filter(|&j| self.tokens[j] == ")")?;
        let mut depth = 0usize;
        let open = (0..=close).rev().find(|&j| match self.tokens[j] {
            ")" => {
                depth += 1;
                false
            }
            "(" => {
                depth -= 1;
                depth == 0
            }
            _ => false,
        })?;
        let ty = self.tokens[prev(prev(open)?)?];
        matches!(
            ty,
            "float"
                | "vec2"
                | "vec3"
                | "vec4"
                | "int"
                | "ivec2"
                | "ivec3"
                | "ivec4"
                | "uint"
                | "uvec2"
                | "uvec3"
                | "uvec4"
        )
        .then_some(ty)
    }

    /// Whether tokens `i..end` hold a comma outside brackets (GLSL's comma operator).
    pub(super) fn top_level_comma(&self, i: usize, end: usize) -> bool {
        let mut depth = 0usize;
        self.tokens[i..end].iter().any(|&t| match t {
            "(" | "[" => {
                depth += 1;
                false
            }
            ")" | "]" => {
                depth = depth.saturating_sub(1);
                false
            }
            "," => depth == 0,
            _ => false,
        })
    }

    /// The `;` that ends the statement starting at token `i` (outside brackets).
    pub(super) fn statement_end(&self, i: usize) -> Option<usize> {
        let mut depth = 0usize;
        for j in i + 1..self.tokens.len() {
            match self.tokens[j] {
                "(" | "[" => depth += 1,
                ")" | "]" => depth = depth.saturating_sub(1),
                ";" if depth == 0 => return Some(j),
                "{" | "}" => return None,
                _ => {}
            }
        }
        None
    }

    pub(super) fn calls_not_constant(&self, i: usize) -> bool {
        for (j, &t) in self.tokens.iter().enumerate().skip(i + 1) {
            if matches!(t, ";" | "{" | "}") {
                return false;
            }
            if NOT_CONSTANT.contains(&t)
                && self.tokens[j + 1..].iter().find(|t| significant(t)) == Some(&"(")
            {
                return true;
            }
        }
        false
    }

    /// When the `[` at token `i` begins two or more array dimensions of a type (after a type
    /// name, `float[2][3]`, or after the name a type declares, `float x[2][3]`), each one's
    /// first and last token. naga's frontend nests such dimensions the other way round.
    fn type_dimensions(&self, i: usize, structs: &[&str]) -> Option<Vec<(usize, usize)>> {
        let prev = |k: usize| (0..k).rev().find(|&j| significant(self.tokens[j]));
        let is_type = |t: &str| TYPE_NAMES.contains(&t) || structs.contains(&t);
        let p = prev(i)?;
        let declared = is_ident(self.tokens[p])
            && prev(p).is_some_and(|q| is_type(self.tokens[q]) || self.tokens[q] == "]");
        if !is_type(self.tokens[p]) && !declared {
            return None;
        }
        let mut groups = Vec::new();
        let mut open = i;
        loop {
            let mut level = 0;
            let mut close = None;
            for j in open..self.tokens.len() {
                match self.tokens[j] {
                    "[" => level += 1,
                    "]" => {
                        level -= 1;
                        if level == 0 {
                            close = Some(j);
                            break;
                        }
                    }
                    _ => {}
                }
            }
            let close = close?;
            // An initializer can size the outer dimension. Include it in the reversal
            // together with the explicit inner dimensions rather than reversing only them.
            if (open + 1..close).all(|j| !significant(self.tokens[j]))
                && !(groups.is_empty() && self.array_length(close).is_some())
            {
                return None;
            }
            groups.push((open, close));
            match (close + 1..self.tokens.len()).find(|&j| significant(self.tokens[j])) {
                Some(j) if self.tokens[j] == "[" => open = j,
                _ => break,
            }
        }
        (groups.len() > 1).then_some(groups)
    }

    /// Whether the name at `i`, after a `,`, is another declarator of the statement's type
    /// (`bool a = 1, x = 0;`): the statement starts with a type and a name.
    fn is_next_declarator(&self, i: usize) -> bool {
        let follows = (i + 1..self.tokens.len())
            .find(|&j| significant(self.tokens[j]))
            .map(|j| self.tokens[j]);
        if !matches!(follows, Some("=" | "," | ";" | "[")) {
            return false;
        }
        let mut level = 0i32;
        let mut start = i;
        let mut j = i;
        while j > 0 {
            j -= 1;
            let t = self.tokens[j];
            if !significant(t) {
                continue;
            }
            match t {
                ")" | "]" => level += 1,
                "(" | "[" if level > 0 => level -= 1,
                "(" | "[" | "{" | "}" | ";" if level == 0 => break,
                _ => {}
            }
            start = j;
        }
        is_ident(self.tokens[start])
            && !matches!(self.tokens[start], "return" | "case" | "else" | "do")
            && (start + 1..i)
                .find(|&j| significant(self.tokens[j]))
                .is_some_and(|j| is_ident(self.tokens[j]))
    }

    /// Where the scope of the name declared at token `i` begins: after its initializer (GLSL 4.60
    /// 4.2.2: `float depth = texture(depth, uv).x` still reads the outer `depth`), else after it.
    fn scope_start(&self, i: usize) -> usize {
        let after = (i + 1..self.tokens.len()).find(|&j| significant(self.tokens[j]));
        if after.is_none_or(|j| self.tokens[j] != "=") {
            return i + 1;
        }
        let mut level = 0i32;
        for j in i + 1..self.tokens.len() {
            match self.tokens[j] {
                "(" | "[" | "{" => level += 1,
                ")" | "]" | "}" => level -= 1,
                "," | ";" if level <= 0 => return j,
                _ => {}
            }
        }
        self.tokens.len()
    }

    /// The element count of an unsized array whose `[]` ends at `close`: the arguments of the
    /// following constructor, or the top-level elements of its brace initializer (GLSL 4.40,
    /// 4.1.11). Nested aggregate elements and a trailing initializer comma do not add elements.
    pub(super) fn array_length(&self, close: usize) -> Option<usize> {
        let mut j = close + 1;
        let mut seen_eq = false;
        let end = loop {
            match self.tokens.get(j).copied()? {
                "(" => break ")",
                "{" if seen_eq => break "}",
                "=" if !seen_eq => seen_eq = true,
                ";" | "," | ")" | "{" => return None,
                _ => {}
            }
            j += 1;
        };
        let (mut depth, mut args, mut any) = (0, 0, false);
        for &t in &self.tokens[j + 1..] {
            match t {
                "(" | "[" | "{" => {
                    depth += 1;
                    any = true;
                }
                t if t == end && depth == 0 => {
                    let count = args + usize::from(any);
                    return (count > 0).then_some(count);
                }
                ")" | "]" | "}" => depth -= 1,
                "," if depth == 0 => {
                    args += 1;
                    any = false;
                }
                _ if significant(t) => any = true,
                _ => {}
            }
        }
        None
    }
}

/// What our vertex `main` gives a vertex input of a composite-style program.
/// GLSL's scalar, vector and matrix type names.
const TYPE_NAMES: [&str; 35] = [
    "float", "int", "uint", "bool", "double", "vec2", "vec3", "vec4", "ivec2", "ivec3", "ivec4",
    "uvec2", "uvec3", "uvec4", "bvec2", "bvec3", "bvec4", "dvec2", "dvec3", "dvec4", "mat2",
    "mat3", "mat4", "mat2x2", "mat2x3", "mat2x4", "mat3x2", "mat3x3", "mat3x4", "mat4x2", "mat4x3",
    "mat4x4", "dmat2", "dmat3", "dmat4",
];

/// `0.0`, `0.`, `.0`, `0.0f`: a floating-point literal zero.
/// `textureGatherOffsets` (GLSL 4.60, 8.9.4), which naga's frontend lacks: texel `i` of the
/// result is texel `i` of the footprint `offsets[i]` texels away. WGSL takes only constant
/// offsets, so each footprint is gathered at `P` moved by its offset over the texture's size,
/// which picks the same four texels; the component, a constant in GLSL, picks one of four
/// gathers.
/// GL_AMD_shader_trinary_minmax's `min3`, `max3` or `mid3` (its additions to GLSL 4.30
/// Section 8.3: genType, genIType and genUType overloads): the per-component minimum, maximum
/// or median of x, y and z.
fn trinary(name: &str) -> String {
    let body = match name {
        "min3" => "min(x, min(y, z))",
        "max3" => "max(x, max(y, z))",
        _ => "max(min(x, y), min(max(x, y), z))",
    };
    let mut p = String::new();
    for (scalar, vector) in [("float", "vec"), ("int", "ivec"), ("uint", "uvec")] {
        for n in 1..=4 {
            let ty = match n {
                1 => scalar.to_owned(),
                _ => format!("{vector}{n}"),
            };
            writeln!(
                p,
                "{ty} {name}({ty} x, {ty} y, {ty} z) {{ return {body}; }}"
            )
            .unwrap();
        }
    }
    p
}

/// An integer sampler type's texture type and dimension count (`usampler2D` → `utexture2D`, 2).
fn integer_sampler(ty: &str) -> Option<(&'static str, usize)> {
    Some(match ty {
        "usampler2D" => ("utexture2D", 2),
        "isampler2D" => ("itexture2D", 2),
        "usampler3D" => ("utexture3D", 3),
        "isampler3D" => ("itexture3D", 3),
        _ => return None,
    })
}

/// The helper standing for a filtered read of an integer sampler (`integer_texture`).
fn integer_call(callee: &str) -> Option<&'static str> {
    Some(match callee {
        "texture" | "texture2D" | "texture3D" => "hz_integerTexture",
        "textureLod" | "texture2DLod" | "texture3DLod" => "hz_integerTextureLod",
        _ => return None,
    })
}

/// `texture` and `textureLod` of an integer sampler: GL drivers read an integer texture with
/// nearest filtering (a linear filter would leave it incomplete), so the texel the point falls
/// in, the edge texel past the edges. wgpu filters only float textures, so `texelFetch` it is.
/// A bias changes nothing; `textureLod` reads the level it names.
fn integer_texture(types: &[(&str, usize)]) -> String {
    let mut out = String::new();
    for &(ty, dims) in types {
        let sampler = ty.replacen("texture", "sampler", 1);
        let result = if ty.starts_with('u') {
            "uvec4"
        } else {
            "ivec4"
        };
        let (fv, iv) = (format!("vec{dims}"), format!("ivec{dims}"));
        let read = |level: &str| {
            format!(
                "{iv} size = textureSize({sampler}(t, s), {level}); \
                 return texelFetch({sampler}(t, s), clamp({iv}(floor(p * {fv}(size))), {iv}(0), size - 1), {level});"
            )
        };
        let lod = read("int(l)");
        let base = read("0");
        writeln!(
            out,
            "{result} hz_integerTexture({ty} t, sampler s, {fv} p) {{ {base} }}"
        )
        .unwrap();
        writeln!(
            out,
            "{result} hz_integerTexture({ty} t, sampler s, {fv} p, float b) {{ {base} }}"
        )
        .unwrap();
        writeln!(
            out,
            "{result} hz_integerTextureLod({ty} t, sampler s, {fv} p, float l) {{ {lod} }}"
        )
        .unwrap();
    }
    out
}

/// The depth samplers a plain `sampler2D` can name: `hz_depth_linear`'s x, y, z and w.
const DEPTH_NAMES: [&str; 4] = ["shadowtex0", "shadowtex1", "shadow", "watershadow"];

/// The helper standing for a texture call on one of `DEPTH_NAMES`, or on a parameter carrying
/// one (`parameter`: no offset helpers, see `DEPTH_FILTER`).
fn depth_call(callee: &str, parameter: bool) -> Option<&'static str> {
    if parameter && callee.ends_with("Offset") {
        return None;
    }
    Some(match callee {
        "texture2D" | "texture" => "hz_depthTexture",
        "texture2DLod" | "texture2DLodARB" | "textureLod" => "hz_depthTextureLod",
        "textureOffset" => "hz_depthTextureOffset",
        "textureLodOffset" => "hz_depthTextureLodOffset",
        "texture2DGrad" | "texture2DGradARB" | "textureGrad" => "hz_depthTextureGrad",
        "textureGradOffset" => "hz_depthTextureGradOffset",
        "texture2DProj" | "textureProj" => "hz_depthTextureProj",
        "texture2DProjLod" | "textureProjLod" => "hz_depthTextureProjLod",
        _ => return None,
    })
}

/// A shadow depth read through a plain sampler, filtered as a filtering sampler reads a colour
/// texture when `l` is 1 (0: the nearest texel): the four texels around the point gathered, at
/// the corner they share so the hardware's choice of texels can't differ from ours, and blended
/// bilinearly. wgpu filters a depth format only in a comparison. The weights are whole 256ths,
/// as Iris 1.11.7's reads on our NVIDIA GPU fit (#8464; a fit to our probe packs' readings, not
/// Iris's code): the point's place between texels rounded half up to a 256th on each axis, the
/// far corner's weight `wx × wy / 256` rounded half up, the others what is left of each axis.
/// The depth has one level, so a level, bias or gradients change nothing; offsets and projection
/// apply. `l` is -1 for any other texture passed to a parameter that also takes a depth: then the
/// built-in the pack called. A texel offset must be a constant, which a helper's parameter is
/// not, so the offset helpers serve only the samplers themselves (`depth_call`).
const DEPTH_FILTER: &str = "vec4 hz_depthRead(texture2D t, sampler s, float l, vec2 p) {\n\
    \x20   if (l == 0.0) return textureLod(sampler2D(t, s), p, 0.0);\n\
    \x20   vec2 size = vec2(textureSize(sampler2D(t, s), 0));\n\
    \x20   vec2 x = p * size - 0.5;\n\
    \x20   vec2 i = floor(x);\n\
    \x20   vec2 f = floor((x - i) * 256.0 + 0.5);\n\
    \x20   float f11 = floor(f.x * f.y / 256.0 + 0.5);\n\
    \x20   vec4 g = textureGather(sampler2D(t, s), (i + 1.0) / size);\n\
    \x20   float d = (g.z - g.w) * (f.x - f11) + (g.x - g.w) * (f.y - f11) + (g.y - g.w) * f11;\n\
    \x20   return vec4(g.w + d / 256.0, 0.0, 0.0, 1.0);\n}\n\
    vec2 hz_depthOffset(texture2D t, sampler s, ivec2 o) { return vec2(o) / vec2(textureSize(sampler2D(t, s), 0)); }\n\
    vec4 hz_depthTexture(texture2D t, sampler s, float l, vec2 p) {\n\
    \x20   if (l < 0.0) return texture(sampler2D(t, s), p);\n\
    \x20   return hz_depthRead(t, s, l, p);\n}\n\
    vec4 hz_depthTexture(texture2D t, sampler s, float l, vec2 p, float b) {\n\
    \x20   if (l < 0.0) return texture(sampler2D(t, s), p, b);\n\
    \x20   return hz_depthRead(t, s, l, p);\n}\n\
    vec4 hz_depthTextureLod(texture2D t, sampler s, float l, vec2 p, float lod) {\n\
    \x20   if (l < 0.0) return textureLod(sampler2D(t, s), p, lod);\n\
    \x20   return hz_depthRead(t, s, l, p);\n}\n\
    vec4 hz_depthTextureOffset(texture2D t, sampler s, float l, vec2 p, ivec2 o) {\n\
    \x20   return hz_depthRead(t, s, l, p + hz_depthOffset(t, s, o));\n}\n\
    vec4 hz_depthTextureOffset(texture2D t, sampler s, float l, vec2 p, ivec2 o, float b) {\n\
    \x20   return hz_depthRead(t, s, l, p + hz_depthOffset(t, s, o));\n}\n\
    vec4 hz_depthTextureLodOffset(texture2D t, sampler s, float l, vec2 p, float lod, ivec2 o) {\n\
    \x20   return hz_depthRead(t, s, l, p + hz_depthOffset(t, s, o));\n}\n\
    vec4 hz_depthTextureGrad(texture2D t, sampler s, float l, vec2 p, vec2 dx, vec2 dy) {\n\
    \x20   if (l < 0.0) return textureGrad(sampler2D(t, s), p, dx, dy);\n\
    \x20   return hz_depthRead(t, s, l, p);\n}\n\
    vec4 hz_depthTextureGradOffset(texture2D t, sampler s, float l, vec2 p, vec2 dx, vec2 dy, ivec2 o) {\n\
    \x20   return hz_depthRead(t, s, l, p + hz_depthOffset(t, s, o));\n}\n\
    vec4 hz_depthTextureProj(texture2D t, sampler s, float l, vec3 p) {\n\
    \x20   if (l < 0.0) return textureProj(sampler2D(t, s), p);\n\
    \x20   return hz_depthRead(t, s, l, p.xy / p.z);\n}\n\
    vec4 hz_depthTextureProj(texture2D t, sampler s, float l, vec4 p) {\n\
    \x20   if (l < 0.0) return textureProj(sampler2D(t, s), p);\n\
    \x20   return hz_depthRead(t, s, l, p.xy / p.w);\n}\n\
    vec4 hz_depthTextureProj(texture2D t, sampler s, float l, vec3 p, float b) {\n\
    \x20   if (l < 0.0) return textureProj(sampler2D(t, s), p, b);\n\
    \x20   return hz_depthRead(t, s, l, p.xy / p.z);\n}\n\
    vec4 hz_depthTextureProj(texture2D t, sampler s, float l, vec4 p, float b) {\n\
    \x20   if (l < 0.0) return textureProj(sampler2D(t, s), p, b);\n\
    \x20   return hz_depthRead(t, s, l, p.xy / p.w);\n}\n\
    vec4 hz_depthTextureProjLod(texture2D t, sampler s, float l, vec3 p, float lod) {\n\
    \x20   if (l < 0.0) return textureProjLod(sampler2D(t, s), p, lod);\n\
    \x20   return hz_depthRead(t, s, l, p.xy / p.z);\n}\n\
    vec4 hz_depthTextureProjLod(texture2D t, sampler s, float l, vec4 p, float lod) {\n\
    \x20   if (l < 0.0) return textureProjLod(sampler2D(t, s), p, lod);\n\
    \x20   return hz_depthRead(t, s, l, p.xy / p.w);\n}\n";

fn gather_offsets() -> String {
    let mut p = String::new();
    for prefix in ["", "i", "u"] {
        let (tex, smp) = (format!("{prefix}texture2D"), format!("{prefix}sampler2D"));
        let vec = format!("{prefix}vec4");
        write!(
            p,
            "{vec} hz_gather({tex} t, sampler s, vec2 p, int c) {{\n\
             \x20   if (c == 1) return textureGather({smp}(t, s), p, 1);\n\
             \x20   if (c == 2) return textureGather({smp}(t, s), p, 2);\n\
             \x20   if (c == 3) return textureGather({smp}(t, s), p, 3);\n\
             \x20   return textureGather({smp}(t, s), p, 0);\n}}\n\
             {vec} hz_textureGatherOffsets({tex} t, sampler s, vec2 p, ivec2 o[4], int c) {{\n\
             \x20   vec2 px = 1.0 / vec2(textureSize({smp}(t, s), 0));\n\
             \x20   return {vec}(hz_gather(t, s, p + vec2(o[0]) * px, c).x, hz_gather(t, s, p + vec2(o[1]) * px, c).y,\n\
             \x20       hz_gather(t, s, p + vec2(o[2]) * px, c).z, hz_gather(t, s, p + vec2(o[3]) * px, c).w);\n}}\n\
             {vec} hz_textureGatherOffsets({tex} t, sampler s, vec2 p, ivec2 o[4]) {{\n\
             \x20   return hz_textureGatherOffsets(t, s, p, o, 0);\n}}\n"
        )
        .unwrap();
    }
    p.push_str(
        "vec4 hz_textureGatherOffsets(texture2D t, samplerShadow s, vec2 p, float r, ivec2 o[4]) {\n\
         \x20   vec2 px = 1.0 / vec2(textureSize(sampler2DShadow(t, s), 0));\n\
         \x20   return vec4(textureGather(sampler2DShadow(t, s), p + vec2(o[0]) * px, r).x,\n\
         \x20       textureGather(sampler2DShadow(t, s), p + vec2(o[1]) * px, r).y,\n\
         \x20       textureGather(sampler2DShadow(t, s), p + vec2(o[2]) * px, r).z,\n\
         \x20       textureGather(sampler2DShadow(t, s), p + vec2(o[3]) * px, r).w);\n}\n",
    );
    p
}

/// `textureQueryLod` (GLSL 4.60, 8.9.1), which naga's frontend lacks: `y` is the level of
/// detail relative to the base level, worked out as texturing does (OpenGL 4.6, 8.14.1: the log2 of the
/// larger of the coordinates' texel-space changes from one pixel to the next), and `x` the level
/// that would be read, that clamped to the texture's levels. For a cube map the direction is
/// first taken to its face.
fn query_lod() -> String {
    let mut p = String::new();
    for prefix in ["", "i", "u"] {
        for (dim, coord, texel) in [
            ("2D", "vec2", "p * vec2(textureSize({smp}(t, s), 0))"),
            (
                "2DArray",
                "vec2",
                "p * vec2(textureSize({smp}(t, s), 0).xy)",
            ),
            ("3D", "vec3", "p * vec3(textureSize({smp}(t, s), 0))"),
            (
                "Cube",
                "vec3",
                "p / max(max(abs(p.x), abs(p.y)), abs(p.z)) * 0.5 * float(textureSize({smp}(t, s), 0).x)",
            ),
        ] {
            let (tex, smp) = (
                format!("{prefix}texture{dim}"),
                format!("{prefix}sampler{dim}"),
            );
            let texel = texel.replace("{smp}", &smp);
            write!(
                p,
                "vec2 hz_textureQueryLod({tex} t, sampler s, {coord} p) {{\n\
                 \x20   {coord} q = {texel};\n\
                 \x20   {coord} dx = dFdx(q), dy = dFdy(q);\n\
                 \x20   float lod = 0.5 * log2(max(dot(dx, dx), dot(dy, dy)));\n\
                 \x20   float levels = float(textureQueryLevels({smp}(t, s)));\n\
                 \x20   return vec2(clamp(lod, 0.0, levels - 1.0), lod);\n}}\n"
            )
            .unwrap();
        }
    }
    p
}

pub(super) fn is_zero_literal(t: &str) -> bool {
    let t = t.trim_end_matches(['f', 'F']);
    t.contains('.') && !t.contains(['e', 'E']) && t.chars().all(|c| c == '0' || c == '.')
}

pub(super) fn attribute_value(name: &str, ty: &str) -> String {
    match name {
        "vaPosition" => "vec3(hz_p, 0.0)".into(),
        "vaUV0" => "hz_p".into(),
        "vaColor" => "vec4(1.0)".into(),
        "vaNormal" => "vec3(0.0, 0.0, 1.0)".into(),
        _ => format!("{ty}(0)"),
    }
}
