//! Crafting and cooking recipes from the pinned data pack: shaped patterns
//! (`ShapedRecipePattern.matches`), shapeless recipes (a bipartite match of
//! ingredients to stacks, as `StackedContents.canCraft`), the special and
//! transmuting crafting recipes (`CustomRecipe` and friends), and
//! furnace-type cooking lookups.
use crate::{
    Result,
    item_data::StackData,
    items::{ItemStack, Items},
    particles::{DYE_FIREWORK_COLORS, FireworkExplosion, FireworkShape},
};
use horizon_world::nbt::{JavaString, Tag};
use horizon_world::{component_patch::Patch, loot::PackOverlay};
use serde_json::Value;
use std::{
    collections::{HashMap, HashSet},
    path::Path,
    sync::Arc,
};

/// A recipe ingredient of a mod's own kind: the entry named a type in a
/// namespace outside `minecraft:`, and the loader kept it for this call.
/// The kind and the JSON the file wrote are here; fill `items` with the
/// item ids the ingredient matches (item ids only: components are not
/// checked here; a match-time hook follows separately). Duplicates are
/// removed keeping first-seen order. The hook may be called more than
/// once per recipe; the answer must be the same. An unclaimed kind
/// leaves the list empty and the recipe fails, as an unknown kind does.
/// API 166.
#[inline(never)]
pub fn native_ingredient(
    kind: &str,
    data: &serde_json::Map<String, Value>,
    items: &mut Vec<String>,
) {
    crate::native_client_hooks::ingredient(kind, data, items);
}

/// A mod's own ingredient kind, matching a concrete stack at craft time:
/// the ingredient's `test` calls here with the kind, its JSON and the
/// stack being matched, `accept` already true (the load-time list named
/// the item). Set `accept` to false to refuse the stack — its components
/// are the usual reason. The hook may be called many times a craft; the
/// answer must be the same for the same stack. API 377.
#[inline(never)]
pub fn native_ingredient_test(
    kind: &str,
    data: &serde_json::Map<String, Value>,
    stack: &ItemStack,
    accept: &mut bool,
) {
    crate::native_client_hooks::ingredient_test(kind, data, stack, accept);
}

/// Keep first-seen order, drop the rest.
fn dedup_keep_order(items: &mut Vec<String>) {
    let mut seen = std::collections::HashSet::new();
    items.retain(|i| seen.insert(i.clone()));
}

/// A set of accepted items (expanded from an item, list or tag), and the
/// items in its `HolderSet` order (`Ingredient.display`'s `TagSlotDisplay`).
#[derive(Clone, Debug)]
pub struct Ingredient {
    /// The items it accepts, however the source shape named them.
    pub items: HashSet<String>,
    /// The same items in `HolderSet` order (`display`).
    pub order: Vec<String>,
    /// A mod's own kind, for matching at craft time: the kind and its
    /// JSON, as the load-time hook saw them (`native_ingredient_test`).
    pub custom: Option<(String, serde_json::Map<String, Value>)>,
    /// NeoForge's shapes, with their children parsed: matching a concrete
    /// stack asks each child its own `test` (a mod's kind among them),
    /// as on NeoForge — the flat list above only names items.
    pub children: Option<(Shape, Vec<Self>)>,
}

/// How a shape's children combine at match time.
#[derive(Clone, Debug)]
pub enum Shape {
    /// Any child matching the stack is enough.
    Compound,
    /// Every child must match it.
    Intersection,
    /// The first child must, and the second must not.
    Difference,
}
impl Ingredient {
    /// The items of a list, in order.
    pub fn of(items: Vec<String>) -> Self {
        Self {
            items: items.iter().cloned().collect(),
            order: items,
            custom: None,
            children: None,
        }
    }
    pub fn parse(v: &Value, items: &Items) -> Option<Self> {
        let mut list: Vec<String> = Vec::new();
        let mut add = |s: &str| {
            let more: Vec<String> = match s.strip_prefix('#') {
                Some(tag) => items.item_tag_order.get(tag).cloned().unwrap_or_default(),
                None => vec![s.to_owned()],
            };
            for i in more {
                if !list.contains(&i) {
                    list.push(i);
                }
            }
        };
        match v {
            Value::String(s) => add(s),
            Value::Array(a) => a.iter().filter_map(Value::as_str).for_each(&mut add),
            Value::Object(o) => return Self::parse_object(o, items),
            _ => return None,
        }
        (!list.is_empty()).then(|| Self::of(list))
    }
    /// NeoForge's ingredient types (`NeoForgeRegistries.Keys.INGREDIENT_TYPES`),
    /// the standard shapes mods' recipes carry, each resolved to the flat item
    /// list it matches. A kind outside these still fails the file: a mod's
    /// own ingredient types come with their own hook, not the loader.
    fn parse_object(o: &serde_json::Map<String, Value>, items: &Items) -> Option<Self> {
        // Current NeoForge marks a custom ingredient with
        // `neoforge:ingredient_type`; `type` is the older packs' key.
        let kind = o
            .get("neoforge:ingredient_type")
            .or_else(|| o.get("type"))?
            .as_str()?;
        let children = || {
            o.get("children")
                .or_else(|| o.get("ingredients"))
                .and_then(Value::as_array)
        };
        // The shapes' parsed children, for matching at craft time: every
        // arm either fills it or returns.
        let nested;
        let kept = match kind {
            // `CompoundIngredient`: any of its children matching the stack
            // is enough — the union of their items.
            "neoforge:compound" => {
                let subs: Vec<Self> = children()?
                    .iter()
                    .map(|s| Self::parse(s, items))
                    .collect::<Option<_>>()?;
                let mut seen = Vec::new();
                for sub in &subs {
                    for item in &sub.order {
                        if !seen.contains(item) {
                            seen.push(item.clone());
                        }
                    }
                }
                nested = Some((Shape::Compound, subs));
                seen
            }
            // `IntersectionIngredient`: every child must match the same
            // stack — the items all of them name.
            "neoforge:intersection" => {
                let subs: Vec<Self> = children()?
                    .iter()
                    .map(|s| Self::parse(s, items))
                    .collect::<Option<_>>()?;
                nested = Some((Shape::Intersection, subs.clone()));
                subs.first()?
                    .order
                    .iter()
                    .filter(|i| subs[1..].iter().all(|s| s.items.contains(*i)))
                    .cloned()
                    .collect()
            }
            // The base's items without the subtracted's.
            "neoforge:difference" => {
                let base = Self::parse(o.get("base")?, items)?;
                let gone = Self::parse(o.get("subtracted")?, items)?;
                nested = Some((Shape::Difference, vec![base.clone(), gone.clone()]));
                base.order
                    .iter()
                    .filter(|i| !gone.items.contains(*i))
                    .cloned()
                    .collect()
            }
            // A mod's own kind: the hook answers with the item list it
            // matches; a bare type name is minecraft's own, not a mod's.
            k if k.contains(':') && !k.starts_with("minecraft:") => {
                let mut list = Vec::new();
                native_ingredient(k, o, &mut list);
                dedup_keep_order(&mut list);
                // The kind and its JSON stay with the ingredient: the
                // load-time list only names items, and matching a concrete
                // stack (its components) is the match-time hook's.
                return (!list.is_empty()).then(|| Self {
                    order: list.clone(),
                    items: list.iter().cloned().collect(),
                    custom: Some((k.to_owned(), o.clone())),
                    children: None,
                });
            }
            _ => return None,
        };
        (!kept.is_empty()).then(|| Self {
            items: kept.iter().cloned().collect(),
            order: kept,
            custom: None,
            children: nested,
        })
    }
    /// `Ingredient.test`: a stack the list names — and for a mod's own
    /// kind, one the match-time hook accepts (`ICustomIngredient.test`).
    pub fn test(&self, stack: &ItemStack) -> bool {
        match &self.children {
            // Each child its own `test`, as on NeoForge — a mod's kind
            // among them answers through its hook.
            Some((Shape::Compound, kids)) => kids.iter().any(|k| k.test(stack)),
            Some((Shape::Intersection, kids)) => kids.iter().all(|k| k.test(stack)),
            Some((Shape::Difference, kids)) => {
                kids.first().is_some_and(|k| k.test(stack))
                    && kids.get(1).is_none_or(|k| !k.test(stack))
            }
            None => {
                if !self.items.contains(&*stack.item) {
                    return false;
                }
                if let Some((kind, data)) = &self.custom {
                    let mut accept = true;
                    native_ingredient_test(kind, data, stack, &mut accept);
                    return accept;
                }
                true
            }
        }
    }
}
/// `PlacementInfo`: the ingredients to find and, per recipe slot, the index
/// of its ingredient (`slotsToIngredientIndex`, -1 for an empty slot). Empty
/// when the recipe is impossible to place.
#[derive(Clone, Debug, Default)]
pub struct Placement {
    pub ingredients: Vec<Ingredient>,
    pub slots: Vec<i32>,
    /// A `ShapedRecipe`'s width and height (the others fill the grid).
    pub shaped: Option<(usize, usize)>,
}
impl Placement {
    /// `PlacementInfo.createFromOptionals` (and `create` with no empty slots).
    pub fn of(cells: Vec<Option<Ingredient>>, shaped: Option<(usize, usize)>) -> Self {
        let mut out = Self {
            shaped,
            ..Self::default()
        };
        for cell in cells {
            match cell {
                Some(i) if i.items.is_empty() => return Self::default(),
                Some(i) => {
                    out.slots.push(out.ingredients.len() as i32);
                    out.ingredients.push(i);
                }
                None => out.slots.push(-1),
            }
        }
        out
    }
    pub fn impossible(&self) -> bool {
        self.slots.is_empty()
    }
}
/// A recipe result: `ItemStackTemplate` (`id`, `count`, `components`), or a bare item id
/// (`ItemStackTemplate.CODEC` falls back to `Item.CODEC`), with the id optional for the
/// transmuting recipes that keep the input's item.
#[derive(Clone, Debug)]
pub struct Template {
    pub item: Option<Arc<str>>,
    pub count: u32,
    pub damage: u32,
    pub extra: Option<Box<StackData>>,
    /// Result patch before decoding defaults, including explicit removals/zeroes.
    pub components: Option<Tag>,
}
/// `ItemStackTemplate.CODEC` count: absent means 1, present must be an
/// integer in `1..=99` (`ExtraCodecs.intRange(1, 99)`), else the recipe is
/// not loaded.
pub(crate) fn template_count(v: &Value) -> Option<u32> {
    match v.get("count") {
        None => Some(1),
        Some(c) => c
            .as_u64()
            .filter(|n| (1..=99).contains(n))
            .map(|n| n as u32),
    }
}
impl Template {
    fn parse(v: &Value) -> Option<Self> {
        let components = v.get("components").map(json_tag);
        let (damage, extra) = crate::item_data::decode_components(components.as_ref());
        Some(Self {
            item: horizon_world::loot::recipe_result_id(v).map(Arc::from),
            count: template_count(v)?,
            damage,
            extra,
            components,
        })
    }
    /// `ItemStackTemplate.create`.
    pub fn create(&self) -> ItemStack {
        ItemStack {
            item: self
                .item
                .clone()
                .unwrap_or_else(|| Arc::from("minecraft:air")),
            count: self.count,
            damage: self.damage,
            extra: self.extra.clone(),
        }
    }
    /// `TransmuteRecipe.createWithOriginalComponents`: the input's component
    /// patch on the result item, then the template's own components over it.
    fn over(&self, input: &ItemStack, extra_count: u32) -> ItemStack {
        let original = assembly_components(input);
        let result = self
            .components
            .clone()
            .unwrap_or_else(|| assembly_components(&self.create()));
        // ItemStackTemplate.apply: the second patch wins for each component;
        // a removal replaces a value rather than coexisting with it.
        let entries = |tag: Tag| match tag {
            Tag::Compound(map) => map
                .into_iter()
                .map(|(key, value)| {
                    let key = key.to_string_lossy();
                    match key.strip_prefix('!') {
                        Some(key) => (key.to_owned(), None),
                        None => (key.to_owned(), Some(value)),
                    }
                })
                .collect::<Vec<_>>(),
            _ => Vec::new(),
        };
        let patch = Patch::new(entries(original).into_iter().chain(entries(result)));
        let components = Tag::compound(patch.entries().iter().map(|(key, value)| match value {
            Some(value) => (JavaString::from(key.as_str()), value.clone()),
            None => (
                JavaString::from(format!("!{key}").as_str()),
                Tag::Compound(Default::default()),
            ),
        }));
        let (damage, extra) = crate::item_data::decode_components(Some(&components));
        let mut out = ItemStack {
            item: self.item.clone().unwrap_or_else(|| input.item.clone()),
            count: self.count + extra_count,
            damage,
            extra,
        };
        if let Some(input) = input.data() {
            // Runtime-only stack bookkeeping is not a saved component patch.
            let data = out.data_mut();
            data.wire = input.wire.clone();
            data.bundle_selected = input.bundle_selected;
        }
        out.tidy();
        out
    }
}
/// Assembly also carries the transient map postprocess component; the saved
/// ItemStack codec deliberately omits it. Do not turn it into saved data.
fn assembly_components(stack: &ItemStack) -> Tag {
    let mut components = match crate::item_data::encode_components(stack) {
        Some(Tag::Compound(map)) => map,
        _ => Default::default(),
    };
    if let Some(postprocess) = stack.data().and_then(|d| d.map_post_processing) {
        components.insert(
            "minecraft:map_post_processing".into(),
            Tag::Int(i32::from(postprocess)),
        );
    }
    Tag::Compound(components)
}
/// A JSON recipe value as the NBT a component codec reads.
fn json_tag(v: &Value) -> Tag {
    match v {
        Value::Null => Tag::End,
        Value::Bool(b) => Tag::Byte(i8::from(*b)),
        Value::Number(n) => match n.as_i64() {
            Some(i) => i32::try_from(i).map_or(Tag::Long(i), Tag::Int),
            None => Tag::Double(n.as_f64().unwrap_or(0.0).to_bits()),
        },
        Value::String(s) => Tag::String(s.as_str().into()),
        Value::Array(a) => Tag::List(a.iter().map(json_tag).collect()),
        Value::Object(o) => Tag::compound(o.iter().map(|(k, v)| (k.as_str(), json_tag(v)))),
    }
}
#[derive(Clone, Debug)]
pub enum Recipe {
    Shaped {
        width: usize,
        height: usize,
        cells: Vec<Option<Ingredient>>,
        result: Template,
    },
    Shapeless {
        ingredients: Vec<Ingredient>,
        result: Template,
    },
    /// The recipes with code of their own.
    Special(Special),
}
impl Recipe {
    /// `Recipe.isSpecial`: special recipes (e.g. firework rocket, dye) are not in the recipe book.
    pub fn is_special(&self) -> bool {
        matches!(self, Recipe::Special(_))
    }
}
/// The custom and transmuting crafting recipes.
#[derive(Clone, Debug)]
pub enum Special {
    /// A patterned banner and a blank one of the same colour copy the patterns.
    BannerDuplicate { banner: Ingredient, result: String },
    /// A banner decorates an undecorated shield.
    ShieldDecoration {
        banner: Ingredient,
        target: Ingredient,
        result: String,
    },
    /// `TransmuteRecipe`: one input, 1..8 materials; shulker box and bundle
    /// dyeing, map cloning.
    Transmute {
        input: Ingredient,
        material: Ingredient,
        min: usize,
        max: usize,
        add_count: bool,
        result: Template,
    },
    /// `DyeRecipe`: dyed armour.
    Dye {
        target: Ingredient,
        dye: Ingredient,
        result: Template,
    },
    /// `ImbueRecipe`: tipped arrows.
    Imbue {
        source: Ingredient,
        material: Ingredient,
        result: Template,
    },
    /// `BookCloningRecipe`.
    BookCloning {
        source: Ingredient,
        material: Ingredient,
        min: i32,
        max: i32,
        result: Template,
    },
    /// `FireworkRocketRecipe`.
    FireworkRocket {
        shell: Ingredient,
        fuel: Ingredient,
        star: Ingredient,
        result: Template,
    },
    /// `FireworkStarRecipe`.
    FireworkStar {
        dye: Ingredient,
        fuel: Ingredient,
        trail: Ingredient,
        twinkle: Ingredient,
        shapes: Vec<(FireworkShape, Ingredient)>,
        result: Template,
    },
    /// `FireworkStarFadeRecipe`.
    FireworkStarFade {
        dye: Ingredient,
        target: Ingredient,
        result: Template,
    },
    /// `MapExtendingRecipe`: a map ringed by paper, when its scale is under 4.
    MapExtending {
        map: Ingredient,
        material: Ingredient,
        result: Template,
    },
    /// `DecoratedPotRecipe`: four sherds or bricks.
    DecoratedPot {
        back: Ingredient,
        left: Ingredient,
        right: Ingredient,
        front: Ingredient,
        result: Template,
    },
    /// `RepairItemRecipe`: two damaged items of one kind.
    RepairItem,
}
impl Special {
    /// The recipe-book displays of a learnable (non-custom) crafting recipe:
    /// its layout, its result as the button shows it, and every stack the
    /// result display cycles through when it is more than that one
    /// (`SlotDisplay.resolveForStacks`).
    pub fn book_displays(&self) -> Vec<BookDisplay> {
        use crate::recipe_book::Display;
        let first_of =
            |all: &Vec<ItemStack>, single: ItemStack| all.first().cloned().unwrap_or(single);
        let shown = |display, result, variants| BookDisplay {
            display,
            result,
            variants,
            stacks: Vec::new(),
        };
        match self {
            Self::Transmute {
                input,
                material,
                min,
                max,
                add_count,
                result,
            } => (*min..=*max)
                .map(|n| {
                    let mut ingredients = vec![input.clone()];
                    ingredients.extend(std::iter::repeat_n(material.clone(), n));
                    let mut made = result.create();
                    if *add_count {
                        made.count += n as u32;
                    }
                    // The result keeps the input's item: any item of the ingredient.
                    let all: Vec<ItemStack> = if result.item.is_none() {
                        input
                            .order
                            .iter()
                            .map(|item| {
                                let mut stack = made.clone();
                                stack.item = Arc::from(item.as_str());
                                stack
                            })
                            .collect()
                    } else {
                        Vec::new()
                    };
                    shown(Display::Shapeless(ingredients), first_of(&all, made), all)
                })
                .collect(),
            Self::Dye {
                target,
                dye,
                result,
            } => {
                // DyedSlotDemo: the targets cycle fastest, 16 stacks at most.
                let (targets, dyes) = (&target.order, &dye.order);
                let all: Vec<ItemStack> = (0..targets.len() * dyes.len())
                    .map(|i| {
                        let mut made = result.create();
                        made.item = Arc::from(targets[i % targets.len()].as_str());
                        let name = dyes[i / targets.len()].trim_start_matches("minecraft:");
                        let color = crate::block_entity_render::DYES
                            .iter()
                            .find(|(c, _)| name.strip_suffix("_dye") == Some(c))
                            .map_or(crate::block_entity_render::DYES[0].1, |d| d.1);
                        made.data_mut().dyed_color = Some(color as i32);
                        made
                    })
                    .take(16)
                    .collect();
                let first = result.create();
                vec![shown(
                    Display::Shapeless(vec![target.clone(), dye.clone()]),
                    first_of(&all, first),
                    all,
                )]
            }
            Self::Imbue {
                source,
                material,
                result,
            } => {
                let cells = (0..9)
                    .map(|i| Some(if i == 4 { source } else { material }.clone()))
                    .collect();
                // Any potion's tipped arrow.
                let potions = |item: ItemStack| -> Vec<ItemStack> {
                    crate::brewing::POTIONS
                        .iter()
                        .map(|p| item.clone().with_potion(&format!("minecraft:{}", p.id)))
                        .collect()
                };
                let all = potions(result.create());
                // The source ingredient is shown as a lingering potion of each kind.
                let lingering = source
                    .order
                    .iter()
                    .flat_map(|item| potions(ItemStack::new(item, 1)))
                    .collect();
                vec![BookDisplay {
                    stacks: vec![(4, lingering)],
                    ..shown(
                        Display::Shaped {
                            width: 3,
                            height: 3,
                            cells,
                        },
                        first_of(&all, result.create()),
                        all,
                    )
                }]
            }
            _ => Vec::new(),
        }
    }
}
/// One recipe-book display of a special recipe.
pub struct BookDisplay {
    pub display: crate::recipe_book::Display,
    /// The result as the button shows it (the first of `variants`).
    pub result: ItemStack,
    /// Every stack the result display cycles through; empty for one stack.
    pub variants: Vec<ItemStack>,
    /// Ingredients shown as other stacks than their items, by index in
    /// `Entry::requirements`.
    pub stacks: Vec<(usize, Vec<ItemStack>)>,
}
/// `CraftingInput`: the occupied bounding box of the grid.
pub struct Input<'a> {
    pub width: usize,
    pub height: usize,
    /// Position of the box in the grid.
    pub left: usize,
    pub top: usize,
    cells: Vec<Option<&'a ItemStack>>,
}
impl<'a> Input<'a> {
    /// `CraftingInput.ofPositioned`; None for an empty grid.
    pub fn of(grid: &'a [Option<ItemStack>], size: usize) -> Option<Self> {
        let occupied: Vec<(usize, usize)> = (0..size * size)
            .filter(|&i| grid.get(i).is_some_and(|c| c.is_some()))
            .map(|i| (i % size, i / size))
            .collect();
        let (x0, x1) = (
            occupied.iter().map(|p| p.0).min()?,
            occupied.iter().map(|p| p.0).max()?,
        );
        let (y0, y1) = (
            occupied.iter().map(|p| p.1).min()?,
            occupied.iter().map(|p| p.1).max()?,
        );
        let (width, height) = (x1 - x0 + 1, y1 - y0 + 1);
        let cells = (0..width * height)
            .map(|i| grid[(y0 + i / width) * size + x0 + i % width].as_ref())
            .collect();
        Some(Self {
            width,
            height,
            left: x0,
            top: y0,
            cells,
        })
    }
    pub fn get(&self, x: usize, y: usize) -> Option<&'a ItemStack> {
        self.cells.get(y * self.width + x).copied().flatten()
    }
    /// The non-empty stacks in slot order.
    pub fn stacks(&self) -> Vec<&'a ItemStack> {
        self.cells.iter().flatten().copied().collect()
    }
    pub fn count(&self) -> usize {
        self.cells.iter().flatten().count()
    }
}
/// What recipes need to know about an item.
#[derive(Clone, Debug, Default)]
struct Facts {
    /// Index into the dye colours when the item has the `dye` component.
    dye: Option<usize>,
    max_damage: u32,
    max_stack: u32,
    remainder: Option<Arc<str>>,
}
/// The tables recipes consult.
pub struct Context<'a> {
    recipes: &'a Recipes,
    /// A filled map's scale, when its data is known.
    pub map_scale: &'a dyn Fn(i32) -> Option<u8>,
}
impl Context<'_> {
    fn facts(&self, stack: &ItemStack) -> Option<&Facts> {
        self.recipes.facts.get(&stack.item)
    }
    /// `itemStack.has(DataComponents.DYE)`.
    fn dye(&self, stack: &ItemStack) -> Option<usize> {
        self.facts(stack).and_then(|f| f.dye)
    }
    fn max_stack(&self, item: &str) -> u32 {
        self.recipes.facts.get(item).map_or(64, |f| f.max_stack)
    }
}
impl Special {
    /// `Recipe.matches`.
    fn matches(&self, ctx: &Context, input: &Input) -> bool {
        use crate::banner;
        let stacks = input.stacks();
        match self {
            Self::BannerDuplicate { banner: ing, .. } => {
                if stacks.len() != 2 {
                    return false;
                }
                let mut color = None;
                let (mut target, mut source) = (false, false);
                for s in &stacks {
                    let Some(this) = banner::banner_color(&s.item).filter(|_| ing.test(s)) else {
                        return false;
                    };
                    match color {
                        None => color = Some(this),
                        Some(c) if c != this => return false,
                        _ => {}
                    }
                    let layers = banner::layers(s).len();
                    if layers > banner::MAX_LAYERS {
                        return false;
                    }
                    let seen = if layers > 0 { &mut source } else { &mut target };
                    if *seen {
                        return false;
                    }
                    *seen = true;
                }
                source && target
            }
            Self::ShieldDecoration {
                banner: ing,
                target: tgt,
                ..
            } => {
                if stacks.len() != 2 {
                    return false;
                }
                let (mut patterned, mut clear) = (false, false);
                for s in &stacks {
                    if ing.test(s) && banner::banner_color(&s.item).is_some() {
                        if patterned {
                            return false;
                        }
                        patterned = true;
                    } else {
                        if !tgt.test(s) || clear || !banner::layers(s).is_empty() {
                            return false;
                        }
                        clear = true;
                    }
                }
                patterned && clear
            }
            Self::Transmute {
                input: base,
                material,
                min,
                max,
                add_count,
                result,
            } => {
                let n = stacks.len();
                if n < min + 1 || n > max + 1 {
                    return false;
                }
                let mut found: Option<&ItemStack> = None;
                let mut materials = 0;
                for s in &stacks {
                    if base.test(s) {
                        if found.is_some() {
                            return false;
                        }
                        found = Some(s);
                    } else {
                        if !material.test(s) {
                            return false;
                        }
                        materials += 1;
                        if materials > *max {
                            return false;
                        }
                    }
                }
                let Some(found) = found else {
                    return false;
                };
                if materials < *min || materials > *max {
                    return false;
                }
                let count = if *add_count {
                    materials as u32 + result.count
                } else {
                    result.count
                };
                if count != 1 {
                    return true;
                }
                let made = result.over(found, 0);
                made.count <= ctx.max_stack(&made.item) && !made.same_item_same_components(found)
            }
            Self::Dye { target, dye, .. } => {
                if stacks.len() < 2 {
                    return false;
                }
                let (mut has_target, mut has_dyes) = (false, false);
                for s in &stacks {
                    if target.test(s) {
                        if has_target {
                            return false;
                        }
                        has_target = true;
                    } else {
                        if !dye.test(s) || ctx.dye(s).is_none() {
                            return false;
                        }
                        has_dyes = true;
                    }
                }
                has_dyes && has_target
            }
            Self::Imbue {
                source, material, ..
            } => {
                if input.width != 3 || input.height != 3 || stacks.len() != 9 {
                    return false;
                }
                (0..3).all(|y| {
                    (0..3).all(|x| {
                        let ing = if x == 1 && y == 1 { source } else { material };
                        input.get(x, y).is_some_and(|s| ing.test(s))
                    })
                })
            }
            Self::BookCloning {
                source,
                material,
                min,
                max,
                ..
            } => {
                if stacks.len() < 2 {
                    return false;
                }
                let (mut has_material, mut has_source) = (false, false);
                for s in &stacks {
                    if source.test(s) {
                        let Some(book) = s.data().and_then(|d| d.written.as_ref()) else {
                            return false;
                        };
                        let generation = i32::from(book.generation);
                        if generation < *min || generation > *max || has_source {
                            return false;
                        }
                        has_source = true;
                    } else {
                        if !material.test(s) {
                            return false;
                        }
                        has_material = true;
                    }
                }
                has_source && has_material
            }
            Self::FireworkRocket {
                shell, fuel, star, ..
            } => {
                if stacks.len() < 2 {
                    return false;
                }
                let mut has_shell = false;
                let mut fuels = 0;
                for s in &stacks {
                    if shell.test(s) {
                        if has_shell {
                            return false;
                        }
                        has_shell = true;
                    } else if fuel.test(s) {
                        fuels += 1;
                        if fuels > 3 {
                            return false;
                        }
                    } else if !star.test(s) {
                        return false;
                    }
                }
                has_shell && fuels >= 1
            }
            Self::FireworkStar {
                dye,
                fuel,
                trail,
                twinkle,
                shapes,
                ..
            } => {
                if stacks.len() < 2 {
                    return false;
                }
                let (mut has_fuel, mut has_dye, mut has_shape) = (false, false, false);
                let (mut has_trail, mut has_twinkle) = (false, false);
                for s in &stacks {
                    if twinkle.test(s) {
                        if has_twinkle {
                            return false;
                        }
                        has_twinkle = true;
                    } else if trail.test(s) {
                        if has_trail {
                            return false;
                        }
                        has_trail = true;
                    } else if fuel.test(s) {
                        if has_fuel {
                            return false;
                        }
                        has_fuel = true;
                    } else if dye.test(s) && ctx.dye(s).is_some() {
                        has_dye = true;
                    } else {
                        if !shapes.iter().any(|(_, ing)| ing.test(s)) || has_shape {
                            return false;
                        }
                        has_shape = true;
                    }
                }
                has_fuel && has_dye
            }
            Self::FireworkStarFade { dye, target, .. } => {
                if stacks.len() < 2 {
                    return false;
                }
                let (mut has_dye, mut has_target) = (false, false);
                for s in &stacks {
                    if dye.test(s) && ctx.dye(s).is_some() {
                        has_dye = true;
                    } else {
                        if !target.test(s) || has_target {
                            return false;
                        }
                        has_target = true;
                    }
                }
                has_target && has_dye
            }
            Self::MapExtending { map, material, .. } => {
                if input.width != 3 || input.height != 3 || stacks.len() != 9 {
                    return false;
                }
                let ring = (0..3).all(|y| {
                    (0..3).all(|x| {
                        let ing = if x == 1 && y == 1 { map } else { material };
                        input.get(x, y).is_some_and(|s| ing.test(s))
                    })
                });
                if !ring {
                    return false;
                }
                stacks
                    .iter()
                    .find_map(|s| s.data().and_then(|d| d.map_id))
                    .and_then(|id| (ctx.map_scale)(id))
                    .is_some_and(|scale| scale < 4)
            }
            Self::DecoratedPot {
                back,
                left,
                right,
                front,
                ..
            } => {
                input.width == 3
                    && input.height == 3
                    && stacks.len() == 4
                    && input.get(1, 0).is_some_and(|s| back.test(s))
                    && input.get(0, 1).is_some_and(|s| left.test(s))
                    && input.get(2, 1).is_some_and(|s| right.test(s))
                    && input.get(1, 2).is_some_and(|s| front.test(s))
            }
            Self::RepairItem => Self::repair_pair(ctx, &stacks).is_some(),
        }
    }
    /// `RepairItemRecipe.getItemsToCombine`.
    fn repair_pair<'a>(
        ctx: &Context,
        stacks: &[&'a ItemStack],
    ) -> Option<(&'a ItemStack, &'a ItemStack)> {
        let [first, second] = stacks else {
            return None;
        };
        let durable = |s: &ItemStack| ctx.facts(s).is_some_and(|f| f.max_damage > 0);
        (second.item == first.item
            && first.count == 1
            && second.count == 1
            && durable(first)
            && durable(second))
        .then_some((*first, *second))
    }
    /// `Recipe.assemble`; None is the empty stack.
    fn assemble(&self, ctx: &Context, input: &Input) -> Option<ItemStack> {
        use crate::banner;
        let stacks = input.stacks();
        let made = match self {
            Self::BannerDuplicate { result, .. } => {
                let source = stacks
                    .iter()
                    .find(|s| (1..=banner::MAX_LAYERS).contains(&banner::layers(s).len()))?;
                // TransmuteRecipe.createWithOriginalComponents: the source's components.
                ItemStack {
                    item: Arc::from(result.as_str()),
                    count: 1,
                    ..(**source).clone()
                }
            }
            Self::ShieldDecoration {
                banner: ing,
                target,
                result,
            } => {
                let (mut banner_stack, mut shield) = (None, None);
                for s in &stacks {
                    if ing.test(s) && banner::banner_color(&s.item).is_some() {
                        banner_stack = Some(*s);
                    } else if target.test(s) {
                        shield = Some(*s);
                    }
                }
                let (banner_stack, shield) = (banner_stack?, shield?);
                let mut out = ItemStack {
                    item: Arc::from(result.as_str()),
                    count: 1,
                    ..shield.clone()
                };
                let data = out.data_mut();
                data.banner_patterns = banner::layers(banner_stack).to_vec();
                data.base_color = banner::banner_color(&banner_stack.item).map(Arc::from);
                out
            }
            Self::Transmute {
                input: base,
                material,
                add_count,
                result,
                ..
            } => {
                if *add_count {
                    let mut materials = 0;
                    let mut found = None;
                    for s in &stacks {
                        if base.test(s) {
                            found = Some(*s);
                        } else if material.test(s) {
                            materials += 1;
                        }
                    }
                    result.over(found?, materials)
                } else {
                    let s = stacks.iter().find(|s| base.test(s))?;
                    result.over(s, 0)
                }
            }
            Self::Dye {
                target,
                dye,
                result,
            } => {
                let mut dyes = Vec::new();
                let mut target_stack: Option<&ItemStack> = None;
                for s in &stacks {
                    if target.test(s) {
                        if target_stack.is_some() {
                            return None;
                        }
                        target_stack = Some(s);
                    } else {
                        if !dye.test(s) {
                            return None;
                        }
                        // getOrDefault(DYE, WHITE)
                        dyes.push(ctx.dye(s).unwrap_or(0));
                    }
                }
                let target_stack = target_stack?;
                if dyes.is_empty() {
                    return None;
                }
                let current = target_stack.data().and_then(|d| d.dyed_color);
                let mut out = result.over(target_stack, 0);
                out.data_mut().dyed_color = Some(apply_dyes(current, &dyes));
                out
            }
            Self::Imbue { result, .. } => {
                let source = input.get(1, 1)?;
                let mut out = result.create();
                out.data_mut().potion = source.data().and_then(|d| d.potion.clone());
                out
            }
            Self::BookCloning {
                source,
                material,
                result,
                ..
            } => {
                let mut copies = 0u32;
                let mut book: Option<&ItemStack> = None;
                for s in &stacks {
                    if source.test(s) && s.data().is_some_and(|d| d.written.is_some()) {
                        if book.is_some() {
                            return None;
                        }
                        book = Some(s);
                    } else {
                        if !material.test(s) {
                            return None;
                        }
                        copies += 1;
                    }
                }
                let book = book?;
                // count - 1 can be -1 when no material was seen; matches() ensures one.
                let mut out = result.over(book, copies.saturating_sub(1));
                if let Some(w) = out.data_mut().written.as_mut() {
                    w.generation += 1;
                }
                out
            }
            Self::FireworkRocket {
                fuel, star, result, ..
            } => {
                let mut explosions = Vec::new();
                let mut fuels = 0u8;
                for s in &stacks {
                    if fuel.test(s) {
                        fuels += 1;
                    } else if star.test(s)
                        && let Some(e) = s.data().and_then(|d| d.firework_explosion.clone())
                    {
                        explosions.push(e);
                    }
                }
                let mut out = result.create();
                // A rocket's prototype is one flight and no explosions.
                if fuels != 1 || !explosions.is_empty() {
                    out.data_mut().fireworks = Some((fuels, explosions));
                }
                out
            }
            Self::FireworkStar {
                dye,
                trail,
                twinkle,
                shapes,
                result,
                ..
            } => {
                let mut shape = FireworkShape::SmallBall;
                let (mut has_twinkle, mut has_trail) = (false, false);
                let mut colors = Vec::new();
                for s in &stacks {
                    if let Some((found, _)) = shapes.iter().find(|(_, ing)| ing.test(s)) {
                        shape = *found;
                    } else if twinkle.test(s) {
                        has_twinkle = true;
                    } else if trail.test(s) {
                        has_trail = true;
                    } else if dye.test(s) {
                        colors.push(DYE_FIREWORK_COLORS[ctx.dye(s).unwrap_or(0)].1);
                    }
                }
                let mut out = result.create();
                out.data_mut().firework_explosion = Some(FireworkExplosion {
                    shape,
                    colors,
                    fade: Vec::new(),
                    trail: has_trail,
                    twinkle: has_twinkle,
                });
                out
            }
            Self::FireworkStarFade {
                dye,
                target,
                result,
            } => {
                let mut colors = Vec::new();
                let mut target_stack = None;
                for s in &stacks {
                    if dye.test(s) {
                        colors.push(DYE_FIREWORK_COLORS[ctx.dye(s).unwrap_or(0)].1);
                    } else if target.test(s) {
                        target_stack = Some(*s);
                    }
                }
                let target_stack = target_stack?;
                if colors.is_empty() {
                    return None;
                }
                let mut out = result.over(target_stack, 0);
                let explosion = out
                    .data_mut()
                    .firework_explosion
                    .get_or_insert_with(FireworkExplosion::default);
                explosion.fade = colors;
                out
            }
            Self::MapExtending { result, .. } => {
                let map = stacks
                    .iter()
                    .find(|s| s.data().is_some_and(|d| d.map_id.is_some()))?;
                let mut out = result.over(map, 0);
                out.data_mut().map_post_processing = Some(1);
                out
            }
            Self::DecoratedPot { result, .. } => {
                let side = |x, y| {
                    input.get(x, y).map(|s| ItemStack {
                        count: 1,
                        ..s.clone()
                    })
                };
                let mut out = result.create();
                let sides = [side(1, 0), side(0, 1), side(2, 1), side(1, 2)];
                if !crate::item_data::all_bricks(&sides) {
                    out.data_mut().pot_decorations = Some(Box::new(sides));
                }
                out
            }
            Self::RepairItem => {
                let (first, second) = Self::repair_pair(ctx, &stacks)?;
                let max = |s: &ItemStack| ctx.facts(s).map_or(0, |f| f.max_damage) as i64;
                let durability = max(first).max(max(second));
                let remaining = (max(first) - i64::from(first.damage))
                    + (max(second) - i64::from(second.damage))
                    + durability * 5 / 100;
                let mut out = ItemStack::new(&first.item, 1);
                out.damage = (durability - remaining).max(0) as u32;
                // Only the curses of both survive, at the higher level.
                let (a, b) = (
                    first.crafting_enchantments(),
                    second.crafting_enchantments(),
                );
                let mut curses: Vec<(Arc<str>, u32)> = Vec::new();
                for (id, level) in a.iter().chain(b.iter()) {
                    if !ctx.recipes.curses.contains(&**id) {
                        continue;
                    }
                    match curses.iter_mut().find(|(c, _)| c == id) {
                        Some((_, l)) => *l = (*l).max(*level),
                        None => curses.push((id.clone(), *level)),
                    }
                }
                out.set_crafting_enchantments(curses);
                out
            }
        };
        let mut made = made;
        made.tidy();
        // ItemStackTemplate.validate: oversized stacks become empty.
        (made.count > 0 && made.count <= ctx.max_stack(&made.item)).then_some(made)
    }
}
/// `DyedItemColor.applyDyes` over dye indexes.
pub(crate) fn apply_dyes(current: Option<i32>, dyes: &[usize]) -> i32 {
    let (mut r, mut g, mut b, mut intensity, mut n) = (0i32, 0i32, 0i32, 0i32, 0i32);
    let mut add = |rgb: u32| {
        let (red, green, blue) = (
            (rgb >> 16 & 255) as i32,
            (rgb >> 8 & 255) as i32,
            (rgb & 255) as i32,
        );
        intensity += red.max(green.max(blue));
        r += red;
        g += green;
        b += blue;
        n += 1;
    };
    if let Some(c) = current {
        add(c as u32);
    }
    for d in dyes {
        add(crate::block_entity_render::DYES[*d].1);
    }
    let (red, green, blue) = (r / n, g / n, b / n);
    let average = intensity as f32 / n as f32;
    let result = red.max(green.max(blue)) as f32;
    let scale = |c: i32| (c as f32 * average / result) as i32;
    scale(red) << 16 | scale(green) << 8 | scale(blue)
}
#[derive(Clone, Debug)]
pub struct Cooking {
    /// The recipe's file name (its id without namespace).
    pub id: String,
    /// `category` (`food`, `blocks`, `misc`) and `group` of the recipe book.
    pub category: String,
    pub group: String,
    pub kind: String,
    pub ingredient: Ingredient,
    pub result: ItemStack,
    pub experience: f32,
    pub time: u32,
}
/// A recipe of a type of a mod's own, kept as its file says: the mod reads it.
#[derive(Clone, Debug, PartialEq)]
pub struct CustomRecipe {
    /// `<namespace>:<path>`, its place under `data/<namespace>/recipe/`.
    pub id: String,
    pub json: Arc<Value>,
}
/// An item stack as a recipe's `result` names it (`ItemStackTemplate`); none
/// with no `id` or a count outside 1 to 99.
pub fn recipe_result(v: &Value) -> Option<ItemStack> {
    let template = Template::parse(v)?;
    template.item.is_some().then(|| template.create())
}
/// The type of a recipe the game doesn't craft itself: one outside `minecraft`.
/// A recipe's whole id from its name in the tables: vanilla's are kept bare
/// (`oak_planks`), everyone else's whole (`mymod:crusher/iron`).
pub fn recipe_id(name: &str) -> String {
    if name.contains(':') {
        name.to_owned()
    } else {
        format!("minecraft:{name}")
    }
}
/// The sort key of vanilla's recipe registration order, which first-match
/// lookups (`RecipeManager.getRecipeFor`'s `findFirst`), the stonecutter's
/// list and the recipe book's display numbers all follow:
/// `ResourceManagerRegistryLoadTask` sorts the resource files by `Identifier`
/// (path, then namespace) and `RecipeMap` keeps that order. The file's path
/// ends in `.json`, so `prefix-early` sorts before `prefix`. `name` is a
/// table name (`oak_planks`) or a whole id.
pub fn registration_key(name: &str) -> (String, String) {
    let (namespace, path) = name.split_once(':').unwrap_or(("minecraft", name));
    (format!("{path}.json"), namespace.to_owned())
}
fn custom_type(v: &Value) -> Option<&str> {
    v["type"]
        .as_str()
        .filter(|t| t.contains(':') && !t.starts_with("minecraft:"))
}
pub struct Recipes {
    pub crafting: Vec<(String, Recipe)>,
    pub cooking: Vec<Cooking>,
    /// The recipes of types of mods' own, by type, in registration order.
    pub custom: HashMap<String, Vec<CustomRecipe>>,
    /// `category` and `group` of each crafting recipe, by file name.
    pub meta: HashMap<String, (String, String)>,
    facts: HashMap<Arc<str>, Facts>,
    /// The `#minecraft:curse` enchantments.
    curses: HashSet<String>,
    /// The first cooking recipe of each kind taking each item, built at the
    /// first lookup (furnaces look theirs up every tick).
    cook_index: std::sync::OnceLock<CookIndex>,
}
type CookIndex = HashMap<String, crate::fast_hash::FxHashMap<String, Vec<usize>>>;
/// `MinMaxBounds.Ints` as (min, max) with the given defaults.
fn bounds(v: Option<&Value>, default: (i64, i64), open: (i64, i64)) -> (i64, i64) {
    match v {
        Some(Value::Number(n)) => {
            let n = n.as_i64().unwrap_or(default.0);
            (n, n)
        }
        Some(o @ Value::Object(_)) => (
            o["min"].as_i64().unwrap_or(open.0),
            o["max"].as_i64().unwrap_or(open.1),
        ),
        _ => default,
    }
}
/// `Util.isSymmetrical` is not needed: both orientations are tried.
/// `ShapedRecipePattern.shrink`: the pattern without empty border rows and columns.
fn shrink(pattern: &[Vec<char>]) -> Vec<Vec<char>> {
    let rows: Vec<&Vec<char>> = pattern
        .iter()
        .skip_while(|r| r.iter().all(|c| *c == ' '))
        .collect();
    let mut rows: Vec<Vec<char>> = rows.into_iter().cloned().collect();
    while rows.last().is_some_and(|r| r.iter().all(|c| *c == ' ')) {
        rows.pop();
    }
    let left = rows
        .iter()
        .filter_map(|r| r.iter().position(|c| *c != ' '))
        .min();
    let right = rows
        .iter()
        .filter_map(|r| r.iter().rposition(|c| *c != ' '))
        .max();
    match (left, right) {
        (Some(l), Some(r)) => rows.iter().map(|row| row[l..=r].to_vec()).collect(),
        _ => Vec::new(),
    }
}
/// A perfect matching of the ingredients to distinct stacks (`StackedContents.canCraft`).
fn matches_all(ingredients: &[Ingredient], stacks: &[&ItemStack]) -> bool {
    fn augment(
        i: usize,
        ingredients: &[Ingredient],
        stacks: &[&ItemStack],
        owner: &mut [Option<usize>],
        seen: &mut [bool],
    ) -> bool {
        for s in 0..stacks.len() {
            if seen[s] || !ingredients[i].test(stacks[s]) {
                continue;
            }
            seen[s] = true;
            if owner[s].is_none_or(|o| augment(o, ingredients, stacks, owner, seen)) {
                owner[s] = Some(i);
                return true;
            }
        }
        false
    }
    if ingredients.len() != stacks.len() {
        return false;
    }
    let mut owner = vec![None; stacks.len()];
    (0..ingredients.len()).all(|i| {
        let mut seen = vec![false; stacks.len()];
        augment(i, ingredients, stacks, &mut owner, &mut seen)
    })
}
/// A resource id with its default namespace filled in — the whole id the
/// book, the network copy and the advancements' JSON know a recipe by,
/// whatever the caller passes. `sources` names a `minecraft:` recipe bare
/// on purpose (vanilla's own ids); this puts the namespace back.
pub fn qualified(id: &str) -> String {
    if id.contains(':') {
        id.to_owned()
    } else {
        format!("minecraft:{id}")
    }
}

impl Recipes {
    pub fn empty() -> Self {
        Self {
            crafting: Vec::new(),
            cooking: Vec::new(),
            custom: HashMap::new(),
            meta: HashMap::new(),
            facts: HashMap::new(),
            curses: HashSet::new(),
            cook_index: std::sync::OnceLock::new(),
        }
    }

    /// `RecipeManager.getRecipe`: look up a crafting recipe by its id name.
    pub fn recipe(&self, name: &str) -> Option<&Recipe> {
        let bare = name.strip_prefix("minecraft:").unwrap_or(name);
        self.crafting
            .iter()
            .find(|(n, _)| n == name || n == bare)
            .map(|(_, r)| r)
    }

    pub fn load(root: &Path, items: &Items, overlay: &PackOverlay) -> Result<Self> {
        let sources = Self::sources(root, overlay)?;
        Self::from_sources(root, items, overlay, sources)
    }
    /// The recipe files the tables are built from, each id once: vanilla's by
    /// bare name, then the content mods' as `<ns>:<name>`, the world's packs'
    /// over them (`overlay`), parsed, and only those whose load conditions
    /// hold. A server sends some of them to its clients (`recipe_content`).
    pub fn sources(root: &Path, overlay: &PackOverlay) -> Result<Vec<(String, Value)>> {
        // Vanilla's recipes by bare name, then content mods' as `<ns>:<name>`.
        let mut sources: Vec<(String, Vec<u8>)> = Vec::new();
        // NeoForge's load conditions: `mod_loaded` asks which mods' data is
        // in this root (`minecraft`, always, and the content mods').
        // `mod_loaded` asks which mods are loaded, not which namespaces
        // they own: a mod that also owns a namespace doesn't make that
        // namespace another mod.
        let mods: Vec<String> = {
            let mut mods = horizon_items::content_namespaces::mod_ids(root);
            if !mods.iter().any(|m| m == "minecraft") {
                mods.push("minecraft".to_owned());
            }
            mods
        };
        for file in &crate::json_folder::read(&root.join("data/minecraft/recipe"))?.files {
            sources.push((file.name.clone(), file.bytes()?.to_vec()));
        }
        for namespace in crate::mod_content::namespaces(root) {
            let dir = root.join(format!("data/{namespace}/recipe"));
            if dir.is_dir() {
                for file in &crate::json_folder::read(&dir)?.files {
                    sources.push((format!("{namespace}:{}", file.name), file.bytes()?.to_vec()));
                }
            }
        }
        // The world's packs' recipes over the game's own: the top pack's
        // file for each id replaces it (`SimpleJsonResourceReloadListener`
        // sees one resource per id, the resource stack's top).
        for (id, files) in overlay.kind("recipe") {
            let Some((ns, path)) = id.split_once(':') else {
                continue;
            };
            let name = if ns == "minecraft" {
                path.to_owned()
            } else {
                id.to_owned()
            };
            let bytes = PackOverlay::top(files).to_vec();
            match sources.iter_mut().find(|(n, _)| *n == name) {
                Some(slot) => slot.1 = bytes,
                None => sources.push((name, bytes)),
            }
        }
        let filters = horizon_items::recipe_filters::RecipeFilters::load(root, overlay);
        let mut parsed = Vec::with_capacity(sources.len());
        for (name, bytes) in sources {
            // Vanilla's RecipeManager logs a file that does not parse and
            // goes on ("Couldn't parse data file").
            let mut v: Value = match serde_json::from_slice(&bytes) {
                Ok(v) => v,
                Err(e) => {
                    log::warn!("Horizon: recipe {name} not loaded: {e}");
                    continue;
                }
            };
            // A file whose load conditions don't hold is silently absent,
            // as NeoForge's ICondition leaves it out of the manager.
            if !horizon_world::conditions::conditions_hold(&v, &|id: &str| {
                mods.iter().any(|m| m == id)
            }) {
                continue;
            }
            // The data's recipe filters, over the final set.
            if !filters.apply(&recipe_id(&name), &mut v) {
                continue;
            }
            parsed.push((name, v));
        }
        Ok(parsed)
    }
    /// The tables from `sources` (`Recipes::sources`' shape); `root` and
    /// `overlay` give the enchantment tags the tables keep.
    pub fn from_sources(
        root: &Path,
        items: &Items,
        overlay: &PackOverlay,
        mut sources: Vec<(String, Value)>,
    ) -> Result<Self> {
        // Every table in registration order, whatever order the sources come
        // in (the world's packs' files after the game's own).
        sources.sort_by_cached_key(|(name, _)| registration_key(name));
        let mut crafting = Vec::new();
        let mut cooking = Vec::new();
        let mut custom: HashMap<String, Vec<CustomRecipe>> = HashMap::new();
        let mut meta = HashMap::new();
        for (name, v) in sources {
            if let Some(kind) = custom_type(&v) {
                let id = if name.contains(':') {
                    name
                } else {
                    format!("minecraft:{name}")
                };
                let kind = kind.to_owned();
                let json = Arc::new(v);
                custom
                    .entry(kind)
                    .or_default()
                    .push(CustomRecipe { id, json });
                continue;
            }
            let text = |k: &str| v[k].as_str().unwrap_or("").to_owned();
            meta.insert(name.clone(), (text("category"), text("group")));
            let ing = |k: &str| Ingredient::parse(&v[k], items);
            let result = || Template::parse(&v["result"]);
            let special = |recipe: Option<Special>| recipe.map(Recipe::Special);
            let parsed: Option<Recipe> = match v["type"].as_str().unwrap_or("") {
                "minecraft:crafting_shaped" => {
                    let pattern: Vec<Vec<char>> = v["pattern"]
                        .as_array()
                        .into_iter()
                        .flatten()
                        .filter_map(|r| r.as_str().map(|s| s.chars().collect()))
                        .collect();
                    let pattern = shrink(&pattern);
                    let height = pattern.len();
                    let width = pattern.first().map_or(0, Vec::len);
                    let mut cells = Vec::with_capacity(width * height);
                    let mut ok = height > 0;
                    for row in &pattern {
                        for c in row {
                            if *c == ' ' {
                                cells.push(None);
                            } else {
                                match Ingredient::parse(&v["key"][c.to_string()], items) {
                                    Some(i) => cells.push(Some(i)),
                                    None => ok = false,
                                }
                            }
                        }
                    }
                    match (ok, result()) {
                        (true, Some(result)) => Some(Recipe::Shaped {
                            width,
                            height,
                            cells,
                            result,
                        }),
                        _ => None,
                    }
                }
                "minecraft:crafting_shapeless" => {
                    let ingredients: Option<Vec<_>> = v["ingredients"]
                        .as_array()
                        .into_iter()
                        .flatten()
                        .map(|i| Ingredient::parse(i, items))
                        .collect();
                    match (ingredients, result()) {
                        (Some(ingredients), Some(result)) => Some(Recipe::Shapeless {
                            ingredients,
                            result,
                        }),
                        _ => None,
                    }
                }
                "minecraft:crafting_special_bannerduplicate" => special(
                    ing("banner")
                        .zip(horizon_world::loot::recipe_result_id(&v["result"]))
                        .map(|(banner, id)| Special::BannerDuplicate {
                            banner,
                            result: id.to_owned(),
                        }),
                ),
                "minecraft:crafting_special_shielddecoration" => special(
                    ing("banner")
                        .zip(ing("target"))
                        .zip(horizon_world::loot::recipe_result_id(&v["result"]))
                        .map(|((banner, target), id)| Special::ShieldDecoration {
                            banner,
                            target,
                            result: id.to_owned(),
                        }),
                ),
                "minecraft:crafting_transmute" => special((|| {
                    let (min, max) = bounds(v.get("material_count"), (1, 1), (1, 8));
                    Some(Special::Transmute {
                        input: ing("input")?,
                        material: ing("material")?,
                        min: min.clamp(1, 8) as usize,
                        max: max.clamp(1, 8) as usize,
                        add_count: v["add_material_count_to_result"].as_bool().unwrap_or(false),
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_dye" => special((|| {
                    Some(Special::Dye {
                        target: ing("target")?,
                        dye: ing("dye")?,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_imbue" => special((|| {
                    Some(Special::Imbue {
                        source: ing("source")?,
                        material: ing("material")?,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_special_bookcloning" => special((|| {
                    let (min, max) = bounds(v.get("allowed_generations"), (0, 1), (0, 2));
                    Some(Special::BookCloning {
                        source: ing("source")?,
                        material: ing("material")?,
                        min: min as i32,
                        max: max as i32,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_special_firework_rocket" => special((|| {
                    Some(Special::FireworkRocket {
                        shell: ing("shell")?,
                        fuel: ing("fuel")?,
                        star: ing("star")?,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_special_firework_star" => special((|| {
                    let mut shapes = Vec::new();
                    for (shape, value) in v["shapes"].as_object()? {
                        shapes.push((
                            FireworkShape::from_name(shape),
                            Ingredient::parse(value, items)?,
                        ));
                    }
                    Some(Special::FireworkStar {
                        dye: ing("dye")?,
                        fuel: ing("fuel")?,
                        trail: ing("trail")?,
                        twinkle: ing("twinkle")?,
                        shapes,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_special_firework_star_fade" => special((|| {
                    Some(Special::FireworkStarFade {
                        dye: ing("dye")?,
                        target: ing("target")?,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_special_mapextending" => special((|| {
                    Some(Special::MapExtending {
                        map: ing("map")?,
                        material: ing("material")?,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_decorated_pot" => special((|| {
                    Some(Special::DecoratedPot {
                        back: ing("back")?,
                        left: ing("left")?,
                        right: ing("right")?,
                        front: ing("front")?,
                        result: result()?,
                    })
                })()),
                "minecraft:crafting_special_repairitem" => special(Some(Special::RepairItem)),
                kind @ ("minecraft:smelting"
                | "minecraft:blasting"
                | "minecraft:smoking"
                | "minecraft:campfire_cooking") => {
                    if let (Some(ingredient), Some(result)) = (ing("ingredient"), result()) {
                        cooking.push(Cooking {
                            id: name.clone(),
                            category: text("category"),
                            group: text("group"),
                            kind: kind.to_owned(),
                            ingredient,
                            result: result.create(),
                            experience: v["experience"].as_f64().unwrap_or(0.0) as f32,
                            time: v["cookingtime"].as_u64().unwrap_or(200) as u32,
                        });
                    }
                    None
                }
                _ => None,
            };
            if let Some(recipe) = parsed {
                crafting.push((name, recipe));
            }
        }
        let facts = items
            .items
            .iter()
            .map(|(id, info)| {
                (
                    id.clone(),
                    Facts {
                        dye: info.dye.as_deref().and_then(|d| {
                            crate::block_entity_render::DYES
                                .iter()
                                .position(|(name, _)| *name == d)
                        }),
                        max_damage: info.max_damage,
                        max_stack: info.max_stack,
                        remainder: info.crafting_remainder.as_deref().map(Arc::from),
                    },
                )
            })
            .collect();
        let curses = crate::items::load_tags(root, "enchantment", overlay)?
            .remove("minecraft:curse")
            .unwrap_or_default();
        Ok(Self {
            crafting,
            cooking,
            custom,
            meta,
            facts,
            curses,
            cook_index: Default::default(),
        })
    }
    /// Match a `size`x`size` grid (row-major) against the crafting recipes.
    pub fn craft(&self, grid: &[Option<ItemStack>], size: usize) -> Option<ItemStack> {
        self.find(grid, size).map(|(_, result)| result)
    }
    /// `craft` with the matched recipe's id (the file name without namespace).
    pub fn find(&self, grid: &[Option<ItemStack>], size: usize) -> Option<(&str, ItemStack)> {
        self.find_with(grid, size, &|_| None)
    }
    /// `RecipeManager.getRecipeFor(CRAFTING, ...)` with a lookup for the scale
    /// of a filled map (map extending reads the map's saved data).
    pub fn find_with(
        &self,
        grid: &[Option<ItemStack>],
        size: usize,
        map_scale: &dyn Fn(i32) -> Option<u8>,
    ) -> Option<(&str, ItemStack)> {
        let input = Input::of(grid, size)?;
        let ctx = Context {
            recipes: self,
            map_scale,
        };
        for (name, recipe) in &self.crafting {
            if let Some(result) = Self::assemble_if_matches(&ctx, &input, recipe) {
                return result.map(|r| (name.as_str(), r));
            }
        }
        None
    }
    /// `Recipe.matches` then `assemble` for one recipe: None when it does
    /// not match, Some(None) when it matches with nothing to make.
    fn assemble_if_matches(
        ctx: &Context,
        input: &Input,
        recipe: &Recipe,
    ) -> Option<Option<ItemStack>> {
        match recipe {
            Recipe::Special(special) => special
                .matches(ctx, input)
                .then(|| special.assemble(ctx, input)),
            Recipe::Shaped {
                width,
                height,
                cells,
                result,
            } => {
                if *width != input.width
                    || *height != input.height
                    || cells.iter().flatten().count() != input.count()
                {
                    return None;
                }
                let matches = |mirror: bool| {
                    (0..*height).all(|y| {
                        (0..*width).all(|x| {
                            let rx = if mirror { width - 1 - x } else { x };
                            match (&cells[y * width + rx], input.get(x, y)) {
                                (None, None) => true,
                                (Some(i), Some(s)) => i.test(s),
                                _ => false,
                            }
                        })
                    })
                };
                (matches(false) || matches(true)).then(|| Some(result.create()))
            }
            Recipe::Shapeless {
                ingredients,
                result,
            } => matches_all(ingredients, &input.stacks()).then(|| Some(result.create())),
        }
    }
    /// `recipe.matches(craftSlots.asCraftInput())` for one recipe by id
    /// (`minecraft:name`).
    pub fn recipe_matches(&self, id: &str, grid: &[Option<ItemStack>], size: usize) -> bool {
        let name = id.trim_start_matches("minecraft:");
        let Some((_, recipe)) = self.crafting.iter().find(|(n, _)| n == name) else {
            return false;
        };
        let Some(input) = Input::of(grid, size) else {
            return false;
        };
        let ctx = Context {
            recipes: self,
            map_scale: &|_| None,
        };
        Self::assemble_if_matches(&ctx, &input, recipe).is_some()
    }
    /// `Recipe.placementInfo` of a crafting or cooking recipe by id; None for
    /// an unknown id, an empty placement when it is impossible to place.
    pub fn placement(&self, id: &str) -> Option<Placement> {
        let name = id.trim_start_matches("minecraft:");
        if let Some(c) = self.cooking.iter().find(|c| c.id == name) {
            return Some(Placement::of(vec![Some(c.ingredient.clone())], None));
        }
        let (_, recipe) = self.crafting.iter().find(|(n, _)| n == name)?;
        Some(match recipe {
            Recipe::Shaped {
                width,
                height,
                cells,
                ..
            } => Placement::of(cells.clone(), Some((*width, *height))),
            Recipe::Shapeless { ingredients, .. } => {
                Placement::of(ingredients.iter().cloned().map(Some).collect(), None)
            }
            Recipe::Special(Special::Transmute {
                input,
                material,
                max,
                ..
            }) => {
                let mut list = vec![Some(input.clone())];
                list.extend(std::iter::repeat_n(Some(material.clone()), *max));
                Placement::of(list, None)
            }
            Recipe::Special(Special::Dye { target, dye, .. }) => {
                Placement::of(vec![Some(target.clone()), Some(dye.clone())], None)
            }
            Recipe::Special(Special::Imbue {
                source, material, ..
            }) => Placement::of(
                (0..9)
                    .map(|i| Some(if i == 4 { source } else { material }.clone()))
                    .collect(),
                None,
            ),
            // CustomRecipe.placementInfo: NOT_PLACEABLE.
            Recipe::Special(_) => Placement::default(),
        })
    }
    /// `Recipe.getRemainingItems` placed on the `size`x`size` grid: an item's
    /// crafting remainder (buckets, bottles), the patterned banner a duplicate
    /// keeps and the written book a clone keeps.
    pub fn remainders(
        &self,
        recipe: &str,
        grid: &[Option<ItemStack>],
        size: usize,
    ) -> Vec<Option<ItemStack>> {
        let mut out = vec![None; size * size];
        let Some(input) = Input::of(grid, size) else {
            return out;
        };
        let kind = self
            .crafting
            .iter()
            .find(|(n, _)| n == recipe)
            .map(|(_, r)| r);
        for (i, cell) in input.cells.iter().enumerate() {
            let Some(s) = cell else { continue };
            let at = (input.top + i / input.width) * size + input.left + i % input.width;
            let rest = self
                .facts
                .get(&s.item)
                .and_then(|f| f.remainder.as_deref())
                .map(|r| ItemStack::new(r, 1));
            if rest.is_some() {
                out[at] = rest;
                continue;
            }
            let copy = ItemStack {
                count: 1,
                ..(*s).clone()
            };
            match kind {
                Some(Recipe::Special(Special::BannerDuplicate { .. }))
                    if !crate::banner::layers(s).is_empty() =>
                {
                    out[at] = Some(copy);
                }
                // BookCloningRecipe stops at the first copied book.
                Some(Recipe::Special(Special::BookCloning { .. }))
                    if s.data().is_some_and(|d| d.written.is_some()) =>
                {
                    out[at] = Some(copy);
                    break;
                }
                _ => {}
            }
        }
        out
    }
    /// The `experience` of the cooking recipe with this file name, and 0 for one this data
    /// pack does not have (a save from another pack can name it).
    /// `id` with or without the `minecraft:` namespace (a furnace keeps the full id).
    pub fn cooking_experience(&self, id: &str) -> f32 {
        let id = id.strip_prefix("minecraft:").unwrap_or(id);
        self.cooking
            .iter()
            .find(|c| c.id == id)
            .map_or(0.0, |c| c.experience)
    }
    pub fn cook(&self, kind: &str, input: &ItemStack) -> Option<&Cooking> {
        // Every recipe an item names, not just the first: a mod's match-time
        // hook may refuse the one the first recipe would take (`Ingredient::test`).
        let index = self.cook_index.get_or_init(|| {
            let mut index = CookIndex::new();
            for (i, c) in self.cooking.iter().enumerate() {
                let of_kind = index.entry(c.kind.clone()).or_default();
                for item in &c.ingredient.items {
                    of_kind.entry(item.clone()).or_default().push(i);
                }
            }
            index
        });
        index
            .get(kind)?
            .get(&*input.item)?
            .iter()
            .find_map(|i| self.cooking.get(*i).filter(|c| c.ingredient.test(input)))
    }
    /// `cook` by scanning every recipe, as it was before the index.
    #[cfg(test)]
    fn cook_scan(&self, kind: &str, input: &ItemStack) -> Option<&Cooking> {
        self.cooking
            .iter()
            .find(|c| c.kind == kind && c.ingredient.test(input))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::banner::BannerLayer;
    use std::fs;

    /// ItemStackTemplate.apply applies the result patch after the input patch.
    #[test]
    fn transmute_result_patch_preserves_inheritance_and_explicit_removals() {
        let input_tag = json_tag(&serde_json::json!({
            "minecraft:damage": 5, "minecraft:lore": ["Old"]
        }));
        let (damage, extra) = crate::item_data::decode_components(Some(&input_tag));
        let input = ItemStack {
            item: "minecraft:wooden_sword".into(),
            count: 1,
            damage,
            extra,
        };
        for (components, expected_damage, removed) in [
            (
                serde_json::json!({"minecraft:custom_name": "Kept"}),
                5,
                false,
            ),
            (
                serde_json::json!({"minecraft:custom_name": "Up", "!minecraft:damage": {}}),
                0,
                true,
            ),
            (
                serde_json::json!({"minecraft:custom_name": "Zero", "minecraft:damage": 0}),
                0,
                false,
            ),
        ] {
            let template = Template::parse(&serde_json::json!({
                "id": "minecraft:stone_sword", "components": components
            }))
            .unwrap();
            let output = template.over(&input, 0);
            assert_eq!(output.item.as_ref(), "minecraft:stone_sword");
            assert_eq!(output.damage, expected_damage);
            let encoded = crate::item_data::encode_components(&output).unwrap();
            assert_eq!(
                encoded.get("minecraft:lore"),
                input_tag.get("minecraft:lore")
            );
            assert_eq!(
                encoded.get("minecraft:custom_name"),
                Some(&json_tag(&components["minecraft:custom_name"]))
            );
            assert_eq!(encoded.get("!minecraft:damage").is_some(), removed);
            if expected_damage == 0 {
                assert!(encoded.get("minecraft:damage").is_none());
            }
        }
        let mut map = input.clone();
        map.data_mut().map_post_processing = Some(1);
        let template = Template::parse(&serde_json::json!({"id": "minecraft:filled_map"})).unwrap();
        let output = template.over(&map, 0);
        assert_eq!(output.data().unwrap().map_post_processing, Some(1));
        assert!(
            crate::item_data::encode_components(&output)
                .unwrap()
                .get("minecraft:map_post_processing")
                .is_none()
        );
    }

    #[test]
    fn result_count_is_bounded_like_vanilla() {
        let parse = |s: &str| Template::parse(&serde_json::from_str(s).unwrap());
        assert_eq!(parse(r#"{"id":"minecraft:stone"}"#).unwrap().count, 1);
        let top = parse(r#"{"id":"minecraft:stone","count":99}"#);
        assert_eq!(top.unwrap().count, 99);
        for bad in [
            "0",
            "100",
            "2147483648",
            "4294967295",
            "4294967296",
            "-1",
            "1.5",
            "\"2\"",
        ] {
            let json = format!(r#"{{"id":"minecraft:stone","count":{bad}}}"#);
            assert!(parse(&json).is_none(), "count {bad} must be rejected");
        }
    }

    /// A mod's recipe whose ingredient is one of NeoForge's standard shapes
    /// loads and carries the resolved items, where the plain string parser
    /// used to drop the file whole.
    #[test]
    fn a_neoforge_ingredient_recipe_loads() {
        let root =
            std::env::temp_dir().join(format!("horizon-neo-ingredient-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        fs::create_dir_all(root.join("data/mymod/recipe")).unwrap();
        fs::write(
            root.join(horizon_items::content_namespaces::MARKER),
            br#"["mymod"]"#,
        )
        .unwrap();
        let recipe = r##"{
            "type": "minecraft:crafting_shapeless",
            "ingredients": [
                {"neoforge:ingredient_type": "neoforge:compound",
                 "children": ["minecraft:oak_planks", "minecraft:birch_planks"]},
                {"type": "neoforge:difference",
                 "base": ["minecraft:oak_planks", "minecraft:birch_planks"],
                 "subtracted": "minecraft:birch_planks"}
            ],
            "result": {"id": "minecraft:stick", "count": 4}
        }"##;
        fs::write(root.join("data/mymod/recipe/treated.json"), recipe).unwrap();
        let items = Items::for_tests(HashMap::new());
        let recipes = Recipes::load(&root, &items, &PackOverlay::NONE).unwrap();
        assert_eq!(recipes.crafting.len(), 1);
        assert_eq!(recipes.crafting[0].0, "mymod:treated");
        let _ = fs::remove_dir_all(&root);
    }

    /// NeoForge's standard ingredient shapes resolve to their flat item
    /// lists; a kind the loader doesn't know still fails the file.
    #[test]
    fn an_unclaimed_ingredient_kind_fails_and_dedup_keeps_order() {
        let items = Items::for_tests(HashMap::new());
        let json = |s: &str| serde_json::from_str::<Value>(s).unwrap();
        assert!(
            Ingredient::parse(&json(r#"{"type":"mymod:aspect","aspect":"fire"}"#), &items,)
                .is_none()
        );
        assert!(
            Ingredient::parse(&json(r#"{"type":"minecraft:future_shape"}"#), &items,).is_none()
        );
        assert!(Ingredient::parse(&json(r#"{"type":"aspect"}"#), &items,).is_none());
        let mut list = vec!["b".to_string(), "a".to_string(), "b".to_string()];
        dedup_keep_order(&mut list);
        assert_eq!(list, vec!["b".to_string(), "a".to_string()]);
    }

    /// NeoForge's shapes keep their children, and matching a concrete
    /// stack asks each child its own way — any for compound, all for
    /// intersection, base-but-not-subtracted for difference. A mod's own
    /// kind among the children answers through its hook the same way
    /// (proven on a staged build).
    #[test]
    fn nested_shapes_test_each_child_their_own_way() {
        let items = Items::for_tests(HashMap::new());
        let parse = |s: &str| {
            Ingredient::parse(&serde_json::from_str::<Value>(s).unwrap(), &items).unwrap()
        };
        let stack = |n: &str| ItemStack {
            item: n.into(),
            count: 1,
            damage: 0,
            extra: None,
        };
        let compound = parse(
            r#"{"type":"neoforge:compound","children":["minecraft:oak_planks","minecraft:birch_planks"]}"#,
        );
        assert!(compound.children.is_some(), "the children stay with it");
        assert!(compound.test(&stack("minecraft:oak_planks")));
        assert!(compound.test(&stack("minecraft:birch_planks")));
        assert!(!compound.test(&stack("minecraft:stone")));
        let inter = parse(
            r#"{"type":"neoforge:intersection","ingredients":["minecraft:oak_planks",["minecraft:oak_planks","minecraft:birch_planks"]]}"#,
        );
        assert!(inter.test(&stack("minecraft:oak_planks")));
        assert!(!inter.test(&stack("minecraft:birch_planks")));
        let diff = parse(
            r#"{"type":"neoforge:difference","base":["minecraft:oak_planks","minecraft:birch_planks"],"subtracted":"minecraft:birch_planks"}"#,
        );
        assert!(diff.test(&stack("minecraft:oak_planks")));
        assert!(!diff.test(&stack("minecraft:birch_planks")));
    }

    #[test]
    fn neoforge_ingredient_shapes_parse() {
        let mut tags = HashMap::new();
        tags.insert(
            "minecraft:planks".to_owned(),
            ["minecraft:oak_planks", "minecraft:birch_planks"]
                .iter()
                .map(|s| s.to_string())
                .collect::<HashSet<_>>(),
        );
        let items = Items::for_tests(tags);
        let json = |s: &str| serde_json::from_str::<Value>(s).unwrap();
        // Compound (`CompoundIngredient`): any child matching is enough —
        // the union of their items, a tag beside an item gives both.
        let union = Ingredient::parse(
            &json(r##"{"neoforge:ingredient_type":"neoforge:compound","children":["#minecraft:planks","minecraft:stone"]}"##),
            &items,
        )
        .unwrap();
        // The tag's items come from a HashSet: their order is not fixed.
        let mut all = union.order.clone();
        all.sort();
        assert_eq!(
            all,
            [
                "minecraft:birch_planks",
                "minecraft:oak_planks",
                "minecraft:stone"
            ]
        );
        // Intersection: every child must match — only the items all name.
        let both = Ingredient::parse(
            &json(r##"{"type":"neoforge:intersection","children":["#minecraft:planks","minecraft:oak_planks"]}"##),
            &items,
        )
        .unwrap();
        assert_eq!(both.order, ["minecraft:oak_planks"]);
        // Difference: the base without the subtracted.
        let no_oak = Ingredient::parse(
            &json(r##"{"type":"neoforge:difference","base":"#minecraft:planks","subtracted":"minecraft:oak_planks"}"##),
            &items,
        )
        .unwrap();
        assert_eq!(no_oak.order, ["minecraft:birch_planks"]);
        // An empty intersection and an unknown kind fail the file, as today.
        let empty = Ingredient::parse(
            &json(
                r#"{"type":"neoforge:intersection","children":["minecraft:oak_planks","minecraft:birch_planks"]}"#,
            ),
            &items,
        );
        assert!(empty.is_none());
        let unknown =
            Ingredient::parse(&json(r#"{"type":"mymod:aspect","aspect":"fire"}"#), &items);
        assert!(unknown.is_none());
    }

    fn ingredient(items: &[&str]) -> Ingredient {
        Ingredient::of(items.iter().map(|s| (*s).to_owned()).collect())
    }
    fn patterned(item: &str) -> ItemStack {
        let mut s = ItemStack::new(item, 1);
        s.data_mut().banner_patterns = vec![BannerLayer::new("minecraft:cross", "red")];
        s
    }
    /// About vanilla's count of cooking recipes: four kinds, ingredients of
    /// one to twelve items, overlapping (several recipes take some items).
    fn cooking_book() -> Recipes {
        let kinds = ["smelting", "blasting", "smoking", "campfire_cooking"];
        let cooking = (0..320usize)
            .map(|i| Cooking {
                id: format!("r{i}"),
                category: "misc".into(),
                group: String::new(),
                kind: kinds[i % 4].into(),
                ingredient: ingredient(
                    &(0..1 + i % 12)
                        .map(|k| format!("minecraft:item_{}", (i * 7 + k * 13) % 400))
                        .collect::<Vec<_>>()
                        .iter()
                        .map(String::as_str)
                        .collect::<Vec<_>>(),
                ),
                result: ItemStack::new("minecraft:stone", 1),
                experience: 0.1,
                time: 200,
            })
            .collect();
        Recipes {
            crafting: Vec::new(),
            cooking,
            custom: HashMap::new(),
            meta: HashMap::new(),
            facts: HashMap::new(),
            curses: HashSet::new(),
            cook_index: Default::default(),
        }
    }
    #[test]
    fn only_types_outside_minecraft_are_custom() {
        let kind = |json: &str| {
            let v: Value = serde_json::from_str(json).unwrap();
            custom_type(&v).map(str::to_owned)
        };
        assert_eq!(
            kind(r#"{"type":"mymod:crusher"}"#).as_deref(),
            Some("mymod:crusher")
        );
        assert_eq!(kind(r#"{"type":"minecraft:smelting"}"#), None);
        assert_eq!(kind(r#"{"type":"minecraft:from_a_later_version"}"#), None);
        assert_eq!(kind(r#"{"type":"no_namespace"}"#), None);
        assert_eq!(kind(r#"{"type":7}"#), None);
        assert_eq!(kind("{}"), None);
    }
    /// Recipes of a mod's own types land in `custom` by type, in registration order,
    /// with the id the file has; a data pack overrides by id and adds more; a
    /// `minecraft` type the game doesn't know is dropped.
    #[test]
    fn custom_recipes_load_by_type_with_pack_override() {
        let root =
            std::env::temp_dir().join(format!("horizon-custom-recipes-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        fs::create_dir_all(root.join("data/mymod/recipe")).unwrap();
        fs::write(
            root.join(horizon_items::content_namespaces::MARKER),
            br#"["mymod"]"#,
        )
        .unwrap();
        let file =
            |kind: &str, tag: &str| format!(r#"{{"type":"{kind}","tag":"{tag}"}}"#).into_bytes();
        fs::write(
            root.join("data/mymod/recipe/a.json"),
            file("mymod:crusher", "a"),
        )
        .unwrap();
        fs::write(
            root.join("data/mymod/recipe/b.json"),
            file("mymod:crusher", "b"),
        )
        .unwrap();
        fs::write(
            root.join("data/mymod/recipe/c.json"),
            file("mymod:mixer", "c"),
        )
        .unwrap();
        fs::create_dir_all(root.join("data/mymod/recipe/deep/er")).unwrap();
        fs::write(
            root.join("data/mymod/recipe/deep/er/d.json"),
            file("mymod:mixer", "d"),
        )
        .unwrap();
        fs::write(
            root.join("data/minecraft/recipe/later.json"),
            file("minecraft:from_a_later_version", "x"),
        )
        .unwrap();
        let items = Items::for_tests(HashMap::new());
        let recipes = Recipes::load(&root, &items, &PackOverlay::NONE).unwrap();
        let ids = |kind: &str| -> Vec<String> {
            recipes.custom[kind].iter().map(|r| r.id.clone()).collect()
        };
        assert_eq!(ids("mymod:crusher"), ["mymod:a", "mymod:b"]);
        assert_eq!(ids("mymod:mixer"), ["mymod:c", "mymod:deep/er/d"]);
        assert_eq!(recipes.custom.len(), 2);
        // Not crafted, and no recipe-book meta of their own.
        assert!(recipes.crafting.is_empty() && recipes.cooking.is_empty());
        assert!(!recipes.meta.keys().any(|k| k.starts_with("mymod:")));
        // A pack replaces `mymod:b`, and adds `pack:d` and a `minecraft:p` of its own type.
        let packs = [
            (
                "recipe/mymod:b".to_owned(),
                vec![file("mymod:crusher", "pack-b")],
            ),
            ("recipe/pack:d".to_owned(), vec![file("mymod:crusher", "d")]),
            (
                "recipe/minecraft:p".to_owned(),
                vec![file("pack:press", "p")],
            ),
        ];
        let recipes = Recipes::load(&root, &items, &PackOverlay { files: &packs }).unwrap();
        let crusher = &recipes.custom["mymod:crusher"];
        assert_eq!(
            crusher.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(),
            ["mymod:a", "mymod:b", "pack:d"]
        );
        assert_eq!(crusher[1].json["tag"], "pack-b");
        assert_eq!(recipes.custom["pack:press"][0].id, "minecraft:p");
        let _ = fs::remove_dir_all(&root);
    }
    #[test]
    fn a_recipe_result_needs_an_item_and_a_sane_count() {
        let result = |json: &str| recipe_result(&serde_json::from_str(json).unwrap());
        let stack = result(r#"{"id":"minecraft:iron_ingot","count":2}"#).unwrap();
        assert_eq!((&*stack.item, stack.count), ("minecraft:iron_ingot", 2));
        assert_eq!(result(r#"{"id":"minecraft:iron_ingot"}"#).unwrap().count, 1);
        assert!(result(r#"{"count":2}"#).is_none());
        assert!(result(r#"{"id":"minecraft:iron_ingot","count":0}"#).is_none());
    }
    #[test]
    fn a_recipe_result_can_be_a_bare_item_id() {
        // `ItemStackTemplate.CODEC` falls back to `Item.CODEC`: `"result": "mod:item"` is one item.
        let result = |json: &str| recipe_result(&serde_json::from_str(json).unwrap());
        let stack = result(r#""ruby:ruby""#).unwrap();
        assert_eq!((&*stack.item, stack.count), ("ruby:ruby", 1));
        // The `item` key of older versions is no `id`, and a number names no item.
        assert!(result(r#"{"item":"ruby:ruby"}"#).is_none());
        assert!(result("42").is_none());
    }
    #[test]
    fn a_shapeless_recipe_makes_the_item_its_bare_result_names() {
        let root = std::env::temp_dir().join(format!("horizon-bare-result-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        fs::write(
            root.join("data/minecraft/recipe/bare.json"),
            br#"{"type":"minecraft:crafting_shapeless","ingredients":["minecraft:flint"],"result":"minecraft:stick"}"#,
        )
        .unwrap();
        let items = Items::for_tests(HashMap::new());
        let recipes = Recipes::load(&root, &items, &PackOverlay::NONE).unwrap();
        let grid = [Some(ItemStack::new("minecraft:flint", 1)), None, None, None];
        let (_, made) = recipes.find(&grid, 2).unwrap();
        assert_eq!((&*made.item, made.count), ("minecraft:stick", 1));
        let _ = fs::remove_dir_all(&root);
    }

    /// ResourceManagerRegistryLoadTask registers by resource-file Identifier,
    /// and RecipeMap keeps that order when taking the first matching recipe,
    /// for the crafting grid and the furnaces alike.
    #[test]
    fn recipe_selection_follows_resource_file_order() {
        let root =
            std::env::temp_dir().join(format!("horizon-recipe-order-{}", std::process::id()));
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        let items = Items::for_tests(HashMap::new());
        let crafting = |item: &str| {
            serde_json::json!({
                "type": "minecraft:crafting_shapeless", "ingredients": ["minecraft:flint"],
                "result": {"id": item}
            })
        };
        let smelting = |item: &str| {
            serde_json::json!({
                "type": "minecraft:smelting", "ingredient": "minecraft:flint",
                "result": {"id": item}
            })
        };
        let flint = ItemStack::new("minecraft:flint", 1);
        let cases = [
            (vec!["minecraft:z_pick", "parity:a_pick"], "parity:a_pick"),
            (
                vec!["a_priority:z_pick", "z_priority:a_pick"],
                "z_priority:a_pick",
            ),
            (
                vec!["z_priority:equal", "a_priority:equal"],
                "a_priority:equal",
            ),
            // File names include .json: '-' sorts before the parent's '.'.
            (
                vec!["parity:prefix", "parity:prefix-early"],
                "parity:prefix-early",
            ),
            (vec!["z_pick", "parity:a_pick"], "parity:a_pick"),
        ];
        let kinds: [(&str, &dyn Fn(&str) -> serde_json::Value); 2] =
            [("crafting", &crafting), ("smelting", &smelting)];
        for (ids, expected) in cases {
            for (kind, recipe) in kinds {
                for reverse in [false, true] {
                    let mut sources: Vec<_> = ids
                        .iter()
                        .map(|id| (id.to_string(), recipe("minecraft:stick")))
                        .collect();
                    if reverse {
                        sources.reverse();
                    }
                    let recipes =
                        Recipes::from_sources(&root, &items, &PackOverlay::NONE, sources).unwrap();
                    let (id, result) = match kind {
                        "crafting" => recipes.find(&[Some(flint.clone())], 1).unwrap(),
                        _ => {
                            let c = recipes.cook("minecraft:smelting", &flint).unwrap();
                            (c.id.as_str(), c.result.clone())
                        }
                    };
                    assert_eq!(
                        id, expected,
                        "{kind}, input order: {ids:?}, reversed={reverse}"
                    );
                    assert_eq!(&*result.item, "minecraft:stick");
                }
            }
        }
        let _ = fs::remove_dir_all(&root);
    }

    /// A recipe whose `neoforge:conditions` hold loads, one whose don't is
    /// silently absent, from the root's own files and a pack's alike.
    #[test]
    fn load_conditions_gate_recipes() {
        let root = std::env::temp_dir().join(format!("horizon-conditions-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        fs::write(
            root.join(horizon_items::content_namespaces::MARKER),
            br#"["mymod"]"#,
        )
        .unwrap();
        fs::write(
            root.join(horizon_items::content_namespaces::MOD_IDS_MARKER),
            br#"["mymod"]"#,
        )
        .unwrap();
        let file = |conditions: &str, tag: &str| {
            format!(
                r#"{{"type":"mymod:crusher","tag":"{tag}","neoforge:conditions":{conditions}}}"#
            )
            .into_bytes()
        };
        // `mymod` is in the root, `ic2` is not.
        fs::write(
            root.join("data/minecraft/recipe/yes.json"),
            file(r#"[{"type":"neoforge:mod_loaded","modid":"mymod"}]"#, "yes"),
        )
        .unwrap();
        fs::write(
            root.join("data/minecraft/recipe/no.json"),
            file(r#"[{"type":"neoforge:mod_loaded","modid":"ic2"}]"#, "no"),
        )
        .unwrap();
        fs::write(
            root.join("data/minecraft/recipe/inverted.json"),
            file(
                r#"[{"type":"neoforge:not","value":{"type":"neoforge:mod_loaded","modid":"ic2"}}]"#,
                "inverted",
            ),
        )
        .unwrap();
        let items = Items::for_tests(HashMap::new());
        let recipes = Recipes::load(&root, &items, &PackOverlay::NONE).unwrap();
        let ids = &recipes.custom["mymod:crusher"];
        assert_eq!(
            ids.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(),
            ["minecraft:inverted", "minecraft:yes"]
        );
        // A pack's gated file answers the same gate.
        let packs = [(
            "recipe/minecraft:pack_yes".to_owned(),
            vec![file(r#"[{"type":"neoforge:true"}]"#, "pack_yes")],
        )];
        let recipes = Recipes::load(&root, &items, &PackOverlay { files: &packs }).unwrap();
        let ids = &recipes.custom["mymod:crusher"];
        assert!(ids.iter().any(|r| r.id == "minecraft:pack_yes"));
        let _ = fs::remove_dir_all(&root);
    }
    /// A pack's recipe filter removes a recipe and swaps a mod recipe's input
    /// in the loaded tables, after the packs are merged.
    #[test]
    fn recipe_filters_remove_and_swap() {
        let root = std::env::temp_dir().join(format!("horizon-filters-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        fs::create_dir_all(root.join("data/minecraft/recipe")).unwrap();
        let crusher = |input: &str| {
            format!(
                r#"{{"type":"mymod:crusher","input":"{input}","result":{{"id":"mymod:dust"}}}}"#
            )
            .into_bytes()
        };
        fs::write(
            root.join("data/minecraft/recipe/iron.json"),
            crusher("minecraft:iron_ingot"),
        )
        .unwrap();
        fs::write(
            root.join("data/minecraft/recipe/gold.json"),
            crusher("minecraft:gold_ingot"),
        )
        .unwrap();
        let filter = br##"{"filters":[
            {"id":"minecraft:gold","remove":true},
            {"type":"mymod:*","replace_input":{"from":"minecraft:iron_ingot","to":"#c:ingots/iron"}}
        ]}"##;
        let packs = [("recipe_filter/pack:f".to_owned(), vec![filter.to_vec()])];
        let items = Items::for_tests(HashMap::new());
        let recipes = Recipes::load(&root, &items, &PackOverlay { files: &packs }).unwrap();
        let crushed = &recipes.custom["mymod:crusher"];
        assert_eq!(
            crushed.iter().map(|r| r.id.as_str()).collect::<Vec<_>>(),
            ["minecraft:iron"]
        );
        assert_eq!(crushed[0].json["input"], "#c:ingots/iron");
        let _ = fs::remove_dir_all(&root);
    }
    #[test]
    fn cook_finds_the_first_recipe_the_scan_finds() {
        let recipes = cooking_book();
        for kind in [
            "smelting",
            "blasting",
            "smoking",
            "campfire_cooking",
            "other",
        ] {
            for n in 0..420 {
                let stack = ItemStack::new(&format!("minecraft:item_{n}"), 1);
                let a = recipes.cook(kind, &stack).map(|c| &c.id);
                let b = recipes.cook_scan(kind, &stack).map(|c| &c.id);
                assert_eq!(a, b, "{kind} item_{n}");
            }
        }
    }
    /// A furnace's recipe lookup, once per lit furnace per tick.
    #[test]
    #[ignore]
    fn cook_cost() {
        let recipes = cooking_book();
        let stacks: Vec<ItemStack> = (0..1000)
            .map(|n| ItemStack::new(&format!("minecraft:item_{}", n % 400), 1))
            .collect();
        let t = std::time::Instant::now();
        let a = stacks
            .iter()
            .filter(|s| recipes.cook_scan("smelting", s).cloned().is_some())
            .count();
        let before = t.elapsed().as_secs_f64() * 1e3;
        recipes.cook("smelting", &stacks[0]);
        let t = std::time::Instant::now();
        let b = stacks
            .iter()
            .filter(|s| recipes.cook("smelting", s).is_some())
            .count();
        let after = t.elapsed().as_secs_f64() * 1e3;
        assert_eq!(a, b);
        println!("1000 furnace lookups (scan and clone -> index): {before:.3} ms -> {after:.3} ms");
    }
    fn run(special: &Special, cells: &[ItemStack]) -> Option<ItemStack> {
        let recipes = Recipes {
            crafting: Vec::new(),
            cooking: Vec::new(),
            custom: HashMap::new(),
            meta: HashMap::new(),
            facts: HashMap::new(),
            curses: HashSet::new(),
            cook_index: Default::default(),
        };
        let ctx = Context {
            recipes: &recipes,
            map_scale: &|_| None,
        };
        let mut grid: Vec<Option<ItemStack>> = cells.iter().cloned().map(Some).collect();
        grid.resize(9, None);
        let input = Input::of(&grid, 3)?;
        special
            .matches(&ctx, &input)
            .then(|| special.assemble(&ctx, &input))
            .flatten()
    }
    #[test]
    fn banner_duplicate_copies_the_patterns_of_the_same_colour() {
        let recipe = Special::BannerDuplicate {
            banner: ingredient(&["minecraft:white_banner"]),
            result: "minecraft:white_banner".into(),
        };
        let source = patterned("minecraft:white_banner");
        let blank = ItemStack::new("minecraft:white_banner", 1);
        let out = run(&recipe, &[source.clone(), blank.clone()]).expect("copy");
        assert_eq!(out.data().unwrap().banner_patterns.len(), 1);
        // Two blanks, or two patterned banners, do not match.
        assert!(run(&recipe, &[blank.clone(), blank.clone()]).is_none());
        assert!(run(&recipe, &[source.clone(), source.clone()]).is_none());
        // Another colour is not in the recipe's ingredient.
        let other = ItemStack::new("minecraft:red_banner", 1);
        assert!(run(&recipe, &[source, other]).is_none());
    }
    #[test]
    fn shield_decoration_needs_a_bare_shield() {
        let recipe = Special::ShieldDecoration {
            banner: ingredient(&["minecraft:red_banner"]),
            target: ingredient(&["minecraft:shield"]),
            result: "minecraft:shield".into(),
        };
        let banner = patterned("minecraft:red_banner");
        let shield = ItemStack::new("minecraft:shield", 1);
        let out = run(&recipe, &[banner.clone(), shield]).expect("decorated");
        let data = out.data().unwrap();
        assert_eq!(data.base_color.as_deref(), Some("red"));
        assert_eq!(data.banner_patterns.len(), 1);
        // A shield that already has patterns cannot be decorated again.
        assert!(run(&recipe, &[banner, out]).is_none());
    }
    #[test]
    fn shapeless_matching_assigns_each_stack_one_ingredient() {
        let any = ingredient(&["a", "b"]);
        let only_a = ingredient(&["a"]);
        let (a, b) = (ItemStack::new("a", 1), ItemStack::new("b", 1));
        // Greedy matching would give `a` to the first ingredient and fail.
        assert!(matches_all(&[any.clone(), only_a.clone()], &[&a, &b]));
        assert!(!matches_all(&[only_a.clone(), only_a], &[&a, &b]));
        assert!(!matches_all(&[any], &[&a, &b]));
    }
    #[test]
    fn dyes_blend_like_dyed_item_color() {
        // One red dye on an undyed item gives the dye's own colour.
        assert_eq!(apply_dyes(None, &[14]), 0xB02E26);
    }
}
