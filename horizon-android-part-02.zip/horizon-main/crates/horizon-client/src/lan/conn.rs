//! One accepted connection: handshake, status ping, login (offline, or online
//! with encryption and the session service's verdict) and the
//! configuration phase (ServerStatusPacketListenerImpl,
//! ServerLoginPacketListenerImpl, ServerConfigurationPacketListenerImpl). A
//! player that completes configuration continues in the play state on the
//! network threads ([`io_pool`]): they forward decoded packets to the game
//! thread, frame, compress and encrypt what the game queues, and keep the
//! keep-alive schedule on their own so a long tick never times a client out.
use super::{
    Joined, NetEvent, Out, Shared,
    data::{CORE_PACK, SyncData},
    forwarding,
    io_pool::{self, Session as _},
};
use horizon_protocol::{
    PROTOCOL_VERSION,
    connection::{ConnWriter, Connection, Counters},
    crypto::{offline_uuid, server_hash, uuid_string},
    packets::{
        Empty,
        configuration::{self as cfg, ClientInformation, KnownPack},
        handshake, login, play, status,
    },
    text::translatable,
};
use std::{
    cell::Cell,
    net::TcpStream,
    sync::{
        Arc, Mutex, PoisonError,
        atomic::{AtomicI32, AtomicI64, AtomicU32, AtomicUsize, Ordering},
        mpsc::{RecvTimeoutError, Sender, channel},
    },
    time::{Duration, Instant},
};

/// ServerCommonPacketListenerImpl.keepConnectionAlive: a keep-alive every 15 s,
/// and a client that has not answered the last one by the next is dropped.
const KEEP_ALIVE_EVERY: Duration = Duration::from_secs(15);
/// ReadTimeoutHandler(30) in ServerConnectionListener: a connection that sends
/// nothing for 30 s.
const READ_TIMEOUT: Duration = Duration::from_secs(30);

/// How long the handshake, a status request and the login may wait for the client's next packet,
/// where vanilla waits 30 s: a client answers these at once, and each connection holds a thread
/// and one of the places the server keeps for connections, which a crowd of silent or slow
/// sockets would otherwise take for 30 s each. Configuration and play keep [`READ_TIMEOUT`] (a
/// resource pack downloads in configuration).
const LOGIN_TIMEOUT: Duration = Duration::from_secs(10);
/// Vanilla's server-side disconnect during login is a JSON component.
fn login_disconnect(c: &mut Connection, reason: &horizon_world::nbt::Tag) {
    let json = component_json(reason);
    let _ =
        c.send(&login::Clientbound::Disconnect(login::Disconnect { reason_json: json }).encode());
}

/// A component as ComponentSerialization.CODEC writes it with JsonOps (and
/// Gson without HTML escaping): plain text collapses to a string, the
/// content fields come first, then `extra`, then the style.
pub fn component_json(tag: &horizon_world::nbt::Tag) -> String {
    component_value(tag).compact()
}
fn component_value(tag: &horizon_world::nbt::Tag) -> crate::server::json::Json {
    use crate::server::json::Json;
    use horizon_world::nbt::Tag;
    const ORDER: &[&str] = &[
        "type",
        "text",
        "translate",
        "fallback",
        "with",
        "score",
        "selector",
        "separator",
        "keybind",
        "nbt",
        "interpret",
        "block",
        "entity",
        "storage",
        "source",
        "object",
        "sprite",
        "atlas",
        "player",
        "hat",
        "extra",
        "color",
        "shadow_color",
        "bold",
        "italic",
        "underlined",
        "strikethrough",
        "obfuscated",
        "click_event",
        "hover_event",
        "insertion",
        "font",
    ];
    match tag {
        Tag::String(s) => Json::String(s.to_string_lossy()),
        Tag::List(items) => Json::Array(items.iter().map(component_value).collect()),
        Tag::Compound(map) => {
            if map.len() == 1
                && let Some(Tag::String(t)) = map.get(&horizon_world::nbt::JavaString::from("text"))
            {
                return Json::String(t.to_string_lossy());
            }
            let mut keys: Vec<String> = map.keys().map(|k| k.to_string_lossy()).collect();
            keys.sort_by_key(|k| ORDER.iter().position(|o| o == k).unwrap_or(ORDER.len()));
            Json::Object(
                keys.into_iter()
                    .map(|k| {
                        let v = &map[&horizon_world::nbt::JavaString::from(k.as_str())];
                        let value = match v {
                            Tag::Byte(b) => Json::Bool(*b != 0),
                            Tag::Int(i) => Json::Number(i.to_string()),
                            other => component_value(other),
                        };
                        (k, value)
                    })
                    .collect(),
            )
        }
        Tag::Byte(b) => Json::Bool(*b != 0),
        Tag::Int(i) => Json::Number(i.to_string()),
        Tag::Long(i) => Json::Number(i.to_string()),
        _ => Json::Null,
    }
}

/// The inverse of [`component_value`]: a JSON component (a server.properties
/// prompt) as ComponentSerialization.CODEC writes it with NbtOps. An array is
/// its first component with the rest appended (`createFromList`); a list of
/// components mixing plain strings and objects has the strings as `{text}`.
pub fn component_tag(v: &crate::server::json::Json) -> horizon_world::nbt::Tag {
    use crate::server::json::Json;
    use horizon_world::nbt::{JavaString, Tag};
    fn list(items: &[Json]) -> Tag {
        same_kind(items.iter().map(component_tag).collect())
    }
    fn same_kind(mut tags: Vec<Tag>) -> Tag {
        if tags.iter().any(|t| matches!(t, Tag::Compound(_))) {
            for t in &mut tags {
                if let Tag::String(s) = t {
                    *t = Tag::compound([("text", Tag::String(s.clone()))]);
                }
            }
        }
        Tag::List(tags)
    }
    fn value(v: &Json) -> Tag {
        match v {
            Json::Bool(b) => Tag::Byte(i8::from(*b)),
            Json::Number(n) => n.parse().map_or_else(
                |_| Tag::Double(n.parse::<f64>().unwrap_or(0.0).to_bits()),
                Tag::Int,
            ),
            Json::String(s) => Tag::String(JavaString::from(s.as_str())),
            Json::Array(items) => list(items),
            Json::Object(members) => Tag::compound(
                members
                    .iter()
                    .map(|(k, v)| (k.as_str(), value(v)))
                    .collect::<Vec<_>>(),
            ),
            Json::Null => Tag::String(JavaString::from("")),
        }
    }
    match v {
        Json::Array(items) if !items.is_empty() => {
            let mut first = component_tag(&items[0]);
            if let Tag::String(s) = &first {
                first = Tag::compound([("text", Tag::String(s.clone()))]);
            }
            if let Tag::Compound(map) = &mut first {
                let mut extra = match map.remove(&JavaString::from("extra")) {
                    Some(Tag::List(e)) => e,
                    _ => Vec::new(),
                };
                extra.extend(items[1..].iter().map(component_tag));
                map.insert(JavaString::from("extra"), same_kind(extra));
            }
            first
        }
        Json::Object(members) => {
            if let [(key, Json::String(text))] = members.as_slice()
                && key == "text"
            {
                return Tag::String(JavaString::from(text.as_str()));
            }
            Tag::compound(
                members
                    .iter()
                    .map(|(k, v)| {
                        let tag = match k.as_str() {
                            "extra" | "with" => match v {
                                Json::Array(items) => list(items),
                                other => value(other),
                            },
                            _ => value(v),
                        };
                        (k.as_str(), tag)
                    })
                    .collect::<Vec<_>>(),
            )
        }
        Json::String(s) | Json::Number(s) => Tag::String(JavaString::from(s.as_str())),
        Json::Bool(b) => Tag::String(JavaString::from(b.to_string().as_str())),
        _ => Tag::String(JavaString::from("")),
    }
}

/// StringUtil.isValidPlayerName.
pub fn valid_name(name: &str) -> bool {
    (1..=16).contains(&name.len()) && name.chars().all(|c| c as u32 > 32 && (c as u32) < 127)
}

thread_local! {
    static HOLDING: Cell<bool> = const { Cell::new(false) };
}

/// While one is alive, the packets this thread sends to each player are held
/// and handed to the player's network thread together by
/// [`PlayerSender::flush`] or [`flush_all`]: one hand-over per player per tick
/// rather than one per packet. The bytes and their order don't change.
pub struct Holding(bool);
impl Holding {
    pub fn start() -> Self {
        Self(HOLDING.replace(true))
    }
}
impl Drop for Holding {
    fn drop(&mut self) {
        HOLDING.set(self.0);
    }
}

/// The sending half given to the game thread.
#[derive(Clone)]
pub struct PlayerSender {
    /// The bytes of the bodies sent and not framed yet.
    pub pending: Arc<AtomicUsize>,
    held: Arc<Mutex<Vec<Vec<u8>>>>,
    to: To,
    /// The connection's bytes on the wire (after compression and encryption), counted by its
    /// network thread: `horizon-report`'s network use per player. None for a test's channel.
    wire: Option<Arc<Counters>>,
}
#[derive(Clone)]
enum To {
    /// A test's channel.
    Channel(Sender<Out>),
    /// A connection on the network threads, and its keep-alive clock.
    Pool(Arc<io_pool::Outbox>, Arc<KeepAliveWatch>),
}
impl PlayerSender {
    /// A sender whose packets go to `tx` (a test's).
    pub fn new(tx: Sender<Out>, pending: Arc<AtomicUsize>) -> Self {
        Self {
            pending,
            held: Arc::default(),
            to: To::Channel(tx),
            wire: None,
        }
    }
    /// The bytes received from and sent to the client on the wire so far, where the
    /// connection counts them.
    pub fn wire_bytes(&self) -> Option<(u64, u64)> {
        self.wire.as_ref().map(|c| {
            (
                c.bytes_in.load(Ordering::Relaxed).max(0) as u64,
                c.bytes_out.load(Ordering::Relaxed).max(0) as u64,
            )
        })
    }
    /// Whether the client has answered no keep-alive for too long.
    pub fn timed_out(&self) -> bool {
        matches!(&self.to, To::Pool(_, watch) if watch.timed_out())
    }
    /// Close the connection now, dropping what is still queued for it.
    pub fn close(&self) {
        if let To::Pool(outbox, _) = &self.to {
            outbox.send(Vec::new(), Some(io_pool::End::Close));
        }
    }
    fn held(&self) -> std::sync::MutexGuard<'_, Vec<Vec<u8>>> {
        self.held.lock().unwrap_or_else(PoisonError::into_inner)
    }
    pub fn send(&self, body: Vec<u8>) {
        self.pending.fetch_add(body.len(), Ordering::Relaxed);
        if HOLDING.get() {
            self.held().push(body);
        } else {
            self.flush();
            match &self.to {
                To::Channel(tx) => drop(tx.send(Out::Packet(body))),
                To::Pool(outbox, _) => outbox.send(vec![body], None),
            }
        }
    }
    /// Several packets in order, as [`Self::send`] each: under one lock
    /// while the tick holds them.
    pub fn send_many(&self, bodies: impl IntoIterator<Item = Vec<u8>>) {
        if !HOLDING.get() {
            bodies.into_iter().for_each(|body| self.send(body));
            return;
        }
        let mut held = self.held();
        for body in bodies {
            self.pending.fetch_add(body.len(), Ordering::Relaxed);
            held.push(body);
        }
    }
    /// Hand the held packets to the network thread.
    pub fn flush(&self) {
        let held = std::mem::take(&mut *self.held());
        if !held.is_empty() {
            match &self.to {
                To::Channel(tx) => drop(tx.send(Out::Packets(held))),
                To::Pool(outbox, _) => outbox.send(held, None),
            }
        }
    }
    /// Send a play disconnect with this reason after what was sent before,
    /// then close.
    pub fn disconnect(&self, reason: horizon_world::nbt::Tag) {
        self.flush();
        match &self.to {
            To::Channel(tx) => drop(tx.send(Out::Disconnect(reason))),
            To::Pool(outbox, _) => {
                let body = play::Clientbound::Disconnect(cfg::Disconnect { reason }).encode();
                self.pending.fetch_add(body.len(), Ordering::Relaxed);
                outbox.send(vec![body], Some(io_pool::End::Disconnect));
            }
        }
    }
}

/// Hand every player's held packets to their network threads, waking each
/// thread once: a wake-up costs a system call, and on a busy machine often
/// the rest of the core's time slice. Each player's packets keep their order,
/// also with what is sent to it next.
pub fn flush_all<'a>(senders: impl IntoIterator<Item = &'a PlayerSender>) {
    let mut wake: Vec<&Arc<io_pool::Worker>> = Vec::new();
    for s in senders {
        let held = std::mem::take(&mut *s.held());
        if held.is_empty() {
            continue;
        }
        match &s.to {
            To::Channel(tx) => drop(tx.send(Out::Packets(held))),
            To::Pool(outbox, _) => {
                if let Some(worker) = outbox.push(held, None)
                    && !wake.iter().any(|w| Arc::ptr_eq(w, worker))
                {
                    wake.push(worker);
                }
            }
        }
    }
    wake.into_iter().for_each(|w| w.wake());
}

/// LegacyQueryHandler: the pre-1.7 server list ping. What the first read
/// holds decides the reply (1.3 and older: no more bytes; 1.4 and 1.5: 0x01;
/// 1.6: 0x01 then the MC|PingHost payload); anything else gets no reply.
fn serve_legacy(mut stream: TcpStream, shared: &Shared) -> Result<(), String> {
    use std::io::{Read, Write};
    let _ = stream.set_read_timeout(Some(Duration::from_millis(100)));
    let mut data = Vec::new();
    let mut chunk = [0u8; 1024];
    // The bytes of the first read: what arrived together.
    if let Ok(n) = stream.read(&mut chunk) {
        data.extend_from_slice(&chunk[..n]);
    }
    let in_string = |d: &[u8], at: &mut usize| -> Option<String> {
        let len = usize::from(u16::from_be_bytes([*d.get(*at)?, *d.get(*at + 1)?]));
        let bytes = d.get(*at + 2..*at + 2 + len * 2)?;
        *at += 2 + len * 2;
        Some(String::from_utf16_lossy(
            &bytes
                .chunks(2)
                .map(|c| u16::from_be_bytes([c[0], c[1]]))
                .collect::<Vec<_>>(),
        ))
    };
    let motd = shared.motd();
    let (online, max) = (shared.online(), shared.max_players());
    let body = if data.len() == 1 {
        format!("{motd}\u{a7}{online}\u{a7}{max}")
    } else {
        if data.get(1) != Some(&1) {
            return Ok(());
        }
        if data.len() > 2 {
            // readCustomPayloadPacket.
            let mut at = 3;
            let valid = data[2] == 0xFA
                && in_string(&data, &mut at).as_deref() == Some("MC|PingHost")
                && data
                    .get(at..at + 2)
                    .map(|b| usize::from(u16::from_be_bytes([b[0], b[1]])))
                    == Some(data.len().saturating_sub(at + 2))
                && {
                    at += 2;
                    data.get(at).is_some_and(|v| *v >= 73)
                }
                && {
                    at += 1;
                    in_string(&data, &mut at).is_some()
                }
                && data
                    .get(at..at + 4)
                    .is_some_and(|b| i32::from_be_bytes([b[0], b[1], b[2], b[3]]) <= 65535);
            if !valid {
                return Ok(());
            }
        }
        format!(
            "\u{a7}1\0127\0{}\0{motd}\0{online}\0{max}",
            horizon_core::VANILLA_VERSION
        )
    };
    let units: Vec<u16> = body.encode_utf16().collect();
    let mut out = vec![0xFF];
    out.extend_from_slice(&(units.len() as u16).to_be_bytes());
    for u in units {
        out.extend_from_slice(&u.to_be_bytes());
    }
    stream.write_all(&out).map_err(|e| e.to_string())?;
    let _ = stream.shutdown(std::net::Shutdown::Both);
    Ok(())
}

/// Serve an accepted connection, which holds `counted`'s place among the
/// server's until it closes.
pub(super) fn serve(
    stream: TcpStream,
    address: std::net::SocketAddr,
    shared: Arc<Shared>,
    counted: super::Counted,
) -> Result<(), String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    // LegacyQueryHandler, ahead of the frame decoder while status is on.
    let mut first = [0u8; 1];
    if shared.enable_status() && stream.peek(&mut first).is_ok_and(|n| n == 1) && first[0] == 0xFE {
        return serve_legacy(stream, &shared);
    }
    // A peer that stops reading (a frozen game, a dropped network) would otherwise hold
    // its writer in a full send buffer for good, or until TCP gives up minutes later, and
    // its thread and its place among the server's connections with it.
    let _ = stream.set_write_timeout(Some(WRITE_TIMEOUT));
    let c = Connection::from_stream(stream).map_err(e)?;
    serve_connection(c, address, shared, Some(counted))
}

/// How long one write may wait on a peer that reads nothing: as long as a read may wait.
const WRITE_TIMEOUT: Duration = READ_TIMEOUT;

/// The address a memory connection logs in from: no network peer has port 0.
pub const MEMORY_ADDRESS: std::net::SocketAddr = std::net::SocketAddr::V4(
    std::net::SocketAddrV4::new(std::net::Ipv4Addr::LOCALHOST, 0),
);

/// `ServerConnectionListener.startMemoryChannel`: an integrated server's
/// own player, over one end of an in-memory pipe.
pub fn serve_local(
    pipe: horizon_protocol::connection::Pipe,
    shared: Arc<Shared>,
) -> Result<(), String> {
    serve_connection(Connection::local(pipe), MEMORY_ADDRESS, shared, None)
}

fn serve_connection(
    mut c: Connection,
    address: std::net::SocketAddr,
    shared: Arc<Shared>,
    counted: Option<super::Counted>,
) -> Result<(), String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    c.reader.set_read_timeout(Some(LOGIN_TIMEOUT)).map_err(e)?;
    let (id, payload) = c.recv().map_err(e)?;
    let intention = match handshake::Serverbound::decode(id, &payload).map_err(e)? {
        handshake::Serverbound::Intention(i) => i,
        _ => return Err("expected a handshake".into()),
    };
    match intention.intent {
        // ServerHandshakePacketListenerImpl: a server that does not reply
        // to status requests closes the connection.
        handshake::STATUS if !shared.enable_status() => Ok(()),
        handshake::STATUS => serve_status(&mut c, &shared, intention.protocol),
        handshake::TRANSFER if !shared.accepts_transfers() => {
            login_disconnect(
                &mut c,
                &translatable("multiplayer.disconnect.transfers_disabled", &[]),
            );
            Ok(())
        }
        handshake::LOGIN | handshake::TRANSFER => {
            if let Some(version) = older_client(&shared, intention.protocol) {
                c.serve_older(version);
            } else if intention.protocol != PROTOCOL_VERSION {
                let key = if intention.protocol < 754 {
                    "multiplayer.disconnect.outdated_client"
                } else {
                    "multiplayer.disconnect.incompatible"
                };
                let json = format!(
                    "{{\"translate\":\"{key}\",\"with\":[\"{}\"]}}",
                    horizon_protocol::GAME_VERSION
                );
                let _ = c.send(
                    &login::Clientbound::Disconnect(login::Disconnect { reason_json: json })
                        .encode(),
                );
                return Ok(());
            }
            serve_login(c, address, &shared, counted)
        }
        other => Err(format!("unknown intent {other}")),
    }
}

/// The older release a client's handshake states, when this server lets it join
/// (`horizon-accept-older-clients`): 26.2 only, for now.
fn older_client(
    shared: &Shared,
    protocol: i32,
) -> Option<horizon_protocol::adapter::ServerVersion> {
    use horizon_protocol::adapter::ServerVersion;
    let version = ServerVersion::from_protocol(protocol)?;
    (shared.config.accept_older_clients && version == ServerVersion::V26_2).then_some(version)
}

fn serve_status(c: &mut Connection, shared: &Shared, protocol: i32) -> Result<(), String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    let mut requested = false;
    loop {
        let (id, payload) = c.recv().map_err(e)?;
        match status::Serverbound::decode(id, &payload).map_err(e)? {
            // ServerStatusPacketListenerImpl: a second request disconnects.
            status::Serverbound::StatusRequest(_) if requested => return Ok(()),
            status::Serverbound::StatusRequest(_) => {
                requested = true;
                // A client this server lets join is told its own protocol, so its list shows it joinable.
                let json = match older_client(shared, protocol) {
                    Some(_) => shared.status_json_for(protocol),
                    None => shared.status_json(),
                };
                c.send(
                    &status::Clientbound::StatusResponse(status::StatusResponse { json }).encode(),
                )
                .map_err(e)?;
            }
            status::Serverbound::PingRequest(p) => {
                c.send(&status::Clientbound::PongResponse(p).encode())
                    .map_err(e)?;
                return Ok(());
            }
            status::Serverbound::Unknown(..) => return Ok(()),
        }
    }
}

/// ServerLoginPacketListenerImpl.getUserName: the name and the address
/// (Connection.getLoggableAddress, `/ip:port` as InetSocketAddress prints it).
fn user_name(name: &str, address: std::net::SocketAddr, log: &super::NetLog) -> String {
    if log.log_ips {
        format!("{name} (/{address})")
    } else {
        format!("{name} (<ip address withheld>)")
    }
}

/// ServerLoginPacketListenerImpl.disconnect: log the reason's text and send
/// it. Returns the text, for the "lost connection" line that follows.
fn refuse(
    c: &mut Connection,
    shared: &Shared,
    thread: &str,
    user: &str,
    reason: &horizon_world::nbt::Tag,
) -> String {
    let text = shared
        .config
        .log
        .as_ref()
        .map(|log| horizon_protocol::text::plain(reason, &log.lang))
        .unwrap_or_default();
    if let Some(log) = &shared.config.log {
        (log.write)(thread, "INFO", &format!("Disconnecting {user}: {text}"));
    }
    login_disconnect(c, reason);
    text
}

/// ServerLoginPacketListenerImpl.onDisconnect, once the server thread sees
/// the connection closed: by a refusal, or by the client ("Disconnected").
fn lost(shared: &Shared, user: &str, text: &str) {
    if let Some(log) = &shared.config.log {
        (log.write)(
            "Server thread",
            "INFO",
            &format!("{user} lost connection: {text}"),
        );
    }
}

/// UNIQUE_THREAD_ID: the User Authenticator threads are numbered from 1.
static AUTHENTICATORS: AtomicU32 = AtomicU32::new(0);

/// ServerLoginPacketListenerImpl.handleKey and the User Authenticator
/// thread: check the client's answer to the encryption request, encrypt the
/// connection, and ask the session service whether the player joined with
/// this server's hash. The profile, or the text of the refusal.
fn authenticate(
    c: &mut Connection,
    shared: &Shared,
    online: &super::OnlineMode,
    name: &str,
    address: std::net::SocketAddr,
    user: &str,
) -> Result<Result<(u128, Vec<login::Property>), String>, String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    let mut challenge = [0u8; 4];
    horizon_protocol::crypto::random_bytes(&mut challenge).map_err(e)?;
    c.send(
        &login::Clientbound::Hello(login::Hello {
            server_id: String::new(),
            public_key: online.public_der.clone(),
            challenge: challenge.to_vec(),
            should_authenticate: true,
        })
        .encode(),
    )
    .map_err(e)?;
    let (id, payload) = c.recv().map_err(e)?;
    let key = match login::Serverbound::decode(id, &payload).map_err(e)? {
        login::Serverbound::Key(k) => k,
        _ => return Err("Unexpected packet during login".into()),
    };
    // ServerboundKeyPacket.isChallengeValid and getSecretKey.
    let protocol_error = || "Protocol error".to_owned();
    if online.key.decrypt(&key.challenge).ok().as_deref() != Some(&challenge[..]) {
        return Err(protocol_error());
    }
    let secret: [u8; 16] = online
        .key
        .decrypt(&key.key)
        .ok()
        .and_then(|s| s.try_into().ok())
        .ok_or_else(protocol_error)?;
    let digest = server_hash("", &secret, &online.public_der);
    c.enable_encryption(&secret);
    let thread = format!(
        "User Authenticator #{}",
        AUTHENTICATORS.fetch_add(1, Ordering::Relaxed) + 1
    );
    let log = |level: &str, line: &str| {
        if let Some(log) = &shared.config.log {
            (log.write)(&thread, level, line);
        }
    };
    let ip = online.prevent_proxy.then(|| address.ip());
    match crate::auth::has_joined(name, &digest, ip) {
        Ok(Some(profile)) => {
            log(
                "INFO",
                &format!("UUID of player {name} is {}", uuid_string(profile.uuid)),
            );
            Ok(Ok((profile.uuid, profile.properties)))
        }
        Ok(None) => {
            let text = refuse(
                c,
                shared,
                &thread,
                user,
                &translatable("multiplayer.disconnect.unverified_username", &[]),
            );
            log(
                "ERROR",
                &format!("Username '{name}' tried to join with an invalid session"),
            );
            Ok(Err(text))
        }
        Err(_) => {
            let text = refuse(
                c,
                shared,
                &thread,
                user,
                &translatable("multiplayer.disconnect.authservers_down", &[]),
            );
            log(
                "ERROR",
                "Couldn't verify username because servers are unavailable",
            );
            Ok(Err(text))
        }
    }
}

fn serve_login(
    mut c: Connection,
    address: std::net::SocketAddr,
    shared: &Arc<Shared>,
    counted: Option<super::Counted>,
) -> Result<(), String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    let (id, payload) = c.recv().map_err(e)?;
    let hello = match login::Serverbound::decode(id, &payload).map_err(e)? {
        login::Serverbound::Hello(h) => h,
        _ => return Err("expected a login hello".into()),
    };
    if !valid_name(&hello.name) {
        // handleHello's validState throws; Connection.exceptionCaught sends the
        // exception as the login disconnect.
        login_disconnect(
            &mut c,
            &translatable(
                "disconnect.genericReason",
                &[
                    "Internal Exception: java.lang.IllegalStateException: Invalid characters in username",
                ],
            ),
        );
        return Ok(());
    }
    let (mut name, mut address) = (hello.name.clone(), address);
    let user_of = |name: &str, address| {
        shared
            .config
            .log
            .as_ref()
            .map(|log| user_name(name, address, log))
            .unwrap_or_default()
    };
    let mut user = user_of(&name, address);
    // handleHello: online mode authenticates first; offline mode, and the
    // integrated server's own player through memory, derive the profile
    // from the name. Behind a Velocity proxy (forwarding.secret) the proxy has
    // authenticated the player and the profile is the one it forwards.
    let online = shared.config.online.as_ref().filter(|_| !c.is_memory());
    let forwarding = shared
        .config
        .forwarding_secret
        .as_deref()
        .filter(|_| online.is_none() && !c.is_memory());
    let (uuid, properties) = match (online, forwarding) {
        (Some(online), _) => {
            match authenticate(&mut c, shared, online, &hello.name, address, &user) {
                Ok(Ok(profile)) => profile,
                Ok(Err(refused)) => {
                    lost(shared, &user, &refused);
                    return Ok(());
                }
                Err(err) => {
                    lost(shared, &user, "Disconnected");
                    return Err(err);
                }
            }
        }
        (None, Some(secret)) => match forward(&mut c, secret) {
            Ok(Ok(forwarded)) => {
                (name, address) = (
                    forwarded.name,
                    std::net::SocketAddr::new(forwarded.address, address.port()),
                );
                user = user_of(&name, address);
                (forwarded.uuid, forwarded.properties)
            }
            Ok(Err(reason)) => {
                let text = "This server is behind a proxy: join through the proxy.";
                let json = format!("{{\"text\":\"{text}\"}}");
                let _ = c.send(
                    &login::Clientbound::Disconnect(login::Disconnect { reason_json: json })
                        .encode(),
                );
                if let Some(log) = &shared.config.log {
                    (log.write)(
                        "Server thread",
                        "WARN",
                        &format!("Refused {user}: {reason}"),
                    );
                }
                lost(shared, &user, text);
                return Ok(());
            }
            Err(err) => {
                lost(shared, &user, "Disconnected");
                return Err(err);
            }
        },
        (None, None) => (offline_uuid(&hello.name), Vec::new()),
    };
    // verifyLoginAndFinishConnectionSetup: PlayerList.canPlayerLogin, then
    // duplicates and a full server.
    if let Some(reason) = shared.try_admit(address, uuid, &name) {
        let text = refuse(&mut c, shared, "Server thread", &user, &reason);
        lost(shared, &user, &text);
        return Ok(());
    }
    // A player a proxy said would arrive (`player-expect`) uses the expectation up
    // here, as the login starts: one that ran out while the player was still in
    // configuration (a resource pack prompt) would otherwise make it an ordinary
    // login from this server's own file.
    let expected = shared.config.arrivals.as_ref().and_then(|table| {
        table
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .take_until(uuid, std::time::Instant::now())
    });
    // A login that does not reach play (it failed in configuration) gives the
    // expectation back, so the proxy's next attempt is still expected.
    let put_back = || {
        if let (Some(deadline), Some(table)) = (expected, shared.config.arrivals.as_ref()) {
            table.lock().unwrap_or_else(|e| e.into_inner()).put_back(
                uuid,
                deadline,
                std::time::Instant::now(),
            );
        }
    };
    let result = login_and_configure(&mut c, shared, uuid, &name, properties);
    match result {
        Ok(Some(parts)) => {
            play(c, shared, parts, address, counted, expected.is_some());
            Ok(())
        }
        Ok(None) => {
            put_back();
            shared.release(uuid);
            Ok(())
        }
        Err(err) => {
            put_back();
            shared.release(uuid);
            // ServerConfigurationPacketListenerImpl.onDisconnect.
            let profile = format!("{name} ({})", uuid_string(uuid));
            lost(shared, &profile, "Disconnected");
            Err(err)
        }
    }
}

/// Asks the proxy for the player's forwarded information (login plugin channel `velocity:player_info`) and
/// checks it against the shared secret. The outer error is the connection failing; the inner one is a refusal
/// (the client isn't a proxy, or signed with another secret), with the reason for the log.
fn forward(
    c: &mut Connection,
    secret: &[u8],
) -> Result<Result<forwarding::Forwarded, String>, String> {
    const TRANSACTION: i32 = 1;
    let e = |e: horizon_protocol::Error| e.to_string();
    c.send(
        &login::Clientbound::CustomQuery(login::CustomQuery {
            transaction: TRANSACTION,
            channel: forwarding::CHANNEL.into(),
            data: forwarding::request(),
        })
        .encode(),
    )
    .map_err(e)?;
    let (id, payload) = c.recv().map_err(e)?;
    match login::Serverbound::decode(id, &payload).map_err(e)? {
        login::Serverbound::CustomQueryAnswer(answer) if answer.transaction == TRANSACTION => {
            Ok(match answer.payload {
                Some(data) => forwarding::verify(secret, &data),
                None => Err("the client didn't answer the forwarding request".into()),
            })
        }
        _ => Err("unexpected packet during login".into()),
    }
}

struct Parts {
    uuid: u128,
    name: String,
    properties: Vec<login::Property>,
    info: ClientInformation,
    brand: String,
}

fn login_and_configure(
    c: &mut Connection,
    shared: &Arc<Shared>,
    uuid: u128,
    name: &str,
    properties: Vec<login::Property>,
) -> Result<Option<Parts>, String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    // ServerLoginPacketListenerImpl: memory connections are not compressed.
    let threshold = shared.config.compression_threshold;
    if threshold >= 0 && !c.is_memory() {
        c.send(&login::Clientbound::Compression(login::Compression { threshold }).encode())
            .map_err(e)?;
        c.set_compression(threshold);
    }
    c.send(
        &login::Clientbound::LoginFinished(login::LoginFinished {
            profile: login::GameProfile {
                uuid,
                name: name.to_owned(),
                properties: properties.clone(),
            },
            session: uuid,
        })
        .encode(),
    )
    .map_err(e)?;
    // The client may send its settings before acknowledging the login.
    loop {
        let (id, payload) = c.recv().map_err(e)?;
        match login::Serverbound::decode(id, &payload).map_err(e)? {
            login::Serverbound::LoginAcknowledged(_) => break,
            login::Serverbound::CustomQueryAnswer(_) | login::Serverbound::CookieResponse(_) => {}
            _ => return Err("unexpected packet during login".into()),
        }
    }
    c.reader.set_read_timeout(Some(READ_TIMEOUT)).map_err(e)?;
    // Configuration.
    let sync_data = shared.sync();
    let sync: &SyncData = &sync_data;
    let send = |c: &mut Connection, p: cfg::Clientbound| c.send(&p.encode()).map_err(e);
    send(
        c,
        cfg::Clientbound::CustomPayload(cfg::CustomPayload {
            channel: "minecraft:brand".into(),
            data: {
                let mut w = horizon_protocol::buf::Writer::new();
                // MinecraftServer.getServerModName: "vanilla" there; a modded
                // server names itself, and Horizon's says "horizon", as its client does.
                w.string("horizon");
                w.data
            },
        }),
    )?;
    // ServerConfigurationPacketListenerImpl.startConfiguration: links, only
    // when there are any (MinecraftServer.serverLinks is empty elsewhere).
    if !shared.config.server_links.is_empty() {
        send(
            c,
            cfg::Clientbound::ServerLinks(cfg::ServerLinks {
                links: shared.config.server_links.clone(),
            }),
        )?;
    }
    send(
        c,
        cfg::Clientbound::UpdateEnabledFeatures(cfg::UpdateEnabledFeatures {
            features: sync.features.clone(),
        }),
    )?;
    let core = KnownPack {
        namespace: CORE_PACK.0.into(),
        id: CORE_PACK.1.into(),
        version: CORE_PACK.2.into(),
    };
    send(
        c,
        cfg::Clientbound::SelectKnownPacks(cfg::SelectKnownPacks {
            packs: vec![core.clone()],
        }),
    )?;
    let mut info = ClientInformation::new(10);
    let mut brand = String::from("vanilla");
    let known_pack = loop {
        let (id, payload) = c.recv().map_err(e)?;
        match decode_config(id, &payload).map_err(e)? {
            cfg::Serverbound::ClientInformation(i) => info = i,
            cfg::Serverbound::CustomPayload(p) if p.channel == "minecraft:brand" => {
                brand = horizon_protocol::buf::Reader::new(&p.data)
                    .string(32767)
                    .unwrap_or(brand);
            }
            cfg::Serverbound::SelectKnownPacks(p) => break p.packs == vec![core.clone()],
            _ => {}
        }
    };
    // An older client's packet ids are translated, not yet what is inside them (#10404): the registry data,
    // tags and play packets would reach it in 26.3's ids and layouts, so it is turned away before them.
    if let Some(version) = c.older_client()
        && !shared.config.older_clients_play
    {
        let text = super::OLDER_CLIENTS_UNFINISHED;
        let reason = horizon_world::nbt::Tag::String(horizon_world::nbt::JavaString::from(text));
        let _ = send(c, cfg::Clientbound::Disconnect(cfg::Disconnect { reason }));
        if let Some(log) = &shared.config.log {
            let line = format!(
                "Disconnecting {name}: its client is on protocol {} ({text})",
                version.protocol()
            );
            (log.write)("Server thread", "INFO", &line);
        }
        lost(shared, &format!("{name} ({})", uuid_string(uuid)), text);
        return Ok(None);
    }
    // Custom component IDs need Horizon's registry check. The server may also
    // require Horizon clients even when it has no custom components.
    if brand != "horizon"
        && (shared.config.horizon_clients_only
            || horizon_protocol::item::custom::entries().next().is_some())
    {
        let text = if shared.config.horizon_clients_only {
            super::HORIZON_CLIENTS_ONLY_REASON
        } else {
            crate::content_identity::MISMATCH
        };
        let reason = horizon_world::nbt::Tag::String(horizon_world::nbt::JavaString::from(text));
        let _ = send(c, cfg::Clientbound::Disconnect(cfg::Disconnect { reason }));
        if let Some(log) = &shared.config.log {
            let line =
                format!("Disconnecting {name}: its client is \"{brand}\", not Horizon ({text})");
            (log.write)("Server thread", "INFO", &line);
        }
        lost(shared, &format!("{name} ({})", uuid_string(uuid)), text);
        return Ok(None);
    }
    // A Horizon client hears that this server runs its mods' quiet commands
    // (horizon_protocol::quiet); a vanilla one is told nothing.
    if brand == "horizon" {
        send(
            c,
            cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                channel: horizon_protocol::quiet::CHANNEL.into(),
                data: Vec::new(),
            }),
        )?;
        // And that it carries native mods' messages (horizon_protocol::mod_net).
        send(
            c,
            cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                channel: horizon_protocol::mod_net::CHANNEL.into(),
                data: Vec::new(),
            }),
        )?;
    }
    // And how far it samples far terrain for it (crate::lod_net).
    if brand == "horizon" && shared.config.lod_distance > 0 {
        send(
            c,
            cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                channel: crate::lod_net::CHANNEL.into(),
                data: crate::lod_net::Offer::new(shared.config.lod_distance).encode(),
            }),
        )?;
    }
    // The mods that must be the same on both sides, named when they are not
    // (horizon_protocol::mod_list); the registry hash below only sees ids.
    let server_mods = horizon_protocol::mod_list::local();
    if brand == "horizon" && !server_mods.is_empty() {
        send(
            c,
            cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                channel: horizon_protocol::mod_list::CHANNEL.into(),
                data: horizon_protocol::mod_list::encode(&horizon_protocol::mod_list::shared(
                    &server_mods,
                )),
            }),
        )?;
        send(c, cfg::Clientbound::Ping(cfg::Ping { id: 1 }))?;
        // A client that does not answer has no mods to offer.
        let mut client_mods = Vec::new();
        loop {
            let (id, payload) = c.recv().map_err(e)?;
            match decode_config(id, &payload).map_err(e)? {
                cfg::Serverbound::CustomPayload(p)
                    if p.channel == horizon_protocol::mod_list::CHANNEL =>
                {
                    client_mods = horizon_protocol::mod_list::decode(&p.data).unwrap_or_default();
                }
                cfg::Serverbound::Pong(p) if p.id == 1 => break,
                cfg::Serverbound::ClientInformation(i) => info = i,
                _ => {}
            }
        }
        let difference = horizon_protocol::mod_list::compare(&server_mods, &client_mods);
        if !difference.is_empty() {
            let text = difference.reason();
            let reason = horizon_world::nbt::Tag::String(horizon_world::nbt::JavaString::from(
                text.as_str(),
            ));
            let _ = send(c, cfg::Clientbound::Disconnect(cfg::Disconnect { reason }));
            lost(shared, &format!("{name} ({})", uuid_string(uuid)), &text);
            return Ok(None);
        }
    }
    if brand == "horizon"
        && let Some(hash) = sync.content_identity
    {
        send(
            c,
            cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                channel: crate::content_identity::CHANNEL.into(),
                data: hash.to_vec(),
            }),
        )?;
        send(c, cfg::Clientbound::Ping(cfg::Ping { id: 0 }))?;
        let mut content_match = false;
        loop {
            let (id, payload) = c.recv().map_err(e)?;
            match decode_config(id, &payload).map_err(e)? {
                cfg::Serverbound::CustomPayload(p)
                    if p.channel == crate::content_identity::CHANNEL =>
                {
                    content_match = p.data == hash;
                }
                cfg::Serverbound::Pong(p) if p.id == 0 => break,
                cfg::Serverbound::ClientInformation(i) => info = i,
                _ => {}
            }
        }
        if !content_match {
            let reason = horizon_world::nbt::Tag::String(horizon_world::nbt::JavaString::from(
                crate::content_identity::MISMATCH,
            ));
            let _ = send(c, cfg::Clientbound::Disconnect(cfg::Disconnect { reason }));
            lost(
                shared,
                &format!("{name} ({})", uuid_string(uuid)),
                crate::content_identity::MISMATCH,
            );
            return Ok(None);
        }
    }
    for packet in sync.registry_packets(known_pack, &shared.config.levels) {
        send(c, cfg::Clientbound::RegistryData(packet))?;
    }
    send(c, cfg::Clientbound::UpdateTags(sync.tags.clone()))?;
    // addOptionalTasks: the code of conduct task comes first.
    if let Some(text) =
        super::code_of_conduct::pick(&shared.config.code_of_conducts, &info.language)
    {
        accept_code_of_conduct(c, text, &mut info)?;
    }
    if let Some(pack) = &shared.config.resource_pack
        && let Some(rejected) = offer_pack(c, pack, &mut info)?
    {
        let (reason, text) = pack_rejected(shared, name, rejected);
        let _ = send(c, cfg::Clientbound::Disconnect(cfg::Disconnect { reason }));
        lost(shared, &format!("{name} ({})", uuid_string(uuid)), &text);
        return Ok(None);
    }
    send(c, cfg::Clientbound::FinishConfiguration(Empty))?;
    loop {
        let (id, payload) = c.recv().map_err(e)?;
        match decode_config(id, &payload).map_err(e)? {
            cfg::Serverbound::FinishConfiguration(_) => break,
            cfg::Serverbound::ClientInformation(i) => info = i,
            _ => {}
        }
    }
    Ok(Some(Parts {
        uuid,
        name: name.to_owned(),
        properties,
        info,
        brand,
    }))
}

/// ServerboundResourcePackPacket.Action.DECLINED.
const PACK_DECLINED: i32 = 1;

/// ServerCommonPacketListenerImpl.handleResourcePackResponse: a player who
/// declined the required pack is disconnected. The reason and its text.
fn pack_rejected(shared: &Shared, name: &str, pack: u128) -> (horizon_world::nbt::Tag, String) {
    let reason = translatable("multiplayer.requiredTexturePrompt.disconnect", &[]);
    let Some(log) = &shared.config.log else {
        return (reason, String::new());
    };
    let line = format!(
        "Disconnecting {name} due to resource pack {} rejection",
        uuid_string(pack)
    );
    (log.write)("Server thread", "INFO", &line);
    let text = horizon_protocol::text::plain(&reason, &log.lang);
    (reason, text)
}

/// RateKickingConnection: a player whose packets a second passed rate-limit
/// is disconnected ("disconnect.exceeded_packet_rate") with a WARN, as
/// vanilla's kick logs it.
fn rate_exceeded(shared: &Shared, average: f32) -> (horizon_world::nbt::Tag, String) {
    let reason = translatable("disconnect.exceeded_packet_rate", &[]);
    let Some(log) = &shared.config.log else {
        return (reason, String::new());
    };
    let line = format!(
        "Player exceeded rate-limit (sent {} packets per second)",
        crate::java_text::float_to_string(average)
    );
    (log.write)("Server thread", "WARN", &line);
    let text = horizon_protocol::text::plain(&reason, &log.lang);
    (reason, text)
}

/// ServerResourcePackConfigurationTask: offer the server's pack, then wait
/// for the client's final answer (`Action.isTerminal`: anything but
/// ACCEPTED or DOWNLOADED). The player may take a while to answer the
/// prompt, so the connection is kept alive meanwhile, as
/// ServerConfigurationPacketListenerImpl.tick does. The id of a required
/// pack the client declined, which disconnects it.
fn offer_pack(
    c: &mut Connection,
    pack: &crate::server::properties::ResourcePackInfo,
    info: &mut ClientInformation,
) -> Result<Option<u128>, String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    let push = cfg::ResourcePackPush {
        id: pack.id,
        url: pack.url.clone(),
        hash: pack.hash.clone(),
        required: pack.required,
        prompt: pack.prompt.as_ref().map(component_tag),
    };
    c.send(&cfg::Clientbound::ResourcePackPush(push).encode())
        .map_err(e)?;
    wait_alive(c, |packet| match packet {
        Ok(cfg::Serverbound::ResourcePack(r)) if !matches!(r.action, 3 | 4) => {
            let rejected = r.action == PACK_DECLINED && pack.required;
            Some(Ok(rejected.then_some(r.id)))
        }
        Ok(cfg::Serverbound::ClientInformation(i)) => {
            *info = i;
            None
        }
        Ok(_) => None,
        Err(err) => Some(Err(err)),
    })
}

/// ServerCodeOfConductConfigurationTask: send the text, then wait for
/// ServerboundAcceptCodeOfConductPacket (`handleAcceptCodeOfConduct`),
/// keeping the connection alive while the player reads. Finishing the
/// configuration first is `finishCurrentTask` of the wrong task type, an
/// error that drops the connection.
fn accept_code_of_conduct(
    c: &mut Connection,
    text: &str,
    info: &mut ClientInformation,
) -> Result<(), String> {
    let e = |e: horizon_protocol::Error| e.to_string();
    c.send(&cfg::Clientbound::CodeOfConduct(cfg::CodeOfConduct { text: text.into() }).encode())
        .map_err(e)?;
    wait_alive(c, |packet| match packet {
        Ok(cfg::Serverbound::AcceptCodeOfConduct(_)) => Some(Ok(())),
        Ok(cfg::Serverbound::FinishConfiguration(_)) => {
            Some(Err("Unexpected configuration task".to_owned()))
        }
        Ok(cfg::Serverbound::ClientInformation(i)) => {
            *info = i;
            None
        }
        Ok(_) => None,
        Err(err) => Some(Err(err)),
    })
}

/// Read configuration packets until `answer` has a result, sending a
/// keep-alive every `KEEP_ALIVE_EVERY` meanwhile
/// (ServerConfigurationPacketListenerImpl.tick).
fn wait_alive<T>(
    c: &mut Connection,
    mut answer: impl FnMut(Result<cfg::Serverbound, String>) -> Option<Result<T, String>>,
) -> Result<T, String> {
    std::thread::scope(|scope| {
        let (stop, stopped) = channel::<()>();
        let writer = &mut c.writer;
        scope.spawn(move || {
            let start = Instant::now();
            while stopped.recv_timeout(KEEP_ALIVE_EVERY) == Err(RecvTimeoutError::Timeout) {
                let id = i64::try_from(start.elapsed().as_millis()).unwrap_or(0);
                let keep_alive = cfg::Clientbound::KeepAlive(cfg::KeepAlive { id });
                if writer.send(&keep_alive.encode()).is_err() {
                    break;
                }
            }
        });
        let result = loop {
            let packet = match c.reader.recv() {
                Ok((id, payload)) => decode_config(id, &payload).map_err(|e| e.to_string()),
                Err(err) => break Err(err.to_string()),
            };
            if let Some(result) = answer(packet) {
                break result;
            }
        };
        drop(stop);
        result
    })
}

fn play(
    c: Connection,
    shared: &Arc<Shared>,
    parts: Parts,
    address: std::net::SocketAddr,
    counted: Option<super::Counted>,
    expected: bool,
) {
    shared.entered_play();
    let conn = shared.next_id();
    let pending = Arc::new(AtomicUsize::new(0));
    let outbox = match io_pool::Outbox::new(pending.clone()) {
        Ok(outbox) => outbox,
        Err(e) => {
            log::warn!("[lan] {e}");
            shared.release(parts.uuid);
            return;
        }
    };
    let latency = Arc::new(AtomicI32::new(0));
    let watch = Arc::new(KeepAliveWatch {
        start: Instant::now(),
        alive: Arc::new(AtomicI64::new(-1)),
    });
    let sender = PlayerSender {
        pending,
        held: Arc::default(),
        to: To::Pool(outbox.clone(), watch.clone()),
        wire: Some(c.reader.counters.clone()),
    };
    let required_pack = shared
        .config
        .resource_pack
        .as_ref()
        .is_some_and(|p| p.required);
    let session = PlayConn {
        conn,
        shared: shared.clone(),
        uuid: parts.uuid,
        name: parts.name.clone(),
        required_pack,
        rate: PacketRate::new(shared.config.rate_limit, Instant::now()),
        latency: latency.clone(),
        sent_at: None,
        next_keep_alive: watch.start + KEEP_ALIVE_EVERY,
        watch,
        counted,
    };
    let joined = Joined {
        conn,
        uuid: parts.uuid,
        name: parts.name,
        properties: parts.properties,
        info: parts.info,
        brand: parts.brand,
        sender,
        latency,
        address,
        expected,
    };
    let mut session = Box::new(session);
    if shared
        .events
        .send(NetEvent::Joined(Box::new(joined)))
        .is_err()
    {
        session.left("server closed".to_owned());
        session.closed();
        return;
    }
    let (socket, reader, writer) = c.detach();
    io_pool::adopt(socket, (reader, writer), outbox, session, READ_TIMEOUT);
}

/// A player's play state on its network thread.
struct PlayConn {
    conn: u32,
    shared: Arc<Shared>,
    uuid: u128,
    name: String,
    required_pack: bool,
    rate: Option<PacketRate>,
    watch: Arc<KeepAliveWatch>,
    /// Smoothed keep-alive round trip in milliseconds.
    latency: Arc<AtomicI32>,
    /// The keep-alive waiting for its answer, and when it was sent.
    sent_at: Option<(i64, Instant)>,
    next_keep_alive: Instant,
    /// The connection's place among the server's, given back once closed.
    counted: Option<super::Counted>,
}
impl io_pool::Session for PlayConn {
    /// Forward the player's packet, or say why it ends the connection: a
    /// required resource pack declined, a rate-limit excess, a malformed packet.
    fn packet(&mut self, id: i32, payload: Vec<u8>) -> io_pool::Verdict {
        use io_pool::Verdict;
        let kick = |(reason, text): (horizon_world::nbt::Tag, String)| {
            let body = play::Clientbound::Disconnect(cfg::Disconnect { reason }).encode();
            Verdict::Kick(text, body)
        };
        let now = Instant::now();
        if let Some(average) = self.rate.as_mut().and_then(|r| r.received(now)) {
            return kick(rate_exceeded(&self.shared, average));
        }
        match play::Serverbound::decode(id, &payload).and_then(checked_play) {
            Ok(play::Serverbound::KeepAlive(k)) => {
                self.watch.alive.store(k.id, Ordering::Relaxed);
                if let Some((sent, at)) = self.sent_at
                    && k.id == sent
                {
                    let ms = i32::try_from(at.elapsed().as_millis()).unwrap_or(i32::MAX);
                    let old = self.latency.load(Ordering::Relaxed);
                    self.latency.store((old * 3 + ms) / 4, Ordering::Relaxed);
                    self.sent_at = None;
                }
                Verdict::Go
            }
            Ok(play::Serverbound::ResourcePack(r))
                if r.action == PACK_DECLINED && self.required_pack =>
            {
                kick(pack_rejected(&self.shared, &self.name, r.id))
            }
            Ok(p) => {
                let event = NetEvent::Packet(self.conn, Box::new(p), payload.len());
                match self.shared.events.send(event) {
                    Ok(()) => Verdict::Go,
                    Err(_) => Verdict::Close("server closed".to_owned()),
                }
            }
            // A malformed packet disconnects like vanilla's decoder exception.
            Err(e) => Verdict::Close(format!("Invalid packet {id}: {e}")),
        }
    }
    /// ServerCommonPacketListenerImpl.keepConnectionAlive: a keep-alive 15 s
    /// after the last was answered. The game thread times a client out
    /// ([`PlayerSender::timed_out`]).
    fn tick(&mut self, now: Instant) -> Option<Vec<u8>> {
        if self.sent_at.is_some() || now < self.next_keep_alive {
            return None;
        }
        let id = i64::try_from(self.watch.start.elapsed().as_millis()).unwrap_or(0);
        self.sent_at = Some((id, now));
        self.next_keep_alive = now + KEEP_ALIVE_EVERY;
        Some(play::Clientbound::KeepAlive(cfg::KeepAlive { id }).encode())
    }
    fn left(&mut self, reason: String) {
        let _ = self.shared.events.send(NetEvent::Left(self.conn, reason));
        self.shared.closing.fetch_add(1, Ordering::AcqRel);
    }
    fn closed(&mut self) {
        self.shared.closing.fetch_sub(1, Ordering::AcqRel);
        self.shared.release(self.uuid);
        self.counted = None;
    }
}

/// RateKickingConnection: the packets a second a connection averages, as
/// Connection.tickSecond keeps it, against server.properties' rate-limit.
struct PacketRate {
    limit: f32,
    received: u32,
    average: f32,
    next: Instant,
}
impl PacketRate {
    /// The tracker of a connection, or none when the limit is off (0 or less).
    fn new(limit: i32, now: Instant) -> Option<Self> {
        (limit > 0).then(|| Self {
            limit: limit as f32,
            received: 0,
            average: 0.0,
            next: now + Duration::from_secs(1),
        })
    }
    /// A packet arrived. Every whole second the average updates
    /// (Mth.lerp(0.75F, received, average)): over the limit, Some of it.
    fn received(&mut self, now: Instant) -> Option<f32> {
        let exceeded = if now >= self.next {
            // One tick with the count, then a packetless tick's 0.75 decay
            // for each further whole second already gone.
            let first = self.received as f32 + 0.75 * (self.average - self.received as f32);
            self.average = first;
            self.received = 0;
            let elapsed = (now - self.next).as_secs() + 1;
            if elapsed > 1 {
                self.average *= 0.75f32.powi((elapsed - 1) as i32);
            }
            self.next += Duration::from_secs(elapsed);
            (first > self.limit).then_some(first)
        } else {
            None
        };
        self.received = self.received.saturating_add(1);
        exceeded
    }
}

/// ServerboundCustomPayloadPacket's codec (DiscardedPayload): a payload of at most
/// 32767 bytes, in configuration and in play.
const MAX_PAYLOAD: usize = horizon_protocol::quiet::MAX_PAYLOAD;
const COMMAND_SUGGESTION: i32 = horizon_protocol::ids::play::serverbound::COMMAND_SUGGESTION;

fn too_large() -> String {
    format!("Payload may not be larger than {MAX_PAYLOAD} bytes")
}

/// A play packet as vanilla's decoders read it.
fn checked_play(packet: play::Serverbound) -> horizon_protocol::Result<play::Serverbound> {
    match &packet {
        play::Serverbound::CustomPayload(p) if p.data.len() > MAX_PAYLOAD => {
            Err(horizon_protocol::Error::new(too_large()))
        }
        // ServerboundCommandSuggestionPacket: a VarInt id, then the command, at most
        // 32500 chars. The game reads it later; its codec's limits apply here.
        play::Serverbound::Unknown(COMMAND_SUGGESTION, body) => {
            let mut r = horizon_protocol::buf::Reader::new(body);
            r.varint()?;
            r.string(32500)?;
            Ok(packet)
        }
        _ => Ok(packet),
    }
}

/// A configuration packet as vanilla's decoders read it.
fn decode_config(id: i32, payload: &[u8]) -> horizon_protocol::Result<cfg::Serverbound> {
    match cfg::Serverbound::decode(id, payload)? {
        cfg::Serverbound::CustomPayload(p) if p.data.len() > MAX_PAYLOAD => {
            Err(horizon_protocol::Error::new(too_large()))
        }
        packet => Ok(packet),
    }
}

/// Packet bodies at least this large are compressed once for every
/// connection: chunk columns, mostly, which every player near them receives.
const SHARED_FRAME_MIN: usize = 8 << 10;
/// The compressed frames kept, in bytes; the oldest go first.
const SHARED_FRAME_BYTES: usize = 32 << 20;

/// Compressed frame contents by the body they were made from: its length,
/// one 128-bit hash of it keyed by a random secret, and the threshold.
struct SharedFrames {
    /// XXH3's secret, random for each run, so that no body can be made to
    /// share its hash with another.
    secret: Box<[u8]>,
    frames: Mutex<FrameCache>,
    /// [`SHARED_FRAME_BYTES`].
    limit: usize,
}
type FrameKey = (usize, u128, usize);
/// A frame's contents, made once: whoever asks while another thread
/// compresses the same body waits for it rather than compressing it again.
type Frame = Arc<std::sync::OnceLock<Result<Arc<[u8]>, String>>>;
#[derive(Default)]
struct FrameCache {
    frames: crate::fast_hash::FxHashMap<FrameKey, Frame>,
    order: std::collections::VecDeque<FrameKey>,
    /// The bytes of the frames made and still here.
    bytes: usize,
}
impl SharedFrames {
    fn get() -> &'static Self {
        static FRAMES: std::sync::OnceLock<SharedFrames> = std::sync::OnceLock::new();
        FRAMES.get_or_init(|| Self::new(SHARED_FRAME_BYTES))
    }
    fn new(limit: usize) -> Self {
        use std::hash::{BuildHasher, Hasher};
        // 192 bytes, as XXH3's default secret.
        let secret = (0..24)
            .flat_map(|i: usize| {
                let mut h = std::hash::RandomState::new().build_hasher();
                h.write_usize(i);
                h.finish().to_le_bytes()
            })
            .collect();
        Self {
            secret,
            frames: Mutex::default(),
            limit,
        }
    }
    fn cache(&self) -> std::sync::MutexGuard<'_, FrameCache> {
        self.frames.lock().unwrap_or_else(PoisonError::into_inner)
    }
    /// `frame::contents(body, Some(threshold))`, compressed only when no
    /// connection has sent the same body lately or compresses it now.
    fn contents(&self, body: &[u8], threshold: usize) -> horizon_protocol::Result<Arc<[u8]>> {
        let hash = xxhash_rust::xxh3::xxh3_128_with_secret(body, &self.secret);
        let key = (body.len(), hash, threshold);
        let (frame, made_here) = {
            let mut cache = self.cache();
            match cache.frames.get(&key) {
                Some(frame) => (frame.clone(), false),
                None => {
                    let frame = Frame::default();
                    cache.frames.insert(key, frame.clone());
                    cache.order.push_back(key);
                    (frame, true)
                }
            }
        };
        let contents = frame
            .get_or_init(|| {
                horizon_protocol::frame::contents(body, Some(threshold))
                    .map(Arc::from)
                    .map_err(|e| e.to_string())
            })
            .clone()
            .map_err(horizon_protocol::Error::new)?;
        if made_here {
            let mut cache = self.cache();
            // Unless pushed out while it was being made.
            if cache
                .frames
                .get(&key)
                .is_some_and(|f| Arc::ptr_eq(f, &frame))
            {
                cache.bytes += contents.len();
            }
            while cache.bytes > self.limit
                && let Some(old) = cache.order.pop_front()
            {
                let made = cache.frames.remove(&old);
                cache.bytes -= made
                    .and_then(|f| f.get()?.as_ref().ok().map(|c| c.len()))
                    .unwrap_or(0);
            }
        }
        Ok(contents)
    }
}

/// Frame one packet body into `out`: a large one compressed through
/// [`SharedFrames`], so a chunk column sent to fifty players is compressed
/// once, not fifty times. The bytes on the wire are the same.
pub(super) fn frame_body(
    writer: &mut ConnWriter,
    body: &[u8],
    out: &mut Vec<u8>,
) -> horizon_protocol::Result<()> {
    // Renumbered first for a client of an older release; one with no such packet gets nothing.
    let Some(body) = writer.for_client(body)? else {
        return Ok(());
    };
    let body = &body[..];
    match writer.threshold {
        Some(t) if body.len() >= t.max(SHARED_FRAME_MIN) => {
            writer.frame_into(&SharedFrames::get().contents(body, t)?, out);
        }
        threshold => writer.frame_into(&horizon_protocol::frame::contents(body, threshold)?, out),
    }
    Ok(())
}

/// The keep-alive clock of a play connection, shared by its network thread
/// (which sends the keep-alives) and the game thread (which watches them).
struct KeepAliveWatch {
    /// What keep-alive ids count from: an id is its sending time in ms.
    start: Instant,
    /// The id of the last keep-alive the client answered (-1: none yet).
    alive: Arc<AtomicI64>,
}
impl KeepAliveWatch {
    /// keepConnectionAlive sends a keep-alive 15 s after the last and drops
    /// a client that has not answered it 15 s later: nothing answered of
    /// what was sent in the last 30 s.
    fn timed_out(&self) -> bool {
        let answered = u64::try_from(self.alive.load(Ordering::Relaxed)).unwrap_or(0);
        self.start.elapsed() > Duration::from_millis(answered) + 2 * KEEP_ALIVE_EVERY
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Logs in through `c` and answers the `LoginFinished` profile.
    fn login_profile(mut c: Connection, name: &str) -> login::GameProfile {
        c.send(
            &handshake::Serverbound::Intention(handshake::Intention {
                protocol: horizon_protocol::PROTOCOL_VERSION,
                host: "127.0.0.1".into(),
                port: 0,
                intent: handshake::LOGIN,
            })
            .encode(),
        )
        .unwrap();
        c.send(
            &login::Serverbound::Hello(login::ServerHello {
                name: name.into(),
                uuid: offline_uuid(name),
            })
            .encode(),
        )
        .unwrap();
        loop {
            let (id, payload) = c.recv().unwrap();
            match login::Clientbound::decode(id, &payload).unwrap() {
                login::Clientbound::Compression(p) => c.set_compression(p.threshold),
                login::Clientbound::LoginFinished(p) => return p.profile,
                other => panic!("unexpected login packet {other:?}"),
            }
        }
    }

    /// A login by transfer: `Ok` once the profile is told, the reason's JSON when it is turned away.
    fn transfer_login(mut c: Connection, name: &str) -> Result<(), String> {
        c.send(
            &handshake::Serverbound::Intention(handshake::Intention {
                protocol: horizon_protocol::PROTOCOL_VERSION,
                host: "127.0.0.1".into(),
                port: 0,
                intent: handshake::TRANSFER,
            })
            .encode(),
        )
        .unwrap();
        // A server that does not accept transfers turns one away at the handshake and closes
        // (ServerHandshakePacketListenerImpl.handleIntention), so the hello may find the connection
        // gone: its disconnect is still there to read.
        let _ = c.send(
            &login::Serverbound::Hello(login::ServerHello {
                name: name.into(),
                uuid: offline_uuid(name),
            })
            .encode(),
        );
        loop {
            let (id, payload) = c.recv().unwrap();
            match login::Clientbound::decode(id, &payload).unwrap() {
                login::Clientbound::Compression(p) => c.set_compression(p.threshold),
                login::Clientbound::LoginFinished(_) => return Ok(()),
                login::Clientbound::Disconnect(d) => return Err(d.reason_json),
                other => panic!("unexpected login packet {other:?}"),
            }
        }
    }

    /// `serversettings/accept_transfers/set` changes what the next transfer finds, with no restart:
    /// a server that does not accept transfers turns one away, and takes it once it does.
    #[test]
    fn accepting_transfers_can_be_turned_on_and_off_live() {
        let config = crate::lan::NetConfig {
            announce: false,
            listen: false,
            accepts_transfers: false,
            ..crate::lan::NetConfig::loopback(0, "Transfers".into(), 8)
        };
        let lan =
            crate::lan::Lan::start_with(Arc::new(crate::lan::data::SyncData::empty()), config)
                .unwrap();
        let refused = transfer_login(Connection::local(lan.connect_local().unwrap()), "Alex")
            .expect_err("a transfer is turned away while transfers are off");
        assert!(
            refused.contains("multiplayer.disconnect.transfers_disabled"),
            "{refused}"
        );
        lan.shared.set_accepts_transfers(true);
        transfer_login(Connection::local(lan.connect_local().unwrap()), "Alex")
            .expect("a transfer is taken once transfers are on");
        lan.shared.set_accepts_transfers(false);
        // The player of the last login is still here: a second profile tries.
        let again = transfer_login(Connection::local(lan.connect_local().unwrap()), "Steve")
            .expect_err("and turned away again once they are off");
        assert!(
            again.contains("multiplayer.disconnect.transfers_disabled"),
            "{again}"
        );
    }

    #[test]
    fn payloads_and_suggestions_past_vanillas_limits_are_malformed() {
        let payload = |len: usize| {
            play::Serverbound::CustomPayload(cfg::CustomPayload {
                channel: "a:b".into(),
                data: vec![0; len],
            })
        };
        assert!(checked_play(payload(MAX_PAYLOAD)).is_ok());
        assert!(checked_play(payload(MAX_PAYLOAD + 1)).is_err());
        let config = |len: usize| {
            cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                channel: "a:b".into(),
                data: vec![0; len],
            })
            .encode()
        };
        // The body after the packet's one-byte VarInt id.
        let id = horizon_protocol::ids::configuration::serverbound::CUSTOM_PAYLOAD;
        assert!(decode_config(id, &config(MAX_PAYLOAD)[1..]).is_ok());
        assert!(decode_config(id, &config(MAX_PAYLOAD + 1)[1..]).is_err());
        let suggestion = |len: usize| {
            let mut w = horizon_protocol::buf::Writer::new();
            w.varint(7);
            w.string(&"a".repeat(len));
            play::Serverbound::Unknown(COMMAND_SUGGESTION, w.data)
        };
        assert!(checked_play(suggestion(32500)).is_ok());
        assert!(checked_play(suggestion(32501)).is_err());
    }

    #[test]
    fn prompts_become_the_components_vanilla_sends() {
        let tag = |json: &str| {
            let tag = component_tag(&crate::server::json::parse(json, true).unwrap());
            component_json(&tag)
        };
        assert_eq!(tag(r#"{"text":"Hi"}"#), r#""Hi""#);
        assert_eq!(tag(r#""Hi""#), r#""Hi""#);
        assert_eq!(
            tag(r#"["Hi ",{"text":"there","bold":true}]"#),
            r#"{"text":"Hi ","extra":[{"text":"there","bold":true}]}"#
        );
        assert_eq!(
            tag(r#"{"translate":"a","with":["b",{"text":"c","color":"red"}]}"#),
            r#"{"translate":"a","with":["b",{"text":"c","color":"red"}]}"#
        );
    }

    /// The owner's login never waits on the profile fetch, even one that
    /// never answers, and carries no properties.
    #[test]
    fn the_owners_login_never_waits_on_the_profile_fetch() {
        let (_hold, never) = channel::<()>();
        let config = crate::lan::NetConfig {
            announce: false,
            listen: false,
            owner_profile: Some(Arc::new(crate::lan::OwnerProfile::new(move || {
                let _ = never.recv();
                Vec::new()
            }))),
            ..crate::lan::NetConfig::loopback(0, "Owner - World".into(), 8)
        };
        let lan =
            crate::lan::Lan::start_with(Arc::new(crate::lan::data::SyncData::empty()), config)
                .unwrap();
        let start = Instant::now();
        let owner = login_profile(Connection::local(lan.connect_local().unwrap()), "Owner");
        assert!(
            start.elapsed() < Duration::from_secs(1),
            "{:?}",
            start.elapsed()
        );
        assert_eq!(owner.uuid, offline_uuid("Owner"));
        assert!(owner.properties.is_empty());
    }

    fn unpack(out: Out) -> Vec<Vec<u8>> {
        match out {
            Out::Packet(body) => vec![body],
            Out::Packets(bodies) => bodies,
            Out::Disconnect(_) => vec![b"disconnect".to_vec()],
        }
    }

    fn bodies(rx: &std::sync::mpsc::Receiver<Out>) -> Vec<Vec<Vec<u8>>> {
        rx.try_iter().map(unpack).collect()
    }

    #[test]
    fn packets_sent_after_a_posted_tick_follow_it() {
        let (tx, rx) = channel();
        let (tx2, rx2) = channel();
        let sender = PlayerSender::new(tx, Arc::default());
        let other = PlayerSender::new(tx2, Arc::default());
        for round in 0..50u8 {
            let holding = Holding::start();
            sender.send(vec![round, 1]);
            sender.send(vec![round, 2]);
            other.send(vec![round]);
            drop(holding);
            flush_all([&sender, &other]);
            sender.send(vec![round, 3]);
            let next = || unpack(rx.recv_timeout(Duration::from_secs(10)).unwrap());
            assert_eq!(next(), [vec![round, 1], vec![round, 2]]);
            assert_eq!(next(), [vec![round, 3]]);
            let got = unpack(rx2.recv_timeout(Duration::from_secs(10)).unwrap());
            assert_eq!(got, [vec![round]]);
        }
        let holding = Holding::start();
        sender.send(vec![9]);
        drop(holding);
        flush_all([&sender]);
        sender.disconnect(horizon_world::nbt::Tag::Byte(0));
        let next = || unpack(rx.recv_timeout(Duration::from_secs(10)).unwrap());
        assert_eq!(next(), [vec![9]]);
        assert_eq!(next(), [b"disconnect".to_vec()]);
        // Nothing sent twice.
        assert!(rx.try_recv().is_err());
    }

    #[test]
    fn shared_frames_are_the_frames_compressed_here() {
        use horizon_protocol::frame;
        let frames = SharedFrames::new(usize::MAX);
        let a: Vec<u8> = (0..40_000u32).map(|i| (i * 7 % 13) as u8).collect();
        let mut b = a.clone();
        b[20_000] ^= 1;
        for (body, threshold) in [(&a, 256), (&b, 256), (&a, 256), (&a, 64), (&b, 256)] {
            let shared = frames.contents(body, threshold).unwrap();
            assert_eq!(*shared, *frame::contents(body, Some(threshold)).unwrap());
        }
        // One frame per body and threshold.
        assert_eq!(frames.frames.lock().unwrap().frames.len(), 3);
    }

    /// Senders asking for the same body at once share one compression: they
    /// all get the frame the first made.
    #[test]
    fn a_body_compressed_now_is_not_compressed_again() {
        let frames = SharedFrames::new(usize::MAX);
        let body: Vec<u8> = (0..400_000u32).map(|i| (i * 7 % 251) as u8).collect();
        let start = std::sync::Barrier::new(8);
        let made: Vec<Arc<[u8]>> = std::thread::scope(|scope| {
            let threads: Vec<_> = (0..8)
                .map(|_| {
                    scope.spawn(|| {
                        start.wait();
                        frames.contents(&body, 256).unwrap()
                    })
                })
                .collect();
            threads.into_iter().map(|t| t.join().unwrap()).collect()
        });
        assert!(made.iter().all(|m| Arc::ptr_eq(m, &made[0])));
        let cache = frames.frames.lock().unwrap();
        assert_eq!(cache.frames.len(), 1);
        assert_eq!(cache.bytes, made[0].len());
    }

    #[test]
    fn shared_frames_keep_the_newest_within_their_limit() {
        let first = SharedFrames::new(0)
            .contents(&[1; 9000], 256)
            .unwrap()
            .len();
        let frames = SharedFrames::new(first * 2);
        for n in 0..5u8 {
            frames.contents(&[n; 9000], 256).unwrap();
        }
        let cache = frames.frames.lock().unwrap();
        assert!((1..=2).contains(&cache.frames.len()));
        assert_eq!(cache.order.len(), cache.frames.len());
        assert_eq!(
            cache.bytes,
            cache
                .frames
                .values()
                .map(|f| f.get().unwrap().as_ref().unwrap().len())
                .sum::<usize>()
        );
        assert!(cache.bytes <= first * 2);
    }

    #[test]
    fn held_packets_go_together_and_in_order() {
        let (tx, rx) = channel();
        let sender = PlayerSender::new(tx, Arc::default());
        sender.send(vec![1]);
        assert_eq!(bodies(&rx), [vec![vec![1]]]);
        let holding = Holding::start();
        sender.send(vec![2]);
        sender.send(vec![3]);
        assert!(bodies(&rx).is_empty());
        drop(holding);
        // A packet sent after the tick still follows the held ones.
        sender.send(vec![4]);
        assert_eq!(bodies(&rx), [vec![vec![2], vec![3]], vec![vec![4]]]);
        let holding = Holding::start();
        sender.send(vec![5]);
        sender.disconnect(horizon_world::nbt::Tag::Byte(0));
        drop(holding);
        sender.flush();
        assert_eq!(bodies(&rx), [vec![vec![5]], vec![b"disconnect".to_vec()]]);
        assert_eq!(sender.pending.load(Ordering::Relaxed), 5);
    }

    /// A client that answers no keep-alive is timed out 30 s after the last
    /// one it answered was sent (or after joining).
    #[test]
    fn a_silent_client_times_out() {
        let ago = |s| Instant::now().checked_sub(Duration::from_secs(s)).unwrap();
        let watch = |start, answered| KeepAliveWatch {
            start,
            alive: Arc::new(AtomicI64::new(answered)),
        };
        assert!(!watch(ago(29), -1).timed_out());
        assert!(watch(ago(31), -1).timed_out());
        // Answered the keep-alive sent 15 s in: fine until 45 s.
        assert!(!watch(ago(44), 15_000).timed_out());
        assert!(watch(ago(46), 15_000).timed_out());
    }

    #[test]
    fn a_rate_over_the_limit_kicks() {
        let t0 = Instant::now();
        let second = Duration::from_secs(1);
        // Off at 0 (and below).
        assert!(PacketRate::new(0, t0).is_none());
        assert!(PacketRate::new(-1, t0).is_none());
        let mut rate = PacketRate::new(10, t0).unwrap();
        // 15 packets inside the first second average 3.75 at the tick.
        for _ in 0..15 {
            assert_eq!(rate.received(t0), None);
        }
        assert_eq!(rate.received(t0 + second), None);
        // 50 a second averages 12.5: over a limit of 10 at the first tick.
        let mut rate = PacketRate::new(10, t0).unwrap();
        for _ in 0..50 {
            rate.received(t0);
        }
        assert_eq!(rate.received(t0 + second), Some(12.5));
    }

    #[test]
    fn an_idle_gap_decays_without_a_loop() {
        let t0 = Instant::now();
        let mut rate = PacketRate {
            limit: 100.0,
            received: 0,
            average: 40.0,
            next: t0,
        };
        // Ten seconds later: one tick (0 packets: 40 * 0.75 = 30), then ten
        // more packetless decays — ~1.69 — with `next` past now.
        assert_eq!(rate.received(t0 + Duration::from_secs(10)), None);
        assert!(rate.average > 1.5 && rate.average < 2.0, "{}", rate.average);
        assert!(rate.next > t0 + Duration::from_secs(10));
    }
}
