//! Guests' saved state: `players/data/<uuid>.dat` in the vanilla player
//! compound, through the same code that saves the host.
use super::guest::{Guest, SavedBody};
use crate::{
    items::ItemStack,
    save::{Level, put, read_dat, uuid_from_tag, write_dat},
};
use horizon_protocol::crypto::uuid_string;
use horizon_world::{
    attachments::{ATTACHMENTS_KEY, attachment_compound},
    nbt::Tag,
};
use std::{
    path::{Path, PathBuf},
    sync::Arc,
};

/// `PlayerDataStorage`'s player directory (`players/data`), created on first use
/// as its constructor does with `mkdirs`.
pub fn directory(world: &Path) -> PathBuf {
    let dir = directory_path(world);
    if let Err(e) = std::fs::create_dir_all(&dir) {
        log::warn!("Horizon: {} is not created: {e}", dir.display());
    }
    dir
}

fn directory_path(world: &Path) -> PathBuf {
    world.join("players").join("data")
}

pub fn path(world: &Path, uuid: u128) -> PathBuf {
    directory_path(world).join(format!("{}.dat", uuid_string(uuid)))
}

/// `UUIDUtil.uuidToIntArray`.
pub fn uuid_ints(uuid: u128) -> [i32; 4] {
    [
        (uuid >> 96) as i32,
        (uuid >> 64) as i32,
        (uuid >> 32) as i32,
        uuid as i32,
    ]
}
/// `UUIDUtil.uuidFromIntArray`.
pub fn ints_uuid(ints: [i32; 4]) -> u128 {
    ints.iter()
        .fold(0, |acc, &i| acc << 32 | u128::from(i as u32))
}

/// Whether a saved file exists for this player.
pub fn exists(world: &Path, uuid: u128) -> bool {
    path(world, uuid).is_file()
}

/// `PlayerDataStorage.load`: a guest's saved state, if they have been here
/// before. The player's file, else its `.dat_old` (what a save cut off
/// between its two renames leaves, `write_dat`).
pub fn load(guest: &mut Guest, world: &Path) -> bool {
    let file = path(world, guest.uuid);
    let Some(tag) = read_dat(&file).or_else(|| read_dat(&file.with_extension("dat_old"))) else {
        return false;
    };
    let mut level = Level {
        health: 20.0,
        food: 20,
        saturation: 5.0,
        ..Level::default()
    };
    level.read_player(&tag);
    level.player_extra = Some(tag);
    apply(guest, &level);
    true
}

/// `PlayerList.loadPlayerData` for the world's single-player owner: the file
/// level.dat names (`singleplayer_uuid`), as the world opening read it into
/// `saved`, before the owner's own file. Builds that save the owner to the
/// named file alone (0.2.93) leave the own file behind, stale (#5351). The
/// own file is for a world whose named file is missing; then the player the
/// world opening found instead (the newest player file, the legacy
/// `Data.Player`, or nothing in a new world). Returns whether the player has
/// been in this world before.
pub fn load_owner(guest: &mut Guest, world: &Path, saved: Option<&Level>) -> bool {
    if let Some(level) = saved.filter(|l| l.singleplayer_file) {
        apply(guest, level);
        return level.position.is_some();
    }
    if load(guest, world) {
        return true;
    }
    saved.is_some_and(|level| {
        apply(guest, level);
        level.position.is_some()
    })
}

/// Save the world's single-player owner: its state into `level` (`store`),
/// then to the file level.dat names, which it loads ([`load_owner`]), and to
/// its own file, so that the one it loads is never the older of the two.
pub fn save_owner(guest: &Guest, level: &mut Level, world: &Path) {
    // `MinecraftServer.saveAllChunks`: `singleplayer_uuid` is the integrated server's own profile,
    // never another player's file the world happened to hold.
    level.player_uuid.get_or_insert(uuid_ints(guest.uuid));
    store(guest, level, None);
    if let Err(e) = level.write_player(world) {
        log::warn!("Horizon: the owner's playerdata is not saved: {e}");
    }
    save(guest, world);
}

/// A player new to the world faces the world spawn's angle (`PrepareSpawnTask`:
/// the saved rotation, else `respawnData.yaw/pitch`).
pub fn face_world_spawn(guest: &mut Guest, known: bool, [yaw, pitch]: [f32; 2]) {
    if known {
        return;
    }
    guest.yaw = yaw;
    guest.pitch = pitch;
    guest.head_yaw = yaw;
}

/// Give a guest the player state read into `level`.
pub fn apply(guest: &mut Guest, level: &Level) {
    if let Some(p) = level.position {
        guest.position = p;
        guest.previous_position = p;
    }
    guest.yaw = level.rotation[0];
    guest.pitch = level.rotation[1];
    guest.head_yaw = guest.yaw;
    guest.on_ground = level.on_ground;
    guest.health = level.health;
    guest.saved_absorption = Some(level.absorption);
    guest.food = level.food;
    guest.saturation = level.saturation;
    guest.xp_level = level.xp_level;
    guest.xp_progress = level.xp_progress;
    guest.xp_total = level.xp_total;
    guest.xp_seed = level.xp_seed;
    guest.effects = crate::effects::PlayerEffects::from_saved(&level.active_effects);
    guest.game_mode = level.mode();
    guest.previous_game_mode = level.previous_game_mode;
    guest.flying = level.flying;
    guest.flying_speed = level.fly_speed.filter(|s| s.is_finite()).unwrap_or(0.05);
    guest.selected = (level.selected_slot.max(0) as usize).min(8);
    // A point that is the world spawn is none of the player's own: it
    // respawns wherever the world spawn is then (`setworldspawn`).
    guest.spawn = level
        .spawn
        .filter(|s| Some(s.map(|v| v.floor() as i32)) != level.world_spawn)
        .map(|s| [s[0] + 0.5, s[1], s[2] + 0.5]);
    guest.respawn_elsewhere = level.respawn_elsewhere.clone();
    guest.saved = level.player_extra.clone();
    guest.attachments = match attachment_compound(
        guest
            .saved
            .as_ref()
            .and_then(|tag| tag.get(ATTACHMENTS_KEY)),
    ) {
        Ok(Some(data)) => horizon_world::attachments::Attachments::from_nbt(data.clone()),
        _ => Default::default(),
    };
    guest.seen_credits = level.seen_credits;
    guest.post_effects.clone_from(&level.post_effects);
    guest.last_death = level.last_death.clone();
    let extra = level.player_extra.as_ref();
    let short = |key: &str, default: i64| {
        extra
            .and_then(|t| crate::save::number(t.get(key)))
            .unwrap_or(default) as i32
    };
    // Entity.load: a component of Motion over 10 blocks a tick reads as 0.
    let motion = level.motion.map(|v| if v.abs() > 10.0 { 0.0 } else { v });
    guest.loaded_body = Some(SavedBody {
        fire_ticks: short("Fire", -20),
        air: short("Air", 300),
        fall_distance: level.fall_distance,
        velocity: motion,
        food_exhaustion: level.food_exhaustion,
        food_tick_timer: level.food_tick_timer,
        ticks_frozen: short("TicksFrozen", 0),
    });
    guest.saved_vehicle = level.root_vehicle;
    guest.recipe_book = level.recipe_book.clone();
    guest.dimension = match level.dimension.as_str() {
        d @ ("minecraft:the_nether" | "minecraft:the_end") => d.to_owned(),
        _ => "minecraft:overworld".to_owned(),
    };
    if level.ender_items.len() == 27 {
        guest.ender_items = level.ender_items.clone();
    }
    for (slot, item, count, damage) in &level.inventory {
        let mut stack = ItemStack {
            item: Arc::from(item.as_str()),
            count: *count,
            damage: *damage,
            extra: level.inventory_components.get(slot).cloned(),
        };
        if stack.count == 0 {
            stack.count = 1;
        }
        match *slot {
            0..=35 => guest.inventory[usize::from(*slot)] = Some(stack),
            100 => guest.armor[3] = Some(stack),
            101 => guest.armor[2] = Some(stack),
            102 => guest.armor[1] = Some(stack),
            103 => guest.armor[0] = Some(stack),
            150 => guest.offhand = Some(stack),
            _ => {}
        }
    }
}

/// The shared player compound for logout and autosave snapshots, and for
/// `player-export`'s record (`arrivals::export_record`).
pub fn player_tag(guest: &Guest) -> Tag {
    let mut level = Level {
        player_uuid: Some(uuid_ints(guest.uuid)),
        ..Level::default()
    };
    store(guest, &mut level, None);
    level.player_tag()
}

/// Save a leaving guest, including its saved vehicle tree.
pub fn save(guest: &Guest, world: &Path) {
    let file = path(world, guest.uuid);
    if let Err(e) = write_dat(&file, player_tag(guest)) {
        log::warn!("Horizon: {} is not saved: {e}", file.display());
    }
}

/// [`save`], synced to the disk and saying whether the file was written: a hand-over's commit
/// point (`player-confirm`) answers only once it is.
pub fn save_now(guest: &Guest, world: &Path) -> Result<(), String> {
    let file = path(world, guest.uuid);
    crate::save::write_dat_durable(&file, player_tag(guest))
        .map_err(|e| format!("{} is not saved: {e}", file.display()))
}

/// An immutable player snapshot. Compression and all filesystem work belong to
/// the writer; native callbacks are delivered by the server after completion.
struct Snapshot {
    uuid: u128,
    name: String,
    file: PathBuf,
    tag: Tag,
}

pub struct SavedPlayer {
    pub uuid: u128,
    pub name: String,
}

fn write_snapshot(snapshot: Snapshot) -> Result<SavedPlayer, String> {
    write_dat(&snapshot.file, snapshot.tag)
        .map(|()| SavedPlayer {
            uuid: snapshot.uuid,
            name: snapshot.name,
        })
        .map_err(|e| format!("{} is not saved: {e}", snapshot.file.display()))
}

struct PlayerWriter {
    send: std::sync::mpsc::Sender<Snapshot>,
    done: std::sync::mpsc::Receiver<Result<SavedPlayer, String>>,
    thread: std::thread::JoinHandle<()>,
}

/// One FIFO writer for a server's player autosaves. Synchronous logout writes
/// must follow a barrier, so an older autosave can never replace them later.
#[derive(Default)]
pub struct Autosaves {
    writer: Option<PlayerWriter>,
    pending: usize,
    error: Option<String>,
    ready: Vec<SavedPlayer>,
}

impl Autosaves {
    pub fn enqueue(&mut self, guest: &Guest, world: &Path) {
        let snapshot = Snapshot {
            uuid: guest.uuid,
            name: guest.name.clone(),
            file: path(world, guest.uuid),
            tag: player_tag(guest),
        };
        if self.writer.is_none() {
            let (send, receive) = std::sync::mpsc::channel::<Snapshot>();
            let (complete, done) = std::sync::mpsc::channel();
            match std::thread::Builder::new()
                .name("horizon-player-writer".into())
                .spawn(move || {
                    for snapshot in receive {
                        let _ = complete.send(write_snapshot(snapshot));
                    }
                }) {
                Ok(thread) => self.writer = Some(PlayerWriter { send, done, thread }),
                Err(error) => {
                    log::warn!("Horizon: cannot start player writer, saving inline: {error}")
                }
            }
        }
        let snapshot = if let Some(writer) = &self.writer {
            match writer.send.send(snapshot) {
                Ok(()) => {
                    self.pending += 1;
                    return;
                }
                Err(error) => {
                    let completed = self.completed(true);
                    self.ready.extend(completed);
                    if let Some(writer) = self.writer.take() {
                        drop(writer.send);
                        let _ = writer.thread.join();
                    }
                    error.0
                }
            }
        } else {
            snapshot
        };
        match write_snapshot(snapshot) {
            Ok(player) => self.ready.push(player),
            Err(error) => {
                log::warn!("Horizon: {error}");
                self.error = Some(error);
            }
        }
    }

    /// Serialize a newer logout snapshot after every queued autosave.
    pub fn save_after(&mut self, guest: &Guest, world: &Path) -> Vec<SavedPlayer> {
        let saved = self.completed(true);
        save(guest, world);
        saved
    }

    /// Drain completions on the tick thread; `wait` is the durability barrier
    /// for explicit saves, logout, and shutdown. Failures remain visible.
    pub fn completed(&mut self, wait: bool) -> Vec<SavedPlayer> {
        let mut saved = std::mem::take(&mut self.ready);
        while self.pending > 0 {
            let done = &self.writer.as_ref().unwrap().done;
            let result = if wait {
                done.recv()
                    .map_err(|_| std::sync::mpsc::TryRecvError::Disconnected)
            } else {
                done.try_recv()
            };
            match result {
                Ok(result) => {
                    self.pending -= 1;
                    match result {
                        Ok(player) => saved.push(player),
                        Err(error) => {
                            log::warn!("Horizon: {error}");
                            self.error = Some(error);
                        }
                    }
                }
                Err(std::sync::mpsc::TryRecvError::Empty) => break,
                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                    self.error = Some("the player writer stopped".into());
                    log::warn!("Horizon: the player writer stopped");
                    self.pending = 0;
                    if let Some(writer) = self.writer.take() {
                        drop(writer.send);
                        let _ = writer.thread.join();
                    }
                }
            }
        }
        saved
    }

    pub fn writes_finished(&mut self) -> crate::Result<bool> {
        match self.error.take() {
            Some(error) => Err(error.into()),
            None => Ok(self.pending == 0),
        }
    }
}

impl Drop for Autosaves {
    fn drop(&mut self) {
        if let Some(writer) = self.writer.take() {
            drop(writer.send);
            let _ = writer.thread.join();
        }
    }
}

/// Put a guest's state in `level`'s player fields; `vehicle` is the
/// RootVehicle compound of the ride (`ServerPlayer.saveParentVehicle`).
pub fn store(guest: &Guest, level: &mut Level, vehicle: Option<Tag>) {
    level.position = Some(guest.position);
    level.dimension = guest.dimension.clone();
    level.rotation = [guest.yaw, guest.pitch];
    level.health = guest.health;
    level.absorption = guest
        .motion
        .as_ref()
        .map_or(guest.saved_absorption.unwrap_or(0.0), |m| {
            m.health.absorption()
        });
    level.food = guest.food;
    level.saturation = guest.saturation;
    level.xp_level = guest.xp_level;
    level.xp_progress = guest.xp_progress;
    level.xp_total = guest.xp_total;
    level.xp_seed = guest.xp_seed;
    level.active_effects = guest.effects.saved();
    level.game_mode = guest.game_mode;
    // ServerPlayer.addAdditionalSaveData: previousPlayerGameType, when there
    // is one (storeNullable).
    level.previous_game_mode = guest.previous_game_mode;
    level.creative = guest.game_mode == 1;
    level.flying = guest.flying;
    level.fly_speed = Some(guest.flying_speed);
    level.selected_slot = guest.selected as i32;
    level.spawn = guest.spawn.map(|s| [s[0] - 0.5, s[1], s[2] - 0.5]);
    level.respawn_elsewhere = guest.respawn_elsewhere.clone();
    level.on_ground = guest.on_ground;
    level.seen_credits = guest.seen_credits;
    level.post_effects.clone_from(&guest.post_effects);
    level.last_death = guest.last_death.clone();
    level.player_extra = guest.saved.clone();
    let extra = level
        .player_extra
        .get_or_insert_with(|| Tag::Compound(Default::default()));
    if let Tag::Compound(map) = extra
        && attachment_compound(map.get(&ATTACHMENTS_KEY.into())).is_ok()
    {
        let data = guest.attachments.to_nbt();
        if data.is_empty() {
            map.remove(&ATTACHMENTS_KEY.into());
        } else {
            map.insert(ATTACHMENTS_KEY.into(), Tag::Compound(data));
        }
    }
    // The vehicle the player rides (`ServerPlayer.saveParentVehicle`), or
    // the one its file names that has not come back yet (kept in `saved`).
    level.root_vehicle = guest.saved_vehicle;
    if let Some(vehicle) = vehicle {
        level.root_vehicle = uuid_from_tag(vehicle.get("Attach"));
        let extra = level
            .player_extra
            .get_or_insert_with(|| Tag::Compound(Default::default()));
        put(extra, "RootVehicle", vehicle);
    }
    // The live body's fire, air, fall distance and motion
    // (Entity.saveWithoutId), or what the file had while the player has no
    // body yet.
    let body = guest
        .motion
        .as_deref()
        .map(SavedBody::of)
        .or(guest.loaded_body);
    if let Some(body) = body {
        level.fall_distance = body.fall_distance;
        level.motion = body.velocity;
        // FoodData.addAdditionalSaveData: the exhaustion and the timer that
        // regenerates or starves the player go with the food level.
        level.food_exhaustion = body.food_exhaustion;
        level.food_tick_timer = body.food_tick_timer;
        let extra = level
            .player_extra
            .get_or_insert_with(|| horizon_world::nbt::Tag::Compound(Default::default()));
        if let horizon_world::nbt::Tag::Compound(map) = extra {
            let short = |v: i32| horizon_world::nbt::Tag::Short(v.clamp(-32768, 32767) as i16);
            map.insert("Fire".into(), short(body.fire_ticks));
            map.insert("Air".into(), short(body.air));
            // Entity.saveWithoutId writes TicksFrozen only above 0, so a
            // count from the file the player thawed since does not come back.
            if body.ticks_frozen > 0 {
                map.insert(
                    "TicksFrozen".into(),
                    horizon_world::nbt::Tag::Int(body.ticks_frozen),
                );
            } else {
                map.remove(&"TicksFrozen".into());
            }
        }
    }
    // LivingEntity.addAdditionalSaveData: the live body's AttributeMap.pack,
    // or the list the file had while the player has no body yet.
    // A player between two bodies (a respawn, a change of level) saves what
    // the next one takes over.
    let attributes = guest
        .motion
        .as_deref()
        .map(crate::motion::PlayerMotion::saved_attributes)
        .or_else(|| guest.carried_attributes.clone());
    if let Some(attributes) = attributes {
        let extra = level
            .player_extra
            .get_or_insert_with(|| horizon_world::nbt::Tag::Compound(Default::default()));
        if let horizon_world::nbt::Tag::Compound(map) = extra {
            map.insert("attributes".into(), attributes);
        }
    }
    level.recipe_book = guest.recipe_book.clone();
    level.ender_items = guest.ender_items.clone();
    level.inventory.clear();
    level.inventory_components.clear();
    let mut put = |slot: u8, stack: &Option<ItemStack>| {
        if let Some(s) = stack {
            level
                .inventory
                .push((slot, s.item.to_string(), s.count, s.damage));
            if let Some(extra) = &s.extra {
                level.inventory_components.insert(slot, extra.clone());
            }
        }
    };
    for (i, s) in guest.inventory.iter().enumerate() {
        put(i as u8, s);
    }
    put(103, &guest.armor[0]);
    put(102, &guest.armor[1]);
    put(101, &guest.armor[2]);
    put(100, &guest.armor[3]);
    put(150, &guest.offhand);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lan::{Joined, PlayerSender};
    use horizon_protocol::packets::configuration::ClientInformation;
    use std::sync::{Arc, atomic::AtomicI32, mpsc};

    fn guest() -> Guest {
        let (tx, _rx) = mpsc::channel();
        Guest::new(
            Joined {
                conn: 2,
                uuid: 2,
                name: "Alex".into(),
                properties: Vec::new(),
                info: ClientInformation::new(8),
                brand: "test".into(),
                sender: PlayerSender::new(tx, Arc::default()),
                latency: Arc::new(AtomicI32::new(0)),
                address: "127.0.0.1:25565".parse().unwrap(),
                expected: false,
            },
            2,
            [0.0, 64.0, 0.0],
            8,
        )
    }

    #[test]
    fn a_new_player_faces_the_world_spawn_angle() {
        let mut g = guest();
        face_world_spawn(&mut g, false, [90.0, -15.0]);
        assert_eq!((g.yaw, g.pitch, g.head_yaw), (90.0, -15.0, 90.0));
    }

    #[test]
    fn a_saved_rotation_beats_the_world_spawn_angle() {
        let mut g = guest();
        let level = Level {
            rotation: [-135.0, 30.0],
            ..Level::default()
        };
        apply(&mut g, &level);
        face_world_spawn(&mut g, true, [90.0, -15.0]);
        assert_eq!((g.yaw, g.pitch, g.head_yaw), (-135.0, 30.0, -135.0));
    }

    fn holding(uuid: u128, item: &str, count: u32) -> Guest {
        let mut g = guest();
        g.uuid = uuid;
        g.position = [10.5, 70.0, -3.5];
        g.inventory[0] = Some(ItemStack {
            item: Arc::from(item),
            count,
            damage: 0,
            extra: None,
        });
        g
    }

    fn world(name: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!("horizon-owner-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        dir
    }

    #[test]
    fn autosaves_keep_snapshots_and_order_before_logout() {
        let dir = world("async-batch");
        let mut saves = Autosaves::default();
        for uuid in 1..=150 {
            let mut g = holding(uuid, "minecraft:diamond", 5);
            saves.enqueue(&g, &dir);
            // Subsequent live changes cannot alter the queued snapshot.
            g.inventory[0] = None;
        }
        let completed = saves.completed(true);
        assert!(saves.writes_finished().unwrap());
        assert!(completed.iter().map(|p| p.uuid).eq(1..=150));
        for uuid in 1..=150 {
            let mut loaded = guest();
            loaded.uuid = uuid;
            assert!(load(&mut loaded, &dir));
            assert_eq!(first_item(&loaded), Some(("minecraft:diamond", 5)));
        }
        saves.enqueue(&holding(1, "minecraft:gold_ingot", 7), &dir);
        saves.enqueue(&holding(1, "minecraft:emerald", 9), &dir);
        assert_eq!(saves.completed(true).len(), 2);
        assert!(saves.writes_finished().unwrap());
        let mut loaded = guest();
        loaded.uuid = 1;
        assert!(load(&mut loaded, &dir));
        assert_eq!(first_item(&loaded), Some(("minecraft:emerald", 9)));
        // The barrier protects the synchronous, newer logout snapshot.
        for uuid in 1..=150 {
            saves.enqueue(&holding(uuid, "minecraft:diamond", 5), &dir);
        }
        saves.save_after(&holding(1, "minecraft:iron_ingot", 11), &dir);
        drop(saves);
        assert!(load(&mut loaded, &dir));
        assert_eq!(first_item(&loaded), Some(("minecraft:iron_ingot", 11)));
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn autosave_failures_recover_and_drop_drains_writes() {
        let dir = world("async-error");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("players"), b"not a directory").unwrap();
        let mut saves = Autosaves::default();
        saves.enqueue(&holding(1, "minecraft:diamond", 5), &dir);
        assert!(saves.completed(true).is_empty());
        assert!(saves.writes_finished().is_err());
        assert!(saves.completed(false).is_empty());
        assert!(saves.writes_finished().unwrap());
        drop(saves);
        std::fs::remove_file(dir.join("players")).unwrap();
        let mut saves = Autosaves::default();
        saves.enqueue(&holding(1, "minecraft:diamond", 5), &dir);
        for uuid in 2..=150 {
            saves.enqueue(&holding(uuid, "minecraft:diamond", 5), &dir);
        }
        drop(saves);
        for uuid in 1..=150 {
            let mut g = guest();
            g.uuid = uuid;
            assert!(load(&mut g, &dir));
            assert_eq!(first_item(&g), Some(("minecraft:diamond", 5)));
        }
        let mut loaded = guest();
        loaded.uuid = 1;
        assert!(load(&mut loaded, &dir));
        assert_eq!(first_item(&loaded), Some(("minecraft:diamond", 5)));
        std::fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn mixed_autosaves_keep_successes_and_match_logout_files() {
        let bad = world("mixed-bad");
        let good = world("mixed-good");
        let reference = world("mixed-reference");
        std::fs::create_dir_all(&bad).unwrap();
        std::fs::write(bad.join("players"), b"not a directory").unwrap();
        let mut saves = Autosaves::default();
        let g = holding(2, "minecraft:emerald", 9);
        saves.enqueue(&holding(1, "minecraft:diamond", 5), &bad);
        saves.enqueue(&g, &good);
        saves.enqueue(&holding(3, "minecraft:diamond", 5), &bad);
        let saved = saves.completed(true);
        assert_eq!(saved.iter().map(|p| p.uuid).collect::<Vec<_>>(), vec![2]);
        assert!(saves.writes_finished().is_err());
        assert!(saves.writes_finished().unwrap());
        save(&g, &reference);
        assert_eq!(
            read_dat(&path(&good, 2)).unwrap(),
            read_dat(&path(&reference, 2)).unwrap()
        );
        std::fs::remove_file(bad.join("players")).unwrap();
        saves.enqueue(&g, &bad);
        assert_eq!(saves.completed(true).len(), 1);
        assert!(saves.writes_finished().unwrap());
        for dir in [bad, good, reference] {
            std::fs::remove_dir_all(dir).unwrap();
        }
    }

    #[test]
    fn a_disconnected_writer_is_restarted() {
        let dir = world("restart");
        let (send, receive) = std::sync::mpsc::channel();
        drop(receive);
        let (complete, done) = std::sync::mpsc::channel();
        drop(complete);
        let mut saves = Autosaves::default();
        saves.writer = Some(PlayerWriter {
            send,
            done,
            thread: std::thread::spawn(|| {}),
        });
        saves.pending = 1;
        saves.enqueue(&holding(1, "minecraft:diamond", 5), &dir);
        assert_eq!(saves.completed(true).len(), 1);
        assert!(saves.writes_finished().is_err());
        saves.enqueue(&holding(2, "minecraft:emerald", 9), &dir);
        assert!(saves.writer.is_some());
        assert_eq!(saves.completed(true).len(), 1);
        assert!(saves.writes_finished().unwrap());
        std::fs::remove_dir_all(dir).unwrap();
    }

    fn first_item(g: &Guest) -> Option<(&str, u32)> {
        g.inventory[0].as_ref().map(|s| (&*s.item, s.count))
    }

    #[test]
    fn the_owner_loads_the_file_level_dat_names_over_an_older_own_file() {
        // #5351: a newer build saved the owner to both files, then 0.2.93 saved
        // it again to the file level.dat names alone. The owner's own file is
        // older; vanilla's loadPlayerData reads the named one for the owner.
        let owner = horizon_protocol::crypto::offline_uuid("Player46606");
        let dir = world("named");
        save(&holding(owner, "minecraft:diamond", 5), &dir);
        let mut level = Level::default();
        store(&holding(owner, "minecraft:gold_ingot", 7), &mut level, None);
        level.write(&dir).unwrap();
        let named = ints_uuid(level.player_uuid.unwrap());
        assert_ne!(
            named, owner,
            "level.dat names offline `Player`, not the owner"
        );
        let saved = Level::read(&dir).unwrap();
        let mut g = guest();
        g.uuid = owner;
        assert!(load_owner(&mut g, &dir, Some(&saved)));
        assert_eq!(first_item(&g), Some(("minecraft:gold_ingot", 7)));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn the_owner_loads_its_own_file_when_the_named_one_is_missing() {
        let owner = horizon_protocol::crypto::offline_uuid("Player46606");
        let dir = world("own");
        let mut level = Level::default();
        level.write_without_player(&dir).unwrap();
        save(&holding(owner, "minecraft:diamond", 5), &dir);
        let saved = Level::read(&dir).unwrap();
        let mut g = guest();
        g.uuid = owner;
        assert!(load_owner(&mut g, &dir, Some(&saved)));
        assert_eq!(first_item(&g), Some(("minecraft:diamond", 5)));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn player_attachments_survive_playerdata_and_respawn() {
        use horizon_world::attachments::{AttachmentCodec, AttachmentError, AttachmentType};
        let keep = AttachmentType {
            namespace: "test",
            name: "keep",
            default: || 0,
            codec: Some(AttachmentCodec {
                encode: |n: &i32| Ok([("count".into(), Tag::Int(*n))].into()),
                decode: |c| match c.get(&"count".into()) {
                    Some(Tag::Int(n)) => Ok(*n),
                    _ => Err(AttachmentError::Decode),
                },
            }),
            copy_on_death: true,
            sync: false,
        };
        let dir = world("attachments");
        let mut original = guest();
        original.attachments.set(&keep, 31).unwrap();
        save(&original, &dir);
        let mut loaded = guest();
        loaded.uuid = original.uuid;
        assert!(load(&mut loaded, &dir));
        loaded.attachments = loaded.attachments.copy_on_death().unwrap();
        assert_eq!(loaded.attachments.get(&keep), Ok(31));
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn a_save_cut_off_between_its_renames_loads_the_dat_old() {
        // PlayerDataStorage.load: a file `write_dat` moved to `.dat_old` and
        // did not replace (the game stopped between the two renames) is read
        // instead, for the owner's named file and for anyone's own file.
        let owner = horizon_protocol::crypto::offline_uuid("Player46606");
        let dir = world("dat-old");
        let mut level = Level::default();
        for (item, count) in [("minecraft:diamond", 5), ("minecraft:gold_ingot", 7)] {
            store(&holding(owner, item, count), &mut level, None);
            level.write(&dir).unwrap();
            save(&holding(owner, item, count), &dir);
        }
        let named = path(&dir, ints_uuid(level.player_uuid.unwrap()));
        for file in [&named, &path(&dir, owner)] {
            std::fs::remove_file(file).unwrap();
            assert!(file.with_extension("dat_old").is_file());
        }
        let saved = Level::read(&dir).unwrap();
        assert!(saved.singleplayer_file, "the named file's .dat_old counts");
        let mut g = guest();
        g.uuid = owner;
        assert!(load_owner(&mut g, &dir, Some(&saved)));
        assert_eq!(first_item(&g), Some(("minecraft:diamond", 5)));
        let mut g = guest();
        g.uuid = owner;
        assert!(load(&mut g, &dir), "a guest's own file falls back too");
        assert_eq!(first_item(&g), Some(("minecraft:diamond", 5)));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn the_owner_leaving_saves_the_file_it_loads() {
        // The last autosave wrote both files with a diamond; the owner leaves
        // with gold and the game stops before the world's own save. The file
        // the owner loads holds the gold, as its own file does.
        let owner = horizon_protocol::crypto::offline_uuid("Player46606");
        let dir = world("leave");
        let mut level = Level::default();
        store(&holding(owner, "minecraft:diamond", 5), &mut level, None);
        level.write(&dir).unwrap();
        save(&holding(owner, "minecraft:diamond", 5), &dir);
        save_owner(&holding(owner, "minecraft:gold_ingot", 7), &mut level, &dir);
        let saved = Level::read(&dir).unwrap();
        let mut g = guest();
        g.uuid = owner;
        assert!(load_owner(&mut g, &dir, Some(&saved)));
        assert_eq!(first_item(&g), Some(("minecraft:gold_ingot", 7)));
        let mut g = guest();
        g.uuid = owner;
        assert!(load(&mut g, &dir));
        assert_eq!(first_item(&g), Some(("minecraft:gold_ingot", 7)));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_saved_burn_and_fall_come_back() {
        // A player saved burning in mid-fall (#1323, #1327): Entity.saveWithoutId's
        // Fire, Air and fall_distance, read back for the next body.
        let mut g = guest();
        g.loaded_body = Some(SavedBody {
            fire_ticks: 96,
            air: 250,
            fall_distance: 9.5,
            velocity: [0.0; 3],
            food_exhaustion: 0.0,
            food_tick_timer: 0,
            ticks_frozen: 0,
        });
        let mut level = Level::default();
        store(&g, &mut level, None);
        let tag = level.player_tag();
        let mut read = Level::default();
        read.read_player(&tag);
        read.player_extra = Some(tag);
        let mut back = guest();
        apply(&mut back, &read);
        assert_eq!(back.loaded_body, g.loaded_body);
    }

    /// Store, write, read and apply a guest's file, as a server does between a
    /// leave and the next join.
    fn round_trip(g: &Guest) -> (Tag, Guest) {
        let mut level = Level::default();
        store(g, &mut level, None);
        let tag = level.player_tag();
        let mut read = Level::default();
        read.read_player(&tag);
        read.player_extra = Some(tag.clone());
        let mut back = guest();
        apply(&mut back, &read);
        (tag, back)
    }

    #[test]
    fn a_saved_motion_comes_back() {
        // Entity.saveWithoutId writes Motion, the delta movement, as it is;
        // Entity.load reads each component back, as 0 when it is over 10.
        let mut g = guest();
        g.loaded_body = Some(SavedBody {
            fire_ticks: -20,
            air: 300,
            fall_distance: 0.0,
            velocity: [0.25, -0.0784, 12.5],
            food_exhaustion: 0.0,
            food_tick_timer: 0,
            ticks_frozen: 0,
        });
        let (tag, back) = round_trip(&g);
        let mut read = Level::default();
        read.read_player(&tag);
        assert_eq!(read.motion, [0.25, -0.0784, 12.5]);
        assert_eq!(
            back.loaded_body.expect("a body").velocity,
            [0.25, -0.0784, 0.0]
        );
    }

    #[test]
    fn a_saved_exhaustion_and_food_timer_come_back() {
        // FoodData.addAdditionalSaveData writes foodExhaustionLevel (a float)
        // and foodTickTimer (an int) with the food level and saturation.
        let mut g = guest();
        g.loaded_body = Some(SavedBody {
            fire_ticks: -20,
            air: 300,
            fall_distance: 0.0,
            velocity: [0.0; 3],
            food_exhaustion: 2.75,
            food_tick_timer: 37,
            ticks_frozen: 0,
        });
        let (tag, back) = round_trip(&g);
        assert_eq!(
            tag.get("foodExhaustionLevel"),
            Some(&Tag::Float(2.75f32.to_bits()))
        );
        assert_eq!(tag.get("foodTickTimer"), Some(&Tag::Int(37)));
        let body = back.loaded_body.expect("a body");
        assert_eq!((body.food_exhaustion, body.food_tick_timer), (2.75, 37));
    }

    #[test]
    fn the_previous_game_mode_is_kept_and_saved() {
        // ServerPlayerGameMode.changeGameModeForPlayer: the mode left becomes
        // the previous one, and the mode in use changes nothing.
        // ServerPlayer.addAdditionalSaveData writes previousPlayerGameType (an
        // int) only when there is one.
        let mut g = guest();
        assert_eq!(g.previous_game_mode, None);
        let (tag, _) = round_trip(&g);
        assert_eq!(tag.get("previousPlayerGameType"), None);
        g.change_game_mode(1);
        assert_eq!((g.game_mode, g.previous_game_mode), (1, Some(0)));
        g.change_game_mode(1);
        assert_eq!((g.game_mode, g.previous_game_mode), (1, Some(0)));
        g.change_game_mode(3);
        assert_eq!((g.game_mode, g.previous_game_mode), (3, Some(1)));
        let (tag, back) = round_trip(&g);
        assert_eq!(tag.get("previousPlayerGameType"), Some(&Tag::Int(1)));
        assert_eq!((back.game_mode, back.previous_game_mode), (3, Some(1)));
    }

    #[test]
    fn a_saved_freeze_comes_back_and_a_thaw_clears_it() {
        // Entity.saveWithoutId writes TicksFrozen (an int) only when it is
        // above 0; Entity.load reads it with 0 for a missing key.
        let frozen = |ticks| SavedBody {
            fire_ticks: -20,
            air: 300,
            fall_distance: 0.0,
            velocity: [0.0; 3],
            food_exhaustion: 0.0,
            food_tick_timer: 0,
            ticks_frozen: ticks,
        };
        let mut g = guest();
        g.loaded_body = Some(frozen(120));
        let (tag, back) = round_trip(&g);
        assert_eq!(tag.get("TicksFrozen"), Some(&Tag::Int(120)));
        assert_eq!(back.loaded_body.expect("a body").ticks_frozen, 120);
        // Thawed since: the file the guest came from still says 120, and the
        // key goes.
        let mut g = back;
        g.loaded_body = Some(frozen(0));
        let (tag, back) = round_trip(&g);
        assert_eq!(tag.get("TicksFrozen"), None);
        assert_eq!(back.loaded_body.expect("a body").ticks_frozen, 0);
    }

    #[test]
    fn post_effects_are_saved_with_the_player() {
        // ServerPlayer.addAdditionalSaveData's `post_effects`, in order; none
        // is an empty list, and a cleared list does not come back from an
        // older file's copy.
        let mut g = guest();
        g.post_effects = vec!["minecraft:invert".into(), "pack:glow".into()];
        let mut level = Level::default();
        store(&g, &mut level, None);
        let tag = level.player_tag();
        let mut read = Level::default();
        read.read_player(&tag);
        read.player_extra = Some(tag);
        let mut back = guest();
        apply(&mut back, &read);
        assert_eq!(back.post_effects, g.post_effects);
        // The cleared list is written over the loaded file.
        g.post_effects.clear();
        store(&g, &mut read, None);
        let tag = read.player_tag();
        assert!(matches!(
            tag.get("post_effects"),
            Some(horizon_world::nbt::Tag::List(l)) if l.is_empty()
        ));
    }

    /// The resources the prepared game data holds, for a body to breathe with.
    fn resources() -> Option<(crate::assets::Assets, crate::motion::MotionResources)> {
        let root = std::env::var_os("HORIZON_TEST_RESOURCES")
            .map(std::path::PathBuf::from)
            .unwrap_or_else(|| {
                std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                    .join("../../.local/horizon-client")
                    .join(horizon_core::VANILLA_VERSION)
            });
        if !root.join("movement-properties.nbt").exists() {
            return None;
        }
        let assets = crate::assets::Assets::load(&root).ok()?;
        let resources = crate::motion::MotionResources::load(&root, &assets).ok()?;
        Some((assets, resources))
    }

    /// A body at scale 0.1 with a permanent +0.4 on its step height, such as
    /// a command or a datapack gives.
    fn small_body(resources: &crate::motion::MotionResources) -> crate::motion::PlayerMotion {
        use horizon_world::attributes::{Modifier, Operation};
        let mut m = crate::motion::PlayerMotion::new(resources, horizon_core::geometry::Vec3::ZERO)
            .expect("a body");
        let key = m.attributes.key("minecraft:scale").unwrap();
        let handle = m.attributes.get_instance(Some(key)).unwrap().unwrap();
        m.attributes
            .edit(&handle, |a, o| a.set_base_value(0.1, o))
            .unwrap();
        let key = m.attributes.key("minecraft:step_height").unwrap();
        let handle = m.attributes.get_instance(Some(key)).unwrap().unwrap();
        let step = Modifier::new("test:step", 0.4, Operation::AddValue).unwrap();
        m.attributes
            .edit(&handle, |a, o| a.add_permanent(step, o))
            .unwrap();
        m
    }

    #[test]
    fn a_new_body_takes_the_scale_of_the_old_one() {
        // #3684: ServerPlayer.restoreFrom copies the base values to the body
        // that follows a death (assignBaseValues) and, for the same player in
        // another level, the permanent modifiers too (assignPermanentModifiers).
        // The body Horizon made on a respawn or a level change started from
        // the defaults: a player at /attribute scale 0.1 was 1.0 again.
        let Some((_assets, resources)) = resources() else {
            eprintln!("skipped: prepared resources unavailable");
            return;
        };
        let next = |g: &Guest| {
            let mut m =
                crate::motion::PlayerMotion::new(&resources, horizon_core::geometry::Vec3::ZERO)
                    .expect("a body");
            m.apply_saved_attributes(g.carried_attributes.as_ref())
                .unwrap();
            m
        };
        for (restore_all, step) in [(false, 0.6), (true, 1.0)] {
            let mut g = guest();
            g.motion = Some(Box::new(small_body(&resources)));
            g.new_body(restore_all);
            assert!(g.motion.is_none());
            let mut m = next(&g);
            assert_eq!(m.attribute("minecraft:scale").unwrap(), 0.1);
            assert!((m.attribute("minecraft:step_height").unwrap() - step).abs() < 1e-9);
            // The tick that follows rebuilds the box at that scale.
            m.refresh_attributes().unwrap();
            assert_eq!(m.dimensions.width, 0.6 * 0.1);
            assert_eq!(m.dimensions.height, 1.8 * 0.1);
        }
        // No body before: nothing to hand over.
        let mut g = guest();
        g.new_body(true);
        assert!(g.carried_attributes.is_none());
    }

    #[test]
    fn a_player_between_two_bodies_saves_the_attributes_the_next_one_takes() {
        // #3684: logging out after a respawn, before the new body has ticked,
        // must not write the file's older list over the scale.
        let Some((_assets, resources)) = resources() else {
            eprintln!("skipped: prepared resources unavailable");
            return;
        };
        let mut g = guest();
        g.motion = Some(Box::new(small_body(&resources)));
        g.new_body(false);
        let mut level = Level::default();
        store(&g, &mut level, None);
        let tag = level.player_tag();
        let mut read = Level::default();
        read.read_player(&tag);
        read.player_extra = Some(tag);
        let mut back =
            crate::motion::PlayerMotion::new(&resources, horizon_core::geometry::Vec3::ZERO)
                .expect("a body");
        back.apply_saved_attributes(read.player_extra.as_ref().and_then(|t| t.get("attributes")))
            .unwrap();
        assert_eq!(back.attribute("minecraft:scale").unwrap(), 0.1);
    }

    #[test]
    fn a_saved_air_comes_back() {
        // A player saved underwater (#1321): the file keeps the remaining air
        // (Entity.saveWithoutId's Air), and the body that comes back breathes
        // on it instead of starting with a full supply.
        let Some((_assets, resources)) = resources() else {
            eprintln!("skipped the air round trip: prepared resources unavailable");
            return;
        };
        let mut g = guest();
        let mut motion =
            crate::motion::PlayerMotion::new(&resources, horizon_core::geometry::Vec3::ZERO)
                .expect("a body");
        motion.air = 99;
        g.motion = Some(Box::new(motion));
        let mut level = Level::default();
        store(&g, &mut level, None);
        let tag = level.player_tag();
        let mut read = Level::default();
        read.read_player(&tag);
        read.player_extra = Some(tag);
        let mut back = guest();
        apply(&mut back, &read);
        assert_eq!(back.loaded_body.expect("a body").air, 99);
    }

    #[test]
    fn a_saved_root_vehicle_comes_back() {
        // A player saved riding a horse (#1474): the file holds the vehicle
        // (ServerPlayer.saveParentVehicle's RootVehicle {Attach, Entity}),
        // and the next login spawns it and rides it again.
        let vehicle = [1, 2, 3, 4];
        let horse = Tag::compound([
            ("id", Tag::String("minecraft:horse".into())),
            ("UUID", Tag::IntArray(vehicle.to_vec())),
        ]);
        let root = Tag::compound([
            ("Attach", Tag::IntArray(vehicle.to_vec())),
            ("Entity", horse),
        ]);
        let g = guest();
        let mut level = Level::default();
        store(&g, &mut level, Some(root.clone()));
        let tag = level.player_tag();
        assert_eq!(tag.get("RootVehicle"), Some(&root));
        let mut read = Level::default();
        read.read_player(&tag);
        read.player_extra = Some(tag);
        let mut back = guest();
        apply(&mut back, &read);
        assert_eq!(back.saved_vehicle, Some(vehicle));
        // Saved again before the horse is back, the file keeps it whole.
        let mut again = Level::default();
        store(&back, &mut again, None);
        assert_eq!(again.player_tag().get("RootVehicle"), Some(&root));
    }

    fn abilities(g: &Guest) -> (i8, f32) {
        match g.abilities() {
            horizon_protocol::packets::play::Clientbound::PlayerAbilities(p) => {
                (p.flags, p.flying_speed)
            }
            other => panic!("not the abilities: {other:?}"),
        }
    }

    /// A flying speed a mod set goes out in every abilities packet (a game
    /// mode change's, a respawn's), is saved as vanilla's `abilities.flySpeed`
    /// and comes back when the player does; a file without one is vanilla's 0.05.
    #[test]
    fn a_set_flying_speed_is_sent_kept_and_saved() {
        let dir = world("fly-speed");
        let mut g = guest();
        assert_eq!(abilities(&g).1, 0.05);
        g.flying_speed = 2.5;
        g.game_mode = 1;
        assert_eq!(abilities(&g), (1 | 4 | 8, 2.5));
        g.game_mode = 0;
        assert_eq!(abilities(&g), (0, 2.5));
        save(&g, &dir);
        let tag = read_dat(&path(&dir, g.uuid)).unwrap();
        let saved = tag.get("abilities").and_then(|a| a.get("flySpeed"));
        assert_eq!(saved, Some(&Tag::Float(2.5f32.to_bits())));
        let mut back = guest();
        assert!(load(&mut back, &dir));
        assert_eq!(back.flying_speed, 2.5);
        // A vanilla file's own speed is read, and one without is 0.05.
        let mut level = Level::default();
        level.read_player(&Tag::compound([(
            "abilities",
            Tag::compound([("flySpeed", Tag::Float(0.1f32.to_bits()))]),
        )]));
        let mut other = guest();
        apply(&mut other, &level);
        assert_eq!(other.flying_speed, 0.1);
        level.read_player(&Tag::compound([(
            "abilities",
            Tag::Compound(Default::default()),
        )]));
        apply(&mut other, &level);
        assert_eq!(other.flying_speed, 0.05);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_world_without_singleplayer_uuid_gives_the_owner_a_new_player_not_anothers() {
        // A world from a vanilla server: no `singleplayer_uuid`, and the players' files are other
        // people's. The owner has none: vanilla starts them new (PlayerList.loadPlayerData).
        let owner = horizon_protocol::crypto::offline_uuid("Owner");
        let friend = horizon_protocol::crypto::offline_uuid("Friend");
        let dir = world("server-world");
        save(&holding(friend, "minecraft:netherite_ingot", 9), &dir);
        let mut level = Level::default();
        level.write(&dir).unwrap();
        let _ = std::fs::remove_file(dir.join("level.dat_old"));
        let mut tag = read_dat(&dir.join("level.dat")).unwrap();
        if let Some(Tag::Compound(data)) = tag.get_mut("Data") {
            data.remove(&"singleplayer_uuid".into());
        }
        write_dat(&dir.join("level.dat"), tag).unwrap();
        let read = Level::read(&dir).unwrap();
        let mut g = holding(owner, "minecraft:dirt", 1);
        g.inventory[0] = None;
        let known = load_owner(&mut g, &dir, Some(&read));
        assert!(!known, "the owner has not been here before");
        assert_eq!(first_item(&g), None, "no inventory of the friend's");
        // The owner's save names the owner, and leaves the friend's file alone.
        let before = std::fs::read(path(&dir, friend)).unwrap();
        let mut level = read;
        save_owner(&g, &mut level, &dir);
        assert_eq!(level.player_uuid, Some(uuid_ints(owner)));
        assert_eq!(std::fs::read(path(&dir, friend)).unwrap(), before);
        assert!(exists(&dir, owner));
    }
}
