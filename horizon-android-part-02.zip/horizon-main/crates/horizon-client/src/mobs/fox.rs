//! Foxes (`net.minecraft.world.entity.animal.fox.Fox`): the goal list, the
//! flags byte (sleeping, sitting, crouching, interested, pouncing,
//! faceplanted), stalking and pouncing, napping in the shade by day, seeking
//! shelter, perching, eating berries and the food held in the mouth (with the
//! item's on-consumed effects: a chorus fruit teleports it).
//! Strolling through villages and defending trusted players are not ported yet.
//! The goal that walks to a dropped item is here; the game side takes the
//! items (`Fox.pickUpItem`, `game/foxes.rs`). A totem in the mouth is a
//! `death_protection` item like any other held one (`Mob::damage`).
use super::{
    Mob, MobEvent, MobWorld, Seen, Species,
    goals::{
        Avoid, AvoidEntity, Breed, ClimbOnTopOfPowderSnow, Cx, Float, FollowParent, Goal, JUMP,
        LOOK, LeapAtTarget, LookAtPlayer, MOVE, MeleeAttack, MoveToBlock, NearestTarget, Panic,
        Prey, Stroll, goal_clone, hide_pos, reduced,
    },
    living::wrap,
    riders,
};
use horizon_core::{
    geometry::{Axis, Vec3},
    jmath,
    random::RandomSource,
};
use horizon_items::items::ConsumeEffect;
use horizon_world::registry::BlockStateId;
use horizon_world::teleport_consume::TeleportConsume;

// Fox.DATA_FLAGS_ID, kept in `extra.ints[0]` (and sent to clients as is).
pub const SITTING: i32 = 1;
pub const CROUCHING: i32 = 4;
pub const INTERESTED: i32 = 8;
pub const POUNCING: i32 = 16;
pub const SLEEPING: i32 = 32;
pub const FACEPLANTED: i32 = 64;
pub const DEFENDING: i32 = 128;
/// `Fox.ticksSinceEaten`.
const TICKS_SINCE_EATEN: usize = 1;
/// `Fox.interestedAngle` and `crouchAmount` in `anim.v`, the previous tick's
/// values in `anim.vo`.
const INTERESTED_ANGLE: usize = 0;
const CROUCH_AMOUNT: usize = 1;
/// `Fox.MAX_CROUCH_AMOUNT`.
const MAX_CROUCH_AMOUNT: f32 = 5.0;

pub fn flag(m: &Mob, f: i32) -> bool {
    m.extra.ints[0] & f != 0
}
/// `Fox.getAmbientSound` for a fox awake: when it isn't bright outside, one
/// time in ten, the screech if no non-spectator player's box is within 16
/// blocks of the fox's; otherwise the ambient sound.
pub fn awake_ambient(m: &mut Mob, w: &MobWorld) -> &'static str {
    // Level.isBrightOutside: the End has a fixed time, so never there.
    let bright = w.daylight && !w.end;
    if !bright && m.random.next_float() < 0.1 {
        let around = m.bounds().inflate(Vec3::new(16.0, 16.0, 16.0));
        let player_near = w
            .player
            .as_ref()
            .is_some_and(|p| !p.spectator && p.bounds.intersects(around));
        if !player_near {
            return SCREECH;
        }
    }
    "entity.fox.ambient"
}
/// `SoundEvents.FOX_SCREECH`.
pub const SCREECH: &str = "entity.fox.screech";
fn set_flag(m: &mut Mob, f: i32, on: bool) {
    if on {
        m.extra.ints[0] |= f;
    } else {
        m.extra.ints[0] &= !f;
    }
}
/// `Fox.clearStates`.
fn clear_states(m: &mut Mob) {
    m.extra.ints[0] = 0;
}
/// `Fox.getTrustedEntities`: the UUIDs a fox trusts, `DATA_TRUSTED_ID_0`
/// first.
pub fn trusted_entities(m: &Mob) -> impl Iterator<Item = [i32; 4]> + '_ {
    m.extra.trusted.iter().flatten().copied()
}
/// `Fox.addTrustedEntity`: the first free slot, and once both are taken a new
/// one replaces the second.
pub fn add_trusted_entity(m: &mut Mob, uuid: [i32; 4]) {
    let slot = usize::from(m.extra.trusted[0].is_some());
    m.extra.trusted[slot] = Some(uuid);
}
/// `Fox.clearTrusted`: forget everyone.
pub fn clear_trusted(m: &mut Mob) {
    m.extra.trusted = [None; 2];
}
/// `Fox.trusts`: the UUID is one of the trusted.
pub fn trusts(m: &Mob, uuid: [i32; 4]) -> bool {
    trusted_entities(m).any(|trusted| trusted == uuid)
}
/// The trust of a fox's breeding (`Fox.FoxBreedGoal.breed`): the baby trusts
/// the player who fed this fox into love and, when it is another player, the
/// one who fed its partner.
pub fn trust_breeders(
    baby: &mut Mob,
    love_cause: Option<[i32; 4]>,
    partner_love_cause: Option<[i32; 4]>,
) {
    if let Some(cause) = love_cause {
        add_trusted_entity(baby, cause);
    }
    if let Some(cause) = partner_love_cause
        && partner_love_cause != love_cause
    {
        add_trusted_entity(baby, cause);
    }
}
/// `Fox.canMove`, which `FoxMoveControl` waits for.
pub fn can_move(m: &Mob) -> bool {
    !flag(m, SLEEPING | SITTING | FACEPLANTED)
}
/// `FoxLookControl.resetXRotOnTick`: stalking and pouncing keep their pitch.
pub fn resets_x_rot(m: &Mob) -> bool {
    !flag(m, POUNCING | CROUCHING | INTERESTED | FACEPLANTED)
}

/// `Fox.populateDefaultEquipmentSlots`: one fox in five holds an emerald, an
/// egg, rabbit feet or hide, wheat, leather or a feather in its mouth.
pub fn populate_default_equipment(m: &mut Mob) {
    if m.random.next_float() < 0.2 {
        let odds = m.random.next_float();
        let held = if odds < 0.05 {
            "minecraft:emerald"
        } else if odds < 0.2 {
            "minecraft:egg"
        } else if odds < 0.4 {
            if m.random.next_boolean() {
                "minecraft:rabbit_foot"
            } else {
                "minecraft:rabbit_hide"
            }
        } else if odds < 0.6 {
            "minecraft:wheat"
        } else if odds < 0.8 {
            "minecraft:leather"
        } else {
            "minecraft:feather"
        };
        m.extra.main_hand = Some(held.into());
    }
}
/// `Fox.registerGoals` and `setTargetGoals` (the targets wait for the variant:
/// red foxes prefer chickens and rabbits, snow foxes fish).
pub fn register(m: &mut Mob) {
    let countdown = m.random.next_int_bound(reduced(140)).unwrap_or(0);
    let g = &mut m.ai.goals;
    g.add(0, Wrap::new(Float).on_start(clear_states));
    g.add(0, ClimbOnTopOfPowderSnow);
    g.add(1, Faceplant { countdown: 0 });
    g.add(2, Panic::new(2.2));
    g.add(3, Wrap::new(Breed::new(1.0)).on_start(clear_states));
    // AVOID_PLAYERS: not a sneaking player.
    g.add(
        4,
        AvoidEntity::new(Avoid::Player, 16.0, 1.6, 1.4)
            .player_when(|m, p| !p.sneaking && !p.spectator && !trusts(m, p.uuid)),
    );
    g.add(
        4,
        AvoidEntity::new(Avoid::Species(vec![Species::Wolf]), 8.0, 1.6, 1.4).seen_when(|s| !s.tame),
    );
    g.add(
        4,
        AvoidEntity::new(Avoid::Species(vec![Species::PolarBear]), 8.0, 1.6, 1.4),
    );
    g.add(5, StalkPrey);
    g.add(6, Pounce);
    g.add(6, SeekShelter::new(1.25));
    g.add(
        7,
        Wrap::new(MeleeAttack::new(1.2, true).bite("entity.fox.bite"))
            .when(
                |m| !flag(m, SITTING | SLEEPING | CROUCHING | FACEPLANTED),
                false,
            )
            .on_start(|m| set_flag(m, INTERESTED, false)),
    );
    g.add(7, Sleep { countdown });
    g.add(8, Wrap::new(FollowParent::new(1.25)).on_start(clear_states));
    g.add(10, EatBerries::new());
    g.add(10, LeapAtTarget::new(0.4));
    g.add(11, Stroll::avoiding_water(1.0));
    g.add(11, SearchForItems);
    // FoxLookAtPlayerGoal: not with the nose in the snow or while stalking.
    g.add(
        12,
        Wrap::new(LookAtPlayer::new(24.0)).when(|m| !flag(m, FACEPLANTED | INTERESTED), true),
    );
    g.add(13, Perch::default());
    let red = |m: &Mob, _: &MobWorld| m.extra.variant == 0;
    let snow = |m: &Mob, _: &MobWorld| m.extra.variant != 0;
    let land = || NearestTarget::new(Prey::Filter(chicken_or_rabbit), false).interval(10);
    let turtle = || NearestTarget::new(Prey::Filter(baby_turtle_on_land), false).interval(10);
    let fish = || NearestTarget::new(Prey::Filter(schooling_fish), false).interval(20);
    let t = &mut m.ai.targets;
    t.add(4, land().gate(red));
    t.add(4, turtle().gate(red));
    t.add(6, fish().gate(red));
    t.add(4, fish().gate(snow));
    t.add(6, land().gate(snow));
    t.add(6, turtle().gate(snow));
}

fn chicken_or_rabbit(s: &Seen) -> bool {
    matches!(s.species, Species::Chicken | Species::Rabbit)
}
fn baby_turtle_on_land(s: &Seen) -> bool {
    s.species == Species::Turtle && s.baby && !s.in_water
}
fn schooling_fish(s: &Seen) -> bool {
    matches!(
        s.species,
        Species::Cod | Species::Salmon | Species::TropicalFish
    )
}

/// The part of `Fox.tick` a client runs too: the head tilt eases toward the
/// interested flag and the crouch builds up to 5 while crouching.
pub fn client_tick(m: &mut Mob) {
    let (interested, crouching) = (flag(m, INTERESTED), flag(m, CROUCHING));
    let v = &mut m.anim.v;
    m.anim.vo[INTERESTED_ANGLE] = v[INTERESTED_ANGLE];
    v[INTERESTED_ANGLE] += (if interested { 1.0 } else { 0.0 } - v[INTERESTED_ANGLE]) * 0.4;
    m.anim.vo[CROUCH_AMOUNT] = v[CROUCH_AMOUNT];
    v[CROUCH_AMOUNT] = if crouching {
        (v[CROUCH_AMOUNT] + 0.2).min(MAX_CROUCH_AMOUNT)
    } else {
        0.0
    };
}
/// `Fox.isFullyCrouched`.
fn fully_crouched(m: &Mob) -> bool {
    m.anim.v[CROUCH_AMOUNT] == MAX_CROUCH_AMOUNT
}

/// `Fox.tick` and `Fox.aiStep`: eating, and `SoundEvents.FOX_AGGRO`
/// (`Entity.playSound` at its feet) while the fox is defending. Only the
/// server broadcasts that sound.
pub fn ai_step(m: &mut Mob, w: &MobWorld, events: &mut Vec<MobEvent>) {
    client_tick(m);
    if !m.alive() {
        return;
    }
    m.extra.ints[TICKS_SINCE_EATEN] += 1;
    if let Some(item) = m.extra.main_hand.clone()
        && eats(w, &item)
        && m.ai.target.is_none()
        && m.on_ground
        && !flag(m, SLEEPING)
    {
        let eaten = m.extra.ints[TICKS_SINCE_EATEN];
        if eaten > 600 {
            // ItemStack.finishUsingItem: the consumable's on-consumed effects
            // run (a chorus fruit teleports it), then a use remainder stays.
            consume(w, m, events, &item);
            m.extra.set_main_hand(
                w.items
                    .and_then(|i| i.items.get(&item))
                    .and_then(|i| i.use_remainder.as_deref())
                    .map(Into::into),
            );
            m.extra.ints[TICKS_SINCE_EATEN] = 0;
        } else if eaten > 560 && m.random.next_float() < 0.1 {
            let at = [m.position.x, m.position.y, m.position.z];
            events.push(MobEvent::Sound("entity.fox.eat", at, 1.0, 1.0));
            // Fox.handleEntityEvent 45: the clients throw the crumbs of the food.
            events.push(MobEvent::EntityEvent {
                mob: m.id,
                event: 45,
                at,
            });
        }
    }
    if !m.target_info(w).is_some_and(|t| t.alive) {
        set_flag(m, CROUCHING | INTERESTED, false);
    }
    let in_water = m.fluids.in_water;
    if in_water || m.ai.target.is_some() || w.thundering {
        set_flag(m, SLEEPING, false);
    }
    if in_water || flag(m, SLEEPING) {
        set_flag(m, SITTING, false);
    }
    // `Fox.aiStep`, after the living step: one tick in twenty a defending fox
    // growls. `Entity.playSound` is positional and a silent fox stays quiet.
    if flag(m, DEFENDING) && m.random.next_float() < 0.05 && !m.silent {
        let at = [m.position.x, m.position.y, m.position.z];
        events.push(MobEvent::Sound("entity.fox.aggro", at, 1.0, 1.0));
    }
    // Faceplanted: crumbs of the snow now and then (level event 2001).
    if flag(m, FACEPLANTED) && m.random.next_float() < 0.2 {
        let at = [
            m.position.x.floor() as i32,
            m.position.y.floor() as i32,
            m.position.z.floor() as i32,
        ];
        events.push(MobEvent::LevelEvent {
            id: 2001,
            pos: at,
            data: w.world.block(at[0], at[1], at[2]).0 as i32,
        });
    }
}
/// `Fox.aiStep` before the living step: a sleeping fox takes no input.
pub fn pre_ai_step(m: &mut Mob) {
    if flag(m, SLEEPING) {
        m.ai.jumping = false;
        m.ai.xxa = 0.0;
        m.ai.zza = 0.0;
    }
}
/// `Fox.isConsumableFood`: the item has food and consumable components.
fn eats(w: &MobWorld, item: &str) -> bool {
    w.items
        .and_then(|i| i.items.get(item))
        .is_some_and(|i| i.food.is_some() && i.consumable.is_some())
}

/// `Consumable.onConsume`'s `on_consume_effects` when a fox finishes an item
/// (`Item.finishUsingItem`): the teleport that a chorus fruit gives it.
fn consume(w: &MobWorld, m: &mut Mob, events: &mut Vec<MobEvent>, item: &str) {
    let Some(consumable) = w
        .items
        .and_then(|i| i.items.get(item))
        .and_then(|i| i.consumable.as_ref())
    else {
        return;
    };
    for effect in &consumable.effects {
        if let ConsumeEffect::TeleportRandomly(teleport) = effect {
            teleport_randomly(w, m, events, teleport);
        }
    }
}

/// `TeleportRandomlyConsumeEffect.apply` for a fox: 16 draws of a point in a
/// cube of `diameter` around it, the first it can stand at takes it, with the
/// fox's own teleport sound and the portal trail (level event 2017).
fn teleport_randomly(
    w: &MobWorld,
    m: &mut Mob,
    events: &mut Vec<MobEvent>,
    teleport: &TeleportConsume,
) {
    let origin = m.position;
    let diameter = f64::from(teleport.diameter);
    // `Mth.clamp(y, level.getMinY(), getMinY() + logicalHeight - 1)`.
    let low = f64::from(w.world.bottom_y());
    let high = low + f64::from(w.world.shape.logical_height) - 1.0;
    for _ in 0..16 {
        let x = origin.x + (m.random.next_double() - 0.5) * diameter;
        let y = (origin.y + (m.random.next_double() - 0.5) * diameter).clamp(low, high);
        let z = origin.z + (m.random.next_double() - 0.5) * diameter;
        if m.extra.passenger {
            riders::stop_riding(m, None);
        }
        let old = m.position;
        if !random_teleport(w, m, Vec3::new(x, y, z)) {
            continue;
        }
        // `LivingEntity.checkPositionAndTeleport` broadcasts entity event 46
        // before the teleport sound and the directional trail.
        events.push(MobEvent::EntityEvent {
            mob: m.id,
            event: 46,
            at: [m.position.x, m.position.y, m.position.z],
        });
        // `SoundEvents.FOX_TELEPORT`, else the chorus fruit's own; the sound
        // plays at the point reached.
        events.push(MobEvent::Sound(
            "entity.fox.teleport",
            [m.position.x, m.position.y, m.position.z],
            1.0,
            1.0,
        ));
        if teleport.directional_particles {
            let at = |p: Vec3| [p.x.floor() as i32, p.y.floor() as i32, p.z.floor() as i32];
            let (from, to) = (at(old), at(m.position));
            // `BlockPos` offset clamped to a byte per axis, packed as vanilla does.
            let axis = |a: i32, b: i32| (b - a).clamp(-127, 127) + 127;
            events.push(MobEvent::LevelEvent {
                id: 2017,
                pos: from,
                data: (axis(from[0], to[0]) << 16)
                    | (axis(from[1], to[1]) << 8)
                    | axis(from[2], to[2]),
            });
        }
        m.fall_distance = 0.0;
        return;
    }
}

/// `Entity.randomTeleport`: the drawn point drops to the first
/// motion-blocking ground below it and takes the fox only if its box there
/// is free and holds no liquid, on a block the consume effect allows.
/// Otherwise the fox stays where it was.
fn random_teleport(w: &MobWorld, m: &mut Mob, to: Vec3) -> bool {
    let (x, z) = (to.x, to.z);
    let (bx, bz) = (x.floor() as i32, z.floor() as i32);
    if !w.world.loaded(bx, bz) {
        return false;
    }
    // `while (!foundGround && pos.getY() > level().getMinY())`: every step
    // down that is not ground lowers the landing height by one.
    let mut y = to.y;
    let mut by = to.y.floor() as i32;
    let mut ground = false;
    while by > w.world.bottom_y() {
        by -= 1;
        if w.facts.get(w.world.block(bx, by, bz)).full_collision {
            ground = true;
            break;
        }
        y -= 1.0;
    }
    if !ground {
        return false;
    }
    // `level().noCollision(this) && !level().containsAnyLiquid(getBoundingBox())
    // && !getBlockState(blockPosition()).is(CONSUMABLE_DOES_NOT_TELEPORT_TO)`.
    let at = Vec3::new(x, y, z);
    let bounds = m.bounds_at(at);
    let landing = w.block_name(x.floor() as i32, y.floor() as i32, z.floor() as i32);
    if !w.no_collision(bounds)
        || w.contains_any_liquid(bounds)
        || w.has_tag("minecraft:consumable_does_not_teleport_to", landing)
    {
        return false;
    }
    m.position = at;
    m.previous = at;
    m.velocity = Vec3::ZERO;
    m.ai.nav.stop();
    true
}

/// `Fox.FoxBehaviorGoal.hasShelter`: out of the sky's sight and not a bad spot.
fn has_shelter(m: &Mob, w: &MobWorld) -> bool {
    let at = [
        m.position.x.floor() as i32,
        m.bounds().max(Axis::Y).floor() as i32,
        m.position.z.floor() as i32,
    ];
    !w.can_see_sky(at[0], at[1], at[2]) && m.walk_target_value(w, at) >= 0.0
}
/// `Fox.FoxBehaviorGoal.alertable`: someone within 12 blocks the fox would
/// keep watch over (`FoxAlertableEntitiesSelector`).
fn alertable(m: &Mob, w: &MobWorld) -> bool {
    let (from, id, y) = (m.position, m.id, m.position.y);
    let mob = w
        .nearby(from, 12.0, |s: &Seen| {
            s.id != id
                && (s.position.y - y).abs() <= 6.0
                && m.distance_sqr(s.position) <= 144.0
                && match s.species {
                    Species::Fox => false,
                    Species::Chicken | Species::Rabbit => true,
                    Species::Wolf | Species::Cat | Species::Parrot | Species::Nautilus => !s.tame,
                    _ => true,
                }
        })
        .next()
        .is_some();
    mob || w.player.as_ref().is_some_and(|p| {
        p.alive
            && !p.creative
            && !p.spectator
            && !p.sneaking
            && (p.position.y - y).abs() <= 6.0
            && m.distance_sqr(p.position) <= 144.0
    })
}

/// `Fox.SleepGoal`: nap in the shade by day when nothing is around.
#[derive(Clone, Debug)]
struct Sleep {
    countdown: i32,
}
impl Sleep {
    fn can_sleep(&mut self, m: &Mob, w: &MobWorld) -> bool {
        if self.countdown > 0 {
            self.countdown -= 1;
            return false;
        }
        let (x, y, z) = (
            m.position.x.floor() as i32,
            m.position.y.floor() as i32,
            m.position.z.floor() as i32,
        );
        w.daylight
            && has_shelter(m, w)
            && !alertable(m, w)
            && w.block_name(x, y, z) != "minecraft:powder_snow"
    }
}
impl Goal for Sleep {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK | JUMP
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        m.ai.nav.is_done() && (self.can_sleep(m, cx.w) || flag(m, SLEEPING))
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.can_sleep(m, cx.w)
    }
    fn start(&mut self, m: &mut Mob, _: &mut Cx) {
        set_flag(m, SITTING | CROUCHING | INTERESTED, false);
        m.ai.jumping = false;
        set_flag(m, SLEEPING, true);
        m.nav_stop();
        let p = m.position;
        m.ai.mov.set_wanted(p.x, p.y, p.z, 0.0);
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        self.countdown = m.random.next_int_bound(reduced(140)).unwrap_or(0);
        clear_states(m);
    }
}

/// A shared goal under the fox's own conditions and start-up: the extra
/// `canUse` of `FoxMeleeAttackGoal` and `FoxLookAtPlayerGoal` and the
/// `clearStates` or `setIsInterested(false)` its subclasses do in `start`.
#[derive(Clone, Debug)]
struct Wrap<G> {
    goal: G,
    when: Option<fn(&Mob) -> bool>,
    /// The condition also applies to `canContinueToUse`.
    both: bool,
    on_start: Option<fn(&mut Mob)>,
}
impl<G: Goal + Clone + 'static> Wrap<G> {
    fn new(goal: G) -> Self {
        Self {
            goal,
            when: None,
            both: false,
            on_start: None,
        }
    }
    fn when(mut self, f: fn(&Mob) -> bool, both: bool) -> Self {
        (self.when, self.both) = (Some(f), both);
        self
    }
    fn on_start(mut self, f: fn(&mut Mob)) -> Self {
        self.on_start = Some(f);
        self
    }
}
impl<G: Goal + Clone + 'static> Goal for Wrap<G> {
    goal_clone!();
    fn flags(&self) -> u8 {
        self.goal.flags()
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.when.is_none_or(|f| f(m)) && self.goal.can_use(m, cx)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        (!self.both || self.when.is_none_or(|f| f(m))) && self.goal.can_continue(m, cx)
    }
    fn interruptable(&self) -> bool {
        self.goal.interruptable()
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        if let Some(f) = self.on_start {
            f(m);
        }
        self.goal.start(m, cx);
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.goal.stop(m, cx);
    }
    fn every_tick(&self) -> bool {
        self.goal.every_tick()
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.goal.tick(m, cx);
    }
    fn name(&self) -> &'static str {
        self.goal.name()
    }
}

/// `Fox.isPathClear`: six points along the way to the target, each with
/// nothing but replaceable blocks in the three above it.
fn path_clear(m: &Mob, w: &MobWorld, to: Vec3) -> bool {
    let (zdiff, xdiff) = (to.z - m.position.z, to.x - m.position.x);
    let slope = zdiff / xdiff;
    for i in 0..6 {
        let step = f64::from(i as f32 / 6.0);
        let z = if slope == 0.0 { 0.0 } else { zdiff * step };
        let x = if slope == 0.0 {
            xdiff * step
        } else {
            z / slope
        };
        for j in 1..4 {
            let at = [
                (m.position.x + x).floor() as i32,
                (m.position.y + f64::from(j)).floor() as i32,
                (m.position.z + z).floor() as i32,
            ];
            if !w.facts.get(w.world.block(at[0], at[1], at[2])).replaceable {
                return false;
            }
        }
    }
    true
}
fn signum(x: f64) -> f64 {
    if x > 0.0 {
        1.0
    } else if x < 0.0 {
        -1.0
    } else {
        0.0
    }
}

/// `Fox.FaceplantGoal`: stay put for 40 ticks with the nose in the snow.
#[derive(Clone, Debug)]
struct Faceplant {
    countdown: i32,
}
impl Goal for Faceplant {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK | JUMP
    }
    fn can_use(&mut self, m: &mut Mob, _: &mut Cx) -> bool {
        flag(m, FACEPLANTED)
    }
    fn can_continue(&mut self, m: &mut Mob, _: &mut Cx) -> bool {
        flag(m, FACEPLANTED) && self.countdown > 0
    }
    fn start(&mut self, _: &mut Mob, _: &mut Cx) {
        self.countdown = reduced(40);
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        set_flag(m, FACEPLANTED, false);
    }
    fn tick(&mut self, _: &mut Mob, _: &mut Cx) {
        self.countdown -= 1;
    }
}

/// `Fox.StalkPreyGoal`: creep up on a chicken or rabbit more than 6 blocks
/// away, then crouch and keep still once it is within 6.
#[derive(Clone, Debug)]
struct StalkPrey;
impl StalkPrey {
    fn look(m: &mut Mob, eye: [f64; 3]) {
        let (y, x) = (m.kind.max_head_y_rot, m.kind.max_head_x_rot);
        m.look_at_speed(eye, y, x);
    }
}
impl Goal for StalkPrey {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if flag(m, SLEEPING) {
            return false;
        }
        let Some(t) = m.target_info(cx.w) else {
            return false;
        };
        let stalkable = match m.ai.target {
            Some(super::Who::Mob(id)) => {
                cx.w.seen(id)
                    .is_some_and(|s| matches!(s.species, Species::Chicken | Species::Rabbit))
            }
            _ => false,
        };
        t.alive
            && stalkable
            && m.distance_sqr(t.position) > 36.0
            && !flag(m, CROUCHING | INTERESTED)
            && !m.ai.jumping
    }
    fn start(&mut self, m: &mut Mob, _: &mut Cx) {
        set_flag(m, SITTING | FACEPLANTED, false);
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        match m.target_info(cx.w) {
            Some(t) if path_clear(m, cx.w, t.position) => {
                set_flag(m, INTERESTED | CROUCHING, true);
                m.nav_stop();
                Self::look(m, [t.position.x, t.eye_y, t.position.z]);
            }
            _ => set_flag(m, INTERESTED | CROUCHING, false),
        }
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let Some(t) = m.target_info(cx.w) else { return };
        Self::look(m, [t.position.x, t.eye_y, t.position.z]);
        if m.distance_sqr(t.position) <= 36.0 {
            set_flag(m, INTERESTED | CROUCHING, true);
            m.nav_stop();
        } else {
            let at = [t.position.x, t.position.y, t.position.z];
            m.nav_move_to_entity(cx.w, at, 0, 1.5);
        }
    }
}

/// `Fox.FoxPounceGoal`: once fully crouched with a clear path, leap at the
/// target, tilt with the flight and bite when within 2 blocks, or end up with
/// the nose in snow.
#[derive(Clone, Debug)]
struct Pounce;
impl Goal for Pounce {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | JUMP
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !fully_crouched(m) {
            return false;
        }
        let Some(t) = m.target_info(cx.w).filter(|t| t.alive) else {
            return false;
        };
        let clear = path_clear(m, cx.w, t.position);
        if !clear {
            set_flag(m, CROUCHING | INTERESTED, false);
        }
        clear
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if !m.target_info(cx.w).is_some_and(|t| t.alive) {
            return false;
        }
        let yd = m.velocity.y;
        (yd * yd >= f64::from(0.05f32) || m.head_pitch.abs() >= 15.0 || !m.on_ground)
            && !flag(m, FACEPLANTED)
    }
    fn interruptable(&self) -> bool {
        false
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.ai.jumping = true;
        set_flag(m, POUNCING, true);
        set_flag(m, INTERESTED, false);
        if let Some(t) = m.target_info(cx.w) {
            m.look_at_speed([t.position.x, t.eye_y, t.position.z], 60.0, 30.0);
            let u = m.position.vector_to(t.position).normalize();
            m.velocity = m.velocity.add_vector(Vec3::new(u.x * 0.8, 0.9, u.z * 0.8));
        }
        m.nav_stop();
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        set_flag(m, CROUCHING | INTERESTED | POUNCING, false);
        m.anim.v[CROUCH_AMOUNT] = 0.0;
        m.anim.vo[CROUCH_AMOUNT] = 0.0;
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let target = m.target_info(cx.w);
        if let Some(t) = &target {
            m.look_at_speed([t.position.x, t.eye_y, t.position.z], 60.0, 30.0);
        }
        if !flag(m, FACEPLANTED) {
            let v = m.velocity;
            if v.y * v.y < f64::from(0.03f32) && m.head_pitch != 0.0 {
                m.head_pitch += 0.2 * wrap(-m.head_pitch);
            } else {
                let horizontal = v.horizontal_distance();
                let bias = if m.ai.jumping && v.y > 0.0 { 6.5 } else { 1.0 };
                let y = v.y * bias;
                let len = (horizontal * horizontal + y * y).sqrt();
                if len > f64::from(1.0e-5f32) {
                    let pitch = signum(-y) * jmath::acos(horizontal / len) * 180.0
                        / f64::from(std::f32::consts::PI);
                    m.head_pitch = (pitch as f32 % 360.0).clamp(-90.0, 90.0);
                }
            }
        }
        if let (Some(t), Some(who)) = (&target, m.ai.target)
            && m.distance_sqr(t.position) <= 4.0
        {
            super::ai::do_hurt_target(m, who, cx);
        } else if m.head_pitch > 0.0
            && m.on_ground
            && m.velocity.y as f32 != 0.0
            && cx.w.block_name(
                m.position.x.floor() as i32,
                m.position.y.floor() as i32,
                m.position.z.floor() as i32,
            ) == "minecraft:snow"
        {
            m.head_pitch = 60.0;
            m.ai.target = None;
            set_flag(m, FACEPLANTED, true);
        }
    }
}

/// `Fox.SeekShelterGoal`: by day, or in a thunderstorm, leave open sky for
/// somewhere the sky does not see. Villages are not told apart yet (vanilla
/// stays put in one).
#[derive(Clone, Debug)]
struct SeekShelter {
    speed: f64,
    interval: i32,
    wanted: [f64; 3],
}
impl SeekShelter {
    fn new(speed: f64) -> Self {
        Self {
            speed,
            interval: reduced(100),
            wanted: [0.0; 3],
        }
    }
    fn set_wanted_pos(&mut self, m: &mut Mob, w: &MobWorld) -> bool {
        hide_pos(m, w).is_some_and(|at| {
            self.wanted = at;
            true
        })
    }
}
impl Goal for SeekShelter {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if flag(m, SLEEPING) || m.ai.target.is_some() {
            return false;
        }
        let at = [
            m.position.x.floor() as i32,
            m.position.y.floor() as i32,
            m.position.z.floor() as i32,
        ];
        let sees_sky = cx.w.can_see_sky(at[0], at[1], at[2]);
        if cx.w.thundering && sees_sky {
            self.set_wanted_pos(m, cx.w)
        } else if self.interval > 0 {
            self.interval -= 1;
            false
        } else {
            self.interval = 100;
            cx.w.daylight && sees_sky && self.set_wanted_pos(m, cx.w)
        }
    }
    fn can_continue(&mut self, m: &mut Mob, _: &mut Cx) -> bool {
        !m.ai.nav.is_done()
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        clear_states(m);
        m.nav_move_to(cx.w, self.wanted, self.speed);
    }
}

/// `Fox.PerchAndSearchGoal`: now and then sit down and look around two to
/// four times when nothing is going on.
#[derive(Clone, Debug, Default)]
struct Perch {
    rel: [f64; 2],
    look_time: i32,
    looks_remaining: i32,
}
impl Perch {
    fn reset_look(&mut self, m: &mut Mob) {
        let angle = std::f64::consts::TAU * m.random.next_double();
        self.rel = [angle.cos(), angle.sin()];
        self.look_time = reduced(80 + m.random.next_int_bound(20).unwrap_or(0));
    }
}
impl Goal for Perch {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        m.ai.last_hurt_by.is_none()
            && m.random.next_float() < 0.02
            && !flag(m, SLEEPING)
            && m.ai.target.is_none()
            && m.ai.nav.is_done()
            && !alertable(m, cx.w)
            && !flag(m, POUNCING | CROUCHING)
    }
    fn can_continue(&mut self, _: &mut Mob, _: &mut Cx) -> bool {
        self.looks_remaining > 0
    }
    fn start(&mut self, m: &mut Mob, _: &mut Cx) {
        self.reset_look(m);
        self.looks_remaining = 2 + m.random.next_int_bound(3).unwrap_or(0);
        set_flag(m, SITTING, true);
        m.nav_stop();
    }
    fn stop(&mut self, m: &mut Mob, _: &mut Cx) {
        set_flag(m, SITTING, false);
    }
    fn tick(&mut self, m: &mut Mob, _: &mut Cx) {
        self.look_time -= 1;
        if self.look_time <= 0 {
            self.looks_remaining -= 1;
            self.reset_look(m);
        }
        let at = [
            m.position.x + self.rel[0],
            m.eye_y(),
            m.position.z + self.rel[1],
        ];
        let (y, x) = (m.kind.max_head_y_rot, m.kind.max_head_x_rot);
        m.look_at_speed(at, y, x);
    }
}

/// `BlockState` with one property changed.
fn with_prop(w: &MobWorld, p: [i32; 3], key: &str, value: &str) -> Option<BlockStateId> {
    let mut s = w.registry.state(w.world.block(p[0], p[1], p[2]))?.clone();
    s.properties.insert(key.into(), value.into());
    w.registry.id(&s)
}
/// `FoxEatBerriesGoal.isValidTarget`: a ripe sweet berry bush or glow berries.
fn has_berries(w: &MobWorld, p: [i32; 3]) -> bool {
    match w.block_name(p[0], p[1], p[2]) {
        "minecraft:sweet_berry_bush" => w
            .prop(p[0], p[1], p[2], "age")
            .and_then(|a| a.parse::<i32>().ok())
            .is_some_and(|a| a >= 2),
        "minecraft:cave_vines" | "minecraft:cave_vines_plant" => {
            w.prop(p[0], p[1], p[2], "berries") == Some("true")
        }
        _ => false,
    }
}

/// `Fox.FoxEatBerriesGoal`: walk to a ripe berry bush and pick it after 40 ticks.
#[derive(Clone, Debug)]
struct EatBerries {
    block: MoveToBlock,
    waited: i32,
}
impl EatBerries {
    fn new() -> Self {
        Self {
            block: MoveToBlock::new(1.2, 12, 1),
            waited: 0,
        }
    }
    fn pick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let p = self.block.block;
        let at = [
            f64::from(p[0]) + 0.5,
            f64::from(p[1]) + 0.5,
            f64::from(p[2]) + 0.5,
        ];
        if cx.w.block_name(p[0], p[1], p[2]) == "minecraft:sweet_berry_bush" {
            let age: i32 =
                cx.w.prop(p[0], p[1], p[2], "age")
                    .and_then(|a| a.parse().ok())
                    .unwrap_or(0);
            let mut count = 1 + m.random.next_int_bound(2).unwrap_or(0) + i32::from(age == 3);
            if m.extra.main_hand.is_none() {
                m.extra
                    .set_main_hand(Some("minecraft:sweet_berries".into()));
                count -= 1;
            }
            if count > 0 {
                cx.events.push(MobEvent::DropItem {
                    mob: m.id,
                    item: "minecraft:sweet_berries".into(),
                    count: count as u32,
                    at,
                });
            }
            if let Some(state) = with_prop(cx.w, p, "age", "1") {
                cx.events.push(MobEvent::SetBlock { pos: p, state });
            }
            cx.events.push(MobEvent::Sound(
                "block.sweet_berry_bush.pick_berries",
                at,
                1.0,
                1.0,
            ));
        } else {
            // CaveVines.use: one glow berry, the vine goes back to bare.
            cx.events.push(MobEvent::DropItem {
                mob: m.id,
                item: "minecraft:glow_berries".into(),
                count: 1,
                at,
            });
            if let Some(state) = with_prop(cx.w, p, "berries", "false") {
                cx.events.push(MobEvent::SetBlock { pos: p, state });
            }
            let pitch = 0.8 + m.random.next_float() * 0.4;
            cx.events.push(MobEvent::Sound(
                "block.cave_vines.pick_berries",
                at,
                1.0,
                pitch,
            ));
        }
    }
}
impl Goal for EatBerries {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | JUMP
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if flag(m, SLEEPING) {
            return false;
        }
        // MoveToBlockGoal.canUse draws the next delay only once the last one
        // has run out.
        if self.block.next_start > 0 {
            self.block.next_start -= 1;
            return false;
        }
        let next = reduced(200 + m.random.next_int_bound(200).unwrap_or(0));
        self.block.can_use(m, cx.w, next, has_berries)
    }
    fn can_continue(&mut self, _: &mut Mob, cx: &mut Cx) -> bool {
        self.block.can_continue(cx.w, has_berries)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.waited = 0;
        set_flag(m, SITTING, false);
        self.block.start(m, cx.w);
    }
    fn every_tick(&self) -> bool {
        true
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        if self.block.reached {
            if self.waited >= 40 {
                if cx.w.mob_griefing {
                    self.pick(m, cx);
                }
            } else {
                self.waited += 1;
            }
        } else if m.random.next_float() < 0.05 {
            let at = [m.position.x, m.position.y, m.position.z];
            cx.events
                .push(MobEvent::Sound("entity.fox.sniff", at, 1.0, 1.0));
        }
        self.block.tick_within(m, cx.w, 2.0);
    }
}

/// `FoxRenderState` as the renderer reads it: the flags, `getHeadRollAngle`
/// and `getCrouchAmount` at the partial tick. `FoxModel.legMotionPos` gains
/// 0.67 a frame; this takes 60 frames a second.
pub fn pose(m: &Mob, partial: f32) -> super::body_anim::Fox {
    super::body_anim::Fox {
        crouching: flag(m, CROUCHING),
        sleeping: flag(m, SLEEPING),
        sitting: flag(m, SITTING),
        pouncing: flag(m, POUNCING),
        faceplanted: flag(m, FACEPLANTED),
        head_roll_angle: m.anim.lerp(INTERESTED_ANGLE, partial) * 0.11 * std::f32::consts::PI,
        crouch_amount: m.anim.lerp(CROUCH_AMOUNT, partial),
        leg_motion_pos: (m.age as f32 + partial) * 0.67 * 3.0,
    }
}

#[cfg(test)]
mod trust_tests {
    use super::*;
    use crate::mobs::sensor_scan_tests::kind;

    fn fox() -> Mob {
        let mut kind = kind();
        let k = std::sync::Arc::make_mut(&mut kind);
        k.id = "minecraft:fox".into();
        k.species = Species::Fox;
        Mob::new(1, kind, Vec3::ZERO, 0.0)
    }

    /// `Fox.addTrustedEntity`: the first free slot, then the second, and a
    /// third player replaces the second (`DATA_TRUSTED_ID_0/1`).
    #[test]
    fn a_fox_trusts_two_players_and_the_third_replaces_the_second() {
        const A: [i32; 4] = [1, 2, 3, 4];
        const B: [i32; 4] = [5, 6, 7, 8];
        const C: [i32; 4] = [9, 10, 11, 12];
        let mut f = fox();
        assert!(!trusts(&f, A), "a fresh fox trusts nobody");
        add_trusted_entity(&mut f, A);
        add_trusted_entity(&mut f, B);
        assert!(trusts(&f, A) && trusts(&f, B));
        add_trusted_entity(&mut f, C);
        assert!(trusts(&f, A), "the first slot stays");
        assert!(!trusts(&f, B) && trusts(&f, C), "the second is replaced");
        assert_eq!(trusted_entities(&f).collect::<Vec<_>>(), vec![A, C]);
        clear_trusted(&mut f);
        assert_eq!(trusted_entities(&f).count(), 0);
        assert!(!trusts(&f, A));
    }
}

#[cfg(test)]
mod trust_breed_tests {
    use super::*;
    use crate::mobs::sensor_scan_tests::kind;

    fn fox() -> Mob {
        let mut kind = kind();
        let k = std::sync::Arc::make_mut(&mut kind);
        k.id = "minecraft:fox".into();
        k.species = Species::Fox;
        Mob::new(1, kind, Vec3::ZERO, 0.0)
    }

    /// `Fox.FoxBreedGoal.breed`: the baby trusts both players who fed the
    /// parents into love, and one of them only once when it is the same.
    #[test]
    fn a_baby_fox_trusts_both_players_who_fed_its_parents() {
        const A: [i32; 4] = [1, 2, 3, 4];
        const B: [i32; 4] = [5, 6, 7, 8];
        let mut baby = fox();
        trust_breeders(&mut baby, Some(A), Some(B));
        assert_eq!(trusted_entities(&baby).collect::<Vec<_>>(), vec![A, B]);
        let mut same = fox();
        trust_breeders(&mut same, Some(A), Some(A));
        assert_eq!(trusted_entities(&same).collect::<Vec<_>>(), vec![A]);
        let mut one = fox();
        trust_breeders(&mut one, Some(A), None);
        assert_eq!(trusted_entities(&one).collect::<Vec<_>>(), vec![A]);
        let mut none = fox();
        trust_breeders(&mut none, None, None);
        assert_eq!(trusted_entities(&none).count(), 0);
    }
}

/// Where the first item a fox may pick up lies within 8 blocks (`Fox.ALLOWED_ITEMS`:
/// no pickup delay, alive), found by the game each tick for `FoxSearchForItemsGoal`.
pub fn set_item_at(m: &mut Mob, at: Option<[f64; 3]>) {
    m.extra.point = at;
}
/// `Fox.canHoldItem`: an empty mouth, or food to swap for what is not food once it has
/// eaten at all. `food` says whether `item` and the held item are consumable food.
pub fn can_hold_item(m: &Mob, item_is_food: bool, held_is_food: bool) -> bool {
    m.extra.main_hand.is_none()
        || (m.extra.ints[TICKS_SINCE_EATEN] > 0 && item_is_food && !held_is_food)
}
/// `Fox.pickUpItem` after the swap: it has taken the item (`ticksSinceEaten = 0`).
pub fn took_item(m: &mut Mob) {
    m.extra.ints[TICKS_SINCE_EATEN] = 0;
}
/// `Fox.FoxSearchForItemsGoal`: walk to a dropped item while the mouth is empty.
#[derive(Clone, Debug)]
struct SearchForItems;
impl Goal for SearchForItems {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE
    }
    fn can_use(&mut self, m: &mut Mob, _cx: &mut Cx) -> bool {
        if m.extra.main_hand.is_some() {
            return false;
        }
        if m.ai.target.is_some() || m.ai.last_hurt_by.is_some() {
            return false;
        }
        if !can_move(m) {
            return false;
        }
        if m.random.next_int_bound(reduced(10)).unwrap_or(0) != 0 {
            return false;
        }
        m.extra.point.is_some() && m.extra.main_hand.is_none()
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        if let Some(at) = m.extra.point {
            m.nav_move_to_entity(cx.w, at, 0, f64::from(1.2_f32));
        }
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        if m.extra.main_hand.is_none()
            && let Some(at) = m.extra.point
        {
            m.nav_move_to_entity(cx.w, at, 0, f64::from(1.2_f32));
        }
    }
}

#[cfg(test)]
mod pickup_tests {
    use super::*;
    use crate::mobs::sensor_scan_tests::kind;

    fn fox() -> Mob {
        let mut kind = kind();
        let k = std::sync::Arc::make_mut(&mut kind);
        k.id = "minecraft:fox".into();
        k.species = Species::Fox;
        Mob::new(1, kind, Vec3::ZERO, 0.0)
    }

    /// `Fox.canHoldItem`: an empty mouth takes anything; a full one only swaps its non-food
    /// for food, and only once the fox has had ticks since it last ate.
    #[test]
    fn a_fox_holds_what_its_mouth_has_room_for() {
        let mut f = fox();
        assert!(
            can_hold_item(&f, false, false),
            "an empty mouth takes any item"
        );
        f.extra.set_main_hand(Some("minecraft:stick".into()));
        f.extra.ints[TICKS_SINCE_EATEN] = 0;
        assert!(
            !can_hold_item(&f, true, false),
            "no food swap at 0 ticks since eating"
        );
        f.extra.ints[TICKS_SINCE_EATEN] = 1;
        assert!(can_hold_item(&f, true, false), "food replaces a stick");
        assert!(
            !can_hold_item(&f, false, false),
            "a stick does not replace a stick"
        );
        assert!(!can_hold_item(&f, true, true), "food does not replace food");
        took_item(&mut f);
        assert_eq!(
            f.extra.ints[TICKS_SINCE_EATEN], 0,
            "taking an item restarts the clock"
        );
    }
}

#[cfg(test)]
mod consume_tests {
    use super::*;
    use crate::mobs::world::with_built_test_world;

    /// `Item.finishUsingItem` → `Consumable.onConsume`: a fox that finishes a
    /// chorus fruit takes `TeleportRandomlyConsumeEffect`'s teleport, with its
    /// own sound and the portal trail (level event 2017).
    #[test]
    fn a_chorus_fruit_carries_the_fox_to_free_ground() {
        let ran = with_built_test_world(
            &[],
            |world, registry| {
                for (cx, cz) in [
                    (-1, -1),
                    (-1, 0),
                    (-1, 1),
                    (0, -1),
                    (0, 0),
                    (0, 1),
                    (1, -1),
                    (1, 0),
                    (1, 1),
                ] {
                    world.chunks.insert(
                        (cx, cz),
                        std::sync::Arc::new(crate::chunk::Chunk::empty(cx, cz)),
                    );
                }
                let stone = registry.default_state("minecraft:stone").unwrap();
                for x in -16..32 {
                    for z in -16..32 {
                        world.set(x, 0, z, stone).unwrap();
                    }
                }
            },
            |w, types| {
                let kind = std::sync::Arc::new(types.types["minecraft:fox"].clone());
                let mut m = Mob::new(1, kind, Vec3::new(0.5, 1.0, 0.5), 0.0);
                m.on_ground = true;
                m.extra.set_main_hand(Some("minecraft:chorus_fruit".into()));
                // Past the 600 ticks `Fox.aiStep` waits before it finishes the item.
                m.extra.ints[TICKS_SINCE_EATEN] = 601;
                let mut events = Vec::new();
                ai_step(&mut m, w, &mut events);
                assert_ne!(m.position, Vec3::new(0.5, 1.0, 0.5), "the fruit moved it");
                // `Entity.randomTeleport` drops the drawn height by one per
                // step until the block below it is ground: just above the stone.
                assert!(
                    (1.0..2.0).contains(&m.position.y),
                    "it stands on the stone floor, got {}",
                    m.position.y
                );
                assert_eq!(m.extra.main_hand, None, "the fruit was eaten");
                assert_eq!(m.extra.ints[TICKS_SINCE_EATEN], 0);
                assert!(
                    events
                        .iter()
                        .any(|e| matches!(e, MobEvent::Sound("entity.fox.teleport", ..))),
                    "the fox's teleport sound: {events:?}"
                );
                assert!(
                    events
                        .iter()
                        .any(|e| matches!(e, MobEvent::LevelEvent { id: 2017, .. })),
                    "the portal trail: {events:?}"
                );
                assert!(
                    events
                        .iter()
                        .any(|e| matches!(e, MobEvent::EntityEvent { event: 46, .. })),
                    "entity event 46: {events:?}"
                );
            },
        );
        // Without the vanilla data under .local/horizon-client (CI's unit
        // tests) there is no fox to feed: the test has nothing to check.
        let _ = ran;
    }
}
