//! Model animation: ports of each vanilla `EntityModel.setupAnim` family
//! (quadrupeds, humanoids, creepers, spiders, chickens...) applied to a map of
//! part poses before the model is drawn.
use super::{Mob, Part, keyframes::AnimationState, living::wrap};
use crate::fast_hash::{FxHashMap, FxHashSet};
use horizon_core::geometry::trig::Mth;
use std::collections::HashMap;
use std::f32::consts::{FRAC_PI_6, PI};

/// The setupAnim implementation a model uses.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Anim {
    Nautilus,
    HappyGhast,
    Sniffer,
    Breeze,
    Warden,
    Allay,
    Creaking,
    Camel,
    Wither,
    Vex,
    Ravager,
    Guardian,
    Shulker,
    Quadruped,
    Sheep,
    Chicken,
    Zombie,
    Drowned,
    ZombieVillager,
    Skeleton,
    Creeper,
    Spider,
    Enderman,
    Silverfish,
    Slime,
    MagmaCube,
    Witch,
    Villager,
    IronGolem,
    SnowGolem,
    CopperGolem,
    Illager,
    Piglin,
    ZombifiedPiglin,
    Hoglin,
    Wolf,
    Feline,
    Fox,
    Rabbit,
    Horse,
    Llama,
    Goat,
    Panda,
    PolarBear,
    Parrot,
    Bee,
    Turtle,
    Armadillo,
    Frog,
    Axolotl,
    Squid,
    Fish,
    Pufferfish,
    Dolphin,
    Bat,
    Phantom,
    Ghast,
    Blaze,
    Strider,
    /// The humanoid model of the earlier simple renderer.
    Humanoid {
        zombie_arms: bool,
    },
}
/// Client-side animation clocks advanced each tick.
#[derive(Clone, Debug, Default)]
pub struct AnimState {
    pub attack_anim: f32,
    pub attack_anim_o: f32,
    pub flap: f32,
    pub flap_o: f32,
    pub flap_speed: f32,
    pub flap_speed_o: f32,
    pub flapping: f32,
    /// Generic per-species keyframe animation states.
    pub states: [AnimationState; 6],
    /// Per-species animation values (tail wag, squid tentacles, squish...)
    /// with their previous-tick copies for interpolation.
    pub v: [f32; 8],
    pub vo: [f32; 8],
}
impl AnimState {
    pub fn begin_tick(&mut self) {
        self.attack_anim_o = self.attack_anim;
        self.vo = self.v;
    }
    /// Interpolated value `i` at the render partial tick.
    pub fn lerp(&self, i: usize, partial: f32) -> f32 {
        self.vo[i] + (self.v[i] - self.vo[i]) * partial
    }
    pub fn end_tick(&mut self, _swinging: bool) {}
}
/// A part name as `Poses` keys it: its Fx hash, so filling a pose map allocates
/// nothing (a mob farm resets one per layer per mob each frame). Names are short
/// and few per model; `no_two_part_names_share_a_key` checks every vanilla model.
#[inline]
pub(crate) fn key(name: &str) -> u64 {
    use std::hash::Hasher;
    let mut h = crate::fast_hash::FxHasher::default();
    h.write(name.as_bytes());
    // The length too, so "a" and "a\0" differ (str's own Hash adds a terminator).
    h.write_usize(name.len());
    h.finish()
}
/// Part poses for one draw, keyed by part name.
#[derive(Clone, Default)]
pub struct Poses {
    map: FxHashMap<u64, [f32; 9]>,
    dummy: [f32; 9],
    /// Parts with `skipDraw` set: their own cubes are not drawn, children are.
    skipped: FxHashSet<u64>,
    /// Parts with `visible` cleared: neither they nor their children draw.
    hidden: FxHashSet<u64>,
    /// Names this content: a fresh number at each change, kept by copies
    /// ([`Poses::version`]).
    version: u64,
}
/// The next [`Poses::version`].
static NEXT_VERSION: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
thread_local! {
    /// Spare `Poses` for [`Poses::pooled`].
    static POOL: std::cell::RefCell<Vec<Poses>> = const { std::cell::RefCell::new(Vec::new()) };
}
/// A [`Poses`] from this thread's pool, given back when dropped.
pub struct PooledPoses(Poses);
impl std::ops::Deref for PooledPoses {
    type Target = Poses;
    fn deref(&self) -> &Poses {
        &self.0
    }
}
impl std::ops::DerefMut for PooledPoses {
    fn deref_mut(&mut self) -> &mut Poses {
        &mut self.0
    }
}
impl Drop for PooledPoses {
    fn drop(&mut self) {
        let poses = std::mem::take(&mut self.0);
        // A few per thread: a mob's body and layers, a rider's.
        let _ = POOL.try_with(|pool| {
            let mut pool = pool.borrow_mut();
            if pool.len() < 8 {
                pool.push(poses);
            }
        });
    }
}
impl Poses {
    pub fn new(model: &Part) -> Self {
        let mut poses = Self::default();
        poses.reset(model);
        poses
    }
    /// Spare `Poses` of an earlier draw on this thread, to fill with `reset` or
    /// `copy_from` before use: a mob farm poses every mob each frame, and fresh
    /// maps grow (and rehash) part by part.
    pub fn pooled() -> PooledPoses {
        PooledPoses(
            POOL.try_with(|pool| pool.borrow_mut().pop())
                .ok()
                .flatten()
                .unwrap_or_default(),
        )
    }
    /// Names the content: two `Poses` with the same version pose every part
    /// alike (one is a copy of the other, neither changed since). A draw of
    /// the same model under the same matrix with the same version can reuse
    /// the first's part matrices (`skin::Skin::draw`).
    pub fn version(&self) -> u64 {
        self.version
    }
    fn changed(&mut self) {
        self.version = NEXT_VERSION.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    }
    /// Makes this a copy of `other`, keeping this one's capacity.
    pub fn copy_from(&mut self, other: &Poses) {
        self.map.clone_from(&other.map);
        self.dummy = other.dummy;
        self.skipped.clone_from(&other.skipped);
        self.hidden.clone_from(&other.hidden);
        self.version = other.version;
    }
    /// Refills this for another model, keeping the map and the sets' capacity:
    /// a mob draws its body and every equipment layer each frame.
    pub fn reset(&mut self, model: &Part) {
        fn walk(p: &Part, map: &mut FxHashMap<u64, [f32; 9]>) {
            // ModelPart.createPartLookup fills its map with putIfAbsent: the first part keeps a name.
            map.entry(key(&p.name)).or_insert(p.pose);
            for c in &p.children {
                walk(c, map);
            }
        }
        self.map.clear();
        self.dummy = [0.0; 9];
        self.skipped.clear();
        self.hidden.clear();
        walk(model, &mut self.map);
        self.changed();
    }
    pub fn get(&mut self, name: &str) -> &mut [f32; 9] {
        self.changed();
        match self.map.get_mut(&key(name)) {
            Some(p) => p,
            None => &mut self.dummy,
        }
    }
    pub fn pose(&self, part: &Part) -> [f32; 9] {
        self.map.get(&key(&part.name)).copied().unwrap_or(part.pose)
    }
    pub fn skip_draw(&mut self, name: &str) {
        if self.skipped.insert(key(name)) {
            self.changed();
        }
    }
    pub fn skips(&self, part: &Part) -> bool {
        self.skips_named(&part.name)
    }
    /// `skips` by the part's name.
    pub fn skips_named(&self, name: &str) -> bool {
        !self.skipped.is_empty() && self.skipped.contains(&key(name))
    }
    pub fn has(&self, name: &str) -> bool {
        self.map.contains_key(&key(name))
    }
    pub fn xrot(&mut self, n: &str, v: f32) {
        self.get(n)[3] = v;
    }
    pub fn yrot(&mut self, n: &str, v: f32) {
        self.get(n)[4] = v;
    }
    pub fn zrot(&mut self, n: &str, v: f32) {
        self.get(n)[5] = v;
    }
    /// `ModelPart.visible = v`; a hidden part and its children do not draw.
    pub fn visible(&mut self, n: &str, v: bool) {
        let changed = if v {
            self.hidden.remove(&key(n))
        } else {
            self.map.contains_key(&key(n)) && self.hidden.insert(key(n))
        };
        if changed {
            self.changed();
        }
    }
    pub fn is_hidden(&self, part: &Part) -> bool {
        self.is_hidden_named(&part.name)
    }
    /// `is_hidden` by the part's name.
    pub fn is_hidden_named(&self, name: &str) -> bool {
        !self.hidden.is_empty() && self.hidden.contains(&key(name))
    }
}
/// The LivingEntityRenderState values setupAnim reads.
#[derive(Clone, Copy, Debug)]
pub struct State {
    pub pos: f32,
    pub speed: f32,
    pub age: f32,
    /// Head yaw relative to the body, degrees.
    pub y_rot: f32,
    /// Head pitch, degrees.
    pub x_rot: f32,
    pub swing: f32,
    pub baby: bool,
    pub partial: f32,
}
/// `WalkAnimationState.position(partial)`: babies' legs move 3 times as far.
pub fn walk_position(m: &Mob, alpha: f32) -> f32 {
    (m.limb_position - m.limb_speed * (1.0 - alpha)) * if m.is_baby() { 3.0 } else { 1.0 }
}
pub fn state(m: &Mob, alpha: f32) -> State {
    let body = m.previous_body_yaw + wrap(m.body_yaw - m.previous_body_yaw) * alpha;
    let head = m.previous_head_yaw + wrap(m.head_yaw - m.previous_head_yaw) * alpha;
    let mut swing = m.anim.attack_anim - m.anim.attack_anim_o;
    if swing < 0.0 {
        swing += 1.0;
    }
    let swing = m.anim.attack_anim_o + swing * alpha;
    // LivingEntityRenderer.extractRenderState: riding motion is not walking.
    let walking = m.alive() && !m.extra.passenger;
    State {
        pos: if walking {
            walk_position(m, alpha)
        } else {
            0.0
        },
        speed: if walking {
            (m.previous_limb_speed + (m.limb_speed - m.previous_limb_speed) * alpha).min(1.0)
        } else {
            0.0
        },
        age: m.age as f32 + alpha,
        y_rot: wrap(head - body),
        x_rot: m.previous_head_pitch + (m.head_pitch - m.previous_head_pitch) * alpha,
        swing,
        baby: m.is_baby(),
        partial: alpha,
    }
}
fn head(p: &mut Poses, s: &State) {
    p.xrot("head", s.x_rot.to_radians());
    p.yrot("head", s.y_rot.to_radians());
}
/// QuadrupedModel.setupAnim
pub(super) fn quadruped(p: &mut Poses, s: &State) {
    head(p, s);
    let (pos, sp) = (s.pos, s.speed);
    p.xrot("right_hind_leg", (pos * 0.6662).mcos() * 1.4 * sp);
    p.xrot("left_hind_leg", (pos * 0.6662 + PI).mcos() * 1.4 * sp);
    p.xrot("right_front_leg", (pos * 0.6662 + PI).mcos() * 1.4 * sp);
    p.xrot("left_front_leg", (pos * 0.6662).mcos() * 1.4 * sp);
}
/// AnimationUtils.bobModelPart
fn bob(p: &mut Poses, n: &str, age: f32, scale: f32) {
    let q = p.get(n);
    q[5] += scale * ((age * 0.09).mcos() * 0.05 + 0.05);
    q[3] += scale * ((age * 0.067).msin() * 0.05);
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ArmPose {
    Empty,
    Item,
    Block,
    Bow,
    CrossbowHold,
    CrossbowCharge,
    /// Raising a trident to throw it (or to launch with Riptide).
    ThrowTrident,
    /// Playing a goat horn.
    TootHorn,
    /// Looking through a spyglass (`HumanoidModel.ArmPose.SPYGLASS`).
    Spyglass,
    /// A spear held out (`HumanoidModel.ArmPose.SPEAR`), at rest or charging.
    Spear,
    /// A brush being used (`HumanoidModel.ArmPose.BRUSH`).
    Brush,
}
/// HumanoidModel.setupAnim with empty hands (endermen).
/// Passes `isPassenger` so a seated enderman keeps the humanoid riding pose
/// (vanilla EndermanModel.setupAnim calls super first, then halves/clamps xRot).
pub fn humanoid_pub(p: &mut Poses, s: &State, m: &Mob) {
    let mut h = Hum::new(ArmPose::Empty, ArmPose::Empty);
    h.passenger = m.extra.passenger;
    humanoid(p, s, &h);
}
/// `AnimationUtils.swingWeaponDown`: the main arm swings down, the other
/// one hangs and bobs.
pub(super) fn swing_weapon_down(p: &mut Poses, swing: f32, age: f32, left_main: bool) {
    let attack2 = (swing * PI).msin();
    let attack = ((1.0 - (1.0 - swing) * (1.0 - swing)) * PI).msin();
    let (main, off) = if left_main {
        ("left_arm", "right_arm")
    } else {
        ("right_arm", "left_arm")
    };
    p.zrot("right_arm", 0.0);
    p.zrot("left_arm", 0.0);
    p.yrot("right_arm", PI / 20.0);
    p.yrot("left_arm", -PI / 20.0);
    p.xrot(main, -1.884_955_8 + (age * 0.09).mcos() * 0.15);
    p.xrot(off, -0.0 + (age * 0.19).mcos() * 0.5);
    p.get(main)[3] += attack2 * 2.2 - attack * 0.4;
    p.get(off)[3] += attack2 * 1.2 - attack * 0.4;
    bob(p, "right_arm", age, 1.0);
    bob(p, "left_arm", age, -1.0);
}
/// What `HumanoidModel.setupAnim` reads besides the walk and head inputs.
#[derive(Clone, Copy, Debug)]
pub struct Hum {
    pub right: ArmPose,
    pub left: ArmPose,
    pub crouching: bool,
    pub passenger: bool,
    pub fall_flying: bool,
    pub fly_speed_scale: f32,
    /// `Some(aggressive)` for `ZombieModel`-style `animateZombieArms`.
    pub zombie: Option<bool>,
    /// The main hand holds something (`getMainHandItemStack() != EMPTY`).
    pub holding: bool,
    /// `maxCrossbowChargeDuration`, `ticksUsingItem`.
    pub charge: (f32, f32),
    /// `PiglinModel.setupAttackAnimation`: swing a held weapon down.
    pub weapon_swing: bool,
    /// `swimAmount` at this frame.
    pub swim: f32,
    /// `isUsingItem`: the swim stroke leaves the arms alone.
    pub using_item: bool,
    /// The arm the current swing moves (`Some(true)` for the right one).
    pub swing_right_arm: Option<bool>,
    /// The swing is a STAB (`SwingAnimationType` 2): a spear's jab.
    pub stab: bool,
    /// `mainArm` is the left one (`Mob.isLeftHanded`): a mob's swing uses it.
    pub left_main: bool,
    /// The spear each arm (right, left) holds, and how long that arm has
    /// been using it (`ticksUsingItem(arm)`, 0 when it is not).
    pub spear: [Option<crate::spear::Kinetic>; 2],
    pub spear_ticks: [f32; 2],
}
impl Hum {
    pub fn new(right: ArmPose, left: ArmPose) -> Self {
        Self {
            right,
            left,
            crouching: false,
            passenger: false,
            fall_flying: false,
            fly_speed_scale: 1.0,
            zombie: None,
            holding: false,
            charge: (0.0, 0.0),
            weapon_swing: false,
            swim: 0.0,
            using_item: false,
            swing_right_arm: None,
            stab: false,
            left_main: false,
            spear: [None; 2],
            spear_ticks: [0.0; 2],
        }
    }
}
impl ArmPose {
    fn two_handed(self) -> bool {
        matches!(self, Self::Bow | Self::CrossbowHold | Self::CrossbowCharge)
    }
    fn affects_offhand(self) -> bool {
        self.two_handed() || self == Self::ThrowTrident
    }
}
/// `AnimationUtils.animateCrossbowHold`.
pub(super) fn crossbow_hold(p: &mut Poses, hx: f32, hy: f32, in_right: bool) {
    let (hold, shoot) = if in_right {
        ("right_arm", "left_arm")
    } else {
        ("left_arm", "right_arm")
    };
    p.yrot(hold, if in_right { -0.3 } else { 0.3 } + hy);
    p.yrot(shoot, if in_right { 0.6 } else { -0.6 } + hy);
    p.xrot(hold, -PI / 2.0 + hx + 0.1);
    p.xrot(shoot, -1.5 + hx);
}
/// `AnimationUtils.animateCrossbowCharge`.
pub(super) fn crossbow_charge(p: &mut Poses, max: f32, ticks: f32, in_right: bool) {
    let (hold, pull) = if in_right {
        ("right_arm", "left_arm")
    } else {
        ("left_arm", "right_arm")
    };
    p.yrot(hold, if in_right { -0.8 } else { 0.8 });
    p.xrot(hold, -0.970_796_35);
    p.xrot(pull, -0.970_796_35);
    let use_ticks = ticks.clamp(0.0, max);
    let alpha = use_ticks / max;
    let lerp = |a: f32, p0: f32, p1: f32| p0 + a * (p1 - p0);
    p.yrot(
        pull,
        lerp(alpha, 0.4, 0.85) * if in_right { 1.0 } else { -1.0 },
    );
    let x = lerp(alpha, p.get(pull)[3], -PI / 2.0);
    p.xrot(pull, x);
}
/// `HumanoidModel.SPYGLASS_ARM_ROT_X`.
const SPYGLASS_ARM_ROT_X: f32 = 1.919_862_2;
/// `HumanoidModel.poseRightArm` / `poseLeftArm`.
fn pose_arm(p: &mut Poses, pose: ArmPose, right: bool, h: &Hum) {
    let arm = if right { "right_arm" } else { "left_arm" };
    let (hx, hy) = (p.get("head")[3], p.get("head")[4]);
    match pose {
        ArmPose::Empty => p.yrot(arm, 0.0),
        ArmPose::Item => {
            let x = p.get(arm)[3];
            p.xrot(arm, x * 0.5 - PI / 10.0);
            p.yrot(arm, 0.0);
        }
        // Vanilla's BRUSH case: the ITEM pose with twice the drop.
        ArmPose::Brush => {
            let x = p.get(arm)[3];
            p.xrot(arm, x * 0.5 - PI / 5.0);
            p.yrot(arm, 0.0);
        }
        ArmPose::Block => {
            let x = p.get(arm)[3] * 0.5 - 0.942_477_9 + hx.clamp(-1.396_263_4, 0.436_332_32);
            p.xrot(arm, x);
            p.yrot(
                arm,
                if right { -FRAC_PI_6 } else { FRAC_PI_6 } + hy.clamp(-FRAC_PI_6, FRAC_PI_6),
            );
        }
        ArmPose::Bow => {
            p.yrot("right_arm", -0.1 + hy - if right { 0.0 } else { 0.4 });
            p.yrot("left_arm", 0.1 + hy + if right { 0.4 } else { 0.0 });
            p.xrot("right_arm", -PI / 2.0 + hx);
            p.xrot("left_arm", -PI / 2.0 + hx);
        }
        ArmPose::ThrowTrident => {
            let x = p.get(arm)[3];
            p.xrot(arm, x * 0.5 - PI);
            p.yrot(arm, 0.0);
        }
        ArmPose::Spyglass => {
            let crouch = if h.crouching { 0.261_799_4 } else { 0.0 };
            p.xrot(arm, (hx - SPYGLASS_ARM_ROT_X - crouch).clamp(-2.4, 3.3));
            p.yrot(arm, hy + if right { -0.261_799_4 } else { 0.261_799_4 });
        }
        ArmPose::TootHorn => {
            p.xrot(arm, hx.clamp(-1.2, 1.2) - 1.483_529_8);
            p.yrot(arm, hy + if right { -FRAC_PI_6 } else { FRAC_PI_6 });
        }
        ArmPose::CrossbowHold => crossbow_hold(p, hx, hy, right),
        ArmPose::CrossbowCharge => crossbow_charge(p, h.charge.0, h.charge.1, right),
        // SpearAnimations.thirdPersonHandUse.
        ArmPose::Spear => {
            let side = usize::from(!right);
            let Some(kinetic) = h.spear[side] else {
                return;
            };
            let (x, y, z) = crate::spear::third_person_arm(
                &kinetic,
                h.spear_ticks[side],
                right,
                (hx, hy),
                h.fall_flying || h.swim > 0.0,
            );
            p.xrot(arm, x);
            p.yrot(arm, y);
            p.get(arm)[5] += z;
        }
    }
}
/// `HumanoidModel.setupAnim` (and `ZombieModel.setupAttackAnimation`).
pub(super) fn humanoid(p: &mut Poses, s: &State, h: &Hum) {
    head(p, s);
    if h.fall_flying {
        p.xrot("head", -std::f32::consts::FRAC_PI_4);
    }
    let (pos, sp) = (s.pos, s.speed / h.fly_speed_scale);
    p.xrot("right_arm", (pos * 0.6662 + PI).mcos() * 2.0 * sp * 0.5);
    p.xrot("left_arm", (pos * 0.6662).mcos() * 2.0 * sp * 0.5);
    p.xrot("right_leg", (pos * 0.6662).mcos() * 1.4 * sp);
    p.xrot("left_leg", (pos * 0.6662 + PI).mcos() * 1.4 * sp);
    p.yrot("right_leg", 0.005);
    p.yrot("left_leg", -0.005);
    p.zrot("right_leg", 0.005);
    p.zrot("left_leg", -0.005);
    if h.passenger {
        p.get("right_arm")[3] += -PI / 5.0;
        p.get("left_arm")[3] += -PI / 5.0;
        p.xrot("right_leg", -1.413_716_7);
        p.yrot("right_leg", PI / 10.0);
        p.zrot("right_leg", 0.078_539_82);
        p.xrot("left_leg", -1.413_716_7);
        p.yrot("left_leg", -PI / 10.0);
        p.zrot("left_leg", -0.078_539_82);
    }
    // The main arm is the right one: the off-hand pose goes first unless it
    // needs both hands.
    if h.left.two_handed() {
        pose_arm(p, h.right, true, h);
        if !h.right.affects_offhand() {
            pose_arm(p, h.left, false, h);
        }
    } else {
        pose_arm(p, h.left, false, h);
        if !h.left.affects_offhand() {
            pose_arm(p, h.right, true, h);
        }
    }
    // setupAttackAnimation: a WHACK or STAB swing of the swinging hand's arm.
    let hx = p.get("head")[3];
    let swing = s.swing;
    let swing_left = h.swing_right_arm.map_or(h.left_main, |right| !right);
    if swing > 0.0 && h.weapon_swing {
        swing_weapon_down(p, swing, s.age, h.left_main);
    } else if swing > 0.0 {
        let mut body_y = (swing.sqrt() * PI * 2.0).msin() * 0.2;
        if swing_left {
            body_y = -body_y;
        }
        p.yrot("body", body_y);
        let age_scale = if s.baby { 0.5 } else { 1.0 };
        {
            let r = p.get("right_arm");
            r[2] = body_y.msin() * 5.0 * age_scale;
            r[0] = -body_y.mcos() * 5.0 * age_scale;
        }
        {
            let l = p.get("left_arm");
            l[2] = -body_y.msin() * 5.0 * age_scale;
            l[0] = body_y.mcos() * 5.0 * age_scale;
        }
        let arm = if swing_left { "left_arm" } else { "right_arm" };
        if h.stab {
            // SpearAnimations.thirdPersonAttackHand: the arms keep their turn.
            p.get(arm)[3] += crate::spear::third_person_attack_arm(swing);
        } else {
            p.get("right_arm")[4] += body_y;
            p.get("left_arm")[4] += body_y;
            p.get("left_arm")[3] += body_y;
            // Ease.outQuart
            let eased = 1.0 - (1.0 - swing).powi(4);
            let aa = (eased * PI).msin();
            let bb = (swing * PI).msin() * -(hx - 0.7) * 0.75;
            let r = p.get(arm);
            r[3] -= aa * 1.2 + bb;
            r[4] += body_y * 2.0;
            r[5] += (swing * PI).msin() * -0.4;
        }
    }
    // AnimationUtils.animateZombieArms leaves the arms of a spear alone.
    let using_spear = h.right == ArmPose::Spear || h.left == ArmPose::Spear;
    if let Some(aggressive) = h.zombie.filter(|_| !using_spear) {
        // AnimationUtils.animateZombieArms
        let raise = !s.baby || !h.holding;
        let drop = if raise {
            -PI / if aggressive { 1.5 } else { 2.25 }
        } else {
            0.0
        };
        let ym = if raise { 1.0 } else { -1.0 } * (swing * PI).msin();
        let xm = ((1.0 - (1.0 - swing) * (1.0 - swing)) * PI).msin();
        let x = drop + ym * 1.2 - xm * 0.4;
        let y = 0.1 - ym * 0.6;
        // An arm raising a trident keeps its pose.
        if h.right != ArmPose::ThrowTrident {
            p.xrot("right_arm", x);
            p.yrot("right_arm", if raise { -y } else { y });
            p.zrot("right_arm", 0.0);
        }
        if h.left != ArmPose::ThrowTrident {
            p.xrot("left_arm", x);
            p.yrot("left_arm", if raise { y } else { -y });
            p.zrot("left_arm", 0.0);
        }
    }
    if h.crouching {
        p.xrot("body", 0.5);
        p.get("right_arm")[3] += 0.4;
        p.get("left_arm")[3] += 0.4;
        p.get("right_leg")[2] += 4.0;
        p.get("left_leg")[2] += 4.0;
        p.get("head")[1] += 4.2;
        p.get("body")[1] += 3.2;
        p.get("left_arm")[1] += 3.2;
        p.get("right_arm")[1] += 3.2;
    }
    bob(p, "right_arm", s.age, 1.0);
    bob(p, "left_arm", s.age, -1.0);
    if h.swim > 0.0 {
        swim(p, s.pos, h);
    }
}
/// `Mth.rotLerpRad`.
fn rot_lerp_rad(a: f32, from: f32, to: f32) -> f32 {
    let mut diff = to - from;
    while diff < -PI {
        diff += PI * 2.0;
    }
    while diff >= PI {
        diff -= PI * 2.0;
    }
    from + a * diff
}
/// `DrownedModel.setupSwimAnimation`: the arms reach up and sway, the legs
/// kick and the head lies straight.
fn drowned_swim(p: &mut Poses, s: &State, amount: f32) {
    if amount <= 0.0 {
        return;
    }
    let sway = amount * 0.35 * (0.1 * s.age).msin();
    let kick = amount * 0.55 * (0.1 * s.age).msin();
    let reach = -PI * 4.0 / 5.0;
    let (right_x, left_x) = (p.get("right_arm")[3], p.get("left_arm")[3]);
    let (right_z, left_z) = (p.get("right_arm")[5], p.get("left_arm")[5]);
    p.xrot("right_arm", rot_lerp_rad(amount, right_x, reach) + sway);
    p.xrot("left_arm", rot_lerp_rad(amount, left_x, reach) - sway);
    p.zrot("right_arm", rot_lerp_rad(amount, right_z, -0.15));
    p.zrot("left_arm", rot_lerp_rad(amount, left_z, 0.15));
    let (left_leg, right_leg) = (p.get("left_leg")[3], p.get("right_leg")[3]);
    p.xrot("left_leg", left_leg - kick);
    p.xrot("right_leg", right_leg + kick);
    p.xrot("head", 0.0);
}
/// `HumanoidModel.setupSwimAnimation`: the stroke of both arms over 26
/// walk-animation units, the head down and a slow flutter kick. The left arm
/// eases the short way round, the right one linearly, as in vanilla.
fn swim(p: &mut Poses, pos: f32, h: &Hum) {
    let amount = h.swim;
    if !h.fall_flying {
        let x = p.get("head")[3];
        p.xrot(
            "head",
            rot_lerp_rad(amount, x, -std::f32::consts::FRAC_PI_4),
        );
    }
    let swim_pos = pos % 26.0;
    let right_amount = if h.swing_right_arm == Some(true) {
        0.0
    } else {
        amount
    };
    let left_amount = if h.swing_right_arm == Some(false) {
        0.0
    } else {
        amount
    };
    let lerp = |a: f32, from: f32, to: f32| from + a * (to - from);
    let quadratic = |x: f32| -65.0 * x + x * x;
    if !h.using_item {
        // Targets (x, y, z) for the left and right arm.
        let targets = if swim_pos < 14.0 {
            let stroke = 1.870_796_4 * quadratic(swim_pos) / quadratic(14.0);
            Some(([0.0, PI, PI + stroke], [0.0, PI, PI - stroke]))
        } else if swim_pos < 22.0 {
            let t = (swim_pos - 14.0) / 8.0;
            let x = PI / 2.0 * t;
            Some((
                [x, PI, 5.012_389 - 1.870_796_4 * t],
                [x, PI, 1.270_796_3 + 1.870_796_4 * t],
            ))
        } else if swim_pos < 26.0 {
            let t = (swim_pos - 22.0) / 4.0;
            let x = PI / 2.0 - PI / 2.0 * t;
            Some(([x, PI, PI], [x, PI, PI]))
        } else {
            None
        };
        if let Some((left, right)) = targets {
            for (i, target) in left.into_iter().enumerate() {
                let angle = &mut p.get("left_arm")[3 + i];
                *angle = rot_lerp_rad(left_amount, *angle, target);
            }
            for (i, target) in right.into_iter().enumerate() {
                let angle = &mut p.get("right_arm")[3 + i];
                *angle = lerp(right_amount, *angle, target);
            }
        }
    }
    let x = p.get("left_leg")[3];
    p.xrot(
        "left_leg",
        lerp(amount, x, 0.3 * (pos * 0.333_333_34 + PI).mcos()),
    );
    let x = p.get("right_leg")[3];
    p.xrot(
        "right_leg",
        lerp(amount, x, 0.3 * (pos * 0.333_333_34).mcos()),
    );
}
/// Apply the mob's model animation to `p` (at rest), then the emote it plays, if any.
pub fn setup(
    m: &Mob,
    s: &State,
    p: &mut Poses,
    w_anims: &HashMap<String, super::keyframes::Animation>,
) {
    let Some(playing) = &m.emote else {
        return vanilla_setup(m, s, p, w_anims);
    };
    let rest = horizon_cosmetics::BODY.map(|b| p.has(b.part()).then(|| *p.get(b.part())));
    vanilla_setup(m, s, p, w_anims);
    emote(playing, s.age, rest, p);
}

/// Poses the bones `rest` names (those the model has; at rest) as `playing` has them at `age`.
fn emote(
    playing: &horizon_cosmetics::Playing,
    age: f32,
    rest: [Option<[f32; 9]>; 6],
    p: &mut Poses,
) {
    let (Some(emote), Some((t, weight))) = (&playing.item.emote, playing.at(age)) else {
        return;
    };
    const IDENTITY: [f32; 9] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0];
    let bones = horizon_cosmetics::BODY;
    let at_rest = rest.map(|r| r.unwrap_or(IDENTITY));
    let mut poses: [[f32; 9]; 6] =
        std::array::from_fn(|i| rest[i].map_or(IDENTITY, |_| *p.get(bones[i].part())));
    emote.pose_body(t, weight, &at_rest, &mut poses);
    for (i, pose) in poses.into_iter().enumerate() {
        if rest[i].is_some() {
            *p.get(bones[i].part()) = pose;
        }
    }
}

fn vanilla_setup(
    m: &Mob,
    s: &State,
    p: &mut Poses,
    w_anims: &HashMap<String, super::keyframes::Animation>,
) {
    if super::body_anim::anim(m, s, p, w_anims) {
        return;
    }
    match m.kind.anim {
        Anim::Camel => super::camel::anim(m, s, p, w_anims),
        Anim::Breeze => super::breeze::anim(m, s, p, w_anims),
        Anim::Sniffer => super::sniffer::anim(m, s, p, w_anims),
        Anim::CopperGolem => super::copper_golem::anim(m, s, p, w_anims),
        Anim::HappyGhast => super::happy_ghast::anim(m, s, p),
        Anim::Nautilus => super::nautilus::anim(m, s, p, w_anims),
        // body_anim::llama runs first.
        Anim::Llama => quadruped(p, s),
        Anim::Warden => super::warden::anim(m, s, p, w_anims),
        Anim::Allay => super::allay::anim(m, s, p),
        Anim::Creaking => super::creaking::anim(m, s, p, w_anims),
        Anim::Squid | Anim::Fish | Anim::Pufferfish | Anim::Dolphin => {
            super::aquatic::anim(m, s, p)
        }
        Anim::Quadruped | Anim::PolarBear | Anim::Panda | Anim::Goat => quadruped(p, s),
        Anim::Sheep => {
            quadruped(p, s);
            // SheepModel: lower the head while eating grass.
            let t = m.extra.anim_ticks;
            let partial = s.partial;
            let pos_scale = if t <= 0 {
                0.0
            } else if (4..=36).contains(&t) {
                1.0
            } else if t < 4 {
                (t as f32 - partial) / 4.0
            } else {
                -((t - 40) as f32 - partial) / 4.0
            };
            let angle = if t > 4 && t <= 36 {
                let f = ((t - 4) as f32 - partial) / 32.0;
                PI / 5.0 + 0.219_911_49 * (f * 28.7).msin()
            } else if t > 0 {
                PI / 5.0
            } else {
                s.x_rot.to_radians()
            };
            let age_scale = if s.baby { 0.5 } else { 1.0 };
            p.get("head")[1] += pos_scale * 9.0 * age_scale;
            p.xrot("head", angle);
        }
        Anim::Chicken => {
            let flap = m.anim.flap_o + (m.anim.flap - m.anim.flap_o) * s.partial;
            let flap_speed =
                m.anim.flap_speed_o + (m.anim.flap_speed - m.anim.flap_speed_o) * s.partial;
            let angle = (flap.msin() + 1.0) * flap_speed;
            p.xrot("right_leg", (s.pos * 0.6662).mcos() * 1.4 * s.speed);
            p.xrot("left_leg", (s.pos * 0.6662 + PI).mcos() * 1.4 * s.speed);
            p.zrot("right_wing", angle);
            p.zrot("left_wing", -angle);
            if !s.baby {
                head(p, s);
            }
        }
        Anim::Zombie
        | Anim::Drowned
        | Anim::ZombieVillager
        | Anim::ZombifiedPiglin
        | Anim::Humanoid { zombie_arms: true } => {
            // DrownedRenderer.getArmPose: an aggressive drowned raises the
            // trident in its main arm.
            let throwing = m.kind.anim == Anim::Drowned
                && m.ai.aggressive
                && m.extra.main_hand.as_deref() == Some("minecraft:trident");
            // HumanoidMobRenderer.getArmPose: the arm holding a spear (at rest too).
            let spear = m
                .extra
                .main_hand
                .as_deref()
                .and_then(crate::spear::Kinetic::of);
            let main = if throwing {
                ArmPose::ThrowTrident
            } else if spear.is_some() {
                ArmPose::Spear
            } else {
                ArmPose::Empty
            };
            let mut h = if m.main_arm_left() {
                Hum::new(ArmPose::Empty, main)
            } else {
                Hum::new(main, ArmPose::Empty)
            };
            h.left_main = m.main_arm_left();
            let main_side = usize::from(m.main_arm_left());
            if main == ArmPose::Spear {
                h.spear[main_side] = spear;
                if m.extra.using_item > 0 && !m.extra.using_off_hand {
                    h.spear_ticks[main_side] = m.extra.using_item as f32 + s.partial;
                }
            }
            h.zombie = Some(m.ai.aggressive);
            h.holding = m.extra.main_hand.is_some();
            h.crouching = m.extra.crouching;
            h.passenger = m.extra.passenger;
            humanoid(p, s, &h);
            if m.kind.anim == Anim::Drowned {
                drowned_swim(p, s, m.extra.swim.amount(s.partial));
            }
            if m.kind.anim == Anim::ZombifiedPiglin {
                super::piglin::ears(p, s);
            }
        }
        Anim::Skeleton | Anim::Humanoid { zombie_arms: false } => {
            let bow = m.extra.main_hand.as_deref() == Some("minecraft:bow");
            let player = matches!(m.kind.anim, Anim::Humanoid { .. });
            let right = if bow && m.ai.aggressive {
                ArmPose::Bow
            } else if player && m.extra.main_hand.is_some() {
                ArmPose::Item
            } else {
                ArmPose::Empty
            };
            let using_main = m.extra.using_item > 0 && !m.extra.using_off_hand;
            let using_off = m.extra.using_item > 0 && m.extra.using_off_hand;
            // AvatarRenderer.getArmPose: an arm holding a spear (at rest too).
            let spear_in = |hand: &Option<std::sync::Arc<str>>| {
                hand.as_deref()
                    .filter(|_| player)
                    .and_then(crate::spear::Kinetic::of)
            };
            let (main_spear, off_spear) =
                (spear_in(&m.extra.main_hand), spear_in(&m.extra.off_hand));
            let pose = if player {
                match m.extra.main_hand.as_deref() {
                    Some(_) if using_main && m.extra.blocking => ArmPose::Block,
                    Some("minecraft:bow") if using_main => ArmPose::Bow,
                    Some("minecraft:trident") if using_main => ArmPose::ThrowTrident,
                    Some("minecraft:spyglass") if using_main => ArmPose::Spyglass,
                    Some("minecraft:goat_horn") if using_main => ArmPose::TootHorn,
                    Some("minecraft:crossbow") if using_main && !m.extra.charged => {
                        ArmPose::CrossbowCharge
                    }
                    Some("minecraft:crossbow") if m.extra.charged && s.swing == 0.0 => {
                        ArmPose::CrossbowHold
                    }
                    Some("minecraft:brush") if using_main => ArmPose::Brush,
                    Some(_) if main_spear.is_some() => ArmPose::Spear,
                    Some(_) => ArmPose::Item,
                    None => ArmPose::Empty,
                }
            } else {
                right
            };
            let off = if player && m.extra.off_hand.is_some() && !pose.affects_offhand() {
                if off_spear.is_some() {
                    ArmPose::Spear
                } else if using_off && m.extra.blocking {
                    ArmPose::Block
                } else if using_off && m.extra.off_hand.as_deref() == Some("minecraft:spyglass") {
                    ArmPose::Spyglass
                } else if using_off && m.extra.off_hand.as_deref() == Some("minecraft:goat_horn") {
                    ArmPose::TootHorn
                } else if using_off && m.extra.off_hand.as_deref() == Some("minecraft:brush") {
                    ArmPose::Brush
                } else {
                    ArmPose::Item
                }
            } else {
                ArmPose::Empty
            };
            let mut h = if m.main_arm_left() {
                Hum::new(off, pose)
            } else {
                Hum::new(pose, off)
            };
            h.charge = (m.extra.ints[5] as f32, m.extra.using_item as f32);
            h.fall_flying = m.extra.fall_flying;
            if h.fall_flying {
                let v = m.velocity;
                h.fly_speed_scale =
                    (((v.x * v.x + v.y * v.y + v.z * v.z) as f32 / 0.2).powi(3)).max(1.0);
            }
            h.crouching = m.extra.crouching;
            h.passenger = m.extra.passenger;
            h.swim = m.extra.swim.amount(s.partial);
            h.using_item = m.extra.using_item > 0;
            h.swing_right_arm = m.extra.swing_right_arm;
            h.stab = m.extra.swing_stab;
            h.left_main = m.main_arm_left();
            let main_side = usize::from(m.main_arm_left());
            h.spear[main_side] = main_spear;
            h.spear[1 - main_side] = off_spear;
            if m.extra.using_item > 0 {
                let using_side = if m.extra.using_off_hand {
                    1 - main_side
                } else {
                    main_side
                };
                h.spear_ticks[using_side] = m.extra.using_item as f32 + s.partial;
            }
            humanoid(p, s, &h);
            if player {
                player_model_visibility(p, m.extra.hidden_model_parts, m.extra.spectator);
            }
            if m.ai.aggressive && !bow {
                // SkeletonModel melee pose.
                let sw = s.swing;
                let s2 = (sw * PI).msin();
                let s1 = ((1.0 - (1.0 - sw) * (1.0 - sw)) * PI).msin();
                p.zrot("right_arm", 0.0);
                p.zrot("left_arm", 0.0);
                p.yrot("right_arm", -(0.1 - s2 * 0.6));
                p.yrot("left_arm", 0.1 - s2 * 0.6);
                p.xrot("right_arm", -PI / 2.0 - (s2 * 1.2 - s1 * 0.4));
                p.xrot("left_arm", -PI / 2.0 - (s2 * 1.2 - s1 * 0.4));
                bob(p, "right_arm", s.age, 1.0);
                bob(p, "left_arm", s.age, -1.0);
            }
            // BoggedModel.setupAnim: the mushrooms on the head come off once sheared.
            if m.species() == super::Species::Bogged {
                p.visible("mushrooms", !m.extra.sheared);
            }
        }
        Anim::Witch => super::witch::anim(m, s, p),
        Anim::Villager => super::villager::anim(m, s, p),
        Anim::Wolf => super::tame::anim(m, s, p),
        Anim::IronGolem => super::golem::iron_anim(m, s, p),
        Anim::Illager => super::illager::anim(m, s, p),
        Anim::Piglin => super::piglin::piglin_anim(m, s, p),
        Anim::Phantom => super::phantom::anim(m, s, p),
        Anim::Guardian => super::guardian::anim(m, s, p),
        Anim::Vex => super::vex::anim(m, s, p),
        Anim::Wither => super::wither::anim(m, s, p),
        Anim::Ravager => super::ravager::anim(m, s, p),
        Anim::Shulker => super::shulker::anim(m, s, p),
        Anim::Horse => {
            super::equine::anim(m, s, p);
            // DonkeyModel: the chests show once fitted.
            if !m.extra.chested {
                for part in ["left_chest", "right_chest"] {
                    p.visible(part, false);
                }
            }
            // EquineSaddleModel.setupAnim: the reins show only while ridden
            // (`isRidden` is `Entity.isVehicle`: a player or a mob rides it).
            for part in ["left_saddle_line", "right_saddle_line"] {
                p.visible(part, m.rider.is_some() || m.extra.rider.is_some());
            }
        }
        Anim::Hoglin => super::piglin::hoglin_anim(m, s, p),
        Anim::Blaze => super::nether::blaze_anim(s, p),
        Anim::Ghast => super::nether::ghast_anim(s, p),
        Anim::Feline => super::tame::cat_anim(m, s, p),
        Anim::Enderman => super::enderman::anim(m, s, p),
        Anim::Slime | Anim::MagmaCube => super::cube::anim(m, s, p),
        Anim::Creeper => {
            head(p, s);
            // CreeperModel binds its fields to the opposite-side parts, so the
            // left formulas drive the right parts and the reverse.
            p.xrot("left_hind_leg", (s.pos * 0.6662).mcos() * 1.4 * s.speed);
            p.xrot(
                "right_hind_leg",
                (s.pos * 0.6662 + PI).mcos() * 1.4 * s.speed,
            );
            p.xrot(
                "left_front_leg",
                (s.pos * 0.6662 + PI).mcos() * 1.4 * s.speed,
            );
            p.xrot("right_front_leg", (s.pos * 0.6662).mcos() * 1.4 * s.speed);
        }
        Anim::Spider => {
            head(p, s);
            let pos = s.pos * 0.6662;
            let sp = s.speed;
            let swing = |o: f32| -((pos * 2.0 + o).mcos() * 0.4) * sp;
            let step = |o: f32| ((pos + o).msin() * 0.4).abs() * sp;
            let legs = [
                ("right_hind_leg", "left_hind_leg", 0.0f32, 0.0f32),
                ("right_middle_hind_leg", "left_middle_hind_leg", PI, PI),
                (
                    "right_middle_front_leg",
                    "left_middle_front_leg",
                    PI / 2.0,
                    PI / 2.0,
                ),
                (
                    "right_front_leg",
                    "left_front_leg",
                    PI * 3.0 / 2.0,
                    PI * 3.0 / 2.0,
                ),
            ];
            for (right, left, so, to) in legs {
                let (sw, st) = (swing(so), step(to));
                p.get(right)[4] += sw;
                p.get(left)[4] -= sw;
                p.get(right)[5] += st;
                p.get(left)[5] -= st;
            }
        }
        _ => {
            if p.has("head") {
                head(p, s);
            }
            if p.has("right_hind_leg") {
                quadruped(p, s);
            }
        }
    }
}

/// `PlayerModel.setupAnim`'s visibility: a spectator shows only its head (`showBody`), and the
/// skin layers the player hid (`PlayerModelPart`, bit set = hidden) are off.
fn player_model_visibility(p: &mut Poses, hidden: u8, spectator: bool) {
    for part in ["body", "right_arm", "left_arm", "right_leg", "left_leg"] {
        p.visible(part, !spectator);
    }
    for (bit, part) in [
        (1, "jacket"),
        (2, "left_sleeve"),
        (3, "right_sleeve"),
        (4, "left_pants"),
        (5, "right_pants"),
        (6, "hat"),
    ] {
        p.visible(part, hidden & (1 << bit) == 0);
    }
}
#[cfg(test)]
mod emote_tests {
    use super::*;

    #[test]
    fn an_emote_poses_the_bones_the_model_has_after_its_animation() {
        // The right arm up to 90° about z at tick 10, the body hopping 4 px; the model has no legs.
        let item = horizon_cosmetics::Item::parse(
            br#"{"format": 1, "id": "up", "slot": "emote", "parts": [],
                "emote": {"length": 20, "blend": 0, "tracks": [
                  {"part": "right_arm", "keys": [{"t": 10, "rotation": [0, 0, 90]}]},
                  {"part": "root", "keys": [{"t": 0, "offset": [0, -4, 0]}]}]}}"#,
        )
        .unwrap();
        let rest = |x: f32, y: f32| [x, y, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0];
        let mut p = Poses {
            map: [("head", rest(0.0, 0.0)), ("right_arm", rest(-5.0, 2.0))]
                .into_iter()
                .map(|(n, pose)| (key(n), pose))
                .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        let at_rest = horizon_cosmetics::BODY.map(|b| p.has(b.part()).then(|| *p.get(b.part())));
        // What the walk animation did: the head looks aside, the arm swings.
        p.get("head")[4] = 0.4;
        p.get("right_arm")[3] = 0.7;
        let playing = horizon_cosmetics::Playing {
            item: std::sync::Arc::new(item),
            start: 100.0,
            stop: None,
        };
        emote(&playing, 110.0, at_rest, &mut p);
        let arm = *p.get("right_arm");
        assert!(
            (arm[5] - std::f32::consts::FRAC_PI_2).abs() < 1e-5 && arm[3].abs() < 1e-5,
            "{arm:?}"
        );
        assert!((arm[0] + 5.0).abs() < 1e-5 && (arm[1] - (2.0 - 4.0)).abs() < 1e-5);
        // The head keeps looking aside, lifted with the body.
        let head = *p.get("head");
        assert!((head[4] - 0.4).abs() < 1e-5 && (head[1] + 4.0).abs() < 1e-5);
        // Nothing was added for the bones the model lacks, and past its end the emote is gone.
        assert_eq!(p.map.len(), 2);
        let before = *p.get("right_arm");
        emote(&playing, 125.0, at_rest, &mut p);
        assert_eq!(*p.get("right_arm"), before);
    }
}

#[cfg(test)]
mod flight_pose_tests {
    use super::*;
    use horizon_core::geometry::Vec3;
    use std::sync::Arc;

    #[test]
    fn spectators_show_only_the_head_and_its_hat() {
        let mut p = Poses {
            map: [
                "head",
                "hat",
                "body",
                "jacket",
                "right_arm",
                "left_arm",
                "right_leg",
                "left_leg",
            ]
            .into_iter()
            .map(|n| (key(n), [0.0; 9]))
            .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        player_model_visibility(&mut p, 0, true);
        for part in ["body", "right_arm", "left_arm", "right_leg", "left_leg"] {
            assert!(p.hidden.contains(&key(part)), "{part}");
        }
        assert!(!p.hidden.contains(&key("head")) && !p.hidden.contains(&key("hat")));
        // Back in another mode they all show, but for the layers the player hid.
        player_model_visibility(&mut p, 1 << 6, false);
        assert!(!p.hidden.contains(&key("body")) && !p.hidden.contains(&key("left_leg")));
        assert!(p.hidden.contains(&key("hat")));
    }
    #[test]
    fn blocking_arm_follows_the_head_with_limits_in_both_hands() {
        for right in [false, true] {
            for (pitch, yaw, expected_pitch, expected_yaw) in [
                (0.0, 0.0, -0.742_477_9, 0.0),
                (2.0, 2.0, -0.306_145_58, FRAC_PI_6),
                (-2.0, -2.0, -2.138_741_3, -FRAC_PI_6),
            ] {
                let mut p = Poses {
                    map: ["head", "right_arm", "left_arm"]
                        .into_iter()
                        .map(|n| (key(n), [0.0; 9]))
                        .collect(),
                    dummy: [0.0; 9],
                    skipped: Default::default(),
                    hidden: Default::default(),
                    version: 0,
                };
                let arm = if right { "right_arm" } else { "left_arm" };
                p.xrot("head", pitch);
                p.yrot("head", yaw);
                p.xrot(arm, 0.4);
                pose_arm(
                    &mut p,
                    ArmPose::Block,
                    right,
                    &Hum::new(ArmPose::Empty, ArmPose::Empty),
                );
                let pose = *p.get(arm);
                assert!((pose[3] - expected_pitch).abs() < 1e-6);
                let side = if right { -FRAC_PI_6 } else { FRAC_PI_6 };
                assert!((pose[4] - (side + expected_yaw)).abs() < 1e-6);
                assert_eq!(p.get(if right { "left_arm" } else { "right_arm" })[3], 0.0);
            }
        }
    }
    /// HumanoidModel.poseRightArm / poseLeftArm's SPYGLASS case: pitch, yaw,
    /// crouching, and the arm's pitch.
    #[test]
    fn a_spyglass_raises_the_arm_with_the_head_in_both_hands() {
        for right in [false, true] {
            for (pitch, yaw, crouching, expected_pitch) in [
                (0.0, 0.0, false, -1.919_862_2),
                (0.5, 0.3, false, -1.419_862_2),
                (0.0, 0.0, true, -2.181_661_6),
                // Looking up: limited to -2.4.
                (-1.5, 0.0, false, -2.4),
            ] {
                let mut p = Poses {
                    map: ["head", "right_arm", "left_arm"]
                        .into_iter()
                        .map(|n| (key(n), [0.0; 9]))
                        .collect(),
                    dummy: [0.0; 9],
                    skipped: Default::default(),
                    hidden: Default::default(),
                    version: 0,
                };
                let arm = if right { "right_arm" } else { "left_arm" };
                p.xrot("head", pitch);
                p.yrot("head", yaw);
                let mut h = Hum::new(ArmPose::Empty, ArmPose::Empty);
                h.crouching = crouching;
                pose_arm(&mut p, ArmPose::Spyglass, right, &h);
                let pose = *p.get(arm);
                assert!((pose[3] - expected_pitch).abs() < 1e-6, "{pose:?}");
                let side = if right { -0.261_799_4 } else { 0.261_799_4 };
                assert!((pose[4] - (yaw + side)).abs() < 1e-6, "{pose:?}");
                assert_eq!(p.get(if right { "left_arm" } else { "right_arm" })[3], 0.0);
            }
        }
    }
    /// EndermanModel.setupAnim (#4565): humanoid_pub forwards isPassenger so the
    /// riding leg y/z survive; only xRot is halved and clamped to ±0.4 after.
    #[test]
    fn a_seated_enderman_keeps_the_riding_leg_twist() {
        use super::super::enderman;
        use super::super::{Mob, Species};
        use horizon_core::geometry::Vec3;
        use std::sync::Arc;
        let mut kind = (*crate::mobs::sensor_scan_tests::kind()).clone();
        kind.species = Species::Enderman;
        let mut seated = Mob::new(1, Arc::new(kind), Vec3::ZERO, 0.0);
        seated.extra.passenger = true;
        let state = State {
            pos: 0.0,
            speed: 0.0,
            age: 0.0,
            y_rot: 0.0,
            x_rot: 0.0,
            swing: 0.0,
            baby: false,
            partial: 0.0,
        };
        let mut poses = Poses {
            map: [
                "head",
                "hat",
                "body",
                "right_arm",
                "left_arm",
                "right_leg",
                "left_leg",
            ]
            .into_iter()
            .map(|n| (key(n), [0.0; 9]))
            .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        enderman::anim(&seated, &state, &mut poses);
        let right = *poses.get("right_leg");
        let left = *poses.get("left_leg");
        assert!((right[3] - (-0.4)).abs() < 1e-5, "right xRot {}", right[3]);
        assert!((left[3] - (-0.4)).abs() < 1e-5, "left xRot {}", left[3]);
        assert!(
            (right[4] - PI / 10.0).abs() < 1e-5,
            "right yRot {}",
            right[4]
        );
        assert!(
            (left[4] - (-PI / 10.0)).abs() < 1e-5,
            "left yRot {}",
            left[4]
        );
        assert!(
            (right[5] - 0.078_539_82).abs() < 1e-5,
            "right zRot {}",
            right[5]
        );
        assert!(
            (left[5] - (-0.078_539_82)).abs() < 1e-5,
            "left zRot {}",
            left[5]
        );
    }

    #[test]
    fn flight_slows_limbs_and_sets_the_head_pose() {
        let state = State {
            pos: 0.0,
            speed: 1.0,
            age: 0.0,
            y_rot: 0.0,
            x_rot: 0.0,
            swing: 0.0,
            baby: false,
            partial: 0.0,
        };
        let make = || Poses {
            map: [
                "head",
                "right_arm",
                "left_arm",
                "right_leg",
                "left_leg",
                "body",
            ]
            .into_iter()
            .map(|n| (key(n), [0.0; 9]))
            .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        let mut ground = make();
        let mut flight = make();
        let mut h = Hum::new(ArmPose::Empty, ArmPose::Empty);
        humanoid(&mut ground, &state, &h);
        h.fall_flying = true;
        h.fly_speed_scale = 8.0;
        humanoid(&mut flight, &state, &h);
        assert_eq!(flight.get("head")[3], -std::f32::consts::FRAC_PI_4);
        assert_eq!(flight.get("right_leg")[3], ground.get("right_leg")[3] / 8.0);
        // THROW_TRIDENT: the arm goes up over the head, and zombie arms leave it there.
        let mut throw = make();
        let mut h = Hum::new(ArmPose::ThrowTrident, ArmPose::Item);
        h.zombie = Some(true);
        humanoid(&mut throw, &state, &h);
        let still = (state.pos * 0.6662 + PI).mcos() * 2.0 * 0.5;
        assert_eq!(throw.get("right_arm")[3], still * 0.5 - PI);
        assert_eq!(throw.get("right_arm")[4], 0.0);
        assert_eq!(throw.get("left_arm")[3], -PI / 1.5);
    }

    #[test]
    fn swimming_strokes_the_arms_and_kicks() {
        let state = State {
            pos: 7.0,
            speed: 1.0,
            age: 0.0,
            y_rot: 0.0,
            x_rot: 30.0,
            swing: 0.0,
            baby: false,
            partial: 0.0,
        };
        let make = || Poses {
            map: ["head", "right_arm", "left_arm", "right_leg", "left_leg"]
                .into_iter()
                .map(|n| (key(n), [0.0; 9]))
                .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        let same_angle = |a: f32, b: f32| ((a - b + PI).rem_euclid(PI * 2.0) - PI).abs() < 1e-5;
        let mut h = Hum::new(ArmPose::Empty, ArmPose::Empty);
        h.swim = 1.0;
        let mut p = make();
        humanoid(&mut p, &state, &h);
        // Mid-stroke: both arms sweep out from overhead by the quadratic.
        let stroke = 1.870_796_4 * (-65.0 * 7.0 + 49.0) / (-65.0 * 14.0 + 196.0);
        assert_eq!(p.get("right_arm")[5], PI - stroke);
        assert!(same_angle(p.get("left_arm")[5], PI + stroke));
        assert_eq!(p.get("right_arm")[4], PI);
        assert!(same_angle(p.get("head")[3], -std::f32::consts::FRAC_PI_4));
        assert!(same_angle(
            p.get("right_leg")[3],
            0.3 * (7.0f32 * 0.333_333_34).mcos()
        ));
        // Using an item keeps the arms; a swing frees its own arm only.
        let mut using = make();
        h.using_item = true;
        humanoid(&mut using, &state, &h);
        assert_eq!(using.get("right_arm")[4], 0.0);
        h.using_item = false;
        h.swing_right_arm = Some(true);
        let mut swinging = make();
        humanoid(
            &mut swinging,
            &State {
                swing: 0.5,
                ..state
            },
            &h,
        );
        assert!(swinging.get("right_arm")[4] < 1.0);
        assert!(same_angle(swinging.get("left_arm")[4], PI));
        // A STAB swing turns that arm's pitch alone, by the spear's curve.
        let mut stabbing = make();
        h.swim = 0.0;
        h.stab = true;
        let mut still = make();
        humanoid(
            &mut still,
            &state,
            &Hum::new(ArmPose::Empty, ArmPose::Empty),
        );
        let stab = State {
            swing: 0.2,
            ..state
        };
        humanoid(&mut stabbing, &stab, &h);
        let arm_pitch = crate::spear::third_person_attack_arm(0.2);
        assert!(same_angle(
            stabbing.get("right_arm")[3],
            still.get("right_arm")[3] + arm_pitch
        ));
        assert_eq!(stabbing.get("left_arm")[3], still.get("left_arm")[3]);
        // Out of the pose nothing changes.
        let mut dry = make();
        humanoid(&mut dry, &state, &Hum::new(ArmPose::Empty, ArmPose::Empty));
        assert_eq!(dry.get("head")[3], 30.0f32.to_radians());
    }

    #[test]
    fn walk_position_triples_for_babies() {
        // WalkAnimationState.position(partial) = (position - speed * (1 - partial)) * scale.
        let mut m = player();
        m.limb_position = 2.0;
        m.limb_speed = 0.5;
        assert!(!m.is_baby());
        assert_eq!(walk_position(&m, 0.5), 1.75);
        m.extra.age = -100;
        assert!(m.is_baby());
        assert_eq!(walk_position(&m, 0.5), 5.25);
    }

    /// A player: a humanoid model with a shield in its main hand.
    fn player() -> Mob {
        let mut kind = crate::mobs::sensor_scan_tests::kind();
        let k = Arc::make_mut(&mut kind);
        k.anim = Anim::Humanoid { zombie_arms: false };
        Mob::new(1, kind, Vec3::ZERO, 0.0)
    }

    #[test]
    fn a_raised_shield_holds_the_arm_across_the_body() {
        // AvatarRenderer.getArmPose: the used item's use animation decides
        // the arm's pose, and a shield (an item with `blocks_attacks`) uses
        // the BLOCK animation, so the arm is held up across the body
        // (#2289).
        let state = State {
            pos: 0.0,
            speed: 0.0,
            age: 0.0,
            y_rot: 0.0,
            x_rot: 0.0,
            swing: 0.0,
            baby: false,
            partial: 0.0,
        };
        let mut p = Poses {
            map: ["head", "right_arm", "left_arm"]
                .into_iter()
                .map(|n| (key(n), [0.0; 9]))
                .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        let mut m = player();
        m.extra.main_hand = Some("minecraft:shield".into());
        m.extra.using_item = 20;
        m.extra.blocking = true;
        setup(&m, &state, &mut p, &HashMap::new());
        // HumanoidModel.setupAnim's BLOCK pose.
        assert!((p.get("right_arm")[3] + 0.942_477_9).abs() < 1e-6);
        assert!((p.get("right_arm")[4] + FRAC_PI_6).abs() < 1e-6);
        // An item that does not block attacks leaves the arm holding it.
        let mut m = player();
        m.extra.main_hand = Some("minecraft:stick".into());
        m.extra.using_item = 20;
        let mut p = Poses {
            map: ["head", "right_arm", "left_arm"]
                .into_iter()
                .map(|n| (key(n), [0.0; 9]))
                .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        setup(&m, &state, &mut p, &HashMap::new());
        assert!((p.get("right_arm")[3] + PI / 10.0).abs() < 1e-6);
    }

    #[test]
    fn a_brush_being_used_sweeps_the_arm_lower_than_a_plain_item() {
        // AvatarRenderer.getArmPose: a brush being used is the BRUSH pose, and
        // HumanoidModel.poseRightArm drops that arm twice as far as ITEM
        // (#4273: brushing had no third-person arm pose at all).
        let state = State {
            pos: 0.0,
            speed: 0.0,
            age: 0.0,
            y_rot: 0.0,
            x_rot: 0.0,
            swing: 0.0,
            baby: false,
            partial: 0.0,
        };
        let make = || Poses {
            map: ["head", "right_arm", "left_arm"]
                .into_iter()
                .map(|n| (key(n), [0.0; 9]))
                .collect(),
            dummy: [0.0; 9],
            skipped: Default::default(),
            hidden: Default::default(),
            version: 0,
        };
        let mut m = player();
        m.extra.main_hand = Some("minecraft:brush".into());
        m.extra.using_item = 20;
        let mut p = make();
        setup(&m, &state, &mut p, &HashMap::new());
        // HumanoidModel.setupAnim's BRUSH pose.
        assert!((p.get("right_arm")[3] + PI / 5.0).abs() < 1e-6);
        assert_eq!(p.get("right_arm")[4], 0.0);
        // An item with no use animation keeps the ITEM pose: BRUSH cannot leak.
        let mut m = player();
        m.extra.main_hand = Some("minecraft:stick".into());
        m.extra.using_item = 20;
        let mut p = make();
        setup(&m, &state, &mut p, &HashMap::new());
        assert!((p.get("right_arm")[3] + PI / 10.0).abs() < 1e-6);
        assert_eq!(p.get("right_arm")[4], 0.0);
        // AvatarRenderer.getArmPose builds the pose per hand: brushing with the
        // brush in the off hand is BRUSH on the left arm, and the main hand
        // keeps its ITEM pose (the two must not swap).
        let mut m = player();
        m.extra.main_hand = Some("minecraft:stick".into());
        m.extra.off_hand = Some("minecraft:brush".into());
        m.extra.using_item = 20;
        m.extra.using_off_hand = true;
        let mut p = make();
        setup(&m, &state, &mut p, &HashMap::new());
        assert!((p.get("left_arm")[3] + PI / 5.0).abs() < 1e-6);
        assert_eq!(p.get("left_arm")[4], 0.0);
        assert!((p.get("right_arm")[3] + PI / 10.0).abs() < 1e-6);
        assert_eq!(p.get("right_arm")[4], 0.0);
    }

    /// ModelPart.createPartLookup fills the name map with putIfAbsent, so of two
    /// parts sharing a name the first registered keeps it, not the last.
    #[test]
    fn a_name_two_parts_share_belongs_to_the_first() {
        let child = |xrot: f32| Part {
            name: "leg".into(),
            pose: [0.0, 0.0, 0.0, xrot, 0.0, 0.0, 1.0, 1.0, 1.0],
            polygons: Vec::new(),
            children: Vec::new(),
        };
        let root = Part {
            name: "root".into(),
            pose: [0.0; 9],
            polygons: Vec::new(),
            children: vec![child(0.5), child(-0.5)],
        };
        let mut p = Poses::new(&root);
        assert_eq!(p.get("leg")[3], 0.5);
    }
}
