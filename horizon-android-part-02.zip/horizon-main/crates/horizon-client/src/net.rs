//! Multiplayer session: a network thread that connects to a server, logs in,
//! runs the configuration phase and then forwards decoded play packets to the
//! game thread. Keep-alives are answered on the network thread; pings wait for
//! the game thread, like ClientCommonPacketListenerImpl.handlePing, so a pong
//! cannot overtake an earlier world update or teleport acknowledgement.
//! Online-mode servers need the Microsoft account the launcher signed in
//! (crate::auth): the login joins the server through the session service and
//! encrypts the connection (ClientHandshakePacketListenerImpl.handleHello).
use crate::auth::AuthSession;
use crate::studio::{Metadata, RecorderStatus, StudioRecorder};
use horizon_protocol::{
    PROTOCOL_VERSION,
    buf::Reader,
    connection::{ConnReader, ConnWriter, Connection, Counters},
    crypto::{generate_secret, offline_uuid, server_hash},
    packets::{Empty, configuration as cfg, handshake, login, play},
    registry::Dynamic,
    rsa::RsaPublicKey,
    servers::parse_address,
    text::{Language, plain, translatable},
};
use horizon_world::nbt::{JavaString, Tag};
use std::{
    collections::HashMap,
    path::{Path, PathBuf},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicU32, Ordering},
        mpsc::{Receiver, Sender, channel},
    },
    thread::JoinHandle,
    time::Duration,
};

/// `CommonListenerCookie.serverCookies`: cookies the server asked the client
/// to store (`ClientboundStoreCookiePacket`), answered to
/// `ClientboundCookieRequestPacket`. A `transfer` carries them to the next
/// connection (`TransferState`), so a proxy's backend switch keeps them.
pub type Cookies = Arc<Mutex<HashMap<String, Vec<u8>>>>;

/// What the network thread reports to the game.
pub enum Event {
    /// Progress text for the connecting screen.
    Status(String),
    /// The server's `minecraft:brand` custom payload.
    Brand(String),
    /// The server runs mods' quiet commands (`horizon_protocol::quiet`).
    QuietCommands,
    /// The server carries mod messages (`horizon_protocol::mod_net`).
    ModNet,
    /// The server samples far terrain for this client (`lod_net`).
    FarTerrain(crate::lod_net::Offer),
    /// ClientConfigurationPacketListenerImpl.handleEnabledFeatures.
    Features(Vec<String>),
    /// Configuration finished: the play state begins with these registries.
    Joined {
        registries: Arc<Dynamic>,
        uuid: u128,
        name: String,
    },
    Packet(Box<play::Clientbound>),
    /// A packet that failed to decode (skipped, like vanilla's skippable packets).
    DecodeError(String),
    /// The server sent us back to configuration (`ClientboundStartConfigurationPacket`):
    /// the game shows `ServerReconfigScreen` until the server logs it in again.
    Reconfiguring,
    /// The server sent us back to configuration and finished it again.
    Reconfigured(Arc<Dynamic>),
    /// ClientboundResourcePackPushPacket, in configuration or in play.
    PackPush(cfg::ResourcePackPush),
    /// ClientboundResourcePackPopPacket: one pack, or every pack.
    PackPop(Option<u128>),
    /// `show_dialog` in configuration: the dialog itself.
    ShowDialog(horizon_world::nbt::Tag),
    /// `clear_dialog` in configuration.
    ClearDialog,
    /// ClientboundCodeOfConductPacket: the game shows it and answers with
    /// `Session::accept_code_of_conduct` or a disconnect; until then the
    /// server waits in configuration.
    CodeOfConduct(String),
    /// `ClientboundTransferPacket`: the server sent us to another address.
    /// The connection ends right after; the game reconnects there with the
    /// stored cookies.
    Transfer {
        host: String,
        port: i32,
    },
    /// `ClientboundServerLinksPacket`: the links the pause menu's "Server
    /// Links..." lists (ClientCommonPacketListenerImpl.handleServerLinks).
    ServerLinks(Vec<cfg::ServerLink>),
    /// The connection ended. `from_server`: the server gave the reason (or
    /// the connection was refused for good), rather than the connection
    /// failing (auto-reconnect retries only failures and shutdowns).
    Disconnected {
        reason: String,
        /// The reason's translation key, when it had one
        /// (`reconnect::allowed` classifies by it).
        key: Option<String>,
        from_server: bool,
    },
}

pub struct Session {
    events: Receiver<Event>,
    writer: Arc<Mutex<Option<ConnWriter>>>,
    /// The connection is in configuration (else in play). Changed only
    /// with `writer` locked, as the packet that switches is sent.
    configuring: Arc<AtomicBool>,
    thread: Option<JoinHandle<()>>,
    pub address: String,
    pub name: String,
    pub counters: Arc<Mutex<Option<Arc<Counters>>>>,
    /// The cookies this server stored on us (`ClientboundStoreCookiePacket`).
    pub cookies: Cookies,
    /// HORIZON_NET_DEBUG=1 logs every packet sent from the game thread.
    debug: bool,
    /// The far terrain requests waiting for the server (`lod_net`).
    far: Arc<crate::lod_net::Inbox>,
    /// Active packet recorder for Studio replay recordings.
    pub recorder: Arc<Mutex<Option<StudioRecorder>>>,
}
impl Session {
    /// Start connecting in the background, as `auth`'s account when there is one.
    pub fn connect(
        address: &str,
        name: &str,
        auth: Option<Arc<AuthSession>>,
        info: cfg::ClientInformation,
        lang: Arc<Language>,
        resources: PathBuf,
    ) -> Self {
        Self::start(
            address, name, auth, info, lang, None, None, resources, false,
        )
    }
    /// `ClientHandshakePacketListenerImpl.handleHello`: LAN entries can continue
    /// after session authentication fails; the server still decides whether to admit them.
    /// Only for entries selected from LAN discovery, not addresses classified by IP.
    pub fn connect_lan(
        address: &str,
        name: &str,
        auth: Option<Arc<AuthSession>>,
        info: cfg::ClientInformation,
        lang: Arc<Language>,
        resources: PathBuf,
    ) -> Self {
        Self::start(address, name, auth, info, lang, None, None, resources, true)
    }
    /// `ConnectScreen.startConnecting` for a `transfer`: the cookies the
    /// server stored carry to the new connection (`TransferState`).
    pub fn connect_transferred(
        address: &str,
        name: &str,
        auth: Option<Arc<AuthSession>>,
        info: cfg::ClientInformation,
        lang: Arc<Language>,
        cookies: Cookies,
        resources: PathBuf,
    ) -> Self {
        Self::start(
            address,
            name,
            auth,
            info,
            lang,
            None,
            Some(cookies),
            resources,
            false,
        )
    }
    /// Join an integrated server through memory (`Connection.connectToLocalServer`).
    pub fn connect_local(
        pipe: horizon_protocol::connection::Pipe,
        name: &str,
        info: cfg::ClientInformation,
        lang: Arc<Language>,
        resources: PathBuf,
    ) -> Self {
        Self::start(
            "local",
            name,
            None,
            info,
            lang,
            Some(pipe),
            None,
            resources,
            false,
        )
    }
    fn start(
        address: &str,
        name: &str,
        auth: Option<Arc<AuthSession>>,
        info: cfg::ClientInformation,
        lang: Arc<Language>,
        local: Option<horizon_protocol::connection::Pipe>,
        cookies: Option<Cookies>,
        resources: PathBuf,
        lan: bool,
    ) -> Self {
        let (send, events) = channel();
        let writer = Arc::new(Mutex::new(None));
        let configuring = Arc::new(AtomicBool::new(true));
        let counters = Arc::new(Mutex::new(None));
        // Connection.initiateServerboundPlayConnection: a transfer's
        // handshake says so (ClientIntent.TRANSFER).
        let transferred = cookies.is_some();
        let cookies = cookies.unwrap_or_default();
        let (thread_writer, thread_counters, thread_cookies) =
            (writer.clone(), counters.clone(), cookies.clone());
        let thread_configuring = configuring.clone();
        let far = Arc::new(crate::lod_net::Inbox::default());
        let thread_far = far.clone();
        let recorder = Arc::new(Mutex::new(None));
        let thread_recorder = recorder.clone();
        let (address_owned, name_owned) = (address.to_owned(), name.to_owned());
        let thread = std::thread::Builder::new()
            .name("horizon-net".into())
            .spawn(move || {
                let result = run(
                    local,
                    &address_owned,
                    &name_owned,
                    auth.as_deref(),
                    info,
                    &lang,
                    &send,
                    &thread_writer,
                    &thread_configuring,
                    &thread_counters,
                    &thread_cookies,
                    &thread_far,
                    transferred,
                    &resources,
                    lan,
                    &thread_recorder,
                );
                thread_far.cancel();
                let from_server = result.is_ok();
                let why = result.unwrap_or_else(|e| e);
                if let Some(w) = thread_writer.lock().unwrap().take() {
                    w.shutdown();
                }
                let _ = send.send(Event::Disconnected {
                    reason: why.text,
                    key: why.key,
                    from_server,
                });
            })
            .ok();
        let debug = std::env::var_os("HORIZON_NET_DEBUG").is_some();
        Self {
            events,
            writer,
            configuring,
            thread,
            address: address.to_owned(),
            name: name.to_owned(),
            counters,
            cookies,
            debug,
            far,
            recorder,
        }
    }
    /// Everything received since the last poll.
    pub fn poll(&self) -> Vec<Event> {
        self.events.try_iter().collect()
    }
    /// Start recording network packets to `.mcpr` format at `path`.
    pub fn start_recording(
        &self,
        path: impl Into<PathBuf>,
        metadata: Metadata,
    ) -> std::io::Result<()> {
        let rec = StudioRecorder::start(path.into(), metadata)?;
        *self.recorder.lock().unwrap() = Some(rec);
        Ok(())
    }
    /// Stop recording and finalize the `.mcpr` archive.
    pub fn stop_recording(&self) -> Option<std::io::Result<PathBuf>> {
        let rec = self.recorder.lock().unwrap().take()?;
        Some(rec.stop())
    }
    /// Whether recording is currently active.
    pub fn is_recording(&self) -> bool {
        self.recorder
            .lock()
            .unwrap()
            .as_ref()
            .is_some_and(|r| r.is_active())
    }
    /// Status of the active recording, if any.
    pub fn recorder_status(&self) -> Option<RecorderStatus> {
        self.recorder.lock().unwrap().as_ref().map(|r| r.status())
    }
    /// Send a play packet; silently dropped once the connection is gone,
    /// and while the server has the connection back in configuration (a
    /// proxy switching servers). Vanilla's `handleConfigurationStart` clears
    /// the level before it acknowledges, so no play packet follows the
    /// acknowledgement; one that did would reach the server as a
    /// configuration packet, and Velocity drops such a client.
    pub fn send(&self, packet: play::Serverbound) {
        if self.debug
            && !matches!(
                packet,
                play::Serverbound::ClientTickEnd(_)
                    | play::Serverbound::MovePlayerPos(_)
                    | play::Serverbound::MovePlayerPosRot(_)
            )
        {
            eprintln!("[net] -> {packet:?}");
        }
        let mut writer = self.writer.lock().unwrap();
        if self.configuring.load(Ordering::Relaxed) {
            return;
        }
        if let Some(w) = writer.as_mut()
            && w.send(&packet.encode()).is_err()
        {
            w.shutdown();
        }
    }
    /// Far terrain the server samples, as it offered (`Event::FarTerrain`):
    /// biomes named by this client's indices, block states below `states`.
    pub fn far_terrain(
        &self,
        offer: crate::lod_net::Offer,
        biomes: HashMap<String, u16>,
        states: u32,
    ) -> Arc<crate::lod_net::RemoteSource> {
        crate::lod_net::RemoteSource::new(self.far.clone(), offer, biomes, states)
    }
    /// The far terrain requests its samplers queued go to the server, from
    /// the game thread, among its other packets.
    pub fn send_far_terrain(&self) {
        for data in self.far.requests() {
            self.send(play::Serverbound::CustomPayload(cfg::CustomPayload {
                channel: crate::lod_net::CHANNEL.into(),
                data,
            }));
        }
    }
    /// The far terrain made with [`Self::far_terrain`] ends: its samplers
    /// stop waiting for the server.
    pub fn cancel_far_terrain(&self) {
        self.far.cancel();
    }
    /// The connection is configured again (a proxy's next server): requests
    /// the old server held never come back, so their slots are freed.
    pub fn reset_far_terrain(&self) {
        self.far.reset();
    }
    /// ServerboundResourcePackPacket, in whichever phase the connection is.
    pub fn send_pack_status(&self, id: u128, action: i32) {
        let status = cfg::ResourcePackResponse { id, action };
        let mut writer = self.writer.lock().unwrap();
        let body = if self.configuring.load(Ordering::Relaxed) {
            cfg::Serverbound::ResourcePack(status).encode()
        } else {
            play::Serverbound::ResourcePack(status).encode()
        };
        if let Some(w) = writer.as_mut()
            && w.send(&body).is_err()
        {
            w.shutdown();
        }
    }
    /// ServerboundCustomClickActionPacket (a dialog's answer), in whichever
    /// phase the connection is.
    pub fn send_custom_click(&self, id: &str, payload: Option<horizon_world::nbt::Tag>) {
        let click = cfg::CustomClickAction {
            id: id.to_owned(),
            payload,
        };
        let mut writer = self.writer.lock().unwrap();
        let body = if self.configuring.load(Ordering::Relaxed) {
            cfg::Serverbound::CustomClickAction(click).encode()
        } else {
            play::Serverbound::CustomClickAction(click).encode()
        };
        if let Some(w) = writer.as_mut()
            && w.send(&body).is_err()
        {
            w.shutdown();
        }
    }
    /// ServerboundAcceptCodeOfConductPacket, sent in configuration.
    pub fn accept_code_of_conduct(&self) {
        let mut writer = self.writer.lock().unwrap();
        if let Some(w) = writer.as_mut()
            && w.send(&cfg::Serverbound::AcceptCodeOfConduct(Empty).encode())
                .is_err()
        {
            w.shutdown();
        }
    }
    /// `Connection.disconnect`: the socket closes and the game goes on at once.
    /// The reader thread is left to end on its own: on Windows a shutdown
    /// doesn't wake a read already waiting, so joining it held the window until
    /// the server dropped the connection, many seconds later.
    pub fn disconnect(&mut self) {
        if let Some(w) = self.writer.lock().unwrap().take() {
            w.shutdown();
        }
        drop(self.thread.take());
    }
}
impl Drop for Session {
    fn drop(&mut self) {
        self.disconnect();
    }
}

/// An address of the form `friend:K7QM-3XPD` joins a friend's world through
/// its invite code (horizon-friends): the session goes through a tunnel the
/// client reaches on a loopback port, so everything after is a plain join.
pub const FRIEND: &str = horizon_friends::ADDRESS_PREFIX;

/// An address as players and logs see it: a friend's invite code stays
/// out of it (its secret is in there).
pub fn shown_address(address: &str) -> String {
    match address.strip_prefix(FRIEND) {
        Some(code) => match horizon_friends::invite::parse(code) {
            Some(horizon_friends::invite::Parsed::Short(c)) => {
                format!("Friend's world ({}-****)", c.nameplate)
            }
            _ => "Friend's world".to_owned(),
        },
        None => address.to_owned(),
    }
}

/// The relay the player set (`friendsRelay` in horizon.txt, beside
/// options.txt), else `HORIZON_RELAY_URL`. None by default.
pub fn friends_relay_setting() -> Option<String> {
    let dir = std::env::current_dir().ok()?;
    crate::ui_theme::preference(&dir, "friendsRelay")
        .filter(|r| !r.is_empty())
        .or_else(horizon_friends::relay_url)
}
/// Remember the relay typed on Join a friend (empty forgets it).
pub fn save_friends_relay(relay: &str) {
    if let Ok(dir) = std::env::current_dir() {
        crate::ui_theme::set_preference(&dir, "friendsRelay", (!relay.is_empty()).then_some(relay));
    }
}

/// Reach the friend's world from the code (directly, or through a relay)
/// and open the tunnel: the loopback address to connect to.
fn join_friend(code: &str, lang: &Language, send: &Sender<Event>) -> Result<(String, u16), Reason> {
    use horizon_friends::{
        PathMode,
        guest::{self, GuestConfig},
    };
    status(send, &tr(lang, "horizon.multiplayer.finding_friend"));
    let tunnel = guest::join(&GuestConfig {
        code: code.to_owned(),
        relay: friends_relay_setting(),
        protocol: PROTOCOL_VERSION,
        game: horizon_protocol::GAME_VERSION.to_owned(),
        path: PathMode::from_env(),
    })
    .map_err(|e| Reason::plain(e.to_string()))?;
    status(
        send,
        &if tunnel.direct {
            tr(lang, "horizon.multiplayer.connected_friend_direct")
        } else {
            tr(lang, "horizon.multiplayer.connected_friend_relay")
        },
    );
    let (port, _) = tunnel
        .serve_loopback()
        .map_err(|e| Reason::plain(e.to_string()))?;
    Ok(("127.0.0.1".to_owned(), port))
}

fn status(send: &Sender<Event>, text: &str) {
    let _ = send.send(Event::Status(text.to_owned()));
}

/// Shown when an online-mode server asks a client without an account to authenticate.
pub const NOT_SIGNED_IN: &str = "This server is in online mode. Sign in with your Microsoft account in the Horizon launcher to join it.";

/// A translation, or the key itself (Language.getOrDefault).
fn tr(lang: &Language, key: &str) -> String {
    lang.get(key).cloned().unwrap_or_else(|| key.to_owned())
}

/// Why a connection ended: the shown text and, when the reason was a
/// translatable component or a known Horizon error, its translation key —
/// the auto-reconnect classifies by key (`reconnect::allowed`), the
/// English keyword scan of the text is the fallback for plain reasons.
#[derive(Clone)]
pub struct Reason {
    pub text: String,
    pub key: Option<String>,
}
impl Reason {
    fn plain(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            key: None,
        }
    }
    /// A vanilla key's text in the session's language, with the key.
    fn keyed(key: &str, lang: &Language) -> Self {
        Self {
            text: tr(lang, key),
            key: Some(key.to_owned()),
        }
    }
    /// A Horizon key's text with a `%s` argument filled.
    fn keyed_arg(key: &str, lang: &Language, arg: &str) -> Self {
        let mut r = Self::keyed(key, lang);
        r.text = r.text.replacen("%s", arg, 1);
        r
    }
    /// A server's disconnect component: the resolved text and the
    /// `translate` key when the component named one (servers' literal
    /// kicks have none; their text is the server's own language).
    fn component(reason_json: &str, lang: &Language) -> Self {
        match serde_json::from_str::<serde_json::Value>(reason_json) {
            Ok(v) => Self {
                text: json_text(&v, lang),
                key: v["translate"].as_str().map(str::to_owned),
            },
            Err(_) => Self::plain(reason_json),
        }
    }
    /// The play/configuration phases' disconnect: the reason arrives as
    /// an NBT component.
    fn tag(tag: &Tag, lang: &Language) -> Self {
        let key = match tag {
            Tag::Compound(map) => map
                .get(&JavaString::from("translate"))
                .and_then(|t| match t {
                    Tag::String(s) => s.to_string().ok(),
                    _ => None,
                }),
            _ => None,
        };
        Self {
            text: plain(tag, lang),
            key,
        }
    }
}

/// `ConnectScreen.connect`'s log line, as vanilla writes it from its "Server Connector #N" thread:
/// the address as the player gave it, and the port (25565 when none was given), before any SRV
/// lookup. Other launchers read the last one from `latest.log` to offer the server again.
fn connecting_line(host: &str, port: u16) -> String {
    format!("Connecting to {host}, {port}")
}
fn log_connecting(host: &str, port: u16) {
    // ConnectScreen.UNIQUE_THREAD_ID: the first connector is #1.
    static CONNECTORS: AtomicU32 = AtomicU32::new(0);
    let n = CONNECTORS.fetch_add(1, Ordering::Relaxed) + 1;
    crate::logging::write_as(
        &format!("Server Connector #{n}"),
        log::Level::Info,
        &connecting_line(host, port),
    );
}

/// `Connection$1.initChannel`: a client socket's pipeline starts with
/// `ReadTimeoutHandler(30)`. A server sends a keep-alive every 15 s, so one
/// that sends nothing for 30 s has frozen or dropped off the network.
const READ_TIMEOUT: Duration = Duration::from_secs(30);

/// `ConnectScreen.startConnecting`: the socket to a server, with `read_timeout`
/// ([`READ_TIMEOUT`]) on every read. The friends relay supplies a concrete
/// endpoint, not a Minecraft hostname, so it skips the SRV lookup. Returns the
/// resolved host and port for `ConnectScreen`'s login handshake.
fn connect_tcp(
    host: &str,
    port: u16,
    relayed: bool,
    read_timeout: Duration,
) -> Result<(Connection, String, u16), String> {
    let (c, host, port) = if relayed {
        Connection::connect(host, port, Duration::from_secs(10)).map(|c| (c, host.to_owned(), port))
    } else {
        Connection::connect_server_with_address(host, port, Duration::from_secs(10))
    }
    .map_err(|e| e.to_string())?;
    c.reader
        .set_read_timeout(Some(read_timeout))
        .map_err(|e| e.to_string())?;
    Ok((c, host, port))
}

/// Whether joining servers of older releases is on (roadmap `older-servers`): off by default while the
/// adapter is incomplete; `HORIZON_OLDER_SERVERS=1` turns it on.
pub fn older_servers_enabled() -> bool {
    std::env::var_os("HORIZON_OLDER_SERVERS").is_some_and(|v| v == "1")
}

/// The older release a server speaks, by its status ping, when Horizon can translate it; `None` for the
/// pinned version, an unknown one, a failed ping, or with the feature off.
fn older_server(address: &str) -> Option<horizon_protocol::adapter::ServerVersion> {
    use horizon_protocol::adapter::ServerVersion;
    if !older_servers_enabled() {
        return None;
    }
    let (json, _) = ping(address, Duration::from_secs(5)).ok()?;
    let protocol = i32::try_from(json["version"]["protocol"].as_i64()?).ok()?;
    ServerVersion::from_protocol(protocol).filter(|v| *v != ServerVersion::Current)
}

/// `Connection.exceptionCaught`: a read that timed out ends with
/// `disconnect.timeout`, any other failure with `disconnect.genericReason`
/// ("Internal Exception: ..."); a stream the server closed ends with
/// `disconnect.endOfStream` (`Connection.channelInactive`).
fn connection_lost(e: horizon_protocol::Error, lang: &Language) -> String {
    if e.is_timed_out() {
        tr(lang, "disconnect.timeout")
    } else if e.is_end_of_stream() {
        tr(lang, "disconnect.endOfStream")
    } else {
        plain(
            &translatable(
                "disconnect.genericReason",
                &[&format!("Internal Exception: {e}")],
            ),
            lang,
        )
    }
}

/// `ClientHandshakePacketListenerImpl.handleHello`: the whole connection.
/// Ok: why it ended for good (the server's reason, or
/// a refusal no retry fixes); Err: the connection failed.
fn run(
    local: Option<horizon_protocol::connection::Pipe>,
    address: &str,
    name: &str,
    auth: Option<&AuthSession>,
    info: cfg::ClientInformation,
    lang: &Language,
    send: &Sender<Event>,
    shared_writer: &Mutex<Option<ConnWriter>>,
    configuring: &AtomicBool,
    shared_counters: &Mutex<Option<Arc<Counters>>>,
    cookies: &Cookies,
    far: &crate::lod_net::Inbox,
    transferred: bool,
    resources: &Path,
    lan: bool,
    recorder: &Arc<Mutex<Option<StudioRecorder>>>,
) -> Result<Reason, Reason> {
    let (host, port, mut c) = if let Some(pipe) = local {
        (address.to_owned(), 0, Connection::local(pipe))
    } else {
        let (host, port) = match address.strip_prefix(FRIEND) {
            Some(code) => join_friend(code, lang, send)?,
            None => {
                let Some(target) = parse_address(address) else {
                    // A refusal: never retried (`horizon.multiplayer
                    // .invalid_address` is in reconnect's key list).
                    return Err(Reason::keyed_arg(
                        "horizon.multiplayer.invalid_address",
                        lang,
                        address,
                    ));
                };
                status(send, &tr(lang, "connect.connecting"));
                log_connecting(&target.0, target.1);
                target
            }
        };
        let (mut c, host, port) =
            connect_tcp(&host, port, address.starts_with(FRIEND), READ_TIMEOUT)
                .map_err(Reason::plain)?;
        if !address.starts_with(FRIEND)
            && let Some(version) = older_server(address)
        {
            log::info!("Joining {address} as a {} server", version.name());
            c.adapt(version);
        }
        (host, port, c)
    };
    *shared_counters.lock().unwrap() = Some(c.reader.counters.clone());
    let e = |e: horizon_protocol::Error| Reason::plain(connection_lost(e, lang));
    c.send(
        &handshake::Serverbound::Intention(handshake::Intention {
            protocol: PROTOCOL_VERSION,
            host: host.clone(),
            port,
            intent: if transferred {
                handshake::TRANSFER
            } else {
                handshake::LOGIN
            },
        })
        .encode(),
    )
    .map_err(e)?;
    // Vanilla's login sends the account's profile id, or the offline one.
    let uuid = auth.map_or_else(|| offline_uuid(name), |a| a.uuid);
    c.send(
        &login::Serverbound::Hello(login::ServerHello {
            name: name.to_owned(),
            uuid,
        })
        .encode(),
    )
    .map_err(e)?;
    let profile = loop {
        let (id, payload) = c.recv().map_err(e)?;
        match login::Clientbound::decode(id, &payload).map_err(e)? {
            login::Clientbound::Compression(p) => c.set_compression(p.threshold),
            login::Clientbound::LoginFinished(p) => {
                c.send(&login::Serverbound::LoginAcknowledged(Empty).encode())
                    .map_err(e)?;
                break p.profile;
            }
            login::Clientbound::Disconnect(p) => {
                return Ok(Reason::component(&p.reason_json, lang));
            }
            login::Clientbound::Hello(hello) => {
                status(send, &tr(lang, "connect.authorizing"));
                let key = RsaPublicKey::from_der(&hello.public_key)
                    .map_err(|err| Reason::plain(format!("Protocol error: {err}")))?;
                let secret = generate_secret().map_err(e)?;
                if hello.should_authenticate {
                    let signed_in = auth.is_some();
                    let authenticated = auth
                        .ok_or_else(|| Reason::keyed("horizon.multiplayer.not_signed_in", lang))
                        .and_then(|account| {
                            let hash = server_hash(&hello.server_id, &secret, &hello.public_key);
                            // The session service's refusal: the wrapped
                            // `disconnect.loginFailedInfo` text is shown, and
                            // the inner key (the reason's own) classifies
                            // (`reconnect::allowed`).
                            crate::auth::join_server(account, &hash).map_err(|err| {
                                let (reason, key) = match err.reason() {
                                    Ok(key) => (tr(lang, key), Some(key.to_owned())),
                                    Err(message) => (message.to_owned(), None),
                                };
                                Reason {
                                    text: plain(
                                        &translatable("disconnect.loginFailedInfo", &[&reason]),
                                        lang,
                                    ),
                                    key,
                                }
                            })
                        });
                    if let Err(reason) = authenticated {
                        if !continues_after_failed_join(lan, signed_in) {
                            return Err(reason);
                        }
                        log::warn!("Authentication failed: {}", reason.text);
                    }
                }
                status(send, &tr(lang, "connect.encrypting"));
                c.send(
                    &login::Serverbound::Key(login::Key {
                        key: key.encrypt(&secret).map_err(e)?,
                        challenge: key.encrypt(&hello.challenge).map_err(e)?,
                    })
                    .encode(),
                )
                .map_err(e)?;
                c.enable_encryption(&secret);
            }
            login::Clientbound::CustomQuery(q) => {
                c.send(
                    &login::Serverbound::CustomQueryAnswer(login::CustomQueryAnswer {
                        transaction: q.transaction,
                        payload: None,
                    })
                    .encode(),
                )
                .map_err(e)?;
            }
            // ClientHandshakePacketListenerImpl.handleRequestCookie: the
            // cookies a transfer carried over (none on a plain join).
            login::Clientbound::CookieRequest(q) => {
                let payload = cookies.lock().unwrap().get(&q.key).cloned();
                c.send(
                    &login::Serverbound::CookieResponse(login::CookieResponse {
                        key: q.key,
                        payload,
                    })
                    .encode(),
                )
                .map_err(e)?;
            }
            login::Clientbound::Unknown(..) => {}
        }
    };
    status(send, &tr(lang, "connect.joining"));
    // ClientHandshakePacketListenerImpl.handleLoginFinished: the brand, then
    // the client information.
    c.send(
        &cfg::Serverbound::CustomPayload(cfg::CustomPayload {
            channel: "minecraft:brand".into(),
            data: brand(),
        })
        .encode(),
    )
    .map_err(e)?;
    c.send(&cfg::Serverbound::ClientInformation(info).encode())
        .map_err(e)?;
    let (mut reader, writer) = c.split();
    *shared_writer.lock().unwrap() = Some(writer);
    let registries = configure(
        &mut reader,
        shared_writer,
        configuring,
        lang,
        send,
        cookies,
        resources,
    )?;
    let _ = send.send(Event::Joined {
        registries: Arc::new(registries),
        uuid: profile.uuid,
        name: profile.name,
    });
    receive_play(
        &mut reader,
        shared_writer,
        configuring,
        lang,
        send,
        cookies,
        far,
        resources,
        recorder,
    )
}

fn receive_play(
    reader: &mut ConnReader,
    shared_writer: &Mutex<Option<ConnWriter>>,
    configuring: &AtomicBool,
    lang: &Language,
    send: &Sender<Event>,
    cookies: &Cookies,
    far: &crate::lod_net::Inbox,
    resources: &Path,
    recorder: &Arc<Mutex<Option<StudioRecorder>>>,
) -> Result<Reason, Reason> {
    loop {
        let (id, payload) = reader
            .recv()
            .map_err(|e| Reason::plain(connection_lost(e, lang)))?;
        let packet = match play::Clientbound::decode(id, &payload) {
            Ok(p) => p,
            Err(err) => {
                let name = horizon_protocol::ids::name(
                    horizon_protocol::State::Play,
                    horizon_protocol::Direction::Clientbound,
                    id,
                )
                .unwrap_or("?");
                let _ = send.send(Event::DecodeError(format!("{name}: {err}")));
                continue;
            }
        };
        // Only while a recording runs: the filter copies what it keeps, and re-encodes
        // AddEntity with a fresh UUID.
        if let Some(rec) = recorder.lock().unwrap().as_ref()
            && rec.is_active()
            && let Some((recorded_id, recorded_payload)) =
                studio_recording_packet(&packet, id, &payload)
        {
            rec.record_packet(recorded_id, &recorded_payload);
        }
        let reply = |p: play::Serverbound| {
            if let Some(w) = shared_writer.lock().unwrap().as_mut() {
                let _ = w.send(&p.encode());
            }
        };
        match packet {
            play::Clientbound::KeepAlive(k) => reply(play::Serverbound::KeepAlive(k)),
            play::Clientbound::BundleDelimiter(_) => {}
            play::Clientbound::ResourcePackPush(p) => {
                let _ = send.send(Event::PackPush(p));
            }
            play::Clientbound::ResourcePackPop(p) => {
                let _ = send.send(Event::PackPop(p.id));
            }
            play::Clientbound::StartConfiguration(_) => {
                let _ = send.send(Event::Reconfiguring);
                if let Some(w) = shared_writer.lock().unwrap().as_mut() {
                    let _ = w.send(&play::Serverbound::ConfigurationAcknowledged(Empty).encode());
                    configuring.store(true, Ordering::Relaxed);
                }
                let registries = configure(
                    reader,
                    shared_writer,
                    configuring,
                    lang,
                    send,
                    cookies,
                    resources,
                )?;
                let _ = send.send(Event::Reconfigured(Arc::new(registries)));
            }
            // ClientCommonPacketListenerImpl.handleRequestCookie: the stored
            // cookie (or none) goes straight back.
            play::Clientbound::CookieRequest(q) => {
                let payload = cookies.lock().unwrap().get(&q.key).cloned();
                reply(play::Serverbound::CookieResponse(cfg::CookieResponse {
                    key: q.key,
                    payload,
                }));
            }
            play::Clientbound::StoreCookie(p) => {
                cookies.lock().unwrap().insert(p.key, p.payload);
            }
            play::Clientbound::ServerLinks(p) => {
                let _ = send.send(Event::ServerLinks(p.links));
            }
            // ClientCommonPacketListenerImpl.handleTransfer: the connection
            // ends and the game connects to the other address.
            play::Clientbound::Transfer(p) => {
                let _ = send.send(Event::Transfer {
                    host: p.host,
                    port: p.port,
                });
                return Ok(Reason::keyed("disconnect.transfer", lang));
            }
            play::Clientbound::Disconnect(d) => return Ok(Reason::tag(&d.reason, lang)),
            play::Clientbound::CustomPayload(p) if p.channel == "minecraft:brand" => {
                receive_brand(&p, send);
            }
            // A far tile, straight to the sampler waiting for it.
            play::Clientbound::CustomPayload(p) if p.channel == crate::lod_net::CHANNEL => {
                far.deliver(p.data);
            }
            other => {
                if send.send(Event::Packet(Box::new(other))).is_err() {
                    return Ok(Reason::plain("Disconnected"));
                }
            }
        }
    }
}

/// Return the packet bytes safe to persist in a Studio recording.
///
/// Unknown packets fail closed so a newly added protocol packet cannot bypass
/// the privacy policy. `AddEntity` retains its entity id and state, but gets a
/// fresh UUID so the recording cannot link that entity to an account UUID.
fn studio_recording_packet<'a>(
    packet: &play::Clientbound,
    packet_id: i32,
    payload: &'a [u8],
) -> Option<(i32, std::borrow::Cow<'a, [u8]>)> {
    use play::Clientbound as P;
    use std::borrow::Cow;
    match packet {
        P::AddEntity(entity) => {
            let mut anonymous = entity.clone();
            anonymous.uuid = u128::from_be_bytes(generate_secret().ok()?);
            let encoded = P::AddEntity(anonymous).encode();
            let mut reader = Reader::new(&encoded);
            let id = reader.varint().ok()?;
            Some((id, Cow::Owned(reader.rest().to_vec())))
        }
        P::CookieRequest(_)
        | P::CustomChatCompletions(_)
        | P::CustomPayload(_)
        | P::DeleteChat(_)
        | P::Disconnect(_)
        | P::DisguisedChat(_)
        | P::PlayerChat(_)
        | P::PlayerCombatKill(_)
        | P::PlayerInfoRemove(_)
        | P::PlayerInfoUpdate(_)
        | P::ResetScore(_)
        | P::ResourcePackPush(_)
        | P::ServerLinks(_)
        | P::SetPlayerTeam(_)
        | P::SetScore(_)
        | P::StoreCookie(_)
        | P::SystemChat(_)
        | P::TabList(_)
        | P::TrackedWaypoint(_)
        | P::Transfer(_)
        | P::Unknown(..) => None,
        _ => Some((packet_id, Cow::Borrowed(payload))),
    }
}

/// The configuration phase: registries, tags and known packs until the
/// server finishes it (ClientConfigurationPacketListenerImpl).
fn configure(
    reader: &mut ConnReader,
    writer: &Mutex<Option<ConnWriter>>,
    configuring: &AtomicBool,
    lang: &Language,
    send: &Sender<Event>,
    cookies: &Cookies,
    resources: &Path,
) -> Result<Dynamic, Reason> {
    let mut registries = Dynamic::default();
    let mut content_verified = false;
    let reply = |p: cfg::Serverbound| -> Result<(), Reason> {
        match writer.lock().unwrap().as_mut() {
            Some(w) => w
                .send(&p.encode())
                .map_err(|e| Reason::plain(connection_lost(e, lang))),
            None => Err(Reason::plain("Disconnected")),
        }
    };
    loop {
        let (id, payload) = reader
            .recv()
            .map_err(|e| Reason::plain(connection_lost(e, lang)))?;
        match cfg::Clientbound::decode(id, &payload)
            .map_err(|e| Reason::plain(connection_lost(e, lang)))?
        {
            cfg::Clientbound::KeepAlive(k) => reply(cfg::Serverbound::KeepAlive(k))?,
            cfg::Clientbound::CustomPayload(p) if p.channel == crate::content_identity::CHANNEL => {
                let hash = crate::content_identity::identity(resources)
                    .map_err(|_| Reason::plain(crate::content_identity::MISMATCH.to_string()))?;
                content_verified = p.data == hash;
                reply(cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                    channel: crate::content_identity::CHANNEL.into(),
                    data: hash.to_vec(),
                }))?;
            }
            // The server names its mods; the answer is ours, and the server judges.
            cfg::Clientbound::CustomPayload(p)
                if p.channel == horizon_protocol::mod_list::CHANNEL =>
            {
                reply(cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                    channel: horizon_protocol::mod_list::CHANNEL.into(),
                    data: horizon_protocol::mod_list::encode(&horizon_protocol::mod_list::shared(
                        &horizon_protocol::mod_list::local(),
                    )),
                }))?;
            }
            cfg::Clientbound::CustomPayload(p) => {
                // Horizon servers use the client brand to negotiate their extensions.
                // Announce those only after the server identifies itself as Horizon.
                if p.channel == "minecraft:brand"
                    && horizon_protocol::buf::Reader::new(&p.data)
                        .string(32767)
                        .ok()
                        .as_deref()
                        == Some("horizon")
                {
                    let mut w = horizon_protocol::buf::Writer::new();
                    w.string("horizon");
                    reply(cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                        channel: "minecraft:brand".into(),
                        data: w.data,
                    }))?;
                }
                receive_brand(&p, send);
            }
            cfg::Clientbound::Ping(p) => reply(cfg::Serverbound::Pong(p))?,
            cfg::Clientbound::SelectKnownPacks(p) => {
                reply(cfg::Serverbound::SelectKnownPacks(cfg::SelectKnownPacks {
                    packs: select_known_packs(p.packs),
                }))?
            }
            cfg::Clientbound::UpdateEnabledFeatures(p) => {
                let _ = send.send(Event::Features(p.features));
            }
            cfg::Clientbound::RegistryData(mut r) => {
                fill_known_entries(&mut r, resources);
                registries.add(r);
            }
            cfg::Clientbound::UpdateTags(t) => registries.add_tags(&t),
            cfg::Clientbound::CodeOfConduct(c) => {
                let _ = send.send(Event::CodeOfConduct(c.text));
            }
            // The game answers: it may prompt the player first.
            cfg::Clientbound::ResourcePackPush(p) => {
                let _ = send.send(Event::PackPush(p));
            }
            cfg::Clientbound::ResourcePackPop(p) => {
                let _ = send.send(Event::PackPop(p.id));
            }
            // The game shows it; the answer goes back from there.
            cfg::Clientbound::ShowDialog(d) => {
                let _ = send.send(Event::ShowDialog(d.dialog));
            }
            cfg::Clientbound::ClearDialog(_) => {
                let _ = send.send(Event::ClearDialog);
            }
            cfg::Clientbound::CookieRequest(q) => {
                let payload = cookies.lock().unwrap().get(&q.key).cloned();
                reply(cfg::Serverbound::CookieResponse(cfg::CookieResponse {
                    key: q.key,
                    payload,
                }))?
            }
            cfg::Clientbound::StoreCookie(p) => {
                cookies.lock().unwrap().insert(p.key, p.payload);
            }
            cfg::Clientbound::ServerLinks(p) => {
                let _ = send.send(Event::ServerLinks(p.links));
            }
            cfg::Clientbound::Transfer(p) => {
                let _ = send.send(Event::Transfer {
                    host: p.host,
                    port: p.port,
                });
                return Err(Reason::keyed("disconnect.transfer", lang));
            }
            cfg::Clientbound::Disconnect(d) => return Err(Reason::tag(&d.reason, lang)),
            cfg::Clientbound::FinishConfiguration(_) => {
                registries.custom_components = content_verified;
                let mut w = writer.lock().unwrap_or_else(|e| e.into_inner());
                let w = w.as_mut().ok_or_else(|| Reason::plain("Disconnected"))?;
                w.send(&cfg::Serverbound::FinishConfiguration(Empty).encode())
                    .map_err(|e| Reason::plain(connection_lost(e, lang)))?;
                configuring.store(false, Ordering::Relaxed);
                return Ok(registries);
            }
            _ => {}
        }
    }
}

/// `KnownPacksManager.trySelectingPacks`: the packs of the server's list the
/// client has too. Horizon carries vanilla's core pack (the prepared
/// resources' `data/`), so it names that one when the server offers it, and
/// the server leaves that pack's entries' data out (`fill_known_entries`).
fn select_known_packs(offered: Vec<cfg::KnownPack>) -> Vec<cfg::KnownPack> {
    let (namespace, id, version) = crate::lan::data::CORE_PACK;
    offered
        .into_iter()
        .filter(|p| p.namespace == namespace && p.id == id && p.version == version)
        .collect()
}

/// `RegistryDataCollector`: an entry of a pack both sides know comes without
/// its data, which the client reads from its own copy of the pack
/// (`data/<namespace>/<registry path>/<path>.json`, `Registries.elementsDirPath`).
fn fill_known_entries(r: &mut cfg::RegistryData, resources: &Path) {
    let (registry_ns, registry_path) = r
        .registry
        .split_once(':')
        .unwrap_or(("minecraft", r.registry.as_str()));
    let dir = if registry_ns == "minecraft" {
        registry_path.to_owned()
    } else {
        format!("{registry_ns}/{registry_path}")
    };
    for entry in r.entries.iter_mut().filter(|e| e.data.is_none()) {
        let (ns, path) = entry
            .id
            .split_once(':')
            .unwrap_or(("minecraft", entry.id.as_str()));
        let file = resources
            .join("data")
            .join(ns)
            .join(&dir)
            .join(format!("{path}.json"));
        let json = std::fs::read(&file)
            .ok()
            .and_then(|bytes| serde_json::from_slice::<serde_json::Value>(&bytes).ok());
        if let Some(json) = json {
            entry.data = Some(crate::lan::data::json_to_nbt(&json));
        }
    }
}

fn receive_brand(payload: &cfg::CustomPayload, send: &Sender<Event>) {
    if payload.channel == "minecraft:brand"
        && let Ok(brand) = horizon_protocol::buf::Reader::new(&payload.data).string(32767)
    {
        let _ = send.send(Event::Brand(brand));
    } else if payload.channel == horizon_protocol::quiet::CHANNEL {
        let _ = send.send(Event::QuietCommands);
    } else if payload.channel == horizon_protocol::mod_net::CHANNEL {
        let _ = send.send(Event::ModNet);
    } else if payload.channel == crate::lod_net::CHANNEL
        && let Some(offer) = crate::lod_net::Offer::decode(&payload.data)
    {
        let _ = send.send(Event::FarTerrain(offer));
    }
}

/// `ClientBrandRetriever.getClientModName`: vanilla's default client brand.
fn brand() -> Vec<u8> {
    let mut w = horizon_protocol::buf::Writer::new();
    w.string("vanilla");
    w.data
}

/// Flatten a JSON chat component (login disconnects are JSON).
pub fn json_text(v: &serde_json::Value, lang: &Language) -> String {
    match v {
        serde_json::Value::String(s) => s.clone(),
        serde_json::Value::Array(a) => a.iter().map(|e| json_text(e, lang)).collect(),
        serde_json::Value::Object(o) => {
            let mut out = if let Some(t) = o.get("text").and_then(|t| t.as_str()) {
                t.to_owned()
            } else if let Some(key) = o.get("translate").and_then(|t| t.as_str()) {
                let args: Vec<String> = o
                    .get("with")
                    .and_then(|w| w.as_array())
                    .map(|a| a.iter().map(|e| json_text(e, lang)).collect())
                    .unwrap_or_default();
                let pattern = lang
                    .get(key)
                    .cloned()
                    .or_else(|| {
                        o.get("fallback")
                            .and_then(|f| f.as_str())
                            .map(str::to_owned)
                    })
                    .unwrap_or_else(|| key.to_owned());
                horizon_protocol::text::format_java(&pattern, &args)
            } else {
                String::new()
            };
            if let Some(extra) = o.get("extra").and_then(|e| e.as_array()) {
                for e in extra {
                    out.push_str(&json_text(e, lang));
                }
            }
            out
        }
        other => other.to_string(),
    }
}

/// The language a session resolves server-sent components with: the selected
/// one as `lang` loaded it (`en_us` under it, packs included), so a menu title
/// the server sends as a key follows the language screen. A process with no
/// language set (a dedicated server's log) reads en_us.json.
pub fn load_language(resources: &std::path::Path) -> Language {
    if let Some(lang) = crate::lang::current() {
        return lang.map().clone();
    }
    // No language screen ran (a dedicated server's log): en_us, with
    // Horizon's own strings included — the net thread resolves keys with
    // this map (`Reason::keyed`).
    horizon_client_core::lang::Language::load(&[&resources.to_path_buf()], "en_us")
        .map()
        .clone()
}

/// Ask a server for its status (ServerStatusPinger): MOTD, players and the
/// round trip time in milliseconds.
pub fn ping(address: &str, timeout: Duration) -> Result<(serde_json::Value, u128), String> {
    use horizon_protocol::packets::status;
    let (host, port) = parse_address(address).ok_or("Invalid address")?;
    let mut c = Connection::connect_server(&host, port, timeout).map_err(|e| e.to_string())?;
    c.reader
        .set_read_timeout(Some(timeout))
        .map_err(|e| e.to_string())?;
    let e = |e: horizon_protocol::Error| e.to_string();
    c.send(
        &handshake::Serverbound::Intention(handshake::Intention {
            protocol: PROTOCOL_VERSION,
            host: host.clone(),
            port,
            intent: handshake::STATUS,
        })
        .encode(),
    )
    .map_err(e)?;
    c.send(&status::Serverbound::StatusRequest(Empty).encode())
        .map_err(e)?;
    let (id, payload) = c.recv().map_err(e)?;
    let json = match status::Clientbound::decode(id, &payload).map_err(e)? {
        status::Clientbound::StatusResponse(s) => {
            serde_json::from_str(&s.json).map_err(|e| e.to_string())?
        }
        _ => return Err("unexpected status reply".into()),
    };
    let start = std::time::Instant::now();
    c.send(&status::Serverbound::PingRequest(status::Ping { time: 1 }).encode())
        .map_err(e)?;
    let _ = c.recv().map_err(e)?;
    Ok((json, start.elapsed().as_millis()))
}

/// What a server that answers only the legacy ping reports
/// (`LegacyServerPinger.Output.handleResponse`).
#[derive(Clone, Debug, PartialEq)]
pub struct LegacyStatus {
    pub protocol: i32,
    pub version: String,
    pub motd: String,
    pub players: i32,
    pub max_players: i32,
}

/// `Mth.getInt(str, default)`.
fn legacy_int(s: &str, default: i32) -> i32 {
    s.parse().unwrap_or(default)
}

/// `LegacyServerPinger.channelRead0` on the string after the 0xFF byte: split
/// on NUL (at most 6 parts) and the first part must be `§1`.
fn parse_legacy_status(text: &str) -> Option<LegacyStatus> {
    let parts: Vec<&str> = text.splitn(6, '\0').collect();
    if parts.first() != Some(&"\u{a7}1") || parts.len() < 6 {
        return None;
    }
    Some(LegacyStatus {
        protocol: legacy_int(parts[1], 0),
        version: parts[2].to_owned(),
        motd: parts[3].to_owned(),
        players: legacy_int(parts[4], -1),
        max_players: legacy_int(parts[5], -1),
    })
}

/// `LegacyProtocolUtils.writeLegacyString`: the UTF-16 length, then UTF-16BE.
fn write_legacy_string(out: &mut Vec<u8>, s: &str) {
    let units: Vec<u16> = s.encode_utf16().collect();
    out.extend_from_slice(&(units.len() as u16).to_be_bytes());
    for unit in units {
        out.extend_from_slice(&unit.to_be_bytes());
    }
}

/// `LegacyServerPinger.channelActive`: the 1.6 `0xFE 0x01 0xFA MC|PingHost` request.
fn legacy_ping_request(host: &str, port: u16) -> Vec<u8> {
    let mut out = vec![254, 1, 250];
    write_legacy_string(&mut out, "MC|PingHost");
    let mut payload = vec![127];
    write_legacy_string(&mut payload, host);
    payload.extend_from_slice(&i32::from(port).to_be_bytes());
    out.extend_from_slice(&(payload.len() as u16).to_be_bytes());
    out.extend_from_slice(&payload);
    out
}

/// `ServerStatusPinger.pingLegacyServer`: ask a server that does not answer
/// the status handshake with the pre-1.7 ping.
pub fn ping_legacy(address: &str, timeout: Duration) -> Result<LegacyStatus, String> {
    let (host, port) = parse_address(address).ok_or("Invalid address")?;
    let mut c = Connection::connect_server(&host, port, timeout).map_err(|e| e.to_string())?;
    c.reader
        .set_read_timeout(Some(timeout))
        .map_err(|e| e.to_string())?;
    let e = |e: horizon_protocol::Error| e.to_string();
    c.writer
        .write_raw(&legacy_ping_request(&host, port))
        .map_err(e)?;
    let head = c.reader.read_raw(3).map_err(e)?;
    if head[0] != 255 {
        return Err("unexpected legacy reply".into());
    }
    let units = usize::from(u16::from_be_bytes([head[1], head[2]]));
    let bytes = c.reader.read_raw(units * 2).map_err(e)?;
    let units: Vec<u16> = bytes
        .as_chunks::<2>()
        .0
        .iter()
        .map(|p| u16::from_be_bytes(*p))
        .collect();
    parse_legacy_status(&String::from_utf16_lossy(&units))
        .ok_or_else(|| "unexpected legacy reply".to_owned())
}

/// `ClientHandshakePacketListenerImpl.handleHello`: a failed session join goes
/// on to encryption only for an entry picked from LAN discovery
/// (`ServerData.isLan`), and the host decides. A vanilla client always has an
/// account; Horizon without one never joins anything (Mojang's rules: no play
/// without an account that owns the game), LAN included.
fn continues_after_failed_join(lan: bool, signed_in: bool) -> bool {
    lan && signed_in
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pack(namespace: &str, id: &str, version: &str) -> cfg::KnownPack {
        cfg::KnownPack {
            namespace: namespace.into(),
            id: id.into(),
            version: version.into(),
        }
    }

    #[test]
    fn the_client_knows_vanilla_core_pack_of_its_own_version_only() {
        let core = pack("minecraft", "core", horizon_protocol::GAME_VERSION);
        let offered = vec![
            core.clone(),
            pack(
                "minecraft",
                "trade_rebalance",
                horizon_protocol::GAME_VERSION,
            ),
            pack("example", "server_pack", "1"),
        ];
        assert_eq!(select_known_packs(offered), vec![core]);
        assert_eq!(
            select_known_packs(vec![pack("minecraft", "core", "1.21.11")]),
            vec![]
        );
        assert_eq!(select_known_packs(vec![]), vec![]);
    }

    #[test]
    fn a_known_entry_takes_its_data_from_the_clients_pack() {
        let root = std::env::temp_dir().join(format!("hz-known-entries-{}", std::process::id()));
        let dir = root.join("data/minecraft/damage_type");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(
            dir.join("in_fire.json"),
            br#"{"message_id": "inFire", "exhaustion": 0.1, "scaling": "when_caused_by_living_non_player"}"#,
        )
        .unwrap();
        let sent = Tag::compound(vec![(
            "message_id",
            Tag::String(JavaString::from("custom")),
        )]);
        let mut r = cfg::RegistryData {
            registry: "minecraft:damage_type".into(),
            entries: vec![
                cfg::RegistryEntry {
                    id: "minecraft:in_fire".into(),
                    data: None,
                },
                cfg::RegistryEntry {
                    id: "minecraft:custom".into(),
                    data: Some(sent.clone()),
                },
                cfg::RegistryEntry {
                    id: "minecraft:missing".into(),
                    data: None,
                },
            ],
        };
        fill_known_entries(&mut r, &root);
        std::fs::remove_dir_all(&root).unwrap();
        let Some(Tag::Compound(filled)) = &r.entries[0].data else {
            panic!("in_fire was not filled: {:?}", r.entries[0].data);
        };
        assert_eq!(
            filled.get(&JavaString::from("message_id")),
            Some(&Tag::String(JavaString::from("inFire")))
        );
        // Data the server sent stays; an entry the client has no file for stays empty.
        assert_eq!(r.entries[1].data, Some(sent));
        assert_eq!(r.entries[2].data, None);
    }

    /// Launchers find the last server joined in `latest.log` by vanilla's line.
    #[test]
    fn the_connecting_line_is_vanillas() {
        let line = |address: &str| {
            let (host, port) = parse_address(address).unwrap();
            connecting_line(&host, port)
        };
        assert_eq!(
            line("play.example.net"),
            "Connecting to play.example.net, 25565"
        );
        assert_eq!(
            line("play.example.net:25577"),
            "Connecting to play.example.net, 25577"
        );
        assert_eq!(line("[::1]:25566"), "Connecting to ::1, 25566");
    }

    #[test]
    fn studio_recording_drops_packets_with_direct_player_identity_or_private_text() {
        use horizon_protocol::packets::configuration::{
            ResourcePackPush, ServerLink, ServerLinkKind, ServerLinks, StoreCookie, Transfer,
        };
        use play::{
            ChatTypeBound, Clientbound as P, CustomChatCompletions, PlayerInfo, PlayerInfoRemove,
            PlayerInfoUpdate, ResetScore, SetPlayerTeam, SetScore, TrackedWaypoint, WaypointId,
            WaypointTarget,
        };

        let packets = [
            P::CookieRequest(cfg::CookieRequest {
                key: "private_cookie".into(),
            }),
            P::CustomChatCompletions(CustomChatCompletions {
                action: 2,
                entries: vec!["/msg PlayerName private text".into()],
            }),
            P::CustomPayload(cfg::CustomPayload {
                channel: "private:channel".into(),
                data: b"private payload".to_vec(),
            }),
            P::DeleteChat(play::DeleteChat {
                signature: (3, Some(vec![1, 2, 3])),
            }),
            P::DisguisedChat(play::DisguisedChat {
                message: Tag::String("private message".into()),
                chat_type: ChatTypeBound {
                    chat_type: 0,
                    name: Tag::String("PlayerName".into()),
                    target: None,
                },
            }),
            P::PlayerCombatKill(play::PlayerCombatKill {
                id: 7,
                message: Tag::String("PlayerName was slain".into()),
            }),
            P::PlayerChat(play::PlayerChat {
                global_index: 1,
                sender: 7,
                index: 2,
                signature: None,
                content: "private message".into(),
                timestamp: 3,
                salt: 4,
                last_seen: vec![],
                unsigned_content: None,
                filter: (0, vec![]),
                chat_type: ChatTypeBound {
                    chat_type: 0,
                    name: Tag::String("PlayerName".into()),
                    target: None,
                },
            }),
            P::ResetScore(ResetScore {
                owner: "PlayerName".into(),
                objective: Some("deaths".into()),
            }),
            P::SetScore(SetScore {
                owner: "PlayerName".into(),
                objective: "deaths".into(),
                score: 1,
                display: None,
                number_format: None,
            }),
            P::PlayerInfoRemove(PlayerInfoRemove { uuids: vec![7] }),
            P::PlayerInfoUpdate(PlayerInfoUpdate {
                actions: 1,
                entries: vec![PlayerInfo {
                    uuid: 7,
                    name: Some("PlayerName".into()),
                    ..PlayerInfo::default()
                }],
            }),
            P::ResourcePackPush(ResourcePackPush {
                id: 8,
                url: "https://private.example/pack.zip".into(),
                hash: "hash".into(),
                required: false,
                prompt: None,
            }),
            P::ServerLinks(ServerLinks {
                links: vec![ServerLink {
                    kind: ServerLinkKind::Known(0),
                    link: "https://private.example".into(),
                }],
            }),
            P::SetPlayerTeam(SetPlayerTeam {
                name: "red".into(),
                method: 3,
                parameters: None,
                players: vec!["PlayerName".into()],
            }),
            P::StoreCookie(StoreCookie {
                key: "private_cookie".into(),
                payload: b"secret".to_vec(),
            }),
            P::SystemChat(play::SystemChat {
                content: Tag::String("private message".into()),
                overlay: false,
            }),
            P::TabList(play::TabList {
                header: Tag::String("PlayerName".into()),
                footer: Tag::End,
            }),
            P::TrackedWaypoint(TrackedWaypoint {
                operation: play::waypoint_operation::TRACK,
                id: WaypointId::Uuid(7),
                style: "minecraft:default".into(),
                color: None,
                target: WaypointTarget::Empty,
            }),
            P::Transfer(Transfer {
                host: "private.example".into(),
                port: 25565,
            }),
            P::Disconnect(cfg::Disconnect {
                reason: Tag::String("PlayerName was disconnected".into()),
            }),
            P::Unknown(999, b"unclassified private payload".to_vec()),
        ];

        for packet in packets {
            assert!(
                studio_recording_packet(&packet, packet.id(), b"raw packet payload").is_none(),
                "{} should be excluded from recordings",
                packet.name()
            );
        }
    }

    #[test]
    fn studio_recording_replaces_entity_uuids_but_keeps_entity_state() {
        let original = play::AddEntity {
            id: 18,
            uuid: 0x0102_0304_0506_0708_090a_0b0c_0d0e_0f10,
            kind: 42,
            position: [1.0, 64.0, -2.0],
            velocity: [0.0, 0.0, 0.0],
            pitch: 1,
            yaw: 2,
            head_yaw: 3,
            data: 4,
        };
        let packet = play::Clientbound::AddEntity(original.clone());
        let (id, payload) = studio_recording_packet(&packet, packet.id(), b"unused").unwrap();
        let play::Clientbound::AddEntity(recorded) =
            play::Clientbound::decode(id, &payload).unwrap()
        else {
            panic!("sanitized packet changed type")
        };

        assert_ne!(recorded.uuid, original.uuid);
        assert_eq!(recorded.id, original.id);
        assert_eq!(recorded.kind, original.kind);
        assert_eq!(recorded.position, original.position);
        assert_eq!(recorded.velocity, original.velocity);
        assert_eq!(recorded.pitch, original.pitch);
        assert_eq!(recorded.yaw, original.yaw);
        assert_eq!(recorded.head_yaw, original.head_yaw);
        assert_eq!(recorded.data, original.data);
    }

    #[test]
    fn direct_login_preserves_hostname_and_negotiates_brand() {
        for server_brand in [
            b"\x07vanilla".as_slice(),
            b"\x07horizon",
            b"\x05Paper",
            b"\xff",
        ] {
            let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let port = listener.local_addr().unwrap().port();
            let session = Session::connect(
                &format!("localhost:{port}"),
                "Probe",
                None,
                cfg::ClientInformation::new(8),
                Arc::new(Language::new()),
                PathBuf::new(),
            );
            let (stream, _) = listener.accept().unwrap();
            stream
                .set_read_timeout(Some(Duration::from_secs(5)))
                .unwrap();
            let mut server = Connection::from_stream(stream).unwrap();
            let (id, body) = server.recv().unwrap();
            let handshake::Serverbound::Intention(packet) =
                handshake::Serverbound::decode(id, &body).unwrap()
            else {
                panic!("expected login handshake")
            };
            assert_eq!((packet.host.as_str(), packet.port), ("localhost", port));
            assert_eq!(packet.intent, handshake::LOGIN);
            server.recv().unwrap(); // login profile
            server
                .send(
                    &login::Clientbound::LoginFinished(login::LoginFinished {
                        profile: login::GameProfile {
                            uuid: 1,
                            name: "Probe".into(),
                            properties: vec![],
                        },
                        session: 1,
                    })
                    .encode(),
                )
                .unwrap();
            let (id, body) = server.recv().unwrap();
            assert!(matches!(
                login::Serverbound::decode(id, &body).unwrap(),
                login::Serverbound::LoginAcknowledged(_)
            ));
            // handleLoginFinished: the brand first, then the information.
            let (id, body) = server.recv().unwrap();
            assert_eq!(
                cfg::Serverbound::decode(id, &body).unwrap(),
                cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                    channel: "minecraft:brand".into(),
                    data: b"\x07vanilla".to_vec(),
                })
            );
            let (id, body) = server.recv().unwrap();
            assert!(matches!(
                cfg::Serverbound::decode(id, &body).unwrap(),
                cfg::Serverbound::ClientInformation(_)
            ));
            server
                .send(
                    &cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                        channel: "minecraft:brand".into(),
                        data: server_brand.to_vec(),
                    })
                    .encode(),
                )
                .unwrap();
            server
                .send(
                    &cfg::Clientbound::SelectKnownPacks(cfg::SelectKnownPacks { packs: vec![] })
                        .encode(),
                )
                .unwrap();
            if server_brand == b"\x07horizon" {
                let (id, body) = server.recv().unwrap();
                assert_eq!(
                    cfg::Serverbound::decode(id, &body).unwrap(),
                    cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                        channel: "minecraft:brand".into(),
                        data: b"\x07horizon".to_vec(),
                    })
                );
            }
            // The response to the pack query proves any brand reply precedes it.
            // Non-Horizon servers must receive no additional brand announcement.
            let (id, body) = server.recv().unwrap();
            assert_eq!(
                cfg::Serverbound::decode(id, &body).unwrap(),
                cfg::Serverbound::SelectKnownPacks(cfg::SelectKnownPacks { packs: vec![] })
            );
            drop(server);
            drop(session);
        }
    }

    #[test]
    fn legacy_ping_request_is_the_1_6_ping_host_packet() {
        let bytes = legacy_ping_request("a.b", 25565);
        assert_eq!(&bytes[..3], &[254, 1, 250]);
        // "MC|PingHost": 11 chars.
        assert_eq!(&bytes[3..5], &[0, 11]);
        let after = 5 + 22;
        // payload: 127, string (2 + 6 bytes), port.
        assert_eq!(&bytes[after..after + 2], &[0, 1 + 2 + 6 + 4]);
        assert_eq!(bytes[after + 2], 127);
        assert_eq!(&bytes[after + 3..after + 5], &[0, 3]);
        assert_eq!(&bytes[bytes.len() - 4..], &25565i32.to_be_bytes());
    }

    #[test]
    fn legacy_status_is_split_on_nul_after_the_section_one_marker() {
        let status =
            parse_legacy_status("\u{a7}1\x00127\x001.6.4\x00A \u{a7}aserver\x003\x0020").unwrap();
        assert_eq!(
            status,
            LegacyStatus {
                protocol: 127,
                version: "1.6.4".into(),
                motd: "A \u{a7}aserver".into(),
                players: 3,
                max_players: 20,
            }
        );
        // Unparsable counts are -1, a wrong marker is no status.
        let status = parse_legacy_status("\u{a7}1\x00x\x00v\x00m\x00?\x00?").unwrap();
        assert_eq!(
            (status.protocol, status.players, status.max_players),
            (0, -1, -1)
        );
        assert!(parse_legacy_status("kick\x00127\x00v\x00m\x001\x002").is_none());
    }

    /// The en_us text of the disconnect reasons.
    fn disconnect_language() -> Language {
        [
            ("disconnect.timeout", "Timed out"),
            ("disconnect.endOfStream", "End of stream"),
            ("disconnect.genericReason", "%s"),
        ]
        .into_iter()
        .map(|(k, v)| (k.to_owned(), v.to_owned()))
        .collect()
    }

    #[test]
    fn a_server_that_stops_answering_times_out() {
        // The server accepts and then sends nothing, like a frozen server
        // or a network gone without a reset.
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        let held = std::thread::spawn(move || listener.accept().map(|(stream, _)| stream));
        let (c, _, _) = connect_tcp("127.0.0.1", port, true, Duration::from_millis(300)).unwrap();
        let _server = held.join().unwrap().unwrap();
        let (mut reader, writer) = c.split();
        let (done, result) = channel();
        std::thread::spawn(move || {
            let (send, _events) = channel();
            let _ = done.send(receive_play(
                &mut reader,
                &Mutex::new(Some(writer)),
                &AtomicBool::new(false),
                &disconnect_language(),
                &send,
                &Cookies::default(),
                &crate::lod_net::Inbox::default(),
                Path::new("."),
                &Arc::new(Mutex::new(None)),
            ));
        });
        let ended = result
            .recv_timeout(Duration::from_secs(10))
            .expect("the connection never timed out");
        assert_eq!(
            ended.map(|r| r.text).map_err(|r| r.text),
            Err("Timed out".to_owned())
        );
    }

    #[test]
    fn lost_connections_read_like_vanillas_disconnect_reasons() {
        let lang = disconnect_language();
        let lost = |e| connection_lost(e, &lang);
        assert_eq!(lost(horizon_protocol::Error::timed_out()), "Timed out");
        assert_eq!(
            lost(horizon_protocol::Error::end_of_stream()),
            "End of stream"
        );
        assert_eq!(
            lost(horizon_protocol::Error::new("Bad VarInt")),
            "Internal Exception: Bad VarInt"
        );
    }

    #[test]
    fn configuration_answers_the_content_identity_challenge() {
        let root =
            std::env::temp_dir().join(format!("horizon-content-identity-{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(
            root.join("facts.json"),
            br#"{"states":[["minecraft:stone",false,false,"Block{minecraft:stone}",{"id":"minecraft:stone"}]]}"#,
        )
        .unwrap();
        let expected = crate::content_identity::identity(&root).unwrap();
        let (client, server) = horizon_protocol::connection::Pipe::pair();
        let (mut reader, writer) = Connection::local(client).split();
        let writer = Mutex::new(Some(writer));
        let thread = std::thread::spawn(move || {
            let (send, _events) = channel();
            configure(
                &mut reader,
                &writer,
                &AtomicBool::new(true),
                &Language::new(),
                &send,
                &Cookies::default(),
                &root,
            )
        });
        let mut server = Connection::local(server);
        server
            .send(
                &cfg::Clientbound::CustomPayload(cfg::CustomPayload {
                    channel: crate::content_identity::CHANNEL.into(),
                    data: vec![],
                })
                .encode(),
            )
            .unwrap();
        server
            .send(&cfg::Clientbound::Ping(cfg::Ping { id: 17 }).encode())
            .unwrap();
        let (id, body) = server.recv().unwrap();
        assert_eq!(
            cfg::Serverbound::decode(id, &body).unwrap(),
            cfg::Serverbound::CustomPayload(cfg::CustomPayload {
                channel: crate::content_identity::CHANNEL.into(),
                data: expected.to_vec(),
            })
        );
        let (id, body) = server.recv().unwrap();
        assert_eq!(
            cfg::Serverbound::decode(id, &body).unwrap(),
            cfg::Serverbound::Pong(cfg::Ping { id: 17 })
        );
        server
            .send(&cfg::Clientbound::FinishConfiguration(Empty).encode())
            .unwrap();
        let (id, body) = server.recv().unwrap();
        assert_eq!(
            cfg::Serverbound::decode(id, &body).unwrap(),
            cfg::Serverbound::FinishConfiguration(Empty)
        );
        assert!(thread.join().unwrap().is_ok());
        std::fs::remove_dir_all(
            std::env::temp_dir().join(format!("horizon-content-identity-{}", std::process::id())),
        )
        .unwrap();
    }

    #[test]
    fn disconnect_and_drop_do_not_wait_for_a_stalled_reader() {
        // A reader can remain stalled after Windows socket shutdown. It must
        // not delay either an explicit leave or Session's Drop on the UI thread.
        for explicit_disconnect in [true, false] {
            let (client, _server) = horizon_protocol::connection::Pipe::pair();
            let (_reader, writer) = Connection::local(client).split();
            let writer = Arc::new(Mutex::new(Some(writer)));
            let (_send, events) = channel();
            let (release, stalled) = channel();
            let (finished, completed) = channel();
            let thread = std::thread::spawn(move || {
                let _ = stalled.recv_timeout(std::time::Duration::from_secs(3));
                let _ = finished.send(());
            });
            let mut session = Session {
                events,
                writer: writer.clone(),
                configuring: Arc::new(AtomicBool::new(false)),
                thread: Some(thread),
                address: "local".into(),
                name: "TestPlayer".into(),
                counters: Arc::new(Mutex::new(None)),
                cookies: Cookies::default(),
                debug: false,
                far: Arc::default(),
                recorder: Arc::new(Mutex::new(None)),
            };
            let started = std::time::Instant::now();
            if explicit_disconnect {
                session.disconnect();
                session.disconnect(); // Repeated cleanup is harmless.
            }
            drop(session);
            let elapsed = started.elapsed();
            let reader_still_pending = completed.try_recv().is_err();
            // Always release the synthetic reader before asserting, even if
            // a future regression restores the blocking join.
            let _ = release.send(());
            if reader_still_pending {
                completed
                    .recv_timeout(std::time::Duration::from_secs(2))
                    .unwrap();
            }
            assert!(
                writer.lock().unwrap().is_none(),
                "connection was not closed"
            );
            assert!(
                reader_still_pending,
                "disconnect waited for the stalled reader"
            );
            assert!(
                elapsed < std::time::Duration::from_secs(1),
                "disconnect took {elapsed:?}"
            );
        }
    }

    #[test]
    fn pings_wait_behind_teleports_but_keepalives_do_not_wait_for_the_game() {
        let (client, server) = horizon_protocol::connection::Pipe::pair();
        let (mut reader, writer) = Connection::local(client).split();
        let writer = Arc::new(Mutex::new(Some(writer)));
        let (send, events) = channel();
        let thread_writer = writer.clone();
        let thread = std::thread::spawn(move || {
            receive_play(
                &mut reader,
                &thread_writer,
                &AtomicBool::new(false),
                &Language::new(),
                &send,
                &Cookies::default(),
                &crate::lod_net::Inbox::default(),
                Path::new("."),
                &Arc::new(Mutex::new(None)),
            )
        });
        let mut server = Connection::local(server);
        let teleport = play::Clientbound::PlayerPosition(play::PlayerPosition {
            teleport: 42,
            position: [10.0, 64.0, 10.0],
            delta: [0.0; 3],
            yaw: 90.0,
            pitch: 0.0,
            relatives: 0,
        });
        server.send(&teleport.encode()).unwrap();
        server
            .send(&play::Clientbound::Ping(cfg::Ping { id: 7 }).encode())
            .unwrap();
        // A reply to this proves the receive loop has passed the ping. The
        // old implementation instead replies with Pong before this keepalive.
        server
            .send(&play::Clientbound::KeepAlive(cfg::KeepAlive { id: 9 }).encode())
            .unwrap();
        let (id, body) = server.recv().unwrap();
        assert_eq!(
            play::Serverbound::decode(id, &body).unwrap(),
            play::Serverbound::KeepAlive(cfg::KeepAlive { id: 9 })
        );
        let timeout = Duration::from_secs(5);
        assert!(
            matches!(events.recv_timeout(timeout).unwrap(), Event::Packet(p) if *p == teleport)
        );
        assert!(
            matches!(events.recv_timeout(timeout).unwrap(), Event::Packet(p) if *p == play::Clientbound::Ping(cfg::Ping { id: 7 }))
        );
        writer.lock().unwrap().take().unwrap().shutdown();
        assert!(thread.join().unwrap().is_err());
    }

    #[test]
    fn play_packets_wait_out_a_reconfiguration() {
        let (client, server) = horizon_protocol::connection::Pipe::pair();
        let (mut reader, writer) = Connection::local(client).split();
        let (send, events) = channel();
        let session = Session {
            events,
            writer: Arc::new(Mutex::new(Some(writer))),
            configuring: Arc::new(AtomicBool::new(false)),
            thread: None,
            address: "local".into(),
            name: "Player".into(),
            counters: Arc::new(Mutex::new(None)),
            cookies: Cookies::default(),
            debug: false,
            far: Arc::default(),
            recorder: Arc::new(Mutex::new(None)),
        };
        let (thread_writer, thread_configuring, thread_recorder) = (
            session.writer.clone(),
            session.configuring.clone(),
            session.recorder.clone(),
        );
        let thread = std::thread::spawn(move || {
            receive_play(
                &mut reader,
                &thread_writer,
                &thread_configuring,
                &Language::new(),
                &send,
                &Cookies::default(),
                &crate::lod_net::Inbox::default(),
                Path::new("."),
                &thread_recorder,
            )
        });
        let mut server = Connection::local(server);
        let tick_end = play::Serverbound::ClientTickEnd(Empty);
        server
            .send(&play::Clientbound::StartConfiguration(Empty).encode())
            .unwrap();
        let (id, body) = server.recv().unwrap();
        assert_eq!(
            play::Serverbound::decode(id, &body).unwrap(),
            play::Serverbound::ConfigurationAcknowledged(Empty)
        );
        // The game thread still ticks the old level: nothing of it goes out.
        session.send(tick_end.clone());
        server
            .send(&cfg::Clientbound::FinishConfiguration(Empty).encode())
            .unwrap();
        let (id, body) = server.recv().unwrap();
        assert_eq!(
            cfg::Serverbound::decode(id, &body).unwrap(),
            cfg::Serverbound::FinishConfiguration(Empty)
        );
        // Back in play, the game's packets flow again.
        session.send(tick_end.clone());
        let (id, body) = server.recv().unwrap();
        assert_eq!(play::Serverbound::decode(id, &body).unwrap(), tick_end);
        drop(session);
        assert!(thread.join().unwrap().is_err());
    }

    #[test]
    fn play_answers_cookie_requests_from_stored_cookies_and_follows_transfers() {
        let (client, server) = horizon_protocol::connection::Pipe::pair();
        let (mut reader, writer) = Connection::local(client).split();
        let writer = Arc::new(Mutex::new(Some(writer)));
        let (send, events) = channel();
        let cookies = Cookies::default();
        let (thread_writer, thread_cookies) = (writer.clone(), cookies.clone());
        let thread = std::thread::spawn(move || {
            receive_play(
                &mut reader,
                &thread_writer,
                &AtomicBool::new(false),
                &Language::new(),
                &send,
                &thread_cookies,
                &crate::lod_net::Inbox::default(),
                Path::new("."),
                &Arc::new(Mutex::new(None)),
            )
        });
        let mut server = Connection::local(server);
        let ask = |server: &mut Connection, key: &str| {
            let request = play::Clientbound::CookieRequest(cfg::CookieRequest { key: key.into() });
            server.send(&request.encode()).unwrap();
            let (id, body) = server.recv().unwrap();
            play::Serverbound::decode(id, &body).unwrap()
        };
        // handleRequestCookie answers an unknown key with no payload.
        assert_eq!(
            ask(&mut server, "proxy:session"),
            play::Serverbound::CookieResponse(cfg::CookieResponse {
                key: "proxy:session".into(),
                payload: None,
            })
        );
        let store = play::Clientbound::StoreCookie(cfg::StoreCookie {
            key: "proxy:session".into(),
            payload: vec![1, 2, 3],
        });
        server.send(&store.encode()).unwrap();
        assert_eq!(
            ask(&mut server, "proxy:session"),
            play::Serverbound::CookieResponse(cfg::CookieResponse {
                key: "proxy:session".into(),
                payload: Some(vec![1, 2, 3]),
            })
        );
        let transfer = play::Clientbound::Transfer(cfg::Transfer {
            host: "example.net".into(),
            port: 25566,
        });
        server.send(&transfer.encode()).unwrap();
        assert!(thread.join().unwrap().is_ok());
        assert!(matches!(
            events.try_iter().last(),
            Some(Event::Transfer { host, port: 25566 }) if host == "example.net"
        ));
        // The stored cookie stays for the next connection (TransferState).
        assert_eq!(
            cookies.lock().unwrap().get("proxy:session"),
            Some(&vec![1, 2, 3])
        );
    }

    #[test]
    fn server_brand_payload_is_decoded_and_invalid_or_unrelated_payloads_are_ignored() {
        let (send, events) = channel();
        let mut writer = horizon_protocol::buf::Writer::new();
        writer.string("vanilla");
        let mut payload = cfg::CustomPayload {
            channel: "minecraft:brand".into(),
            data: writer.data,
        };
        receive_brand(&payload, &send);
        assert!(matches!(events.try_recv(), Ok(Event::Brand(brand)) if brand == "vanilla"));
        payload.channel = "example:other".into();
        receive_brand(&payload, &send);
        assert!(events.try_recv().is_err());
        payload.channel = "minecraft:brand".into();
        payload.data = vec![0xff];
        receive_brand(&payload, &send);
        assert!(events.try_recv().is_err());
    }
    /// No account never joins; the signed-in rule is compared with the real
    /// client login listener by test_lan_auth_parity.py.
    #[test]
    fn lan_login_continues_after_authentication_failure() {
        for lan in [true, false] {
            let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let port = listener.local_addr().unwrap().port();
            let worker = std::thread::spawn(move || {
                let (stream, _) = listener.accept().unwrap();
                // Generous: a debug build's key generation on a busy CI runner takes seconds. A pass
                // never waits for these.
                stream
                    .set_read_timeout(Some(Duration::from_secs(60)))
                    .unwrap();
                let mut server = Connection::from_stream(stream).unwrap();
                server.recv().unwrap(); // intention
                server.recv().unwrap(); // profile
                let key = horizon_protocol::rsa::RsaPrivateKey::generate(1024).unwrap();
                let challenge = vec![1, 2, 3, 4];
                server
                    .send(
                        &login::Clientbound::Hello(login::Hello {
                            server_id: String::new(),
                            public_key: key.public_der(),
                            challenge: challenge.clone(),
                            should_authenticate: true,
                        })
                        .encode(),
                    )
                    .unwrap();
                let Ok((id, body)) = server.recv() else {
                    return false;
                };
                let login::Serverbound::Key(reply) = login::Serverbound::decode(id, &body).unwrap()
                else {
                    panic!("client did not send encryption reply")
                };
                assert_eq!(key.decrypt(&reply.challenge).unwrap(), challenge);
                let secret: [u8; 16] = key.decrypt(&reply.key).unwrap().try_into().unwrap();
                server.enable_encryption(&secret);
                server
                    .send(
                        &login::Clientbound::Disconnect(login::Disconnect {
                            reason_json: r#"{"text":"LAN fixture accepted"}"#.into(),
                        })
                        .encode(),
                    )
                    .unwrap();
                true
            });
            let address = format!("127.0.0.1:{port}");
            let connect = if lan {
                Session::connect_lan
            } else {
                Session::connect
            };
            // The session's language carries Horizon's bundled strings
            // (`load_language`), so the keyed refusal resolves.
            let lang: Language = [(
                "horizon.multiplayer.not_signed_in".to_owned(),
                NOT_SIGNED_IN.to_owned(),
            )]
            .into_iter()
            .collect();
            let session = connect(
                &address,
                "Tester",
                None,
                cfg::ClientInformation::new(8),
                Arc::new(lang),
                PathBuf::new(),
            );
            let reason = loop {
                if let Event::Disconnected { reason, .. } = session
                    .events
                    .recv_timeout(Duration::from_secs(60))
                    .unwrap()
                {
                    break reason;
                }
            };
            // Without an account nothing joins, LAN or not.
            let sent_key = worker.join().unwrap();
            assert!(!sent_key, "lan {lan}: joined without an account");
            assert_eq!(reason, NOT_SIGNED_IN);
            // A signed-in account whose join the session service rejects:
            // the case vanilla's listener is run with.
            let goes_on = continues_after_failed_join(lan, true);
            assert_eq!(goes_on, lan);
            println!(
                "lan_auth={}:{}:{}",
                if lan { "LAN" } else { "OTHER" },
                goes_on,
                !goes_on
            );
        }
    }

    #[test]
    fn session_studio_recording_tap_records_packets_to_mcpr() {
        let (client, server) = horizon_protocol::connection::Pipe::pair();
        let (mut reader, writer) = Connection::local(client).split();
        let (send, events) = channel();
        let session = Session {
            events,
            writer: Arc::new(Mutex::new(Some(writer))),
            configuring: Arc::new(AtomicBool::new(false)),
            thread: None,
            address: "local".into(),
            name: "StudioTester".into(),
            counters: Arc::new(Mutex::new(None)),
            cookies: Cookies::default(),
            debug: false,
            far: Arc::default(),
            recorder: Arc::new(Mutex::new(None)),
        };

        let temp_dir = std::env::temp_dir().join(format!(
            "horizon-studio-test-{}_{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let _ = std::fs::create_dir_all(&temp_dir);
        let mcpr_path = temp_dir.join("test_tap.mcpr");

        let meta = Metadata::new("Singleplayer World".into(), true, "26.3".into());
        session.start_recording(&mcpr_path, meta).unwrap();
        assert!(session.is_recording());

        let (thread_writer, thread_configuring, thread_recorder) = (
            session.writer.clone(),
            session.configuring.clone(),
            session.recorder.clone(),
        );
        let thread = std::thread::spawn(move || {
            receive_play(
                &mut reader,
                &thread_writer,
                &thread_configuring,
                &Language::new(),
                &send,
                &Cookies::default(),
                &crate::lod_net::Inbox::default(),
                Path::new("."),
                &thread_recorder,
            )
        });

        let mut server = Connection::local(server);
        let pos_pkt = play::Clientbound::PlayerPosition(play::PlayerPosition {
            teleport: 1,
            position: [100.0, 64.0, -200.0],
            delta: [0.0; 3],
            yaw: 45.0,
            pitch: 10.0,
            relatives: 0,
        });
        server.send(&pos_pkt.encode()).unwrap();

        // Disconnect ends receive_play loop
        let disc_pkt = play::Clientbound::Disconnect(cfg::Disconnect {
            reason: Tag::String("Replay tap test completed".into()),
        });
        server.send(&disc_pkt.encode()).unwrap();

        let _ = thread.join().unwrap();

        let saved_path = session.stop_recording().unwrap().unwrap();
        assert_eq!(saved_path, mcpr_path);
        assert!(!session.is_recording());
        assert!(mcpr_path.exists());

        // Verify that the recording archive contains the clientbound packets.
        let mut recording = crate::studio::McprReader::open(&mcpr_path).unwrap();
        assert_eq!(recording.total_packets(), 1);
        assert_eq!(recording.metadata.server_name, "Singleplayer World");
        assert!(recording.metadata.singleplayer);
        assert!(recording.metadata.players.is_empty());

        let packet1 = recording.next_packet().unwrap().unwrap();
        assert!(recording.next_packet().unwrap().is_none());

        let decoded1 = play::Clientbound::decode(packet1.id, &packet1.payload).unwrap();
        assert_eq!(decoded1, pos_pkt);

        let _ = std::fs::remove_dir_all(&temp_dir);
    }
}
