//! Primed TNT, falling blocks, projectiles, tridents, firework rockets and
//! end crystals on a server's client (`ClientPacketListener.handleAddEntity`
//! and `handleSetEntityData`): the server simulates them, the client draws
//! them where it says and interpolates their moves.
use super::{FallStep, FallingBlock, Game, fireworks::fireworks_of};
use horizon_client::items::ItemStack;
use horizon_client::projectiles::{Hit, Projectile, ProjectileKind, ProjectileWorld};
use horizon_client::{
    collisions::SceneCollisions,
    particles::{ParticleOptions, ParticleType},
};
use horizon_core::{geometry::Vec3, position::BlockPos, random::RandomSource};
use horizon_protocol::entity_data::Value;
use horizon_world::registry::BlockStateId;

/// An `AreaEffectCloud` a server tracks: what its client tick reads.
pub(super) struct RemoteCloud {
    id: u32,
    pub(super) at: [f64; 3],
    pub(super) radius: f32,
    waiting: bool,
    particle: ParticleOptions,
}

/// `AreaEffectCloud.DEFAULT_PARTICLE`: a white entity effect.
fn default_cloud_particle() -> ParticleOptions {
    ParticleOptions::colored(ParticleType::EntityEffect, [1.0; 4])
}

/// `AreaEffectCloud.clientTick`: while waiting, now and then two particles
/// near the middle; then about one per square block of the disc, drifting
/// (an entity effect stays still).
pub(super) fn cloud_client_tick(
    particles: &mut horizon_client::particles::ParticleEngine,
    at: [f64; 3],
    radius: f32,
    waiting: bool,
    particle: &ParticleOptions,
) {
    if waiting && particles.random().next_boolean() {
        return;
    }
    let (count, spread) = if waiting {
        (2, 0.2)
    } else {
        (
            (std::f32::consts::PI * radius * radius).ceil() as i32,
            radius,
        )
    };
    for _ in 0..count {
        let r = particles.random();
        let angle = r.next_float() * std::f32::consts::TAU;
        let distance = r.next_float().sqrt() * spread;
        let at = [
            at[0] + f64::from(angle.cos() * distance),
            at[1],
            at[2] + f64::from(angle.sin() * distance),
        ];
        let (options, velocity) = if particle.ty == ParticleType::EntityEffect {
            let default = waiting && r.next_boolean();
            let options = if default {
                default_cloud_particle()
            } else {
                particle.clone()
            };
            (options, [0.0; 3])
        } else if waiting {
            (particle.clone(), [0.0; 3])
        } else {
            let v = [
                (0.5 - r.next_double()) * 0.15,
                f64::from(0.01f32),
                (0.5 - r.next_double()) * 0.15,
            ];
            (particle.clone(), v)
        };
        // `addAlwaysVisibleParticle`.
        particles.add_with(&options, at, velocity, false, true);
    }
}

/// The projectile a type id names, as Horizon models it.
fn projectile_kind(kind: &str) -> Option<ProjectileKind> {
    Some(match kind {
        "minecraft:arrow" | "minecraft:spectral_arrow" => ProjectileKind::Arrow {
            base_damage: 2.0,
            critical: false,
            effect: None,
        },
        "minecraft:snowball" => ProjectileKind::Snowball,
        "minecraft:egg" => ProjectileKind::Egg,
        "minecraft:ender_pearl" => ProjectileKind::EnderPearl,
        "minecraft:small_fireball" => ProjectileKind::SmallFireball,
        "minecraft:fireball" => ProjectileKind::LargeFireball { power: 1 },
        "minecraft:llama_spit" => ProjectileKind::LlamaSpit,
        "minecraft:wind_charge" => ProjectileKind::WindCharge,
        "minecraft:breeze_wind_charge" => ProjectileKind::BreezeWindCharge,
        // Homing state stays on the server; the client interpolates its positions.
        "minecraft:shulker_bullet" => ProjectileKind::ShulkerBullet {
            target: Some(horizon_client::mobs::Who::Player),
            dir: None,
            steps: 0,
            delta: [0.0; 3],
            seed: 0,
        },
        "minecraft:wither_skull" => ProjectileKind::WitherSkull { dangerous: false },
        _ => ProjectileKind::Thrown(horizon_client::projectiles::thrown_type(kind)?),
    })
}

/// A server's client ticks a projectile itself: it flies on between the
/// tracker's updates (10 to 20 ticks apart) with its own gravity and drag,
/// and a block stops it there; only the server decides what it hits.
pub(super) fn remote_projectile_tick(p: &mut Projectile, w: &impl ProjectileWorld) {
    if !matches!(p.tick(w).1, Hit::None) {
        p.velocity = Vec3::ZERO;
    }
}

/// `Entity.getRandomX(0.5)` / `getRandomY` / `getRandomZ(0.5)` for a shulker
/// bullet (`EntityType.SHULKER_BULLET` is 0.3125 x 0.3125).
fn shulker_bullet_trail_at(at: Vec3, random: &mut impl RandomSource) -> [f64; 3] {
    const SIZE: f64 = 0.3125;
    [
        at.x + SIZE * (2.0 * random.next_double() - 1.0) * 0.5,
        at.y + SIZE * random.next_double(),
        at.z + SIZE * (2.0 * random.next_double() - 1.0) * 0.5,
    ]
}

/// `ClientPacketListener.handleSetEntityData`'s `Fireball.DATA_ITEM_STACK`:
/// the item the guest draws the fireball as, through `Fireball.setItem`;
/// a kind that is no `Fireball` has none.
pub(super) fn remote_projectile_item(projectiles: &mut [Projectile], id: u32, stack: ItemStack) {
    if let Some(p) = projectiles
        .iter_mut()
        .find(|p| p.id == id && p.kind.is_item_fireball())
    {
        p.set_item(stack);
    }
}

/// `ClientPacketListener.handleProjectilePowerPacket`: the power a hurting
/// projectile (`AbstractHurtingProjectile`) accelerates by, found by id;
/// anything else is ignored.
pub(super) fn remote_projectile_power(projectiles: &mut [Projectile], id: i32, power: f64) {
    if let Some(p) = projectiles.iter_mut().find(|p| p.id == id as u32)
        && matches!(
            p.kind,
            ProjectileKind::SmallFireball
                | ProjectileKind::LargeFireball { .. }
                | ProjectileKind::WitherSkull { .. }
                | ProjectileKind::WindCharge
                | ProjectileKind::BreezeWindCharge
        )
    {
        p.acceleration = power;
    }
}

/// `AbstractHurtingProjectile.getTrailParticle`: smoke for every one of them
/// but the wind charges (no trail) and the dragon's fireball (its own).
pub(super) fn has_smoke_trail(kind: &ProjectileKind) -> bool {
    matches!(
        kind,
        ProjectileKind::SmallFireball
            | ProjectileKind::LargeFireball { .. }
            | ProjectileKind::WitherSkull { .. }
    )
}

impl Game<'_> {
    /// `Arrow.tick` and `SpectralArrow.tick` on a client: a tipped arrow
    /// sheds two entity-effect swirls in its colour while flying, one every
    /// fifth tick in a block; a spectral arrow an effect sparkle at its
    /// position while flying.
    fn arrow_effect_particles(&mut self) {
        let mut puffs: Vec<(Vec3, i32, u32)> = Vec::new();
        for p in &self.creatures.projectiles {
            let Some(a) = p.arrow.as_ref().filter(|_| p.is_arrow()) else {
                continue;
            };
            let at = p.position;
            if p.is_spectral_arrow() {
                if !p.stuck {
                    let options = ParticleOptions::simple(ParticleType::Effect);
                    self.particles.add(&options, [at.x, at.y, at.z], [0.0; 3]);
                }
                continue;
            }
            let count = match (p.stuck, a.in_ground_time % 5) {
                (true, 0) => 1,
                (true, _) => 0,
                (false, _) => 2,
            };
            puffs.push((at, a.effect_color, count));
        }
        for (at, color, count) in puffs {
            self.arrow_makeparticle(at, color, count);
        }
    }

    /// `Arrow.makeParticle`: `count` entity-effect swirls in `color` (an ARGB
    /// int, -1 for none) inside the arrow's 0.5 x 0.5 box.
    fn arrow_makeparticle(&mut self, at: Vec3, color: i32, count: u32) {
        // `EntityType.ARROW` is 0.5 x 0.5.
        const SIZE: f64 = 0.5;
        if color == -1 {
            return;
        }
        // ColorParticleOption.create(ENTITY_EFFECT, colour): ARGB as floats.
        let channel = |shift: u32| (color as u32 >> shift & 255) as f32 / 255.0;
        let options = ParticleOptions::colored(
            ParticleType::EntityEffect,
            [channel(16), channel(8), channel(0), channel(24)],
        );
        for _ in 0..count {
            // getRandomX(0.5), getRandomY, getRandomZ(0.5).
            let r = self.particles.random();
            let x = at.x + SIZE * (2.0 * r.next_double() - 1.0) * 0.5;
            let y = at.y + SIZE * r.next_double();
            let z = at.z + SIZE * (2.0 * r.next_double() - 1.0) * 0.5;
            self.particles.add(&options, [x, y, z], [0.0; 3]);
        }
    }

    /// `Arrow.handleEntityEvent(0)`: a tipped arrow stuck for 600 ticks bursts
    /// into twenty particles in its colour. The server turns it into a plain
    /// arrow and does not send the colour again, so it stops here.
    pub(super) fn remote_arrow_puff(&mut self, id: u32) {
        let Some(p) = self.creatures.projectiles.iter_mut().find(|p| p.id == id) else {
            return;
        };
        let Some(a) = p.arrow.as_mut() else {
            return;
        };
        let (at, color) = (p.position, std::mem::replace(&mut a.effect_color, -1));
        self.arrow_makeparticle(at, color, 20);
    }

    /// `AbstractHurtingProjectile.createParticleTrail`: one smoke puff half a
    /// block above each position.
    pub(super) fn smoke_trails(&mut self, at: impl IntoIterator<Item = Vec3>) {
        let smoke = ParticleOptions::simple(ParticleType::Smoke);
        for p in at {
            self.particles.add(&smoke, [p.x, p.y + 0.5, p.z], [0.0; 3]);
        }
    }

    pub(super) fn throwable_bubbles(&mut self, at: Vec<([f64; 3], [f64; 3])>) {
        let bubble = ParticleOptions::simple(ParticleType::Bubble);
        for (position, speed) in at {
            for _ in 0..4 {
                self.particles.add(&bubble, position, speed);
            }
        }
    }

    /// `ShulkerBullet.tick` on a client: two `END_ROD` particles in its
    /// 0.3125 box (`getRandomX(0.5)`, `getRandomY`, `getRandomZ(0.5)`).
    pub(super) fn shulker_bullet_trails(&mut self) {
        let bullets: Vec<Vec3> = self
            .creatures
            .projectiles
            .iter()
            .filter(|p| matches!(p.kind, ProjectileKind::ShulkerBullet { .. }))
            .map(|p| p.position)
            .collect();
        let options = ParticleOptions::simple(ParticleType::EndRod);
        for at in bullets {
            for _ in 0..2 {
                let p = shulker_bullet_trail_at(at, self.particles.random());
                self.particles.add(&options, p, [0.0; 3]);
            }
        }
    }

    /// `handleAddEntity` for these types; false when `kind` isn't one.
    pub(super) fn spawn_remote_projectile(
        &mut self,
        id: i32,
        kind: &str,
        position: [f64; 3],
        rotation: (f32, f32),
        velocity: [f64; 3],
        data: i32,
    ) -> bool {
        let id = id as u32;
        let at = Vec3::new(position[0], position[1], position[2]);
        let velocity = Vec3::new(velocity[0], velocity[1], velocity[2]);
        let (yaw, pitch) = rotation;
        self.remove_remote_projectile(id);
        match kind {
            "minecraft:evoker_fangs" => self.insert_fangs(id, position, yaw, 0, 0),
            "minecraft:tnt" => self.tnts.push(super::tnt::PrimedTnt {
                rotation: [0.0, 0.0],
                join: Default::default(),
                no_gravity: false,
                id,
                position: at,
                previous: at,
                velocity,
                fuse: 80,
                on_ground: false,
                owner: None,
                guest: None,
                power: 4.0,
                block_state: None,
            }),
            // FallingBlockEntity.recreateFromPacket: the block state is the data.
            "minecraft:falling_block" => self.falling.push(FallingBlock {
                rotation: [0.0, 0.0],
                join: Default::default(),
                id,
                state: BlockStateId(data.max(0) as u32),
                start_pos: BlockPos::default(),
                position: at,
                previous: at,
                velocity,
                age: 0,
                no_gravity: false,
                portal: Default::default(),
                drop_item: false,
                fall_distance: 0.0,
                stuck: Vec3::ZERO,
                damage: Default::default(),
                saved: None,
            }),
            "minecraft:trident" => {
                let mut t = super::trident::ThrownTrident::remote(id, at, yaw, pitch);
                t.velocity = velocity;
                // Projectile.getAddEntityPacket: the owner's id is the data.
                t.owner = data as u32;
                self.tridents.push(t);
            }
            "minecraft:firework_rocket" => {
                self.rockets
                    .push(super::fireworks::Rocket::remote(id, at, velocity));
            }
            "minecraft:splash_potion"
            | "minecraft:lingering_potion"
            | "minecraft:experience_bottle" => {
                self.potions.add_remote_thrown(id, kind, at, velocity);
            }
            "minecraft:dragon_fireball" => self
                .dragon_fireballs
                .push(super::dragon::DragonFireball::remote(id, at, velocity)),
            "minecraft:area_effect_cloud" => self.potions.clouds.push(RemoteCloud {
                id,
                at: position,
                radius: 3.0,
                waiting: false,
                particle: default_cloud_particle(),
            }),
            "minecraft:eye_of_ender" => {
                self.end
                    .add_remote_eye(id, position, [velocity.x, velocity.y, velocity.z])
            }
            // FishingHook.recreateFromPacket: the owner's id is the data.
            "minecraft:fishing_bobber" => self.spawn_remote_hook(id, at, velocity, data),
            "minecraft:end_crystal" => {
                // EndCrystal's constructor starts `time` from the crystal's own
                // random, so each placed crystal spins from its own phase.
                let time = horizon_client::mobs::entity_random(id, at)
                    .next_int_bound(100_000)
                    .unwrap_or(0);
                self.crystals.push(super::dragon::Crystal {
                    id,
                    position: at,
                    show_bottom: true,
                    time,
                    beam: None,
                    invulnerable: false,
                });
            }
            _ => {
                let Some(k) = projectile_kind(kind) else {
                    return false;
                };
                if k == ProjectileKind::LlamaSpit {
                    self.particles
                        .llama_spit_burst(position, [velocity.x, velocity.y, velocity.z]);
                }
                let mut p = Projectile::new(k, at, None);
                // SpectralArrow: its own type; its pickup item says so.
                if kind == "minecraft:spectral_arrow"
                    && let Some(a) = p.arrow.as_mut()
                {
                    a.pickup_item = ItemStack::new("minecraft:spectral_arrow", 1);
                }
                p.id = id;
                p.velocity = velocity;
                p.yaw = yaw;
                p.pitch = pitch;
                self.add_projectile(p);
            }
        }
        true
    }

    /// `handleSetEntityData` for these types: what changes how they look.
    pub(super) fn remote_projectile_data(&mut self, id: i32, values: &[(u8, i32, Value)]) {
        let id = id as u32;
        self.remote_hook_data(id, values);
        if let Some(at) = self
            .potions
            .clouds
            .iter()
            .find(|c| c.id == id)
            .map(|c| c.at)
        {
            // AreaEffectCloud.DATA_RADIUS, DATA_WAITING and DATA_PARTICLE.
            for (index, _, value) in values {
                let particle = match (index, value) {
                    (10, Value::Particle(p)) => self.received_particle(p, at),
                    _ => None,
                };
                let Some(c) = self.potions.clouds.iter_mut().find(|c| c.id == id) else {
                    return;
                };
                match (index, value) {
                    (8, Value::Float(r)) => c.radius = *r,
                    (9, Value::Bool(w)) => c.waiting = *w,
                    (10, _) => c.particle = particle.unwrap_or_else(default_cloud_particle),
                    _ => {}
                }
            }
            return;
        }
        if self.rockets.iter().any(|r| r.id == id) {
            for (index, _, value) in values {
                match (index, value) {
                    // FireworkRocketEntity.DATA_ID_FIREWORKS_ITEM: its
                    // explosions for `createFireworks`.
                    (8, Value::Item(stack)) => {
                        if let Some(stack) = self.to_stack(stack)
                            && let Some(r) = self.rockets.iter_mut().find(|r| r.id == id)
                        {
                            let (_, explosions) = fireworks_of(&stack);
                            r.explosions = explosions;
                            r.item = stack;
                        }
                    }
                    // DATA_ATTACHED_TO_TARGET (OptionalInt: the id plus 1).
                    (9, Value::Id(v)) => {
                        let v = (*v > 0).then(|| (*v - 1) as u32);
                        if let Some(r) = self.rockets.iter_mut().find(|r| r.id == id) {
                            r.attached_to = v;
                        }
                    }
                    // DATA_SHOT_AT_ANGLE.
                    (10, Value::Bool(a)) => {
                        if let Some(r) = self.rockets.iter_mut().find(|r| r.id == id) {
                            r.angled = *a;
                        }
                    }
                    _ => {}
                }
            }
        }
        if self.potions.has_thrown(id) {
            // ThrowableItemProjectile.DATA_ITEM_STACK: the potion it is.
            for (index, _, value) in values {
                if let (8, Value::Item(stack)) = (index, value)
                    && let Some(stack) = self.to_stack(stack)
                {
                    self.potions.remote_thrown_item(id, stack);
                }
            }
            return;
        }
        // Fireball.DATA_ITEM_STACK: the item a fireball is drawn as.
        if let Some(stack) = values
            .iter()
            .find_map(|(index, _, value)| match (index, value) {
                (8, Value::Item(stack)) => Some(stack),
                _ => None,
            })
            && let Some(stack) = self.to_stack(stack)
        {
            remote_projectile_item(&mut self.creatures.projectiles, id, stack);
        }
        for (index, _, value) in values {
            if let Some(t) = self.tnts.iter_mut().find(|t| t.id == id) {
                // PrimedTnt.DATA_FUSE_ID.
                if let (8, Value::Int(fuse)) = (index, value) {
                    t.fuse = *fuse;
                }
            } else if let Some(f) = self.falling.iter_mut().find(|f| f.id == id) {
                // FallingBlockEntity.DATA_START_POS (the model's seed).
                if let (8, Value::Pos(p)) = (index, value) {
                    f.start_pos = BlockPos::new(p[0], p[1], p[2]);
                }
            } else if let Some(c) = self.crystals.iter_mut().find(|c| c.id == id) {
                // EndCrystal.DATA_BEAM_TARGET and DATA_SHOW_BOTTOM.
                match (index, value) {
                    (8, Value::OptPos(beam)) => c.beam = *beam,
                    (9, Value::Bool(show)) => c.show_bottom = *show,
                    _ => {}
                }
            } else if let Some(t) = self.tridents.iter_mut().find(|t| t.id == id) {
                // AbstractArrow.ID_FLAGS (no physics) and IN_GROUND, and
                // ThrownTrident.ID_LOYALTY.
                match (index, value) {
                    // Clients retain the server's fire flag until the next update.
                    (0, Value::Byte(flags)) => t.fire_ticks = i32::from(flags & 1),
                    (8, Value::Byte(flags)) => t.no_physics = flags & 2 != 0,
                    (10, Value::Bool(in_ground)) => t.in_ground = *in_ground,
                    (11, Value::Byte(loyalty)) => t.loyalty = u32::from(*loyalty as u8),
                    _ => {}
                }
            } else if let Some(p) = self.creatures.projectiles.iter_mut().find(|p| p.id == id) {
                match (&mut p.kind, index, value) {
                    // Entity.DATA_SHARED_FLAGS_ID's FLAG_ONFIRE: Entity.isOnFire on
                    // a client, which draws the flames. A client doesn't count the
                    // fire down: the flag goes off when the server's fire is out.
                    (_, 0, Value::Byte(flags)) => {
                        if let Some(a) = p.arrow.as_mut() {
                            a.synced_fire = flags & 1 != 0;
                        }
                    }
                    // AbstractArrow.ID_FLAGS (critical) and IN_GROUND.
                    (ProjectileKind::Arrow { critical, .. }, 8, Value::Byte(flags)) => {
                        *critical = flags & 1 != 0;
                        if let Some(a) = p.arrow.as_mut() {
                            a.no_physics = flags & 2 != 0;
                        }
                    }
                    (ProjectileKind::Arrow { .. }, 5, Value::Bool(no_gravity)) => {
                        p.no_gravity = *no_gravity;
                    }
                    (ProjectileKind::Arrow { .. }, 10, Value::Bool(in_ground)) => {
                        // AbstractArrow.onSyncedDataUpdated: IN_GROUND turning true after
                        // the first tick starts the shake.
                        if *in_ground
                            && !p.stuck
                            && p.age > 0
                            && let Some(a) = p.arrow.as_mut()
                            && a.shake <= 0
                        {
                            a.shake = 7;
                        }
                        p.stuck = *in_ground;
                        if let Some(a) = p.arrow.as_mut() {
                            a.in_ground = *in_ground;
                        }
                    }
                    // Arrow.ID_EFFECT_COLOR.
                    (ProjectileKind::Arrow { .. }, 11, Value::Int(color)) => {
                        if let Some(a) = p.arrow.as_mut() {
                            a.effect_color = *color;
                        }
                    }
                    // WitherSkull.DATA_DANGEROUS.
                    (ProjectileKind::WitherSkull { dangerous }, 8, Value::Bool(d)) => {
                        *dangerous = *d;
                    }
                    _ => {}
                }
            }
        }
    }

    /// A move's rotation for a projectile or trident.
    pub(super) fn turn_remote_projectile(&mut self, id: i32, rotation: Option<(f32, f32)>) {
        let (id, Some((yaw, pitch))) = (id as u32, rotation) else {
            return;
        };
        if let Some(p) = self.creatures.projectiles.iter_mut().find(|p| p.id == id) {
            p.yaw = yaw;
            p.pitch = pitch;
        } else if let Some(t) = self.tridents.iter_mut().find(|t| t.id == id) {
            t.yaw = yaw;
            t.pitch = pitch;
        }
    }

    /// `Entity.getEyePosition` of a projectile's owner: this game's player or
    /// another player the server sent.
    fn remote_eye(&self, id: u32) -> Option<Vec3> {
        if self.remote_player_id() == Some(id) {
            let eye = self.eye_position()?;
            return Some(Vec3::new(eye[0], eye[1], eye[2]));
        }
        let m = self.mobs.iter().find(|m| m.id == id)?;
        Some(Vec3::new(
            m.position.x,
            m.position.y + m.eye_height(),
            m.position.z,
        ))
    }

    /// This client's own player's entity id on the server.
    fn remote_player_id(&self) -> Option<u32> {
        self.remote
            .as_ref()
            .and_then(|r| u32::try_from(r.entity_id).ok())
    }

    /// `FireworkRocketEntity.tick` for the rockets attached to this client's
    /// own player, once the player has moved (it ticks before them in
    /// `ClientLevel.tickEntities`), each with its spark.
    pub(super) fn tick_own_rockets(&mut self) {
        let Some(me) = self.remote_player_id() else {
            return;
        };
        if !self.clock.runs_normally()
            || self.player.is_none()
            || !self.rockets.iter().any(|r| r.attached_to == Some(me))
        {
            return;
        }
        let mut rockets = std::mem::take(&mut self.rockets);
        for r in rockets.iter_mut().filter(|r| r.attached_to == Some(me)) {
            self.follow_own_player(r);
            self.rocket_spark(r);
        }
        self.rockets = rockets;
    }

    /// One tick of interpolation, as `tick_remote_objects`.
    pub(super) fn tick_remote_projectiles(&mut self, mut step: impl FnMut(u32, Vec3) -> Vec3) {
        self.tick_remote_fangs();
        // PrimedTnt.tick runs on a client too: it falls, bounces and burns its
        // fuse down (the swell and flash follow it) between the server's
        // updates (every 10 ticks), and a client discards it when the fuse
        // runs out; only the server explodes it.
        let (world, collision, assets, facts, fluids, border, blocks) = (
            &self.world,
            self.collision,
            &self.pack.assets,
            self.res.facts(),
            &self.res.motion().fluids,
            Some(self.border.geometry()),
            Some(&self.res.motion().blocks),
        );
        self.tnts.retain_mut(|t| {
            // A fluid lookup that fails leaves it where its move put it.
            let _ = t.tick(world, collision, assets, facts, fluids, border, blocks);
            t.fuse > 0
        });
        // PrimedTnt.tick: while the fuse is still lit, a client adds one SMOKE
        // particle at (x, y + 0.5, z). The server's Level.addParticle never
        // reaches this window.
        let smoking: Vec<Vec3> = self.tnts.iter().map(|t| t.position).collect();
        let smoke = ParticleOptions::simple(ParticleType::Smoke);
        for p in smoking {
            self.particles.add(&smoke, [p.x, p.y + 0.5, p.z], [0.0; 3]);
        }
        // FallingBlockEntity.tick runs on a client too: the block falls by
        // itself between the server's updates (every 20 ticks), then waits
        // where it lands for the server to place it and remove it.
        let mut falling = std::mem::take(&mut self.falling);
        for f in &mut falling {
            if let Ok(FallStep::Landed(_)) = self.fall_step(f, false) {
                // Block.updateEntityMovementAfterFallOn, then the air drag.
                f.velocity = Vec3::new(f.velocity.x * 0.98, 0.0, f.velocity.z * 0.98);
            }
        }
        self.falling = falling;
        // Projectiles tick on the client too and fly on between the tracker's
        // updates (10 to 20 ticks apart); a block stops them there, and only
        // the server decides what they hit.
        let mut projectiles = std::mem::take(&mut self.creatures.projectiles);
        let bubbles: Vec<_> = projectiles
            .iter()
            .filter_map(Projectile::water_bubbles)
            .collect();
        let mut tridents = std::mem::take(&mut self.tridents);
        let mut arrow_events = Vec::new();
        let rain = self.arrow_rain();
        let arrow_scene = self.arrow_scene(&rain);
        {
            let w = self.mob_world_base(&[]);
            let world = super::creatures::ProjWorld {
                w: &w,
                targets: Vec::new(),
                border: Some(self.border.bounds()),
            };
            for p in &mut projectiles {
                match p.kind {
                    ProjectileKind::Arrow { .. } => {
                        let _ = horizon_client::arrows::tick_client(p, &arrow_scene);
                        if let Some(a) = p.arrow.as_mut() {
                            arrow_events.extend(
                                std::mem::take(&mut a.events)
                                    .into_iter()
                                    .map(|event| (p.position, event)),
                            );
                        }
                    }
                    // ShulkerBullet.tick: only the server steers it.
                    ProjectileKind::ShulkerBullet { .. } => {
                        p.set_old_pos_and_rot();
                        p.age += 1;
                        p.position = p.position.add_vector(p.velocity);
                    }
                    _ => remote_projectile_tick(p, &world),
                }
            }
            for t in &mut tridents {
                t.remote_tick(&world, self.remote_eye(t.owner));
            }
        }
        drop(rain);
        self.creatures.projectiles = projectiles;
        self.tridents = tridents;
        for (at, event) in arrow_events {
            self.arrow_event(at, event);
        }
        self.arrow_effect_particles();
        let trails: Vec<Vec3> = self
            .creatures
            .projectiles
            .iter()
            .filter(|p| has_smoke_trail(&p.kind))
            .map(|p| p.position)
            .collect();
        self.smoke_trails(trails);
        self.shulker_bullet_trails();
        self.throwable_bubbles(bubbles);
        // FireworkRocketEntity.tick: a rocket attached to another entity
        // follows it, and every rocket leaves its spark trail on a client. One
        // boosting this client's own player ticks after it (`tick_own_rockets`).
        let me = self.remote_player_id();
        let mut rockets = std::mem::take(&mut self.rockets);
        for r in &mut rockets {
            r.remote_step(&mut SceneCollisions {
                world: &self.world,
                binding: self.collision,
                subject: None,
            });
            if let Some(target) = r.attached_to {
                if me == Some(target) {
                    continue;
                }
                if let Some(m) = self.mobs.iter().find(|m| m.id == target) {
                    // Another player's motion is not known here: its step.
                    r.velocity = Vec3::new(
                        m.position.x - r.previous.x,
                        m.position.y - r.previous.y,
                        m.position.z - r.previous.z,
                    );
                    r.position = m.position;
                }
            }
            self.rocket_spark(r);
        }
        self.rockets = rockets;
        for c in &mut self.crystals {
            c.time += 1;
            c.position = step(c.id, c.position);
        }
        self.step_remote_thrown();
        self.tick_remote_hooks();
        self.end.step_remote_eyes();
        self.tick_remote_clouds();
        // The dragon's fireballs fly on between the tracker's updates, with
        // their dragon_breath trail (`AbstractHurtingProjectile.getTrailParticle`).
        let trail = ParticleOptions::simple(ParticleType::DragonBreath);
        for b in &mut self.dragon_fireballs {
            let at = b.position;
            let water = self
                .res
                .facts()
                .get(self.world.block(
                    at.x.floor() as i32,
                    at.y.floor() as i32,
                    at.z.floor() as i32,
                ))
                .fluid
                == horizon_client::blocks::Fluid::Water;
            if water {
                // applyInertia, before the move: four bubbles on the motion
                // the fireball already has.
                let (at, speed) = horizon_client::projectiles::water_bubble_at(
                    [at.x, at.y, at.z],
                    [b.velocity.x, b.velocity.y, b.velocity.z],
                );
                let bubble = ParticleOptions::simple(ParticleType::Bubble);
                for _ in 0..4 {
                    self.particles.add(&bubble, at, speed);
                }
            }
            b.remote_step(water);
            let p = b.position;
            self.particles.add(&trail, [p.x, p.y + 0.5, p.z], [0.0; 3]);
        }
    }

    /// `AreaEffectCloud.clientTick` for each cloud a server tracks.
    fn tick_remote_clouds(&mut self) {
        for c in &self.potions.clouds {
            cloud_client_tick(&mut self.particles, c.at, c.radius, c.waiting, &c.particle);
        }
    }

    pub(super) fn remove_remote_projectile(&mut self, id: u32) {
        self.fangs.list.retain(|f| f.id != id);
        self.tnts.retain(|t| t.id != id);
        self.falling.retain(|f| f.id != id);
        self.creatures.projectiles.retain(|p| p.id != id);
        self.tridents.retain(|t| t.id != id);
        self.rockets.retain(|r| r.id != id);
        self.crystals.retain(|c| c.id != id);
        self.potions.remove_remote_thrown(id);
        self.potions.clouds.retain(|c| c.id != id);
        self.dragon_fireballs.retain(|b| b.id != id);
        self.end.remove_remote_eye(id);
        self.remove_remote_hook(id);
    }

    /// Every one a server sent (a new connection, level or dimension).
    pub(super) fn clear_remote_projectiles(&mut self) {
        self.fangs.list.clear();
        self.tnts.clear();
        self.falling.clear();
        self.creatures.projectiles.clear();
        self.tridents.clear();
        self.rockets.clear();
        self.crystals.clear();
        // The dragon a server sent goes with its crystals.
        self.dragon = None;
        self.potions.clear_thrown();
        self.potions.clouds.clear();
        self.dragon_fireballs.clear();
        self.end.clear_remote_eyes();
        self.clear_remote_hooks();
    }

    /// Their kind and place, for `status`.
    pub(super) fn projectiles_status(&self) -> Vec<serde_json::Value> {
        use serde_json::json;
        let at = |p: Vec3| [p.x, p.y, p.z];
        let mut out = Vec::new();
        for f in &self.fangs.list {
            out.push(
                json!({"id": f.id, "kind": "minecraft:evoker_fangs", "position": f.pos,
                "yaw": f.yaw, "started": f.started, "life": f.life}),
            );
        }
        for t in &self.tnts {
            out.push(json!({"id": t.id, "kind": "minecraft:tnt", "position": at(t.position), "fuse": t.fuse}));
        }
        for f in &self.falling {
            out.push(json!({"id": f.id, "kind": "minecraft:falling_block", "position": at(f.position), "velocity": at(f.velocity), "state": f.state.0}));
        }
        for b in &self.boats {
            out.push(json!({"id": b.id, "kind": "minecraft:boat", "position": at(b.position), "velocity": at(b.velocity)}));
        }
        for c in &self.carts {
            out.push(json!({"id": c.id, "kind": "minecraft:minecart", "position": at(c.position), "velocity": at(c.velocity)}));
        }
        for c in &self.crystals {
            out.push(json!({"id": c.id, "kind": "minecraft:end_crystal", "position": at(c.position), "show_bottom": c.show_bottom}));
        }
        for t in &self.tridents {
            out.push(json!({"id": t.id, "kind": "minecraft:trident", "position": at(t.position), "velocity": at(t.velocity), "on_fire": t.fire_ticks > 0}));
        }
        for r in &self.rockets {
            out.push(json!({"id": r.id, "kind": "minecraft:firework_rocket", "position": at(r.position), "velocity": at(r.velocity)}));
        }
        for p in &self.creatures.projectiles {
            out.push(json!({"id": p.id, "kind": format!("{:?}", p.kind).split([' ', '{']).next().unwrap_or(""), "position": at(p.position), "velocity": at(p.velocity),
                "player_owned": p.owner == Some(horizon_client::mobs::Who::Player),
                "on_fire": p.arrow.as_ref().is_some_and(|a| a.on_fire())}));
        }
        for (kind, p, _) in self.potions.thrown_entities() {
            out.push(json!({"kind": kind, "position": at(p)}));
        }
        for (id, p) in self.end.eye_positions() {
            out.push(json!({"id": id, "kind": "minecraft:eye_of_ender", "position": p}));
        }
        out.extend(self.hooks_status());
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use horizon_client::mobs::Who;
    use horizon_core::geometry::Aabb;

    /// A world with nothing in it: the client tick of a projectile only
    /// needs the blocks around it.
    struct Empty;
    impl ProjectileWorld for Empty {
        fn clip(&self, _: Vec3, _: Vec3) -> Option<(Vec3, [i32; 3], [i32; 3])> {
            None
        }
        fn in_water(&self, _: Aabb) -> bool {
            false
        }
        fn targets(&self) -> &[(Who, Aabb)] {
            &[]
        }
    }

    /// A thrown item, as a server's client tracks it: the spawn position and
    /// the motion the server gave it.
    fn thrown(kind: ProjectileKind) -> Projectile {
        let mut p = Projectile::new(kind, Vec3::new(0.0, 100.0, 0.0), None);
        p.velocity = Vec3::new(1.5, 0.0, 0.0);
        p
    }

    /// The same, under the id a server tracks it by.
    fn tracked(kind: ProjectileKind, id: u32) -> Projectile {
        let mut p = thrown(kind);
        p.id = id;
        p
    }

    #[test]
    fn a_shulker_bullet_trail_stays_inside_its_box() {
        let at = Vec3::new(10.0, 20.0, 30.0);
        let mut random = horizon_core::random::LegacyRandom::new(1);
        for _ in 0..32 {
            let [x, y, z] = shulker_bullet_trail_at(at, &mut random);
            assert!((x - at.x).abs() <= 0.3125 * 0.5 + 1e-12, "{x}");
            assert!((0.0..0.3125 + 1e-12).contains(&(y - at.y)), "{y}");
            assert!((z - at.z).abs() <= 0.3125 * 0.5 + 1e-12, "{z}");
        }
    }

    /// `Entity.setOldPosAndRot`: what the renderer interpolates a projectile's
    /// rotation from is the rotation the last tick ended with. An arrow shot
    /// straight up at the lowest power a bow fires turns over within a few
    /// ticks, so every tick has to carry the value of the one before it.
    #[test]
    fn a_thrown_item_flies_on_between_the_server_updates() {
        // A thrown egg, an ender pearl and a wind charge (#1762): the server
        // sends their position every 10 ticks, and the client ticks them
        // itself in between, as vanilla's no-op interpolation handler does.
        for kind in [
            ProjectileKind::Egg,
            ProjectileKind::EnderPearl,
            ProjectileKind::WindCharge,
        ] {
            let mut p = thrown(kind);
            remote_projectile_tick(&mut p, &Empty);
            assert!(p.position.x > 1.0, "the projectile did not fly on: {p:?}");
            // A second tick moves it further: it keeps flying, not a hop.
            let first = p.position.x;
            remote_projectile_tick(&mut p, &Empty);
            assert!(p.position.x > first, "the projectile stopped: {p:?}");
        }
    }

    #[test]
    fn a_thrown_item_falls_and_drags_like_a_throwable_projectile() {
        // ThrowableProjectile.tick: gravity 0.03, then the air drag 0.99F
        // (`getAirDrag`, a float widened to the double it scales by).
        let drag = f64::from(0.99_f32);
        let mut p = thrown(ProjectileKind::Egg);
        remote_projectile_tick(&mut p, &Empty);
        assert!((p.velocity.x - 1.5 * drag).abs() < 1e-9, "{p:?}");
        assert!((p.velocity.y - (-0.03 * drag)).abs() < 1e-9, "{p:?}");
        // A wind charge keeps its speed: no gravity and no drag
        // (AbstractWindCharge: acceleration 0, inertia 1).
        let mut p = thrown(ProjectileKind::WindCharge);
        remote_projectile_tick(&mut p, &Empty);
        assert!((p.velocity.x - 1.5).abs() < 1e-9, "{p:?}");
        assert!((p.velocity.y - 0.0).abs() < 1e-9, "{p:?}");
    }

    #[test]
    fn a_power_packet_gives_a_fireball_the_power_its_next_tick_uses() {
        // ClientPacketListener.handleProjectilePowerPacket: the fireball with
        // id 12 gets the power the server sends bundled with its motion.
        let mut list = vec![tracked(ProjectileKind::LargeFireball { power: 1 }, 12)];
        remote_projectile_power(&mut list, 12, 0.5);
        assert_eq!(list[0].acceleration, 0.5);
        // AbstractHurtingProjectile.applyInertia: (1.5 + 0.5) * (double) 0.95f.
        remote_projectile_tick(&mut list[0], &Empty);
        assert_eq!(list[0].velocity.x, 1.899_999_976_158_142);
    }

    #[test]
    fn a_power_packet_ignores_an_arrow_an_unknown_id_and_a_thrown_item() {
        // Vanilla's instanceof AbstractHurtingProjectile: an arrow and a
        // thrown egg are none, and no entity is id 99.
        let mut list = vec![
            tracked(
                ProjectileKind::Arrow {
                    base_damage: 2.0,
                    critical: false,
                    effect: None,
                },
                3,
            ),
            tracked(ProjectileKind::Egg, 4),
            tracked(ProjectileKind::LargeFireball { power: 1 }, 12),
        ];
        remote_projectile_power(&mut list, 3, 0.5);
        remote_projectile_power(&mut list, 4, 0.5);
        remote_projectile_power(&mut list, 99, 0.5);
        assert_eq!(
            list.iter().map(|p| p.acceleration).collect::<Vec<_>>(),
            [0.1; 3]
        );
    }

    #[test]
    fn a_guest_draws_a_fireball_as_the_item_the_server_sends() {
        // `ClientPacketListener.handleSetEntityData` of
        // Fireball.DATA_ITEM_STACK: the item `Fireball.getItem` returns, which
        // is the fire charge the default was until the server says otherwise.
        let mut list = vec![
            tracked(ProjectileKind::LargeFireball { power: 1 }, 12),
            tracked(ProjectileKind::SmallFireball, 13),
            tracked(ProjectileKind::Snowball, 14),
        ];
        remote_projectile_item(&mut list, 12, ItemStack::new("minecraft:diamond", 4));
        assert_eq!(
            list[0].item.as_ref().map(|i| (&*i.item, i.count)),
            Some(("minecraft:diamond", 1)),
            "one of it, as `setItem` keeps"
        );
        // The default fire charge goes back when the server sends an empty
        // stack, and a snowball is no `Fireball`: it has no item to set.
        remote_projectile_item(&mut list, 13, ItemStack::new("minecraft:air", 1));
        assert_eq!(
            list[1].item.as_ref().map(|i| (&*i.item, i.count)),
            Some(("minecraft:fire_charge", 1))
        );
        remote_projectile_item(&mut list, 14, ItemStack::new("minecraft:diamond", 1));
        assert_eq!(list[2].item, None);
    }
}
