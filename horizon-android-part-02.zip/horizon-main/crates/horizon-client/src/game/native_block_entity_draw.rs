//! Mod block entities drawn on the client: `native_block_entity_submit`
//! (vanilla's `BlockEntityRenderer.submit`) gets a [`BlockEntityDraw`], whose
//! pose stack (`PoseStack`) places what the helpers here add to the entity
//! batch, as vanilla's block entity renderers draw.

use super::{Dim, Game};
use glam::{DVec3, Mat4, Quat, Vec3};
use horizon_assets::{
    bake::{bake_flat_face, default_uv},
    item_model::DisplayContext,
    model::{Direction, Material},
};
use horizon_client::{
    block_entity_render::{TextCall, diffuse, diffuse_lights, text_vertices, vertex_light},
    containers::{BlockEntity, ModRevision},
    fast_hash::FxHashMap,
    gfx::Cull,
    hud::Rect,
    items::ItemStack,
    mesher::Vertex,
    mobs::model_layers::{self, ModelPart},
    text::Text,
};
use horizon_world::registry::BlockStateId;

/// `BlockEntityRenderer.getViewDistance`'s default, in blocks.
const VIEW_DISTANCE: f64 = 64.0;
/// A mod block entity's bounds until its mod says otherwise: the block with
/// the block of margin Horizon culls vanilla's block entities with.
const DEFAULT_BOUNDS: [f32; 6] = [-1.0, -1.0, -1.0, 2.0, 2.0, 2.0];

/// Whether `bounds` (min then max, in blocks from `origin`, the block's corner
/// relative to the camera) meet the frustum; an infinite bound always does
/// (NeoForge's `INFINITE_EXTENT_AABB`), as does a frame without a frustum.
fn in_frustum(frustum: Option<&impl Cull>, origin: Vec3, bounds: [f32; 6]) -> bool {
    if bounds.iter().any(|b| !b.is_finite()) {
        return true;
    }
    let min = origin + Vec3::new(bounds[0], bounds[1], bounds[2]);
    let max = origin + Vec3::new(bounds[3], bounds[4], bounds[5]);
    frustum.is_none_or(|f| f.intersects(min, max))
}

/// One mod block entity's frame, as `submit` gets it: the render state's
/// partial tick, game time and light, and the pose stack the helpers draw
/// under (`native_draw_quad`, `native_draw_cube`, `native_draw_block`).
// Native mods read and drive it; nothing in Horizon does.
pub struct BlockEntityDraw {
    /// The frame's partial tick, 0 to 1 (`BlockEntityRenderState`).
    pub partial: f32,
    /// The level's game time, for animations.
    pub game_time: i64,
    /// The light the helpers draw with: the block's own
    /// (`LevelRenderer.getLightCoords`), 16 times sky light in bits 0..8 and
    /// 16 times block light in bits 8..16; set it to light a part otherwise.
    pub light: u32,
    /// The block drawn, for `native_draw_item`'s owner.
    block: [i32; 3],
    poses: Vec<Mat4>,
    lights: (Vec3, Vec3),
    vertices: Vec<Vertex>,
    kept: bool,
    /// Where each turning part starts in `vertices` (`spin`), and where the
    /// parts standing still start again (`still`, none).
    spins: Vec<(usize, Option<Spin>)>,
}

/// A part of a block entity's frame that turns by itself (`BlockEntityDraw::spin`).
#[derive(Clone, Copy, Debug, PartialEq)]
pub(super) struct Spin {
    axis: Vec3,
    pivot: Vec3,
    degrees_per_tick: f32,
    phase: f32,
}

impl Spin {
    /// The turn at `game_time` plus `partial`, about the pivot, in the
    /// block's coordinates. Counted in f64: a world's game time has more
    /// ticks than an f32 holds exactly.
    fn turn(&self, game_time: i64, partial: f32) -> Mat4 {
        let t = game_time as f64 + f64::from(partial);
        let degrees =
            (t * f64::from(self.degrees_per_tick) + f64::from(self.phase)).rem_euclid(360.0);
        Mat4::from_translation(self.pivot)
            * Mat4::from_quat(Quat::from_axis_angle(
                self.axis,
                (degrees as f32).to_radians(),
            ))
            * Mat4::from_translation(-self.pivot)
    }
}

/// `vertices`, drawn relative to the block, moved to the camera by `origin`
/// and each part of `spins` (starts relative to `vertices`) turned as it is
/// at `game_time` plus `partial`, onto `out`.
pub(super) fn place_turning(
    vertices: &[Vertex],
    spins: &[(usize, Option<Spin>)],
    game_time: i64,
    partial: f32,
    origin: Vec3,
    out: &mut Vec<Vertex>,
) {
    let mut turn: Option<Mat4> = None;
    let mut next = spins.iter().peekable();
    for (i, v) in vertices.iter().enumerate() {
        while let Some((start, spin)) = next.next_if(|(start, _)| *start <= i) {
            let _ = start;
            turn = spin.map(|s| s.turn(game_time, partial));
        }
        let mut v = *v;
        if let Some(m) = turn {
            v.pos = m.transform_point3(Vec3::from_array(v.pos)).to_array();
            if v.normal[3] != 0 {
                let n = Vec3::new(
                    f32::from(v.normal[0]),
                    f32::from(v.normal[1]),
                    f32::from(v.normal[2]),
                );
                let n = m.transform_vector3(n);
                v.normal = [
                    n.x.round().clamp(-127.0, 127.0) as i8,
                    n.y.round().clamp(-127.0, 127.0) as i8,
                    n.z.round().clamp(-127.0, 127.0) as i8,
                    v.normal[3],
                ];
            }
        }
        v.pos = (Vec3::from_array(v.pos) + origin).to_array();
        out.push(v);
    }
}

#[allow(dead_code)]
impl BlockEntityDraw {
    /// A frame drawn from `pose` (relative to the camera), lit by `light` and
    /// `lights`, adding to `vertices`; `block` is where `native_draw_item`'s
    /// owner stands. A mob's frame (`native_mob_submit`) is made this way.
    pub(super) fn posed(
        partial: f32,
        game_time: i64,
        light: u32,
        block: [i32; 3],
        pose: Mat4,
        lights: (Vec3, Vec3),
        vertices: Vec<Vertex>,
    ) -> Self {
        Self {
            partial,
            game_time,
            light,
            block,
            poses: vec![pose],
            lights,
            vertices,
            kept: false,
            spins: Vec::new(),
        }
    }
    /// The vertices drawn, with those it was made with first.
    pub(super) fn into_vertices(self) -> Vec<Vertex> {
        self.vertices
    }
    /// The vertices drawn and where its turning parts start in them (`spin`).
    pub(super) fn into_turning(self) -> (Vec<Vertex>, Vec<(usize, Option<Spin>)>) {
        (self.vertices, self.spins)
    }
    /// `PoseStack.pushPose`: `pop` comes back to the pose as it is now.
    pub fn push(&mut self) {
        let pose = self.pose();
        self.poses.push(pose);
    }
    /// `PoseStack.popPose`; the block's own pose is never popped.
    pub fn pop(&mut self) {
        if self.poses.len() > 1 {
            self.poses.pop();
        }
    }
    /// Moves what is drawn next by `by`, in blocks.
    pub fn translate(&mut self, by: [f32; 3]) {
        self.apply(Mat4::from_translation(Vec3::from_array(by)));
    }
    /// Turns what is drawn next by `degrees` about `axis` (counterclockwise
    /// seen from the axis' positive end, as `Axis.rotationDegrees`) through
    /// `pivot`, in blocks from the pose's origin: `[0.5; 3]` is the block's centre.
    pub fn rotate_about(&mut self, axis: [f32; 3], degrees: f32, pivot: [f32; 3]) {
        let axis = Vec3::from_array(axis).normalize_or(Vec3::Y);
        let pivot = Vec3::from_array(pivot);
        self.apply(
            Mat4::from_translation(pivot)
                * Mat4::from_quat(Quat::from_axis_angle(axis, degrees.to_radians()))
                * Mat4::from_translation(-pivot),
        );
    }
    /// Scales what is drawn next by `by` about the pose's origin.
    pub fn scale(&mut self, by: [f32; 3]) {
        self.apply(Mat4::from_scale(Vec3::from_array(by)));
    }
    /// Keeps what this call drew: the block is drawn the same again, with
    /// neither `native_block_entity_submit` nor
    /// `native_block_entity_render_bounding_box` called, until its state,
    /// its block entity (what the server sent), its light or the resource
    /// packs change. Call it only when what you drew reads none of
    /// `partial`, `game_time`, the blocks around it or anything else of
    /// yours, and moves nothing by itself but through `spin`: an idle machine,
    /// or a shaft turning at a steady speed, not one whose speed changes from
    /// frame to frame. Kept geometry stands still: an enchanted item's glint, and an
    /// item drawn with `native_draw_item` whose model reads the time (a clock,
    /// a compass), stop where they were. API 94.
    pub fn keep(&mut self) {
        self.kept = true;
    }
    /// What is drawn next turns by itself: `degrees_per_tick` degrees each
    /// game tick (a shaft at `rpm` turns `rpm * 0.3`, as Create's do), about
    /// `axis` through `pivot`, both in blocks from the block's corner
    /// whatever the pose, counterclockwise seen from the axis' positive end,
    /// `phase` degrees round at game time 0 (to mesh a cog with its
    /// neighbour's). Draw the part at rest; the game turns it each frame from
    /// the game time and the partial tick. With `keep` it goes on turning
    /// with no call of `native_block_entity_submit` until what it was drawn
    /// with changes: send a new speed in the update tag and the block is
    /// drawn again (Flywheel's rotating instances, done on the CPU). The
    /// angle is `game_time * degrees_per_tick + phase`, not a sum of turns:
    /// with a new speed, pass the phase that keeps the part where it was
    /// (`old_angle - game_time * new_speed`), or it jumps. Until
    /// `still` or the next `spin`. A block entity's frame only: a mob's
    /// (`native_mob_submit`) draws it at rest. API @API:spinning_geometry@.
    pub fn spin(&mut self, axis: [f32; 3], pivot: [f32; 3], degrees_per_tick: f32, phase: f32) {
        let spin = Spin {
            axis: Vec3::from_array(axis).normalize_or(Vec3::Y),
            pivot: Vec3::from_array(pivot),
            degrees_per_tick: if degrees_per_tick.is_finite() {
                degrees_per_tick
            } else {
                0.0
            },
            phase: if phase.is_finite() { phase } else { 0.0 },
        };
        self.spins.push((self.vertices.len(), Some(spin)));
    }
    /// What is drawn next stands still again, after `spin`.
    /// API @API:spinning_geometry@.
    pub fn still(&mut self) {
        self.spins.push((self.vertices.len(), None));
    }
    fn apply(&mut self, m: Mat4) {
        if let Some(pose) = self.poses.last_mut() {
            *pose *= m;
        }
    }
    pub(super) fn pose(&self) -> Mat4 {
        self.poses.last().copied().unwrap_or(Mat4::IDENTITY)
    }
    pub(super) fn vertices_mut(&mut self) -> &mut Vec<Vertex> {
        &mut self.vertices
    }
    /// A quad of `corners` (blocks, under the pose) with unit UVs, shaded as
    /// vanilla's block entity models are (`Lighting`'s two lights).
    fn quad(&mut self, corners: [[f32; 3]; 4], uv: [[f32; 2]; 4], sprite: Rect, tint: u32) {
        let pose = self.pose();
        let at = corners.map(|c| pose.transform_point3(Vec3::from_array(c)));
        let normal = (at[1] - at[0]).cross(at[2] - at[0]).normalize_or_zero();
        let normal = if normal == Vec3::ZERO {
            (at[2] - at[1]).cross(at[3] - at[1]).normalize_or(Vec3::Y)
        } else {
            normal
        };
        let color = shaded(tint, diffuse(normal, self.lights));
        for (p, uv) in at.into_iter().zip(uv) {
            self.vertices.push(Vertex {
                pos: p.to_array(),
                uv: [
                    sprite.u0 + (sprite.u1 - sprite.u0) * uv[0],
                    sprite.v0 + (sprite.v1 - sprite.v0) * uv[1],
                ],
                layer: 0,
                color,
                light: self.light,
                normal: [0; 4],
                glint_uv: [0.0, 0.0],
            });
        }
    }
}

/// One face of a `native_draw_cube` box: its sprite (`mymod:entity/cog`,
/// `mymod:block/casing`) and its UVs in texels of 16 per side, as a model
/// face's `uv` (none takes the box's own, as a model's default).
#[derive(Clone, Copy, Debug)]
pub struct CubeFace<'a> {
    pub sprite: &'a str,
    pub uv: Option<[f32; 4]>,
}

/// 0xRRGGBB `tint` times `brightness`, as an opaque vertex colour.
fn shaded(tint: u32, brightness: f32) -> u32 {
    let c = |shift: u32| (((tint >> shift) & 255) as f32 * brightness) as u32;
    0xFF00_0000 | c(0) << 16 | c(8) << 8 | c(16)
}

/// Game ticks kept geometry stays after it was last drawn, as signs' text.
const KEPT_FOR: i64 = 100;

/// What kept geometry was drawn with besides its block entity: drawn again
/// when any of it changes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct KeptKey {
    dim: Dim,
    state: u32,
    light: u32,
    /// `Font::epoch` when it was drawn: a cache reset moves glyphs in the
    /// atlas, so text a mod kept (`native_draw_text`) is drawn again, as a
    /// sign's kept text is.
    glyphs: u64,
}

struct KeptEntry {
    key: KeptKey,
    /// Of the block entity it was drawn from: equal, nothing changed it.
    revision: ModRevision,
    bounds: [f32; 6],
    /// Game time it was last drawn.
    used: i64,
    /// Relative to the block's corner.
    vertices: Vec<Vertex>,
    /// Its turning parts (`BlockEntityDraw::spin`), from the start of `vertices`.
    spins: Vec<(usize, Option<Spin>)>,
}

/// Geometry mods kept (`BlockEntityDraw::keep`), by position. As
/// `SignTexts` keeps a sign's text, it is kept relative to the block and
/// moved to the camera each frame.
#[derive(Default)]
pub(super) struct KeptGeometry {
    entries: FxHashMap<[i32; 3], KeptEntry>,
    /// Game time of the last sweep of what is out of view.
    swept: i64,
}

impl KeptGeometry {
    /// Drops what was not drawn for `KEPT_FOR` ticks, once every `KEPT_FOR`.
    fn sweep(&mut self, now: i64) {
        if (now - self.swept).abs() >= KEPT_FOR {
            self.swept = now;
            self.entries
                .retain(|_, e| (now - KEPT_FOR..=now).contains(&e.used));
        }
    }
    /// What is kept at `pos` when it was drawn with `key` and its block
    /// entity at `revision`, marked drawn at `now`.
    fn get(
        &mut self,
        pos: [i32; 3],
        key: KeptKey,
        revision: ModRevision,
        now: i64,
    ) -> Option<&KeptEntry> {
        let entry = self
            .entries
            .get_mut(&pos)
            .filter(|e| e.key == key && e.revision == revision)?;
        entry.used = now;
        Some(entry)
    }
    fn keep(
        &mut self,
        pos: [i32; 3],
        key: KeptKey,
        revision: ModRevision,
        bounds: [f32; 6],
        vertices: &[Vertex],
        spins: Vec<(usize, Option<Spin>)>,
        now: i64,
    ) {
        let mut kept = self
            .entries
            .remove(&pos)
            .map_or_else(Vec::new, |e| e.vertices);
        kept.clear();
        kept.extend_from_slice(vertices);
        self.entries.insert(
            pos,
            KeptEntry {
                key,
                revision,
                bounds,
                used: now,
                vertices: kept,
                spins,
            },
        );
    }
    fn forget(&mut self, pos: [i32; 3]) {
        self.entries.remove(&pos);
    }
    /// Forgets everything: the atlas's sprites moved.
    pub(super) fn clear(&mut self) {
        self.entries.clear();
    }
}

impl Game<'_> {
    /// The mod block entities within view distance of `camera` whose block's
    /// template has none, which the mesher's block entity lists (made from
    /// the template) leave out: where they are and their block's state, for
    /// `mod_block_entity_geometry`. From the per-chunk list of
    /// `BlockEntities::mods_near`, not a scan of every block entity.
    pub(super) fn untemplated_mod_block_entities(&self, camera: DVec3) -> Vec<([i32; 3], u32)> {
        self.world
            .block_entities
            .mods_near(camera.x, camera.z, VIEW_DISTANCE)
            .map(|p| ([p.0, p.1, p.2], self.world.block(p.0, p.1, p.2).0))
            .filter(|&(_, state)| !self.res.facts().get(BlockStateId(state)).block_entity)
            .collect()
    }
    /// `native_block_entity_submit` for each of `blocks` (in drawn sections,
    /// drawn by no vanilla renderer) whose block entity is a mod's, closer than
    /// `BlockEntityRenderer.getViewDistance` to the camera (`shouldRender`)
    /// and with its bounds (`native_block_entity_render_bounding_box`) in the
    /// frustum. Entity occlusion culling is for ordinary entities; block
    /// entities use these renderer-provided bounds instead.
    pub(super) fn mod_block_entity_geometry<'a>(
        &self,
        blocks: impl Iterator<Item = &'a ([i32; 3], u32)>,
        camera: DVec3,
        partial: f32,
        out: &mut Vec<Vertex>,
    ) {
        let mut draw = BlockEntityDraw {
            partial,
            game_time: self.world.game_time,
            light: 0,
            block: [0; 3],
            poses: Vec::new(),
            lights: diffuse_lights(self.dim == Dim::Nether),
            vertices: std::mem::take(out),
            kept: false,
            spins: Vec::new(),
        };
        let now = self.world.game_time;
        let mut kept = self.kept_block_entities.borrow_mut();
        kept.sweep(now);
        for &(pos, state) in blocks {
            let corner = DVec3::new(f64::from(pos[0]), f64::from(pos[1]), f64::from(pos[2]));
            // Vec3.closerThan: strictly closer.
            if (corner + 0.5).distance_squared(camera) >= VIEW_DISTANCE * VIEW_DISTANCE {
                continue;
            }
            let Some(BlockEntity::Mod(entity)) =
                self.world.block_entities.get(&(pos[0], pos[1], pos[2]))
            else {
                continue;
            };
            let origin = (corner - camera).as_vec3();
            let light = vertex_light(self.world.light(pos[0], pos[1], pos[2]));
            let key = KeptKey {
                dim: self.dim,
                state,
                light,
                glyphs: self.gui.atlas.font.epoch(),
            };
            if let Some(entry) = kept.get(pos, key, entity.revision(), now) {
                if in_frustum(self.view_frustum.as_ref(), origin, entry.bounds) {
                    let start = draw.vertices.len();
                    self.mark_block_entity(start, state);
                    if entry.spins.is_empty() {
                        draw.vertices.extend(entry.vertices.iter().map(|v| Vertex {
                            pos: (Vec3::from_array(v.pos) + origin).to_array(),
                            ..*v
                        }));
                    } else {
                        place_turning(
                            &entry.vertices,
                            &entry.spins,
                            draw.game_time,
                            draw.partial,
                            origin,
                            &mut draw.vertices,
                        );
                    }
                }
                continue;
            }
            let id = BlockStateId(state);
            let block = &*self.res.facts().get(id).name;
            let mut bounds = DEFAULT_BOUNDS;
            self.native_block_entity_render_bounding_box(pos, block, id, entity, &mut bounds);
            if !in_frustum(self.view_frustum.as_ref(), origin, bounds) {
                continue;
            }
            let start = draw.vertices.len();
            self.mark_block_entity(start, state);
            // Drawn relative to the block, then moved to the camera, so what
            // is kept can be moved again.
            draw.block = pos;
            draw.poses.clear();
            draw.poses.push(Mat4::IDENTITY);
            draw.light = light;
            draw.kept = false;
            draw.spins.clear();
            self.native_block_entity_submit(pos, block, id, entity, &mut draw);
            // The turning parts, from the start of this block's vertices.
            let spins: Vec<(usize, Option<Spin>)> = draw
                .spins
                .drain(..)
                .map(|(at, spin)| (at.saturating_sub(start), spin))
                .collect();
            if draw.kept {
                kept.keep(
                    pos,
                    key,
                    entity.revision(),
                    bounds,
                    &draw.vertices[start..],
                    spins.clone(),
                    now,
                );
            } else {
                kept.forget(pos);
            }
            if spins.is_empty() {
                for v in &mut draw.vertices[start..] {
                    v.pos = (Vec3::from_array(v.pos) + origin).to_array();
                }
            } else {
                let drawn = draw.vertices.split_off(start);
                place_turning(
                    &drawn,
                    &spins,
                    draw.game_time,
                    draw.partial,
                    origin,
                    &mut draw.vertices,
                );
            }
        }
        *out = draw.vertices;
    }
}

/// Helpers for drawing mod block entities, kept as stable as the hook points.
// Native mods use these; nothing in Horizon does.
#[allow(dead_code)]
impl Game<'_> {
    /// Draws a quad with `corners` in blocks under `draw`'s pose, in a model
    /// face's order (top left, bottom left, bottom right, top right as seen
    /// from its front), textured with the `uv` rectangle (u0, v0, u1, v1 in
    /// texels of 16 per side) of `sprite` (`mymod:entity/screen`,
    /// `mymod:block/casing`, `block/stone`) times the 0xRRGGBB `tint`
    /// (0xFFFFFF for none). False for an unknown sprite. API 71.
    pub(super) fn native_draw_quad(
        &self,
        draw: &mut BlockEntityDraw,
        sprite: &str,
        corners: [[f32; 3]; 4],
        uv: [f32; 4],
        tint: u32,
    ) -> bool {
        let Some(rect) = self.gui.atlas.sprites.get(sprite).copied() else {
            return false;
        };
        let [u0, v0, u1, v1] = uv.map(|t| t / 16.0);
        draw.quad(
            corners,
            [[u0, v0], [u0, v1], [u1, v1], [u1, v0]],
            rect,
            tint,
        );
        true
    }

    /// Draws `text` under `draw`'s pose as a sign draws its lines
    /// (`Font.drawInBatch` in a `BlockEntityRenderer`): in the pose's x-y
    /// plane, one unit a font pixel, y down, its left end at `at`, facing
    /// +z. Scale the pose first as a sign does (`draw.scale([1.0 / 64.0,
    /// -1.0 / 64.0, 1.0 / 64.0])` for its letters, 8 pixels high). Each span
    /// is drawn in its own colour, the others in the 0xRRGGBB `color`;
    /// `glowing` text is full bright (a glow ink sac's), the rest lit by
    /// `draw.light`; a nonzero 0xRRGGBB `outline` rings each glyph, as glowing
    /// sign text's. Returns the width drawn, in font pixels: centre a line
    /// by starting it at minus half its width. API @API:draw_text@.
    pub(super) fn native_draw_text(
        &self,
        draw: &mut BlockEntityDraw,
        text: &Text,
        at: [f32; 2],
        color: u32,
        glowing: bool,
        outline: u32,
    ) -> f32 {
        let glyph = |c: char| self.gui.atlas.glyph_cell(c);
        let light = if glowing { 240 | 240 << 8 } else { draw.light };
        let matrix = draw.pose();
        let mut x = at[0];
        for span in &text.spans {
            let shown = horizon_client::bidi::visual_str(&span.text).into_owned();
            let width: f32 = shown.chars().map(|c| glyph(c).advance).sum();
            let call = TextCall {
                matrix,
                x,
                y: at[1],
                text: shown,
                color: 0xFF00_0000 | (span.style.color.unwrap_or(color) & 0xFF_FFFF),
                outline: if outline == 0 {
                    0
                } else {
                    0xFF00_0000 | (outline & 0xFF_FFFF)
                },
                light,
            };
            text_vertices(&glyph, &call, &mut draw.vertices);
            x += width;
        }
        x - at[0]
    }

    /// Draws a box from `from` to `to` (texels of 16 per block, as a block
    /// model's element) under `draw`'s pose, with the faces given, by
    /// `Direction` (down, up, north, south, west, east), baked as a model
    /// element's are (`FaceBakery`), times the 0xRRGGBB `tint`. A turned box
    /// is drawn under a turned pose (`BlockEntityDraw::rotate_about`). False
    /// when a face's sprite is unknown; that face is left out. API 71.
    pub(super) fn native_draw_cube(
        &self,
        draw: &mut BlockEntityDraw,
        from: [f32; 3],
        to: [f32; 3],
        faces: [Option<CubeFace<'_>>; 6],
        tint: u32,
    ) -> bool {
        let mut all = true;
        for (direction, face) in Direction::ALL.into_iter().zip(faces) {
            let Some(face) = face else { continue };
            let Some(rect) = self.gui.atlas.sprites.get(face.sprite).copied() else {
                all = false;
                continue;
            };
            let uv = face.uv.unwrap_or_else(|| default_uv(from, to, direction));
            let material = Material {
                sprite: String::new(),
                force_translucent: false,
            };
            if let Ok(quad) = bake_flat_face(from, to, uv, direction, material, -1) {
                draw.quad(quad.positions, quad.uv, rect, tint);
            }
        }
        all
    }

    /// Draws block `block`'s model (`mymod:cog`, any block with a model) in
    /// the state with `properties` (`[("axis", "x")]`, the rest default)
    /// under `draw`'s pose, as vanilla's `submitBlockModel` draws a block in
    /// an entity's place: a block's baked model, with its default tints. A
    /// moving part that is no block is a standalone model
    /// (`native_draw_model`). False for an unknown block or property. API 71.
    pub(super) fn native_draw_block(
        &self,
        draw: &mut BlockEntityDraw,
        block: &str,
        properties: &[(&str, &str)],
    ) -> bool {
        let registry = &self.pack.assets.registry;
        let Some(mut state) = registry
            .default_state(block)
            .and_then(|id| registry.state(id))
            .cloned()
        else {
            return false;
        };
        for (key, value) in properties {
            match state.properties.get_mut(*key) {
                Some(v) => *v = (*value).to_owned(),
                None => return false,
            }
        }
        let Some(id) = registry.id(&state) else {
            return false;
        };
        let pose = draw.pose();
        self.block_model_vertices(id, 42, pose, draw.light, true, &mut draw.vertices);
        true
    }

    /// Draws standalone model `model` (`mymod:block/shaft_half`, one a mod
    /// named in `native_standalone_models`) under `draw`'s pose, as
    /// `native_draw_block` draws a block's: unturned, from the block's lower
    /// north-west corner, lit by `draw.light`. Its faces with a tint index
    /// are multiplied by the 0xRRGGBB `tint` (0xFFFFFF for none), the
    /// others drawn as they are. False when the model isn't baked: not
    /// named, missing from the resources, or on a side that draws nothing.
    /// API 151.
    pub(super) fn native_draw_model(
        &self,
        draw: &mut BlockEntityDraw,
        model: &str,
        tint: u32,
    ) -> bool {
        let Some(baked) = self.pack.render.model_catalog.standalone(model) else {
            return false;
        };
        let pose = draw.pose();
        let light = draw.light;
        let tint = |index: i32| (index >= 0).then_some(tint & 0xFF_FFFF);
        self.baked_model_vertices([baked], pose, |_| light, true, tint, &mut draw.vertices);
        true
    }

    /// Draws model part `part` and the parts under it under `draw`'s pose, as
    /// vanilla's `ModelPart.render` does: each part moved to its place (in
    /// texels, 16 to a block), turned about z, then y, then x, and scaled,
    /// its faces textured from `sprite` (`mymod:entity/golem`, a content
    /// mod's `assets/mymod/textures/entity/golem.png`, or vanilla's
    /// `entity/zombie/zombie`) times the 0xRRGGBB `tint`. A part that isn't
    /// `visible` draws nothing, one that skips drawing (`skip_draw`) only its
    /// children. A mob's model is built in the model's own frame (+y down,
    /// its front towards -z, its feet 24 texels down): in `native_mob_submit`,
    /// `draw.scale([1.0, -1.0, -1.0])` then `draw.translate([0.0, -1.501,
    /// 0.0])` first, as `LivingEntityRenderer` does. False for an unknown
    /// sprite. API @API:model_layers@.
    pub(super) fn native_draw_model_part(
        &self,
        draw: &mut BlockEntityDraw,
        part: &ModelPart,
        sprite: &str,
        tint: u32,
    ) -> bool {
        let Some(rect) = self.gui.atlas.sprites.get(sprite).copied() else {
            return false;
        };
        draw_model_part(draw, part, rect, tint);
        true
    }

    /// Entity model layer `layer` baked into its `ModelPart` tree, each part
    /// at its pose, as `EntityModelSet.bakeLayer` bakes it: one a native mod
    /// registered (`native_layer_definitions`), or vanilla's, by the name
    /// `entity-models.json` gives it (`minecraft:zombie#main`,
    /// `minecraft:player#main`). The tree is the caller's own copy: bake it
    /// once, as a renderer does, and set its parts' poses each frame. None
    /// for a layer neither has. A vanilla layer no mob has (a player's, a
    /// chest's) is read from the resources each call, so slow. API
    /// @API:model_layers@.
    pub(super) fn native_bake_layer(&self, layer: &str) -> Option<ModelPart> {
        if let Some(definition) = model_layers::registered(layer) {
            return Some(definition.bake_root());
        }
        let key = layer.strip_prefix("minecraft:")?;
        if let Some(part) = self.res.mob_types().values().find_map(|t| t.layer(key)) {
            return Some(ModelPart::from_part(part));
        }
        let models = horizon_client::mobs::EntityModelDocument::load(&self.vanilla_root()).ok()?;
        models.model(layer).map(|part| ModelPart::from_part(&part))
    }

    /// Draws `stack` under `draw`'s pose as an item is drawn in the world
    /// (`ItemModelResolver.updateForTopItem` and `ItemStackRenderState.submit`), centred on the
    /// pose's origin, in its model's `display` transform: `Fixed` as a
    /// campfire's or an item frame's, `Ground` as a dropped item's. `seed`
    /// picks among random models (a campfire passes its slot plus its
    /// position's hash). `owner_yaw` makes the block entity the item's
    /// owner (`ItemOwner`), at the block's centre and turned that many
    /// degrees (`getVisualRotationYInDegrees`), as a shelf is: a compass on
    /// it points to its target from there. None draws it with no owner, as
    /// a campfire does. False for an empty stack or one with no model. The
    /// client's copy of a block entity has no item slots (`entity.items` is
    /// empty there): send the stacks you draw in
    /// `native_block_entity_update_tag` and read them from `entity.nbt`.
    /// API 91.
    pub(super) fn native_draw_item(
        &self,
        draw: &mut BlockEntityDraw,
        stack: &ItemStack,
        display: DisplayContext,
        owner_yaw: Option<f32>,
        seed: i32,
    ) -> bool {
        // ShelfBlockEntity.position(): Vec3.atCenterOf(getBlockPos()).
        let owner = owner_yaw
            .map(|yaw| super::item_draw::owner_at(draw.block.map(|c| f64::from(c) + 0.5), yaw, ""));
        let item = self.resolve_item(stack, display, owner.as_ref(), seed);
        if item.is_empty() {
            return false;
        }
        let pose = draw.pose();
        self.submit_item_world(&item, pose, draw.light, &mut draw.vertices);
        true
    }

    /// Property `key` of block state `state` (a machine's `facing`, from the
    /// `state` `native_block_entity_submit` gets), if it has one: no lookup in
    /// the world, so cheap each frame. API 91.
    pub(super) fn native_block_state_property(
        &self,
        state: BlockStateId,
        key: &str,
    ) -> Option<&str> {
        self.pack
            .assets
            .registry
            .state(state)?
            .properties
            .get(key)
            .map(String::as_str)
    }
    /// The block `state` is a state of: its name, as `GameLevel`'s helper of
    /// the same name gives it for the hooks that get a state in the world.
    pub(super) fn native_state_block(&self, state: BlockStateId) -> Option<&str> {
        self.pack.assets.registry.state(state).map(|s| &*s.name)
    }
}

/// `ModelPart.render`: `part`'s faces under its own pose
/// (`translateAndRotate`), then its children under theirs.
fn draw_model_part(draw: &mut BlockEntityDraw, part: &ModelPart, sprite: Rect, tint: u32) {
    if !part.visible || (part.is_empty() && part.children().next().is_none()) {
        return;
    }
    draw.push();
    draw.apply(part_transform(part));
    if !part.skip_draw {
        for polygon in &part.polygons {
            let corners = polygon.vertices.map(|v| v.pos.map(|c| c / 16.0));
            let uv = polygon.vertices.map(|v| [v.u, v.v]);
            draw.quad(corners, uv, sprite, tint);
        }
    }
    for (_, child) in part.children() {
        draw_model_part(draw, child, sprite, tint);
    }
    draw.pop();
}

/// `ModelPart.translateAndRotate`: to the part's place in blocks, turned
/// about z, then y, then x (`rotationZYX`), then scaled.
fn part_transform(part: &ModelPart) -> Mat4 {
    let mut m = Mat4::from_translation(Vec3::new(part.x, part.y, part.z) / 16.0);
    if part.x_rot != 0.0 || part.y_rot != 0.0 || part.z_rot != 0.0 {
        m *= Mat4::from_quat(Quat::from_euler(
            glam::EulerRot::ZYX,
            part.z_rot,
            part.y_rot,
            part.x_rot,
        ));
    }
    if part.x_scale != 1.0 || part.y_scale != 1.0 || part.z_scale != 1.0 {
        m *= Mat4::from_scale(Vec3::new(part.x_scale, part.y_scale, part.z_scale));
    }
    m
}

#[cfg(test)]
mod tests {
    use super::*;
    use horizon_client::containers::{ModBlockEntity, ModBlockEntityFields};

    fn draw() -> BlockEntityDraw {
        BlockEntityDraw {
            partial: 0.0,
            game_time: 0,
            light: 0xF0F0,
            block: [0; 3],
            poses: vec![Mat4::from_translation(Vec3::new(10.0, 0.0, 0.0))],
            lights: diffuse_lights(false),
            vertices: Vec::new(),
            kept: false,
            spins: Vec::new(),
        }
    }

    fn sprite() -> Rect {
        Rect {
            u0: 0.5,
            v0: 0.25,
            u1: 0.75,
            v1: 0.5,
            w: 16,
            h: 16,
        }
    }

    #[test]
    fn the_pose_stack_turns_about_its_pivot_and_pops_back() {
        let mut d = draw();
        d.push();
        d.rotate_about([0.0, 1.0, 0.0], 90.0, [0.5, 0.5, 0.5]);
        // (1, 0, 0.5) turns a quarter about the block's centre to (0.5, 0, 0).
        let p = d.pose().transform_point3(Vec3::new(1.0, 0.0, 0.5));
        assert!(p.abs_diff_eq(Vec3::new(10.5, 0.0, 0.0), 1e-5), "{p}");
        d.pop();
        d.pop();
        // Popping past the block's own pose keeps it.
        let p = d.pose().transform_point3(Vec3::ZERO);
        assert_eq!(p, Vec3::new(10.0, 0.0, 0.0));
        d.translate([0.0, 2.0, 0.0]);
        d.scale([2.0, 2.0, 2.0]);
        let p = d.pose().transform_point3(Vec3::ONE);
        assert_eq!(p, Vec3::new(12.0, 4.0, 2.0));
    }

    /// An arm a block east of the frame's origin, turned a quarter about z,
    /// with a hand a block below its pivot: `translateAndRotate` turns each
    /// part about its own pivot, then moves it, and a child goes with its
    /// parent. Expected corners are worked out by hand from JOML's
    /// `rotationZYX` (a right-handed quarter turn takes +x to +y).
    #[test]
    fn a_model_part_draws_turned_about_its_pivot_and_carries_its_children() {
        use horizon_client::mobs::model_layers::{
            CubeListBuilder, LayerDefinition, MeshDefinition, PartPose,
        };
        use horizon_core::geometry::Direction as Face;
        let mut mesh = MeshDefinition::new();
        let root = mesh.root();
        let cube = |face| CubeListBuilder::create().add_box_faces([0.0; 3], [16.0; 3], &[face]);
        let arm = mesh.add_or_replace_child(
            root,
            "arm",
            cube(Face::South),
            PartPose::offset_and_rotation(16.0, 0.0, 0.0, 0.0, 0.0, std::f32::consts::FRAC_PI_2),
        );
        mesh.add_or_replace_child(
            arm,
            "hand",
            cube(Face::North),
            PartPose::offset(0.0, 16.0, 0.0),
        );
        let mut model = LayerDefinition::create(mesh, 64, 64).bake_root();
        let drawn = |model: &ModelPart| {
            let mut d = draw();
            draw_model_part(&mut d, model, sprite(), 0xFF_FFFF);
            d.into_vertices()
        };
        let near = |v: &Vertex, at: [f32; 3]| {
            assert!(
                Vec3::from(v.pos).abs_diff_eq(Vec3::from(at), 1e-5),
                "{:?} not {at:?}",
                v.pos
            );
        };

        let all = drawn(&model);
        assert_eq!(all.len(), 8);
        // The arm's south face, (0, 0, 1) (1, 0, 1) (1, 1, 1) (0, 1, 1) in
        // its frame, turned and moved a block east, then the frame's 10.
        for (v, at) in all.iter().zip([
            [11.0, 0.0, 1.0],
            [11.0, 1.0, 1.0],
            [10.0, 1.0, 1.0],
            [10.0, 0.0, 1.0],
        ]) {
            near(v, at);
        }
        // Its net's last strip, 48 to 64 across and 16 to 32 down, in the sprite.
        assert_eq!(all[0].uv, [0.75, 0.3125]);
        // The hand's north face starts at its (1, 0, 0), the arm's (1, 1, 0).
        near(&all[4], [10.0, 1.0, 0.0]);
        near(&all[5], [10.0, 0.0, 0.0]);

        let arm = model.get_child_mut("arm").unwrap();
        arm.skip_draw = true;
        let hand_only = drawn(&model);
        assert_eq!(hand_only.len(), 4);
        near(&hand_only[0], [10.0, 1.0, 0.0]);
        model.get_child_mut("arm").unwrap().visible = false;
        assert!(drawn(&model).is_empty());
    }

    #[test]
    fn a_quad_lands_in_its_sprite_lit_and_shaded() {
        let mut d = draw();
        // An upward face: full brightness under vanilla's level lights is
        // below 1 (two lights), so the colour is shaded but opaque.
        d.quad(
            [
                [0.0, 1.0, 0.0],
                [0.0, 1.0, 1.0],
                [1.0, 1.0, 1.0],
                [1.0, 1.0, 0.0],
            ],
            [[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]],
            sprite(),
            0xFFFFFF,
        );
        assert_eq!(d.vertices.len(), 4);
        let v = d.vertices[2];
        assert_eq!(v.pos, [11.0, 1.0, 1.0]);
        assert_eq!(v.uv, [0.75, 0.5]);
        assert_eq!(v.light, 0xF0F0);
        let up = diffuse(Vec3::Y, diffuse_lights(false));
        assert_eq!(v.color, shaded(0xFFFFFF, up));
        assert_eq!(v.color >> 24, 0xFF);
    }

    /// A frustum that sees nothing.
    struct Blind;
    impl Cull for Blind {
        fn intersects(&self, _: Vec3, _: Vec3) -> bool {
            false
        }
        fn contains(&self, _: Vec3, _: Vec3) -> bool {
            false
        }
    }

    #[test]
    fn infinite_bounds_and_frames_without_a_frustum_are_never_culled() {
        let origin = Vec3::new(1.0e6, 0.0, 0.0);
        let infinite = [f32::NEG_INFINITY, 0.0, 0.0, f32::INFINITY, 1.0, 1.0];
        assert!(!in_frustum(Some(&Blind), origin, DEFAULT_BOUNDS));
        assert!(in_frustum(Some(&Blind), origin, infinite));
        assert!(in_frustum(None::<&Blind>, origin, DEFAULT_BOUNDS));
    }

    #[test]
    fn a_tint_keeps_its_channels_in_vertex_order() {
        // The vertex colour is RGBA8 read little-endian: red in the low byte.
        assert_eq!(shaded(0x10_20_30, 1.0), 0xFF_30_20_10);
    }

    fn machine() -> ModRevision {
        ModBlockEntity::new(ModBlockEntityFields {
            id: "mymod:machine".into(),
            ..Default::default()
        })
        .revision()
    }

    fn vertex(x: f32) -> Vertex {
        Vertex {
            pos: [x, 0.0, 0.0],
            ..bytemuck::Zeroable::zeroed()
        }
    }

    const KEY: KeptKey = KeptKey {
        dim: Dim::Overworld,
        state: 7,
        light: 0xF0F0,
        glyphs: 0,
    };

    /// A part drawn after `spin` turns about its pivot by the game time and
    /// partial tick (90 degrees a tick about +y takes +x to -z, by the right
    /// hand), its normal with it; what is drawn after `still` and before the
    /// spin stays; all of it is moved by the origin.
    #[test]
    fn a_spinning_part_turns_with_the_game_time_and_the_rest_stays() {
        let mut draw = draw();
        let at = |x: f32, y: f32, z: f32, normal: [i8; 4]| Vertex {
            pos: [x, y, z],
            normal,
            ..bytemuck::Zeroable::zeroed()
        };
        draw.vertices.push(at(1.0, 0.5, 0.5, [0; 4]));
        draw.spin([0.0, 1.0, 0.0], [0.5, 0.5, 0.5], 90.0, 0.0);
        draw.vertices.push(at(1.0, 0.5, 0.5, [127, 0, 0, 127]));
        draw.still();
        draw.vertices.push(at(0.0, 0.0, 0.0, [0; 4]));
        let origin = Vec3::new(10.0, 0.0, 0.0);
        let close = |a: [f32; 3], b: [f32; 3]| a.iter().zip(b).all(|(a, b)| (a - b).abs() < 1e-4);
        // A tick and a half: 135 degrees.
        let mut out = Vec::new();
        place_turning(&draw.vertices, &draw.spins, 1, 0.5, origin, &mut out);
        assert!(close(out[0].pos, [11.0, 0.5, 0.5]), "{:?}", out[0].pos);
        let h = 0.5 * std::f32::consts::FRAC_1_SQRT_2;
        assert!(
            close(out[1].pos, [10.5 - h, 0.5, 0.5 - h]),
            "{:?}",
            out[1].pos
        );
        assert!(close(out[2].pos, [10.0, 0.0, 0.0]), "{:?}", out[2].pos);
        // One tick: a quarter turn, +x to -z, the normal along.
        out.clear();
        place_turning(&draw.vertices, &draw.spins, 1, 0.0, origin, &mut out);
        assert!(close(out[1].pos, [10.5, 0.5, 0.0]), "{:?}", out[1].pos);
        assert_eq!(out[1].normal, [0, 0, -127, 127]);
        // Four ticks: all the way round, and a world's late game time is no
        // less exact.
        out.clear();
        place_turning(
            &draw.vertices,
            &draw.spins,
            4_000_000_000,
            0.0,
            origin,
            &mut out,
        );
        assert!(close(out[1].pos, [11.0, 0.5, 0.5]), "{:?}", out[1].pos);
    }

    #[test]
    fn kept_geometry_is_drawn_again_until_what_it_was_drawn_with_changes() {
        let mut kept = KeptGeometry::default();
        let pos = [1, 2, 3];
        let mut entity = ModBlockEntity::new(ModBlockEntityFields {
            id: "mymod:machine".into(),
            data: vec![0],
            ..Default::default()
        });
        let drawn = entity.revision();
        kept.keep(
            pos,
            KEY,
            drawn,
            DEFAULT_BOUNDS,
            &[vertex(0.5)],
            Vec::new(),
            0,
        );
        let entry = kept.get(pos, KEY, entity.revision(), 1).expect("kept");
        assert_eq!(entry.vertices.len(), 1);
        assert_eq!(entry.vertices[0].pos, [0.5, 0.0, 0.0]);
        assert_eq!(entry.bounds, DEFAULT_BOUNDS);
        // New data from the server, another state, light or dimension, or
        // another position: none of them is the kept geometry.
        entity.data[0] = 1;
        assert!(kept.get(pos, KEY, entity.revision(), 1).is_none());
        for changed in [
            KeptKey { state: 8, ..KEY },
            KeptKey {
                light: 0x00F0,
                ..KEY
            },
            KeptKey {
                dim: Dim::Nether,
                ..KEY
            },
            KeptKey { glyphs: 1, ..KEY },
        ] {
            assert!(kept.get(pos, changed, drawn, 1).is_none());
        }
        assert!(kept.get([1, 2, 4], KEY, drawn, 1).is_none());
        // Another block entity in its place, as the old one was: not it.
        let replaced = ModBlockEntity::new(ModBlockEntityFields {
            id: "mymod:machine".into(),
            data: vec![0],
            ..Default::default()
        });
        assert!(kept.get(pos, KEY, replaced.revision(), 1).is_none());
        // Drawn again and kept with the new data, it replaces the old.
        kept.keep(
            pos,
            KEY,
            entity.revision(),
            DEFAULT_BOUNDS,
            &[vertex(0.25)],
            Vec::new(),
            2,
        );
        assert!(kept.get(pos, KEY, drawn, 2).is_none());
        let entry = kept
            .get(pos, KEY, entity.revision(), 2)
            .expect("kept again");
        assert_eq!(entry.vertices[0].pos, [0.25, 0.0, 0.0]);
        // Drawn without keeping: forgotten.
        kept.forget(pos);
        assert!(kept.get(pos, KEY, entity.revision(), 3).is_none());
    }

    #[test]
    fn kept_geometry_out_of_view_for_its_ticks_is_swept() {
        let mut kept = KeptGeometry::default();
        let (seen, gone) = ([0, 0, 0], [5, 0, 0]);
        let m = machine();
        kept.keep(seen, KEY, m, DEFAULT_BOUNDS, &[vertex(0.0)], Vec::new(), 0);
        kept.keep(gone, KEY, m, DEFAULT_BOUNDS, &[vertex(0.0)], Vec::new(), 0);
        kept.get(gone, KEY, m, 50);
        // A sweep at 100 keeps both: each was drawn in the last 100 ticks.
        kept.sweep(100);
        assert!(kept.entries.contains_key(&gone));
        assert!(kept.entries.contains_key(&seen));
        kept.get(seen, KEY, m, 150);
        // At 199 no sweep is due yet; at 200 the one last drawn at 50 goes.
        kept.sweep(199);
        assert!(kept.entries.contains_key(&gone));
        kept.sweep(200);
        assert!(!kept.entries.contains_key(&gone));
        assert!(kept.get(seen, KEY, m, 200).is_some());
    }
}
