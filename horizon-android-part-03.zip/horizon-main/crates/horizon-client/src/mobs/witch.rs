//! Witches (potion drinking and splash potion attacks) and the shared
//! `RangedAttackGoal` (also used by snow golems).
use super::{
    Mob, MobEvent, Species, Who,
    anim::{Poses, State},
    goals::{
        Cx, Float, Goal, HurtByTarget, LOOK, LookAtPlayer, MOVE, NearestTarget, RandomLookAround,
        Stroll, goal_clone,
    },
};
use crate::projectiles::{Projectile, ProjectileKind};
use horizon_core::geometry::trig::Mth;
use horizon_core::{geometry::Vec3, random::RandomSource};

pub fn register(m: &mut Mob) {
    let g = &mut m.ai.goals;
    g.add(1, Float);
    g.add(2, RangedAttack::new(1.0, 60, 60, 10.0, witch_attack));
    g.add(2, Stroll::avoiding_water(1.0));
    g.add(3, LookAtPlayer::new(8.0));
    g.add(3, RandomLookAround::default());
    // HurtByTargetGoal(this, Raider.class): a witch ignores the raider that
    // hit it, so raid friendly fire never turns the raid on itself.
    m.ai.targets.add(1, hurt_by());
    m.ai.targets.add(2, HealRaiders::default());
    // NearestAttackableWitchTargetGoal: only while not healing raiders.
    m.ai.targets.add(
        3,
        NearestTarget::player(true)
            .interval(10)
            .gate(|m, _| m.extra.counter2 <= 0)
            .named("NearestAttackableWitchTargetGoal"),
    );
}
/// `Witch.registerGoals`' `HurtByTargetGoal(this, Raider.class)`.
fn hurt_by() -> HurtByTarget {
    HurtByTarget::new().ignoring(&super::raider::RAIDERS)
}
/// `NearestHealableRaiderTargetGoal`: in a raid, target another raider to
/// heal, then wait 10 seconds (the cooldown lives in `extra.counter2`).
#[derive(Clone, Debug)]
struct HealRaiders(NearestTarget);
impl Default for HealRaiders {
    fn default() -> Self {
        Self(
            NearestTarget::new(
                super::goals::Prey::Filter(|s| {
                    super::raider::is_raider(s.species) && s.species != Species::Witch
                }),
                true,
            )
            .interval(0),
        )
    }
}
impl Goal for HealRaiders {
    goal_clone!();
    fn flags(&self) -> u8 {
        self.0.flags()
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        if m.extra.counter2 > 0 || !m.random.next_boolean() {
            return false;
        }
        if !super::raider::has_active_raid(m) {
            return false;
        }
        self.0.can_use(m, cx)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.0.can_continue(m, cx)
    }
    fn start(&mut self, m: &mut Mob, cx: &mut Cx) {
        m.extra.counter2 = super::goals::reduced(200);
        self.0.start(m, cx);
    }
    fn stop(&mut self, m: &mut Mob, cx: &mut Cx) {
        self.0.stop(m, cx);
    }
}
/// The callback a ranged mob uses to fire (`RangedAttackMob.performRangedAttack`).
pub type Fire = fn(&mut Mob, Who, f32, &mut Cx);

/// RangedAttackGoal(speed, intervalMin, intervalMax, radius).
#[derive(Clone, Debug)]
pub struct RangedAttack {
    speed: f64,
    min: i32,
    max: i32,
    radius: f32,
    fire: Fire,
    attack_time: i32,
    see_time: i32,
}
impl RangedAttack {
    pub fn new(speed: f64, min: i32, max: i32, radius: f32, fire: Fire) -> Self {
        Self {
            speed,
            min,
            max,
            radius,
            fire,
            attack_time: -1,
            see_time: 0,
        }
    }
}
impl Goal for RangedAttack {
    goal_clone!();
    fn flags(&self) -> u8 {
        MOVE | LOOK
    }
    fn can_use(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        m.target_info(cx.w).is_some_and(|t| t.alive)
    }
    fn can_continue(&mut self, m: &mut Mob, cx: &mut Cx) -> bool {
        self.can_use(m, cx) || m.target_info(cx.w).is_some_and(|t| t.alive) && !m.ai.nav.is_done()
    }
    fn stop(&mut self, _: &mut Mob, _: &mut Cx) {
        self.see_time = 0;
        self.attack_time = -1;
    }
    fn every_tick(&self) -> bool {
        true
    }
    fn tick(&mut self, m: &mut Mob, cx: &mut Cx) {
        let Some(who) = m.ai.target else { return };
        let Some(t) = cx.w.target_info(who) else {
            return;
        };
        let d2 = m.distance_sqr(t.position);
        let sees = m.sees(cx.w, who);
        if sees {
            self.see_time += 1;
        } else {
            self.see_time = 0;
        }
        if d2 <= f64::from(self.radius * self.radius) && self.see_time >= 5 {
            m.nav_stop();
        } else {
            m.nav_move_to_entity(
                cx.w,
                [t.position.x, t.position.y, t.position.z],
                1,
                self.speed,
            );
        }
        m.look_at_speed([t.position.x, t.eye_y, t.position.z], 30.0, 30.0);
        self.attack_time -= 1;
        if self.attack_time == 0 {
            if !sees {
                return;
            }
            let dist = (d2.sqrt() as f32) / self.radius;
            let power = dist.clamp(0.1, 1.0);
            (self.fire)(m, who, power, cx);
            self.attack_time =
                (dist * (self.max - self.min) as f32 + self.min as f32).floor() as i32;
        } else if self.attack_time < 0 {
            let f = d2.sqrt() / f64::from(self.radius);
            self.attack_time =
                (f64::from(self.min) + f * f64::from(self.max - self.min)).floor() as i32;
        }
    }
}
/// Witch.performRangedAttack: harming by default, slowness at range, poison
/// on healthy targets, weakness up close.
fn witch_attack(m: &mut Mob, who: Who, _power: f32, cx: &mut Cx) {
    // isDrinkingPotion
    if m.extra.flag {
        return;
    }
    let Some(t) = cx.w.target_info(who) else {
        return;
    };
    let motion = match who {
        Who::Player => cx.w.player.as_ref().map_or(Vec3::ZERO, |p| p.velocity),
        Who::Mob(id) => cx.w.seen(id).map_or(Vec3::ZERO, |s| s.velocity),
    };
    let xd = t.position.x + motion.x - m.position.x;
    let yd = t.eye_y - f64::from(1.1_f32) - m.position.y;
    let zd = t.position.z + motion.z - m.position.z;
    let dist = (xd * xd + zd * zd).sqrt();
    let health = if t.is_player {
        20.0
    } else {
        cx.w.seen(match who {
            Who::Mob(id) => id,
            Who::Player => 0,
        })
        .map_or(20.0, |s| s.health)
    };
    // A raider target is healed instead: Healing when nearly dead, else
    // Regeneration, and the witch drops the target afterwards.
    let heals = match who {
        Who::Mob(id) => {
            cx.w.seen(id)
                .is_some_and(|s| super::raider::is_raider(s.species))
        }
        Who::Player => false,
    };
    // `target.hasEffect`: a target that already has the effect gets the next one.
    let has = |effect: &str| match who {
        Who::Player => cx.w.player.as_ref().is_some_and(|p| p.has_effect(effect)),
        Who::Mob(id) => cx.w.seen(id).is_some_and(|s| s.has_effect(effect)),
    };
    // The potion it throws: `PotionContents.createItemStack(Items.SPLASH_POTION,
    // potion)` for the one `Witch.performRangedAttack` picks.
    let potion = if heals {
        m.ai.target = None;
        if health <= 4.0 {
            "minecraft:healing"
        } else {
            "minecraft:regeneration"
        }
    } else if dist >= 8.0 && !has("slowness") {
        "minecraft:slowness"
    } else if health >= 8.0 && !has("poison") {
        "minecraft:poison"
    } else if dist <= 3.0 && !has("weakness") && m.random.next_float() < 0.25 {
        "minecraft:weakness"
    } else {
        "minecraft:harming"
    };
    let start = Vec3::new(m.position.x, m.eye_y() - 0.1, m.position.z);
    let mut p = Projectile::new(
        ProjectileKind::potion(
            crate::items::ItemStack::new("minecraft:splash_potion", 1).with_potion(potion),
        ),
        start,
        Some(Who::Mob(m.id)),
    );
    // Splash potions throw with gravity 0.05.
    p.shoot(
        &mut crate::projectiles::own_random(m),
        [xd, yd + dist * 0.2, zd],
        if dist <= 2.0 { 0.45 } else { 0.75 },
        8.0,
    );
    cx.events.push(MobEvent::Projectile(p));
    // Witch.performRangedAttack: the throw sound, and its pitch draw, only
    // when the witch is not silent.
    witch_sound(m, cx.events, "entity.witch.throw");
}
/// The movement speed of a witch with `SPEED_MODIFIER_DRINKING` (-0.25,
/// `ADD_VALUE`) while it drinks: it stands still for the 32 ticks.
pub fn speed(m: &Mob, base: f64) -> f64 {
    if m.species() == Species::Witch && m.extra.flag {
        (base - 0.25).max(0.0)
    } else {
        base
    }
}
/// Witch.aiStep before `super.aiStep()`: the healing cooldown, then drink
/// water breathing, fire resistance, healing or swiftness.
pub fn ai_step(m: &mut Mob, cx_events: &mut Vec<MobEvent>, target_far: bool) {
    if !m.alive() {
        return;
    }
    // healRaidersGoal.decrementCooldown (the attack goal's canAttack reads it).
    m.extra.counter2 -= 1;
    drink(m, cx_events, target_far);
    // `broadcastEntityEvent(this, 15)`: the magic puffs over its hat on every client.
    if m.random.next_float() < 7.5E-4 {
        cx_events.push(MobEvent::EntityEvent {
            mob: m.id,
            event: 15,
            at: [m.position.x, m.position.y, m.position.z],
        });
    }
}
fn drink(m: &mut Mob, cx_events: &mut Vec<MobEvent>, target_far: bool) {
    if m.extra.flag {
        // `usingTime-- <= 0`
        m.extra.using_item -= 1;
        if m.extra.using_item < 0 {
            m.extra.using_item = 0;
            if let Some(potion) = m.extra.take_main_hand() {
                match potion.as_ref() {
                    "minecraft:water_breathing" => {
                        m.add_effect("minecraft:water_breathing", 3600, 0)
                    }
                    "minecraft:fire_resistance" => {
                        m.add_effect("minecraft:fire_resistance", 3600, 0)
                    }
                    "minecraft:healing" => m.heal(4.0),
                    "minecraft:swiftness" => m.add_effect("minecraft:speed", 3600, 0),
                    _ => {}
                }
            }
            m.extra.flag = false;
        }
        return;
    }
    let potion = if m.random.next_float() < 0.15
        && m.fluids.eye_in_water
        && !m.has_effect("minecraft:water_breathing")
    {
        Some("minecraft:water_breathing")
    } else if m.random.next_float() < 0.15
        && (m.fire_ticks > 0 || m.last_damage.is_some_and(|(d, _)| d.is_fire()))
        && !m.has_effect("minecraft:fire_resistance")
    {
        Some("minecraft:fire_resistance")
    } else if m.random.next_float() < 0.05 && m.health < m.attrs.max_health {
        Some("minecraft:healing")
    } else if m.random.next_float() < 0.5
        && m.ai.target.is_some()
        && !m.has_effect("minecraft:speed")
        && target_far
    {
        Some("minecraft:swiftness")
    } else {
        None
    };
    if let Some(p) = potion {
        m.extra.set_main_hand(Some(p.into()));
        // PotionItem use duration 32 ticks.
        m.extra.using_item = 32;
        m.extra.flag = true;
        // Witch.aiStep: the drink sound, and its pitch draw, only when the
        // witch is not silent.
        witch_sound(m, cx_events, "entity.witch.drink");
    }
}
/// `Witch` drink and throw sounds: volume 1, pitch `0.8 + nextFloat * 0.4`,
/// skipped entirely (including the pitch draw) when `isSilent()`.
fn witch_sound(m: &mut Mob, events: &mut Vec<MobEvent>, name: &'static str) {
    if m.silent {
        return;
    }
    let pitch = 0.8 + m.random.next_float() * 0.4;
    events.push(MobEvent::Sound(name, m.center(), 1.0, pitch));
}
/// `WitchRenderer.extractRenderState`'s `isHoldingPotion`: the main hand holds
/// a potion, either a drunk one (kept by the potion's name, `drink`) or a
/// plain potion item.
pub fn holds_potion(item: &str) -> bool {
    matches!(
        item,
        "minecraft:potion"
            | "minecraft:water_breathing"
            | "minecraft:fire_resistance"
            | "minecraft:healing"
            | "minecraft:swiftness"
    )
}
/// WitchModel.setupAnim (VillagerModel base with a wobbling nose).
pub fn anim(m: &Mob, s: &State, p: &mut Poses) {
    p.yrot("head", s.y_rot.to_radians());
    p.xrot("head", s.x_rot.to_radians());
    p.xrot("right_leg", (s.pos * 0.6662).mcos() * 1.4 * s.speed * 0.5);
    p.xrot(
        "left_leg",
        (s.pos * 0.6662 + std::f32::consts::PI).mcos() * 1.4 * s.speed * 0.5,
    );
    let speed = 0.01 * (m.id % 10) as f32;
    let deg = horizon_core::geometry::trig::DEG_TO_RAD;
    p.xrot("nose", (s.age * speed).msin() * 4.5 * deg);
    p.zrot("nose", (s.age * speed).mcos() * 2.5 * deg);
    if m.extra.main_hand.is_some() {
        let n = p.get("nose");
        n[0] = 0.0;
        n[1] = 1.0;
        n[2] = -1.5;
        n[3] = -0.9;
    }
    let _ = Species::Witch;
}

#[cfg(test)]
mod tests {
    use super::*;

    /// `Witch.registerGoals` passes `Raider.class` to `HurtByTargetGoal`, so a
    /// raider that hits a witch is not taken as its target. The list is the
    /// `Raider` class and nothing else: a vex is not a raider.
    #[test]
    fn a_witch_ignores_the_raider_that_hit_it() {
        let goal = hurt_by();
        assert_eq!(
            goal.ignore,
            vec![
                Species::Pillager,
                Species::Vindicator,
                Species::Evoker,
                Species::Illusioner,
                Species::Witch,
                Species::Ravager,
            ]
        );
        assert!(!goal.ignore.contains(&Species::Vex));
        assert!(!goal.ignore.contains(&Species::Zombie));
    }

    fn witch() -> Mob {
        use std::sync::Arc;
        let mut kind = (*crate::mobs::sensor_scan_tests::kind()).clone();
        kind.id = "minecraft:witch".into();
        kind.species = Species::Witch;
        kind.max_health = 26.0;
        Mob::new(1, Arc::new(kind), Vec3::ZERO, 0.0)
    }

    /// How many drink sounds forty attempts produce. Vanilla plays
    /// `entity.witch.drink` at volume 1, and skips it when the witch is silent.
    fn drink_sounds(silent: bool) -> usize {
        use horizon_core::random::LegacyRandom;
        let mut m = witch();
        m.silent = silent;
        m.random = LegacyRandom::new(1);
        m.fluids.eye_in_water = true;
        m.fire_ticks = 20;
        m.health = 1.0;
        m.ai.target = Some(Who::Player);
        let mut events = Vec::new();
        for _ in 0..40 {
            m.extra.flag = false;
            drink(&mut m, &mut events, true);
        }
        events
            .iter()
            .filter(|e| {
                matches!(e, MobEvent::Sound(s, _, volume, _) if *s == "entity.witch.drink" && *volume == 1.0)
            })
            .count()
    }

    /// `Witch.aiStep` and `performRangedAttack` play at volume 1 only when
    /// the witch is not silent. The pitch draw stays inside that check.
    #[test]
    fn a_silent_witch_does_not_play_its_drink_or_throw_sound() {
        use horizon_core::random::LegacyRandom;
        assert!(drink_sounds(false) > 0);
        assert_eq!(drink_sounds(true), 0);

        let mut loud = witch();
        loud.random = LegacyRandom::new(11);
        let mut quiet = witch();
        quiet.silent = true;
        quiet.random = LegacyRandom::new(11);
        let mut oracle = LegacyRandom::new(11);
        // Vanilla: 0.8F + nextFloat() * 0.4F, volume 1.
        let pitch = 0.8 + oracle.next_float() * 0.4;
        let mut events = Vec::new();
        witch_sound(&mut loud, &mut events, "entity.witch.throw");
        match &events[0] {
            MobEvent::Sound(name, _, volume, got) => {
                assert_eq!(*name, "entity.witch.throw");
                assert_eq!(*volume, 1.0);
                assert!((got - pitch).abs() < 1.0e-5);
            }
            other => panic!("throw sound, got {other:?}"),
        }
        events.clear();
        witch_sound(&mut quiet, &mut events, "entity.witch.throw");
        assert!(events.is_empty());
        let mut untouched = LegacyRandom::new(11);
        assert_eq!(quiet.random.next_float(), untouched.next_float());
    }

    /// The hoisted list is exactly the set `is_raider` answers yes for.
    #[test]
    fn the_raider_list_is_the_raider_class() {
        for def in crate::mobs::species::ALL {
            assert_eq!(
                crate::mobs::raider::is_raider(def.species),
                super::super::raider::RAIDERS.contains(&def.species),
                "{:?}",
                def.species
            );
        }
    }
}
